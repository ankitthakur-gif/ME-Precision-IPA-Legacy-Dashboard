import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { initializeFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyAV1w5pP3OPEuH_wslQZj4ZpjrTTyRa0Uc",
  authDomain: "gen-lang-client-0680807453.firebaseapp.com",
  projectId: "gen-lang-client-0680807453",
  storageBucket: "gen-lang-client-0680807453.firebasestorage.app",
  messagingSenderId: "527752926991",
  appId: "1:527752926991:web:adfedbf5311b6a7d44107a"
};

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Initialize Firestore with settings optimized for sandboxed iframes
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
});

export default app;
