import React, { useState, useEffect } from 'react';
import { collection, getDocs, doc, setDoc, query, where, writeBatch, addDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { ExcelBackup, DatasetVersion } from '../types';

interface ExcelBackupsTabProps {
  userEmail: string;
  hasWriteAccess: boolean;
  onRefreshTrigger: () => void;
}

export default function ExcelBackupsTab({
  userEmail,
  hasWriteAccess,
  onRefreshTrigger
}: ExcelBackupsTabProps) {
  const [backups, setBackups] = useState<ExcelBackup[]>([]);
  const [deletedSheets, setDeletedSheets] = useState<DatasetVersion[]>([]);
  const [loadingBackups, setLoadingBackups] = useState(true);
  const [loadingSheets, setLoadingSheets] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Backup creation action
  const [creatingBackup, setCreatingBackup] = useState(false);
  const [backupSuccessMessage, setBackupSuccessMessage] = useState<string | null>(null);

  // Soft sheet recovery action
  const [recoveringId, setRecoveringId] = useState<string | null>(null);

  const fetchBackupsAndArchive = async () => {
    setLoadingBackups(true);
    setLoadingSheets(true);
    setError(null);
    try {
      // 1. Fetch system backups
      const bSnap = await getDocs(collection(db, 'excel_backups'));
      const bList: ExcelBackup[] = [];
      bSnap.forEach(doc => {
        bList.push(doc.data() as ExcelBackup);
      });
      bList.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setBackups(bList);
      setLoadingBackups(false);

      // 2. Fetch soft-deleted datasets for restoration
      const dSnap = await query(
        collection(db, 'excel_datasets'),
        where('status', '==', 'DELETED')
      );
      const dDocs = await getDocs(dSnap);
      const dList: DatasetVersion[] = [];
      dDocs.forEach(doc => {
        dList.push(doc.data() as DatasetVersion);
      });
      dList.sort((a, b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime());
      setDeletedSheets(dList);
      setLoadingSheets(false);
    } catch (err: any) {
      console.error("Error reading backups data:", err);
      setError(`Database Query Error: ${err.message || 'Permission denied.'}`);
      setLoadingBackups(false);
      setLoadingSheets(false);
    }
  };

  useEffect(() => {
    fetchBackupsAndArchive();
  }, []);

  // Trigger manual complete snapshot backup
  const handleTriggerBackup = async () => {
    if (!hasWriteAccess) return;
    setCreatingBackup(true);
    setError(null);
    setBackupSuccessMessage(null);

    try {
      // Fetch record counts dynamically from primary collections to record complete backup metadata
      const [logsSnap, analystsSnap, teamsSnap, invoicesSnap, vendorsSnap] = await Promise.all([
        getDocs(collection(db, 'logs')),
        getDocs(collection(db, 'analysts')),
        getDocs(collection(db, 'teams')),
        getDocs(collection(db, 'invoices')),
        getDocs(collection(db, 'vendors'))
      ]);

      const backupId = 'backup-' + Date.now();
      const backupDoc: ExcelBackup = {
        id: backupId,
        createdAt: new Date().toISOString(),
        createdBy: userEmail,
        type: 'MANUAL',
        description: 'Manual complete system metadata snapshot',
        recordCounts: {
          logs: logsSnap.size,
          analysts: analystsSnap.size,
          teams: teamsSnap.size,
          invoices: invoicesSnap.size,
          vendors: vendorsSnap.size,
          users: 0 // placeholder
        },
        status: 'SUCCESS'
      };

      await setDoc(doc(db, 'excel_backups', backupId), backupDoc);
      
      setBackupSuccessMessage(`Snapshot backup "${backupId}" successfully created in Firestore!`);
      fetchBackupsAndArchive();
    } catch (err: any) {
      console.error("Backup creation failed:", err);
      setError(`Backup Creation Error: ${err.message}`);
    } finally {
      setCreatingBackup(false);
    }
  };

  // Recover soft-deleted dataset from Archive
  const handleRecoverSheet = async (version: DatasetVersion) => {
    if (!hasWriteAccess) return;
    setRecoveringId(version.id);
    setError(null);

    try {
      const docRef = doc(db, 'excel_datasets', version.id);
      await writeBatch(db).update(docRef, { status: 'ARCHIVED' }).commit();

      // Log recovery audit log
      await addDoc(collection(db, 'excel_audit_logs'), {
        id: 'audit-' + Date.now(),
        datasetId: version.id,
        collection: version.targetCollection,
        recordId: 'archive-recovery',
        editedBy: userEmail,
        editedAt: new Date().toISOString(),
        changes: [{ field: 'status', oldValue: 'DELETED', newValue: 'ARCHIVED' }]
      });

      setBackupSuccessMessage(`Spreadsheet "${version.fileName}" successfully recovered from archive!`);
      onRefreshTrigger();
      fetchBackupsAndArchive();
    } catch (err: any) {
      console.error("Failed to recover sheet:", err);
      setError(`Recovery Error: ${err.message}`);
    } finally {
      setRecoveringId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* HEADER DESCRIPTION */}
      <div className="bg-white dark:bg-[#121620] border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-6 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h3 className="text-sm font-black text-slate-950 dark:text-white tracking-tight">
            Database Backup & Recovery Center
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Create system backups manually, view automated daily cron status logs, and recover soft-deleted spreadsheets safely from the secure archive.
          </p>
        </div>

        {hasWriteAccess && (
          <button
            onClick={handleTriggerBackup}
            disabled={creatingBackup}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black flex items-center gap-1.5 transition-all shadow-sm cursor-pointer disabled:opacity-40"
          >
            <span className="material-symbols-outlined text-sm">{creatingBackup ? 'refresh' : 'backup'}</span>
            {creatingBackup ? 'Saving Snapshot...' : 'Trigger Manual Backup'}
          </button>
        )}
      </div>

      {backupSuccessMessage && (
        <div className="p-3.5 bg-green-500/10 border border-green-500/20 text-green-700 rounded-xl text-xs font-bold flex items-center gap-2">
          <span className="material-symbols-outlined">check_circle</span>
          <p>{backupSuccessMessage}</p>
        </div>
      )}

      {error && (
        <div className="p-3.5 bg-red-500/10 border border-red-500/20 text-red-600 rounded-xl text-xs font-bold flex items-center gap-2">
          <span className="material-symbols-outlined">warning</span>
          <p>{error}</p>
        </div>
      )}

      {/* TWO PANEL SECTIONS */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        
        {/* SNAPSHOT LOGS TABLE */}
        <div className="bg-white dark:bg-[#121620] border border-slate-200/60 dark:border-slate-800/60 rounded-2xl shadow-sm overflow-hidden p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-2">
              <span className="material-symbols-outlined text-primary text-base">history</span>
              Snapshot Backups ({backups.length})
            </h4>
            
            {/* cron automated label status */}
            <span className="px-2 py-0.5 bg-green-500/10 text-green-700 rounded-full font-black text-[9px] uppercase tracking-wider flex items-center gap-0.5">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
              Auto-Backups: Active
            </span>
          </div>

          {loadingBackups ? (
            <div className="py-16 text-center text-slate-400 space-y-2">
              <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="text-xs font-semibold">Reading backup history logs...</p>
            </div>
          ) : backups.length === 0 ? (
            <div className="py-16 text-center text-slate-400 space-y-1">
              <span className="material-symbols-outlined text-28">cloud_done</span>
              <p className="font-extrabold text-xs text-slate-500">No manual snapshots created yet</p>
              <p className="text-[11px] text-slate-400">Click "Trigger Manual Backup" to make an active dataset snapshot.</p>
            </div>
          ) : (
            <div className="border border-slate-200/50 rounded-xl overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50/50 border-b border-slate-200/50 text-[10px] font-black uppercase text-slate-500 tracking-wider">
                    <th className="p-3">Backup ID</th>
                    <th className="p-3">Created Date</th>
                    <th className="p-3">Type</th>
                    <th className="p-3 text-center">Active Collections</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-semibold text-slate-700">
                  {backups.map((b) => (
                    <tr key={b.id} className="hover:bg-slate-50/20">
                      <td className="p-3 font-mono font-black text-slate-800 dark:text-slate-200">
                        <p>{b.id}</p>
                        <p className="text-[9px] text-slate-400 font-bold mt-0.5 font-sans uppercase">BY {b.createdBy}</p>
                      </td>
                      <td className="p-3 text-slate-500 font-medium">{new Date(b.createdAt).toLocaleString()}</td>
                      <td className="p-3">
                        <span className={`inline-block px-1.5 py-0.5 rounded text-[8px] font-black ${
                          b.type === 'MANUAL' ? 'bg-indigo-500/10 text-indigo-700' : 'bg-emerald-500/10 text-emerald-700'
                        }`}>
                          {b.type}
                        </span>
                      </td>
                      <td className="p-3">
                        <div className="text-[9px] font-bold text-slate-500 space-y-0.5">
                          <p>/logs ({b.recordCounts.logs} records)</p>
                          <p>/analysts ({b.recordCounts.analysts} records)</p>
                          <p>/teams ({b.recordCounts.teams} records)</p>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* SOFT DELETED EXCEL RECOVERY PANEL */}
        <div className="bg-white dark:bg-[#121620] border border-slate-200/60 dark:border-slate-800/60 rounded-2xl shadow-sm overflow-hidden p-6 space-y-4">
          <h4 className="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-2">
            <span className="material-symbols-outlined text-primary text-base">restore_from_trash</span>
            Spreadsheet Recovery Pool ({deletedSheets.length})
          </h4>

          {loadingSheets ? (
            <div className="py-16 text-center text-slate-400 space-y-2">
              <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="text-xs font-semibold">Scanning archive pool...</p>
            </div>
          ) : deletedSheets.length === 0 ? (
            <div className="py-16 text-center text-slate-400 space-y-1">
              <span className="material-symbols-outlined text-28">restore</span>
              <p className="font-extrabold text-xs text-slate-500">The Recovery Archive is empty</p>
              <p className="text-[11px] text-slate-400">Archived or soft-deleted spreadsheets are temporarily held here for safety.</p>
            </div>
          ) : (
            <div className="border border-slate-200/50 rounded-xl overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50/50 border-b border-slate-200/50 text-[10px] font-black uppercase text-slate-500 tracking-wider">
                    <th className="p-3">File Name</th>
                    <th className="p-3">Target / Rows</th>
                    <th className="p-3 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-semibold text-slate-700">
                  {deletedSheets.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-50/20">
                      <td className="p-3">
                        <p className="font-extrabold text-slate-800 dark:text-slate-200 max-w-[180px] truncate">{s.fileName}</p>
                        <p className="text-[9px] text-slate-400 mt-0.5">Size: {s.fileSize} | Sync: {new Date(s.uploadDate).toLocaleDateString()}</p>
                      </td>
                      <td className="p-3">
                        <p className="text-[10px] font-bold text-primary uppercase">/{s.targetCollection}</p>
                        <p className="text-[10px] text-slate-500">{s.totalRecords} records</p>
                      </td>
                      <td className="p-3 text-center">
                        <button
                          onClick={() => handleRecoverSheet(s)}
                          disabled={!hasWriteAccess || recoveringId !== null}
                          className="px-2.5 py-1 border border-primary text-primary text-[10px] font-black rounded-lg hover:bg-primary/5 transition-all flex items-center gap-0.5 cursor-pointer disabled:opacity-40"
                          title="Restore spreadsheet back to Version History"
                        >
                          <span className="material-symbols-outlined text-xs">restore_from_trash</span>
                          Recover Version
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
