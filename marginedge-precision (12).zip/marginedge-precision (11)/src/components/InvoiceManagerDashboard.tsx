import React, { useState, useMemo } from 'react';
import { useRealtime } from '../context/RealtimeContext';
import { AMAlert, PortfolioLog } from '../types';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceDot } from 'recharts';

function sanitizeInput(text: string, limit: number = 200): string {
  if (!text) return '';
  return text
    .replace(/<[^>]*>/g, '') // strip HTML tags
    .replace(/[&<>"'/]/g, (match) => {
      const escapeMap: Record<string, string> = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#x27;',
        '/': '&#x2F;',
      };
      return escapeMap[match] || match;
    })
    .trim()
    .substring(0, limit);
}

interface InvoiceManagerDashboardProps {
  userEmail: string;
  userName?: string;
  userPosition?: string;
  onNavigate: (view: any) => void;
  onLogout: () => void;
}

export default function InvoiceManagerDashboard({ 
  userEmail, 
  userName, 
  userPosition, 
  onNavigate, 
  onLogout 
}: InvoiceManagerDashboardProps) {
  const { 
    amAlerts, 
    productionTrend, 
    isConnected, 
    createLog, 
    updateAlert, 
    resetState 
  } = useRealtime();

  // Navigation & filtering states
  const [activeTab, setActiveTab] = useState<'Dashboard' | 'Team' | 'Productivity'>('Dashboard');
  const [timePeriod, setTimePeriod] = useState<'1D' | '1W' | '1M' | '1Y'>('1D');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Active filter pills state
  const [activeFilters, setActiveFilters] = useState<string[]>([
    'Office: Chandigarh', 
    'Role: Lead Analysts',
    'Accuracy: < 95%'
  ]);

  // Notifications popup state
  const [showNotifications, setShowNotifications] = useState(false);
  const notifications = [
    { id: 1, text: 'Havana Desk synced 5,123 invoices.', time: '3m ago', unread: true },
    { id: 2, text: 'Sarah Jenkins accuracy dropped below 95%.', time: '12m ago', unread: true },
    { id: 3, text: 'Reconciliation error reported in Core Ops.', time: '1h ago', unread: false },
  ];

  // Floating modal state for creating audit
  const [showNewAuditModal, setShowNewAuditModal] = useState(false);
  const [auditForm, setAuditForm] = useState({
    analyst: '',
    vendor: 'US Foods',
    taskType: 'Invoice',
    accuracy: '98.5'
  });
  const [validationError, setValidationError] = useState<string | null>(null);

  const removeFilter = (filter: string) => {
    setActiveFilters(prev => prev.filter(f => f !== filter));
  };

  // Filter AM alerts by search query
  const filteredAlerts = useMemo(() => {
    return amAlerts.filter(alert => {
      if (searchQuery) {
        const query = sanitizeInput(searchQuery).toLowerCase();
        return alert.name.toLowerCase().includes(query) || alert.role.toLowerCase().includes(query);
      }
      return true;
    });
  }, [amAlerts, searchQuery]);

  // Handle audit creation
  const [successToast, setSuccessToast] = useState('');
  const handleCreateAudit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    const cleanAnalyst = sanitizeInput(auditForm.analyst, 60);
    if (!cleanAnalyst || cleanAnalyst.length < 3) {
      setValidationError('Analyst name must be at least 3 characters long after sanitization.');
      return;
    }

    const accuracyNum = parseFloat(auditForm.accuracy);
    if (isNaN(accuracyNum) || accuracyNum < 0 || accuracyNum > 100) {
      setValidationError('Accuracy target must be a valid percentage between 0 and 100.');
      return;
    }
    
    // Create a real portfolio log in server state!
    const newLog: PortfolioLog = {
      id: `log-${Date.now()}`,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      analystName: cleanAnalyst,
      vendorName: auditForm.vendor,
      taskType: auditForm.taskType,
      status: 'PENDING',
      accuracy: accuracyNum,
      ir: 10,
      reco: 8,
      time: '30m',
      errors: 0,
      fr: 5,
      qres: 2
    };

    createLog(newLog);

    setSuccessToast(`Audit task created and broadcasted to all users for Analyst: ${cleanAnalyst}!`);
    setShowNewAuditModal(false);
    setAuditForm({ analyst: '', vendor: 'US Foods', taskType: 'Invoice', accuracy: '98.5' });
    setTimeout(() => setSuccessToast(''), 3500);
  };

  return (
    <div className="bg-[#f8f9ff] text-on-background font-sans min-h-screen relative flex">
      {/* Toast Notification */}
      {successToast && (
        <div className="fixed top-20 right-6 z-50 bg-secondary text-on-secondary px-6 py-3 rounded-lg shadow-xl border border-secondary/20 flex items-center space-x-3 animate-bounce">
          <span className="material-symbols-outlined">check_circle</span>
          <span className="font-semibold text-xs">{successToast}</span>
        </div>
      )}

      {/* Sidebar Navigation */}
      <aside className="w-[260px] shrink-0 bg-surface border-r border-outline-variant flex flex-col min-h-screen sticky top-0 h-screen z-40">
        <div className="p-6">
          <h1 className="text-xl font-bold text-primary font-headline">Invoice Manager</h1>
          <p className="text-xs text-on-surface-variant opacity-70">Precision Ops &amp; Audits</p>
        </div>
        
        <nav className="flex-1 px-2 space-y-1">
          <button 
            onClick={() => onNavigate('LIVE_SYNC_DASHBOARD')}
            className="w-full flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container transition-colors duration-150 text-left cursor-pointer"
          >
            <span className="material-symbols-outlined">sync_saved_locally</span>
            <span className="text-sm">Live Sync Panel</span>
          </button>

          {(userPosition === 'Admin' || userPosition === 'AM') && (
            <button 
              onClick={() => onNavigate('PRECISION_OPS_DASHBOARD')}
              className="w-full flex items-center gap-3 px-4 py-3 border-l-4 border-primary bg-surface-container-high text-primary font-bold text-left cursor-pointer"
            >
              <span className="material-symbols-outlined">dashboard</span>
              <span className="text-sm">Invoice Manager</span>
            </button>
          )}
          
          <button 
            onClick={() => onNavigate('DETAILED_PORTFOLIO_LOGS')}
            className="w-full flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container transition-colors duration-150 text-left cursor-pointer"
          >
            <span className="material-symbols-outlined">assessment</span>
            <span className="text-sm">Detailed Reports</span>
          </button>

          {(userPosition === 'Admin' || userPosition === 'AM') && (
            <button 
              onClick={() => onNavigate('GMAIL_DASHBOARD')}
              className="w-full flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container transition-colors duration-150 text-left cursor-pointer"
            >
              <span className="material-symbols-outlined">mail</span>
              <span className="text-sm">Gmail Sync Gateway</span>
            </button>
          )}

          {(userPosition === 'Admin' || userPosition === 'Team Lead' || userPosition === 'Lead') && (
            <button 
              onClick={() => onNavigate('ANALYST_QUALITY_DASHBOARD')}
              className="w-full flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container transition-colors duration-150 text-left cursor-pointer"
            >
              <span className="material-symbols-outlined">reward</span>
              <span className="text-sm">Scoring Analytics</span>
            </button>
          )}

          <button 
            onClick={() => onNavigate('GOOGLE_CHAT_DASHBOARD')}
            className="w-full flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container transition-colors duration-150 text-left cursor-pointer"
          >
            <span className="material-symbols-outlined">forum</span>
            <span className="text-sm">Google Chat Team</span>
          </button>

          {(userPosition === 'Admin' || userPosition === 'AM' || userPosition === 'Team Lead' || userPosition === 'Lead') && (
            <button 
              onClick={() => onNavigate('PRESENTATION_DECK')}
              className="w-full flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-indigo-500/15 via-purple-500/10 to-pink-500/5 text-purple-400 border-l-4 border-purple-500 hover:from-indigo-500/25 transition-all duration-150 text-left cursor-pointer font-bold shadow-sm"
            >
              <span className="material-symbols-outlined text-purple-400 animate-pulse">co_present</span>
              <span className="text-sm text-purple-300">Presentation & Video Tour</span>
            </button>
          )}

          <div className="pt-4 mt-4 border-t border-outline-variant/30">
            <p className="px-4 text-[10px] text-on-surface-variant font-bold uppercase tracking-wider mb-2">
              Conversion Utilities
            </p>
            <button 
              onClick={() => onNavigate('EXCEL_PARSER_UTILITY')}
              className="w-full flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container transition-colors duration-150 text-left cursor-pointer font-bold"
            >
              <span className="material-symbols-outlined text-[#2997ff]">upload_file</span>
              <span className="text-sm text-[#2997ff]">Excel to JSON Tool</span>
            </button>
          </div>

          <div className="pt-4 mt-4 border-t border-outline-variant/30">
            <p className="px-4 text-[10px] text-on-surface-variant font-bold uppercase tracking-wider mb-2">
              KPI QUICK MENU
            </p>
            <button 
              onClick={() => setActiveTab('Dashboard')}
              className={`w-full flex items-center gap-3 px-4 py-2 text-sm text-left hover:bg-surface-container transition-colors ${activeTab === 'Dashboard' ? 'text-primary font-bold' : 'text-on-surface-variant'}`}
            >
              <span className="material-symbols-outlined text-[18px]">query_stats</span>
              <span>Performance Hub</span>
            </button>
            <button 
              onClick={() => setActiveTab('Team')}
              className={`w-full flex items-center gap-3 px-4 py-2 text-sm text-left hover:bg-surface-container transition-colors ${activeTab === 'Team' ? 'text-primary font-bold' : 'text-on-surface-variant'}`}
            >
              <span className="material-symbols-outlined text-[18px]">groups</span>
              <span>Team Productivity</span>
            </button>
          </div>
        </nav>

        <div className="p-4 mt-auto">
          <button 
            onClick={() => onNavigate('DETAILED_PORTFOLIO_LOGS')}
            className="w-full bg-primary text-on-primary py-2.5 rounded-lg font-bold text-sm hover:opacity-90 active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <span className="material-symbols-outlined text-sm">export_notes</span>
            Export Active Logs
          </button>
          
          <div className="mt-4 pt-4 border-t border-outline-variant flex flex-col gap-1">
            <a className="flex items-center gap-3 px-4 py-2 text-on-surface-variant hover:bg-surface-container text-xs transition-colors rounded" href="#help">
              <span className="material-symbols-outlined text-sm">help_outline</span>
              <span>Documentation</span>
            </a>
            <button 
              onClick={onLogout}
              className="flex items-center gap-3 px-4 py-2 text-error hover:bg-error-container/20 text-xs transition-colors rounded text-left w-full cursor-pointer"
            >
              <span className="material-symbols-outlined text-sm">logout</span>
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Panel Area */}
      <div className="flex-1 min-h-screen flex flex-col overflow-x-hidden">
        
        {/* Top Header */}
        <header className="h-16 bg-surface/90 backdrop-blur-sm border-b border-outline-variant flex items-center justify-between px-6 sticky top-0 z-30">
          <div className="flex items-center gap-4 w-full max-w-md">
            <div className="relative w-full">
              <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant opacity-60 text-[18px]">search</span>
              <input 
                className="w-full bg-surface border border-outline-variant rounded-full py-2 pl-10 pr-4 text-xs focus:outline-none focus:border-primary transition-all" 
                placeholder="Search Assistant Managers (AM), status or KPIs..." 
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-1 bg-secondary/5 border border-secondary/20 rounded-full">
              <span className={`block w-2 h-2 rounded-full ${isConnected ? 'bg-secondary animate-pulse' : 'bg-orange-500'}`}></span>
              <span className="text-[10px] font-bold text-secondary uppercase tracking-tight">
                {isConnected ? 'Syncing Ledger: ACTIVE' : 'Syncing Ledger: OFFLINE'}
              </span>
            </div>

            {/* Notifications panel toggle */}
            <div className="relative">
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className="w-10 h-10 flex items-center justify-center text-on-surface-variant hover:bg-surface-container rounded-full transition-all relative cursor-pointer"
              >
                <span className="material-symbols-outlined text-[20px]">notifications</span>
                <span className="absolute top-2.5 right-2.5 block w-2 h-2 bg-error rounded-full ring-2 ring-white"></span>
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-white border border-outline-variant rounded-lg shadow-xl py-2 z-50 text-xs">
                  <div className="px-4 py-2 border-b border-outline-variant/60 font-bold text-on-surface flex justify-between">
                    <span>Notifications</span>
                    <button onClick={() => setShowNotifications(false)} className="text-primary hover:underline">Dismiss All</button>
                  </div>
                  <div className="divide-y divide-outline-variant/30 max-h-60 overflow-y-auto">
                    {notifications.map(n => (
                      <div key={n.id} className={`p-3 hover:bg-surface-container-low transition-colors ${n.unread ? 'bg-primary/5' : ''}`}>
                        <div className="flex justify-between items-start mb-1">
                          <span className="font-semibold text-on-surface">{n.text}</span>
                          {n.unread && <span className="w-1.5 h-1.5 bg-primary rounded-full"></span>}
                        </div>
                        <span className="text-[10px] text-on-surface-variant opacity-60">{n.time}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center gap-3 pl-2 border-l border-outline-variant">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-bold text-on-surface">{userName || 'Ankit Thakur'}</p>
                <p className="text-[10px] text-on-surface-variant font-medium">{userPosition || 'Lead'}</p>
              </div>
              <div className="w-9 h-9 rounded-full bg-primary text-on-primary flex items-center justify-center font-bold text-sm uppercase">
                {userName ? userName.split(' ').map(n => n[0]).join('').slice(0, 2) : 'AT'}
              </div>
            </div>
          </div>
        </header>

        {/* Content Body */}
        <main className="p-6 flex-1">
          
          {/* Time Filter & Tag Bar */}
          <div className="mb-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-center gap-1.5">
              {(['1D', '1W', '1M', '1Y'] as const).map((period) => (
                <button
                  key={period}
                  onClick={() => setTimePeriod(period)}
                  className={`px-4 py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                    timePeriod === period 
                      ? 'border-primary bg-primary text-on-primary shadow-sm' 
                      : 'border-outline-variant text-on-surface-variant bg-white hover:bg-surface-container'
                  }`}
                >
                  {period === '1D' ? '1 Day' : period === '1W' ? '1 Week' : period === '1M' ? '1 Month' : '1 Year'}
                </button>
              ))}
            </div>

            {/* Active Tag Pills */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider">Active Filters:</span>
              {activeFilters.length > 0 ? (
                activeFilters.map(filter => (
                  <span 
                    key={filter} 
                    className="inline-flex items-center gap-1 bg-surface-container border border-outline-variant px-2.5 py-1 rounded-full text-[10px] font-semibold text-on-surface"
                  >
                    {filter}
                    <button 
                      onClick={() => removeFilter(filter)}
                      className="w-3.5 h-3.5 rounded-full hover:bg-outline-variant/30 flex items-center justify-center cursor-pointer"
                    >
                      <span className="material-symbols-outlined text-[10px] font-bold">close</span>
                    </button>
                  </span>
                ))
              ) : (
                <span className="text-xs text-on-surface-variant italic">No filters active. Showing global logs.</span>
              )}
              {activeFilters.length > 0 && (
                <button 
                  onClick={() => setActiveFilters([])}
                  className="text-[10px] text-primary hover:underline font-bold"
                >
                  Clear All
                </button>
              )}
            </div>
          </div>

          {/* KPI Dashboard Cards Grid */}
          <section className="mb-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            
            <div className="bg-white border border-outline-variant rounded-xl p-5 shadow-sm flex justify-between items-start group hover:border-primary transition-colors">
              <div>
                <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-2">Total Tasks Processed</p>
                <h3 className="font-headline text-3xl font-extrabold text-primary tracking-tight">85,248</h3>
                <p className="text-secondary text-xs font-bold mt-2 flex items-center gap-1">
                  <span className="material-symbols-outlined text-sm">trending_up</span>
                  +12.4% vs. Yesterday
                </p>
              </div>
              <span className="material-symbols-outlined text-primary bg-[#f0f4ff] p-2.5 rounded-lg">inventory_2</span>
            </div>

            <div className="bg-white border border-outline-variant rounded-xl p-5 shadow-sm flex justify-between items-start group hover:border-primary transition-colors">
              <div>
                <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-2">Productivity Quotient</p>
                <h3 className="font-headline text-3xl font-extrabold text-[#006d37] tracking-tight">94.2%</h3>
                <p className="text-secondary text-xs font-bold mt-2 flex items-center gap-1">
                  <span className="material-symbols-outlined text-sm">check</span>
                  Optimal Threshold
                </p>
              </div>
              <span className="material-symbols-outlined text-secondary bg-[#e8f7ec] p-2.5 rounded-lg">bolt</span>
            </div>

            <div className="bg-white border border-outline-variant rounded-xl p-5 shadow-sm flex justify-between items-start group hover:border-primary transition-colors">
              <div>
                <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-2">Audit Accuracy Ratio</p>
                <h3 className="font-headline text-3xl font-extrabold text-primary tracking-tight">88.4%</h3>
                <p className="text-error text-xs font-bold mt-2 flex items-center gap-1">
                  <span className="material-symbols-outlined text-sm">warning</span>
                  Requires Review (Target: 90%)
                </p>
              </div>
              <span className="material-symbols-outlined text-error bg-error/10 p-2.5 rounded-lg">verified_user</span>
            </div>

            <div className="bg-white border border-outline-variant rounded-xl p-5 shadow-sm flex justify-between items-start group hover:border-primary transition-colors">
              <div>
                <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-2">Active AM Alerts</p>
                <h3 className="font-headline text-3xl font-extrabold text-error tracking-tight">42</h3>
                <p className="text-error text-xs font-bold mt-2 flex items-center gap-1">
                  <span className="material-symbols-outlined text-sm">error</span>
                  Critical Resolution Required
                </p>
              </div>
              <span className="material-symbols-outlined text-error bg-error/10 p-2.5 rounded-lg">notifications_active</span>
            </div>

          </section>

          {/* Charts & Trends Grid Section */}
          <section className="mb-6 grid grid-cols-12 gap-6">
            
            {/* Smooth Line Chart Area */}
            <div className="col-span-12 lg:col-span-8 bg-white border border-outline-variant rounded-xl p-6 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h4 className="font-headline text-base font-bold text-on-surface flex items-center gap-2">
                    <span className="material-symbols-outlined text-primary">timeline</span>
                    Daily Invoice Production Trend
                  </h4>
                  <p className="text-xs text-on-surface-variant opacity-70">Real-time throughput metrics across master systems</p>
                </div>
                
                <div className="flex items-center gap-2">
                  <span className="block w-2.5 h-2.5 bg-primary rounded-full"></span>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-on-surface-variant">Output Count</span>
                </div>
              </div>

              {/* Area Chart with Recharts */}
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={productionTrend}
                    margin={{ top: 10, right: 30, left: -20, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient id="colorOutput" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#003256" stopOpacity={0.2}/>
                        <stop offset="95%" stopColor="#003256" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <XAxis 
                      dataKey="name" 
                      tick={{ fill: '#42474f', fontSize: 10, fontWeight: 500 }}
                      axisLine={{ stroke: '#c1c7d2' }}
                    />
                    <YAxis 
                      tick={{ fill: '#42474f', fontSize: 10 }}
                      axisLine={{ stroke: '#c1c7d2' }}
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#ffffff', borderRadius: '8px', border: '1px solid #c1c7d2', fontSize: '12px' }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="value" 
                      stroke="#003256" 
                      strokeWidth={3} 
                      fillOpacity={1} 
                      fill="url(#colorOutput)" 
                    />
                    {/* Highlighted Peak Point on Chart */}
                    <ReferenceDot x="02:00 PM" y={14204} r={6} fill="#ba1a1a" stroke="#ffffff" strokeWidth={2} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {/* Chart Meta Details */}
              <div className="mt-4 p-3 bg-surface-container rounded-lg border border-outline-variant/60 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-error">campaign</span>
                  <span className="font-bold text-on-surface">Peak Volume Alert:</span>
                  <span className="text-on-surface-variant">Max throughput of <span className="font-semibold text-primary">14,204 transactions</span> occurred at 02:00 PM (IST).</span>
                </div>
                <span className="text-[10px] font-bold text-error bg-error/10 px-2 py-0.5 rounded uppercase tracking-wider">Heavy Load</span>
              </div>
            </div>

            {/* Side Card: Team Performance Progress Bar */}
            <div className="col-span-12 lg:col-span-4 bg-white border border-outline-variant rounded-xl p-6 shadow-sm flex flex-col justify-between">
              <div>
                <h4 className="font-headline text-sm font-bold text-on-surface uppercase tracking-wider mb-4 flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary font-bold">checklist_rtl</span>
                  Team Performance &amp; Volume
                </h4>
                
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-xs font-semibold text-on-surface mb-1">
                      <span>Alpha Ops (Dhaka)</span>
                      <span>98.4% Accuracy</span>
                    </div>
                    <div className="w-full bg-[#edf4fe] h-2 rounded-full overflow-hidden">
                      <div className="bg-[#006d37] h-full" style={{ width: '98.4%' }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-semibold text-on-surface mb-1">
                      <span>Capital Lead (Chandigarh)</span>
                      <span>96.2% Accuracy</span>
                    </div>
                    <div className="w-full bg-[#edf4fe] h-2 rounded-full overflow-hidden">
                      <div className="bg-[#003256] h-full" style={{ width: '96.2%' }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-semibold text-on-surface mb-1">
                      <span>Beta Team (US)</span>
                      <span>97.2% Accuracy</span>
                    </div>
                    <div className="w-full bg-[#edf4fe] h-2 rounded-full overflow-hidden">
                      <div className="bg-[#006d37] h-full" style={{ width: '97.2%' }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-semibold text-on-surface mb-1">
                      <span>Island Ops (Havana)</span>
                      <span>85.5% Accuracy</span>
                    </div>
                    <div className="w-full bg-[#edf4fe] h-2 rounded-full overflow-hidden">
                      <div className="bg-error h-full" style={{ width: '85.5%' }}></div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-outline-variant/40 flex flex-col gap-2">
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-on-surface-variant">Weekly Average Rate:</span>
                  <span className="font-bold text-primary">94.3k tasks/wk</span>
                </div>
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-on-surface-variant">Active SLA Compliance:</span>
                  <span className="font-bold text-secondary">99.85%</span>
                </div>
                <button 
                  onClick={() => onNavigate('DETAILED_PORTFOLIO_LOGS')}
                  className="w-full mt-2 bg-surface hover:bg-surface-container border border-outline-variant text-primary font-bold py-2 rounded text-xs tracking-wider uppercase transition-colors text-center cursor-pointer"
                >
                  Configure Team Thresholds
                </button>
              </div>
            </div>

          </section>

          {/* Portfolio Alert Feed (Reconciliation Grid Feed) */}
          <section className="bg-white border border-outline-variant rounded-xl overflow-hidden shadow-sm">
            <div className="px-5 py-4 border-b border-outline-variant bg-surface-container-lowest flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="material-symbols-outlined text-error-alert">warning_amber</span>
                <h3 className="font-headline text-base font-bold text-on-surface">Portfolio Alert Feed</h3>
                <span className="text-[10px] font-bold text-error bg-error/10 border border-error/20 px-2 py-0.5 rounded">3 Active Managers</span>
              </div>
              
              <button 
                onClick={() => onNavigate('DETAILED_PORTFOLIO_LOGS')}
                className="text-primary hover:underline text-xs font-bold flex items-center gap-1 cursor-pointer"
              >
                <span>View All Portfolio Logs</span>
                <span className="material-symbols-outlined text-[16px]">arrow_right_alt</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left text-xs">
                <thead className="bg-[#eff4ff] border-b border-outline-variant text-on-surface-variant font-bold">
                  <tr>
                    <th className="px-5 py-3 text-[10px] font-bold uppercase tracking-wider">Assistant Manager (AM)</th>
                    <th className="px-5 py-3 text-[10px] font-bold uppercase tracking-wider text-center">Open Alerts</th>
                    <th className="px-5 py-3 text-[10px] font-bold uppercase tracking-wider">Accuracy Tracking</th>
                    <th className="px-5 py-3 text-[10px] font-bold uppercase tracking-wider text-center">Criticality</th>
                    <th className="px-5 py-3 text-[10px] font-bold uppercase tracking-wider text-right">Actions</th>
                  </tr>
                </thead>
                
                <tbody className="divide-y divide-outline-variant/60">
                  {filteredAlerts.map((alert) => (
                    <tr key={alert.id} className="hover:bg-surface-container/30 transition-colors">
                      <td className="px-5 py-4">
                        <p className="font-bold text-on-surface">{alert.name}</p>
                        <p className="text-[10px] text-on-surface-variant font-medium">{alert.role}</p>
                      </td>
                      
                      <td className="px-5 py-4 text-center">
                        <span className="inline-flex px-2.5 py-1 rounded-full text-xs font-bold bg-error/10 text-error border border-error/20">
                          {alert.alertsCount} Alerts
                        </span>
                      </td>

                      <td className="px-5 py-4 max-w-[280px]">
                        <div className="flex justify-between font-medium text-[11px] text-on-surface-variant mb-1">
                          <span>Current Accuracy: <span className="font-bold text-primary">{alert.accuracyCurrent}%</span></span>
                          <span>Target: {alert.accuracyTarget}%</span>
                        </div>
                        <div className="w-full bg-[#edf4fe] h-2 rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full ${alert.accuracyCurrent < 90 ? 'bg-error' : alert.accuracyCurrent < 95 ? 'bg-amber-500' : 'bg-[#006d37]'}`}
                            style={{ width: `${alert.accuracyCurrent}%` }}
                          ></div>
                        </div>
                      </td>

                      <td className="px-5 py-4 text-center">
                        <span className={`inline-flex px-3 py-1 rounded-full text-[10px] font-bold border ${
                          alert.criticality === 'Immediate Action' 
                            ? 'bg-error text-on-error font-extrabold border-error animate-pulse' 
                            : alert.criticality === 'High Risk'
                            ? 'bg-error/10 text-error border-error/20'
                            : 'bg-secondary/10 text-secondary border-secondary/20'
                        }`}>
                          {alert.criticality}
                        </span>
                      </td>

                      <td className="px-5 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={() => onNavigate('DETAILED_PORTFOLIO_LOGS')}
                            className="px-3 py-1.5 border border-primary text-primary hover:bg-primary/5 rounded font-bold text-[10px] tracking-wider uppercase cursor-pointer"
                          >
                            Audit Logs
                          </button>
                          <button 
                            onClick={() => {
                              setSuccessToast(`Escalated ${alert.name}'s portfolio issues to regional leads.`);
                              setTimeout(() => setSuccessToast(''), 3000);
                            }}
                            className="px-3 py-1.5 bg-error text-on-error hover:opacity-90 rounded font-bold text-[10px] tracking-wider uppercase cursor-pointer"
                          >
                            Escalate
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* Floating Action Button for Audit Creation */}
          <div className="fixed bottom-6 right-6 z-40">
            <button 
              onClick={() => setShowNewAuditModal(true)}
              className="bg-primary text-on-primary hover:bg-primary-container h-14 px-6 rounded-full shadow-2xl flex items-center gap-2 hover:scale-105 active:scale-95 transition-all cursor-pointer font-bold"
            >
              <span className="material-symbols-outlined text-[24px]">add_circle</span>
              <span>New Audit Task</span>
            </button>
          </div>

          {/* New Audit Modal Dialog Form */}
          {showNewAuditModal && (
            <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
              <div className="bg-white border border-outline-variant rounded-xl shadow-2xl w-full max-w-md p-6 overflow-hidden">
                <div className="flex justify-between items-center mb-4 pb-3 border-b border-outline-variant">
                  <h4 className="font-headline text-lg font-bold text-primary flex items-center gap-2">
                    <span className="material-symbols-outlined">assignment_turned_in</span>
                    Create New Audit Task
                  </h4>
                  <button 
                    onClick={() => setShowNewAuditModal(false)}
                    className="w-8 h-8 rounded-full hover:bg-surface-container flex items-center justify-center text-on-surface-variant cursor-pointer"
                  >
                    <span className="material-symbols-outlined">close</span>
                  </button>
                </div>

                <form onSubmit={handleCreateAudit} className="space-y-4">
                  {validationError && (
                    <div className="p-3 bg-red-50 text-red-600 rounded-lg text-xs font-semibold border border-red-200">
                      ⚠️ {validationError}
                    </div>
                  )}
                  <div>
                    <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1">
                      Analyst Name
                    </label>
                    <input 
                      type="text" 
                      placeholder="e.g. kazimuhammad or Michael Chen"
                      className="w-full bg-surface border border-outline-variant rounded p-2 text-xs focus:outline-none focus:border-primary font-sans"
                      required
                      value={auditForm.analyst}
                      onChange={(e) => setAuditForm(prev => ({ ...prev, analyst: e.target.value }))}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1">
                        Vendor
                      </label>
                      <select 
                        className="w-full bg-surface border border-outline-variant rounded p-2 text-xs focus:outline-none focus:border-primary"
                        value={auditForm.vendor}
                        onChange={(e) => setAuditForm(prev => ({ ...prev, vendor: e.target.value }))}
                      >
                        <option>US Foods</option>
                        <option>Sysco Services</option>
                        <option>GORDON Food</option>
                        <option>Performance Food</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1">
                        Task Type
                      </label>
                      <select 
                        className="w-full bg-surface border border-outline-variant rounded p-2 text-xs focus:outline-none focus:border-primary"
                        value={auditForm.taskType}
                        onChange={(e) => setAuditForm(prev => ({ ...prev, taskType: e.target.value }))}
                      >
                        <option>Invoice</option>
                        <option>Credit Note</option>
                        <option>Discrepancy Log</option>
                        <option>Payment Voucher</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1">
                      Accuracy Target (%)
                    </label>
                    <input 
                      type="number" 
                      step="0.1" 
                      min="50" 
                      max="100" 
                      className="w-full bg-surface border border-outline-variant rounded p-2 text-xs focus:outline-none focus:border-primary font-mono"
                      required
                      value={auditForm.accuracy}
                      onChange={(e) => setAuditForm(prev => ({ ...prev, accuracy: e.target.value }))}
                    />
                  </div>

                  <div className="pt-4 border-t border-outline-variant flex gap-2 justify-end">
                    <button 
                      type="button" 
                      onClick={() => setShowNewAuditModal(false)}
                      className="px-4 py-2 border border-outline-variant rounded hover:bg-surface-container text-xs font-semibold cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button 
                      type="submit" 
                      className="px-4 py-2 bg-primary text-on-primary hover:opacity-90 rounded text-xs font-bold cursor-pointer"
                    >
                      Launch Audit Task
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

        </main>
      </div>
    </div>
  );
}
