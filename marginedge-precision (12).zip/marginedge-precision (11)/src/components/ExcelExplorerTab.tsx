import React, { useState, useEffect } from 'react';
import { collection, getDocs, doc, setDoc, query, getDoc, addDoc, writeBatch } from 'firebase/firestore';
import { db } from '../firebase';
import { ExcelAuditLog, TargetSchema } from '../types';

interface ExcelExplorerTabProps {
  userEmail: string;
  hasWriteAccess: boolean;
}

const TARGET_SCHEMAS: Record<string, TargetSchema> = {
  logs: {
    name: 'Portfolio Logs (/logs)',
    collection: 'logs',
    fields: [
      { key: 'id', label: 'ID', type: 'string', required: true, description: 'Unique ID' },
      { key: 'date', label: 'Date', type: 'string', required: true, description: 'E.g. 2026-07-10' },
      { key: 'analystName', label: 'Analyst Name', type: 'string', required: true, description: 'Analyst Name' },
      { key: 'vendorName', label: 'Vendor Name', type: 'string', required: true, description: 'Vendor Name' },
      { key: 'taskType', label: 'Task Type', type: 'string', required: true, description: 'Task Type' },
      { key: 'status', label: 'Status', type: 'enum', required: true, enumValues: ['MATCHING', 'ALERT', 'PENDING'], description: 'MATCHING, ALERT, PENDING' },
      { key: 'accuracy', label: 'Accuracy (%)', type: 'number', required: true, description: 'Accuracy (0-100)' },
      { key: 'ir', label: 'IR Count', type: 'number', required: false, description: 'Optional IR Count' },
      { key: 'reco', label: 'Reco Count', type: 'number', required: false, description: 'Optional Reco Count' },
      { key: 'time', label: 'Processing Time', type: 'string', required: false, description: 'E.g. 04:22' },
      { key: 'errors', label: 'Errors Count', type: 'number', required: false, description: 'Optional errors' }
    ]
  },
  analysts: {
    name: 'Analyst Productivity (/analysts)',
    collection: 'analysts',
    fields: [
      { key: 'id', label: 'Analyst ID', type: 'string', required: true, description: 'Unique analyst ID' },
      { key: 'name', label: 'Analyst Name', type: 'string', required: true, description: 'Analyst name' },
      { key: 'team', label: 'Team', type: 'string', required: true, description: 'E.g. Alpha, Beta' },
      { key: 'tasks', label: 'Tasks Completed', type: 'number', required: true, description: 'Completed tasks volume' }
    ]
  },
  teams: {
    name: 'Team Performance (/teams)',
    collection: 'teams',
    fields: [
      { key: 'teamName', label: 'Team Name', type: 'string', required: true, description: 'E.g. Team Alpha' },
      { key: 'efficiency', label: 'Efficiency (%)', type: 'number', required: true, description: 'Efficiency percentage' },
      { key: 'errorRate', label: 'Error Rate (%)', type: 'number', required: true, description: 'Error rate percentage' },
      { key: 'output', label: 'Output Description', type: 'string', required: true, description: 'E.g. 500 tasks, high performance' },
      { key: 'lead', label: 'Team Lead', type: 'string', required: true, description: 'Team Lead Name' }
    ]
  },
  invoices: {
    name: 'Invoices (/invoices)',
    collection: 'invoices',
    fields: [
      { key: 'id', label: 'ID', type: 'string', required: true, description: 'ID' },
      { key: 'invoiceNumber', label: 'Invoice Number', type: 'string', required: true, description: 'INV-2026-001' },
      { key: 'vendorName', label: 'Vendor Name', type: 'string', required: true, description: 'E.g. US Foods' },
      { key: 'amount', label: 'Amount ($)', type: 'number', required: true, description: 'Total Billing amount' },
      { key: 'status', label: 'Status', type: 'enum', required: true, enumValues: ['MATCHED', 'ALERT', 'PENDING'], description: 'MATCHED, ALERT, PENDING' },
      { key: 'date', label: 'Date', type: 'string', required: true, description: 'Date string' },
      { key: 'analystName', label: 'Analyst Name', type: 'string', required: true, description: 'Analyst name' },
      { key: 'accuracy', label: 'Accuracy (%)', type: 'number', required: true, description: 'Accuracy percentage' }
    ]
  },
  vendors: {
    name: 'Vendors (/vendors)',
    collection: 'vendors',
    fields: [
      { key: 'id', label: 'Vendor ID', type: 'string', required: true, description: 'Unique ID' },
      { key: 'name', label: 'Vendor Name', type: 'string', required: true, description: 'Full Name' }
    ]
  }
};

export default function ExcelExplorerTab({
  userEmail,
  hasWriteAccess
}: ExcelExplorerTabProps) {
  const [selectedCol, setSelectedCol] = useState<string>('logs');
  const [records, setRecords] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<ExcelAuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [sortField, setSortField] = useState<string>('');
  const [sortAsc, setSortAsc] = useState<boolean>(true);

  // Editing record modal
  const [editingRow, setEditingRow] = useState<any | null>(null);
  const [editForm, setEditForm] = useState<Record<string, any>>({});
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [savingEdit, setSavingEdit] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const snap = await getDocs(collection(db, selectedCol));
      const list: any[] = [];
      snap.forEach(doc => {
        list.push({ ...doc.data(), __docId: doc.id });
      });
      setRecords(list);

      // Fetch audit logs as well
      const auditSnap = await getDocs(collection(db, 'excel_audit_logs'));
      const aList: ExcelAuditLog[] = [];
      auditSnap.forEach(doc => {
        aList.push({ id: doc.id, ...doc.data() } as ExcelAuditLog);
      });
      aList.sort((a, b) => new Date(b.editedAt).getTime() - new Date(a.editedAt).getTime());
      setAuditLogs(aList);
    } catch (err: any) {
      console.error("Error exploring records:", err);
      setError(`Read error: ${err.message || 'Permission denied.'}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [selectedCol]);

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  const openEditModal = (row: any) => {
    if (!hasWriteAccess) return;
    setEditingRow(row);
    setEditForm({ ...row });
    setFormErrors({});
  };

  const handleFormChange = (key: string, val: any) => {
    setEditForm(prev => ({ ...prev, [key]: val }));
    // Clear field error
    if (formErrors[key]) {
      setFormErrors(prev => {
        const copy = { ...prev };
        delete copy[key];
        return copy;
      });
    }
  };

  const validateAndSave = async () => {
    if (!hasWriteAccess || !editingRow) return;
    const schema = TARGET_SCHEMAS[selectedCol];
    if (!schema) return;

    const errors: Record<string, string> = {};
    const sanitizedData: Record<string, any> = {};

    schema.fields.forEach(field => {
      const value = editForm[field.key];
      const isEmpty = value === undefined || value === null || String(value).trim() === '';

      if (field.required && isEmpty) {
        errors[field.key] = `${field.label} is required.`;
      } else if (!isEmpty) {
        if (field.type === 'number') {
          const num = Number(String(value).replace(/[^0-9.-]/g, ''));
          if (isNaN(num)) {
            errors[field.key] = `${field.label} must be a number.`;
          } else {
            sanitizedData[field.key] = num;
          }
        } else if (field.type === 'enum' && field.enumValues) {
          const valUpper = String(value).trim().toUpperCase();
          if (!field.enumValues.includes(valUpper)) {
            errors[field.key] = `Value must be one of: ${field.enumValues.join(', ')}`;
          } else {
            sanitizedData[field.key] = valUpper;
          }
        } else {
          sanitizedData[field.key] = String(value).trim();
        }
      }
    });

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    setSavingEdit(true);
    try {
      const docId = editingRow.__docId;
      const docRef = doc(collection(db, selectedCol), docId);
      
      // Calculate changes for the audit log
      const changes: { field: string; oldValue: any; newValue: any }[] = [];
      schema.fields.forEach(field => {
        const oldVal = editingRow[field.key];
        const newVal = sanitizedData[field.key];
        if (oldVal !== newVal) {
          changes.push({
            field: field.key,
            oldValue: oldVal === undefined ? null : oldVal,
            newValue: newVal === undefined ? null : newVal
          });
        }
      });

      if (changes.length > 0) {
        // Write the record update
        await setDoc(docRef, sanitizedData);

        // Record audit log
        await addDoc(collection(db, 'excel_audit_logs'), {
          id: 'audit-' + Date.now(),
          datasetId: editingRow.datasetId || 'direct-explorer-edit',
          collection: selectedCol,
          recordId: docId,
          editedBy: userEmail,
          editedAt: new Date().toISOString(),
          changes: changes
        });
      }

      setEditingRow(null);
      fetchData();
    } catch (err: any) {
      console.error("Save edit failed:", err);
      alert(`Failed to save edit: ${err.message}`);
    } finally {
      setSavingEdit(false);
    }
  };

  const getHeaders = () => {
    const schema = TARGET_SCHEMAS[selectedCol];
    return schema ? schema.fields : [];
  };

  const filteredRecords = records.filter(row => {
    if (!searchQuery) return true;
    return Object.entries(row).some(([k, v]) => {
      if (k.startsWith('__')) return false;
      return String(v).toLowerCase().includes(searchQuery.toLowerCase());
    });
  });

  const sortedRecords = [...filteredRecords].sort((a, b) => {
    if (!sortField) return 0;
    const aVal = a[sortField];
    const bVal = b[sortField];
    
    if (aVal === bVal) return 0;
    if (aVal === undefined) return 1;
    if (bVal === undefined) return -1;
    
    const comparison = typeof aVal === 'number' && typeof bVal === 'number'
      ? aVal - bVal
      : String(aVal).localeCompare(String(bVal));
      
    return sortAsc ? comparison : -comparison;
  });

  const totalPages = Math.ceil(sortedRecords.length / rowsPerPage) || 1;
  const paginatedRecords = sortedRecords.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage);

  return (
    <div className="space-y-6">
      {/* 1. SELECT TABLE TO EXPLORE */}
      <div className="bg-white dark:bg-[#121620] border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-black text-slate-950 dark:text-white tracking-tight">
            Active Cloud Database Record Explorer
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Query collections, edit spreadsheet records, validate cells inline, and review full system histories in real-time.
          </p>
        </div>

        <div className="flex gap-2">
          <select
            value={selectedCol}
            onChange={(e) => {
              setSelectedCol(e.target.value);
              setCurrentPage(1);
            }}
            className="bg-white dark:bg-[#11141e] border border-slate-200 dark:border-slate-800 rounded-lg py-1.5 px-3 text-xs font-bold focus:border-primary/50 outline-none cursor-pointer"
          >
            {Object.entries(TARGET_SCHEMAS).map(([key, value]) => (
              <option key={key} value={key}>{value.name}</option>
            ))}
          </select>

          <button
            onClick={fetchData}
            className="p-1.5 rounded-lg border hover:bg-slate-50 cursor-pointer text-slate-600 dark:text-slate-400"
            title="Reload records"
          >
            <span className="material-symbols-outlined text-sm block">refresh</span>
          </button>
        </div>
      </div>

      {/* TWO COLUMN GRID: MAIN EXPLORER & AUDIT TRAIL */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        
        {/* RECORDS TABLE PANEL */}
        <div className="xl:col-span-8 bg-white dark:bg-[#121620] border border-slate-200/60 dark:border-slate-800/60 rounded-2xl shadow-sm overflow-hidden flex flex-col min-h-[480px]">
          <div className="h-14 border-b border-slate-200/60 dark:border-slate-800/60 px-6 flex items-center justify-between bg-slate-50/50">
            <span className="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-2">
              <span className="material-symbols-outlined text-primary text-base">table_chart</span>
              Records List ({sortedRecords.length})
            </span>

            <input
              type="text"
              placeholder="Search records..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              className="px-2.5 py-1.5 bg-white dark:bg-[#11141e] border border-slate-200 dark:border-slate-800 rounded-lg text-xs outline-none focus:border-primary/50 w-48 shadow-sm"
            />
          </div>

          <div className="p-5 flex-1 overflow-auto">
            {loading ? (
              <div className="py-20 text-center text-slate-400 space-y-2">
                <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
                <p className="text-xs font-bold">Querying live collection documents...</p>
              </div>
            ) : records.length === 0 ? (
              <div className="py-20 text-center text-slate-400 space-y-2">
                <span className="material-symbols-outlined text-36">folder_open</span>
                <p className="font-extrabold text-sm text-slate-600">No active documents</p>
                <p className="text-xs text-slate-400">This Firestore collection is currently empty.</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="border border-slate-200/50 rounded-xl overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200/50 text-[10px] font-black uppercase text-slate-500 tracking-wider">
                        <th className="p-3 text-center w-12 bg-slate-100">#</th>
                        {getHeaders().map((field) => (
                          <th 
                            key={field.key} 
                            onClick={() => handleSort(field.key)}
                            className="p-3 font-mono cursor-pointer select-none hover:bg-slate-100"
                          >
                            <span className="flex items-center gap-1">
                              {field.label}
                              {sortField === field.key && (
                                <span className="material-symbols-outlined text-xs">
                                  {sortAsc ? 'arrow_upward' : 'arrow_downward'}
                                </span>
                              )}
                            </span>
                          </th>
                        ))}
                        {hasWriteAccess && <th className="p-3 text-center w-16">Edit</th>}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {paginatedRecords.length === 0 ? (
                        <tr>
                          <td colSpan={getHeaders().length + 2} className="p-6 text-center text-xs text-slate-400 font-bold">
                            No records matched your filters.
                          </td>
                        </tr>
                      ) : (
                        paginatedRecords.map((row, index) => (
                          <tr key={row.__docId} className="hover:bg-slate-50/50 transition-colors text-xs font-semibold">
                            <td className="p-3 text-[10px] font-mono font-bold text-slate-400 text-center bg-slate-50/30">
                              {(currentPage - 1) * rowsPerPage + index + 1}
                            </td>
                            {getHeaders().map((field) => {
                              const value = row[field.key];
                              return (
                                <td key={field.key} className="p-3 text-slate-700 max-w-xs truncate font-medium">
                                  {value !== undefined && value !== null ? String(value) : <span className="text-slate-300 italic text-[10px]">empty</span>}
                                </td>
                              );
                            })}
                            {hasWriteAccess && (
                              <td className="p-3 text-center">
                                <button
                                  onClick={() => openEditModal(row)}
                                  className="p-1 text-slate-400 hover:text-primary hover:bg-primary/5 rounded transition-all cursor-pointer"
                                  title="Edit cells inline"
                                >
                                  <span className="material-symbols-outlined text-xs block">edit</span>
                                </button>
                              </td>
                            )}
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>

                {sortedRecords.length > 0 && (
                  <div className="flex items-center justify-between pt-1 text-xs">
                    <p className="text-slate-500 font-medium">
                      Showing <span className="font-bold">{(currentPage - 1) * rowsPerPage + 1}</span> to{' '}
                      <span className="font-bold">{Math.min(currentPage * rowsPerPage, sortedRecords.length)}</span> of{' '}
                      <span className="font-bold">{sortedRecords.length}</span> rows
                    </p>
                    
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                        disabled={currentPage === 1}
                        className="p-1.5 rounded-lg border hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-sm block">chevron_left</span>
                      </button>
                      
                      <span className="text-slate-500 font-bold px-1 select-none">
                        Page {currentPage} of {totalPages}
                      </span>

                      <button
                        onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                        disabled={currentPage === totalPages}
                        className="p-1.5 rounded-lg border hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-sm block">chevron_right</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* AUDIT LOG TIMELINE PANEL */}
        <div className="xl:col-span-4 bg-white dark:bg-[#121620] border border-slate-200/60 dark:border-slate-800/60 rounded-2xl shadow-sm overflow-hidden flex flex-col h-[538px]">
          <div className="h-14 border-b border-[#e2e8f0]/60 px-6 flex items-center justify-between bg-[#f8fafc]/50 shrink-0">
            <span className="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-2">
              <span className="material-symbols-outlined text-primary text-base">rule</span>
              Database Audit logs
            </span>
          </div>

          <div className="p-5 flex-1 overflow-y-auto space-y-4">
            {auditLogs.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-slate-400 space-y-1">
                <span className="material-symbols-outlined text-28">history_edu</span>
                <p className="font-bold text-xs text-slate-500">No edits recorded yet</p>
                <p className="text-[11px] text-slate-400">All cells modification histories are tracked here.</p>
              </div>
            ) : (
              auditLogs.map((log) => (
                <div key={log.id} className="p-3 bg-slate-50/50 rounded-xl border border-slate-200/50 space-y-2 text-[11px]">
                  <div className="flex justify-between font-black text-slate-700">
                    <span className="truncate max-w-[120px]">{log.editedBy}</span>
                    <span className="text-slate-400 text-[10px]">{new Date(log.editedAt).toLocaleTimeString()}</span>
                  </div>
                  <div className="text-slate-500 font-medium">
                    Modified <span className="font-bold font-mono text-primary text-[10px]">{log.recordId}</span> in <span className="font-extrabold uppercase text-slate-600">/{log.collection}</span>:
                  </div>
                  <div className="space-y-1 pl-2 border-l border-primary/20">
                    {log.changes.map((ch, i) => (
                      <div key={i} className="text-slate-600 font-semibold font-mono text-[10px]">
                        {ch.field}: <span className="text-red-500 line-through font-medium">{String(ch.oldValue)}</span> &rarr; <span className="text-green-600 font-black">{String(ch.newValue)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* EDITING DIALOG MODAL */}
      {editingRow && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white dark:bg-[#121620] border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xl w-full max-w-lg space-y-5 animate-scaleUp">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <h4 className="text-sm font-black text-slate-900">
                  Edit Cell Records: {editingRow.__docId}
                </h4>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Update database cells dynamically with real-time validation checks.
                </p>
              </div>
              <button
                onClick={() => setEditingRow(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <span className="material-symbols-outlined block">close</span>
              </button>
            </div>

            <div className="space-y-3.5 max-h-[360px] overflow-y-auto pr-1">
              {TARGET_SCHEMAS[selectedCol]?.fields.map((field) => {
                const isFieldErr = formErrors[field.key];
                return (
                  <div key={field.key} className="space-y-1">
                    <label className="block text-[10px] font-black uppercase text-slate-500 tracking-wider">
                      {field.label} {field.required && <span className="text-red-500">*</span>}
                    </label>
                    
                    {field.type === 'enum' && field.enumValues ? (
                      <select
                        value={editForm[field.key] || ''}
                        onChange={(e) => handleFormChange(field.key, e.target.value)}
                        className={`w-full bg-slate-50 border rounded-lg py-1.5 px-2 text-xs font-bold focus:border-primary/50 outline-none cursor-pointer ${
                          isFieldErr ? 'border-red-400' : 'border-slate-200'
                        }`}
                      >
                        <option value="">-- select --</option>
                        {field.enumValues.map(opt => (
                          <option key={opt} value={opt}>{opt}</option>
                        ))}
                      </select>
                    ) : (
                      <input
                        type={field.type === 'number' ? 'number' : 'text'}
                        value={editForm[field.key] !== undefined ? editForm[field.key] : ''}
                        onChange={(e) => handleFormChange(field.key, e.target.value)}
                        disabled={field.key === 'id'}
                        className={`w-full bg-slate-50 border rounded-lg py-1.5 px-2 text-xs font-semibold outline-none focus:border-primary/50 disabled:bg-slate-100 disabled:text-slate-400 ${
                          isFieldErr ? 'border-red-400' : 'border-slate-200'
                        }`}
                        placeholder={field.description}
                      />
                    )}

                    {isFieldErr && (
                      <p className="text-[9px] font-bold text-red-500">{isFieldErr}</p>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="flex gap-2 justify-end border-t pt-3.5">
              <button
                onClick={() => setEditingRow(null)}
                className="px-4 py-2 border rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={validateAndSave}
                disabled={savingEdit}
                className="px-5 py-2 bg-primary text-white hover:bg-primary/95 text-on-primary font-black rounded-xl text-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-40"
              >
                {savingEdit ? (
                  <>
                    <div className="w-3.5 h-3.5 border border-white border-t-transparent rounded-full animate-spin"></div>
                    Saving...
                  </>
                ) : (
                  <>
                    <span className="material-symbols-outlined text-xs">save</span>
                    Save Changes
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
