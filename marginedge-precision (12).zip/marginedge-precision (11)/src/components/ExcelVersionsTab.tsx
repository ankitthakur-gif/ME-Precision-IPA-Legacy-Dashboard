import React, { useState, useEffect } from 'react';
import { collection, doc, getDocs, writeBatch, query, where, addDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { DatasetVersion } from '../types';

interface ExcelVersionsTabProps {
  userEmail: string;
  hasWriteAccess: boolean;
  onRefreshTrigger: number;
}

export default function ExcelVersionsTab({
  userEmail,
  hasWriteAccess,
  onRefreshTrigger
}: ExcelVersionsTabProps) {
  const [datasets, setDatasets] = useState<DatasetVersion[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Restoration states
  const [restoringId, setRestoringId] = useState<string | null>(null);
  const [restoreProgress, setRestoreProgress] = useState<number>(0);
  const [restoreStatus, setRestoreStatus] = useState<string>('');
  const [restoreSuccess, setRestoreSuccess] = useState<string | null>(null);

  const fetchDatasets = async () => {
    setLoading(true);
    setError(null);
    try {
      // Query all non-deleted versions for the versions table
      const q = query(
        collection(db, 'excel_datasets'),
        where('status', '!=', 'DELETED')
      );
      const snap = await getDocs(q);
      const list: DatasetVersion[] = [];
      snap.forEach(doc => {
        list.push(doc.data() as DatasetVersion);
      });
      
      // Sort locally by date desc
      list.sort((a, b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime());
      setDatasets(list);
    } catch (err: any) {
      console.error("Error fetching datasets:", err);
      setError(`Database Query Error: ${err.message || 'Permission denied.'}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDatasets();
  }, [onRefreshTrigger]);

  // Rollback / Restore historical dataset version
  const handleRestore = async (version: DatasetVersion) => {
    if (!hasWriteAccess) return;
    setRestoringId(version.id);
    setRestoreProgress(0);
    setRestoreStatus('Querying historical records archive...');
    setError(null);
    setRestoreSuccess(null);

    try {
      const targetCol = version.targetCollection;

      // 1. Fetch records linked with this datasetId
      const recordsQuery = query(
        collection(db, 'excel_datasets_records'),
        where('datasetId', '==', version.id)
      );
      const recordsSnap = await getDocs(recordsQuery);
      
      if (recordsSnap.empty) {
        throw new Error(`The spreadsheet records archive is empty for ID: ${version.id}`);
      }

      const recordsToRestore = recordsSnap.docs.map(d => d.data());
      setRestoreStatus(`Found ${recordsToRestore.length} rows. Purging current active destination...`);

      // 2. Clear current target active collection records
      const activeSnap = await getDocs(collection(db, targetCol));
      const deleteBatchSize = 100;
      const activeDocs = activeSnap.docs;

      for (let i = 0; i < activeDocs.length; i += deleteBatchSize) {
        const chunk = activeDocs.slice(i, i + deleteBatchSize);
        const batch = writeBatch(db);
        chunk.forEach(doc => batch.delete(doc.ref));
        await batch.commit();
        
        const deletePercent = Math.round(((i + chunk.length) / activeDocs.length) * 30);
        setRestoreProgress(deletePercent);
      }

      setRestoreStatus('Purge completed. Writing archived records to active Firestore...');

      // 3. Re-write historical dataset records to active target collection
      const writeBatchSize = 100;
      const totalToRestore = recordsToRestore.length;

      for (let i = 0; i < totalToRestore; i += writeBatchSize) {
        const chunk = recordsToRestore.slice(i, i + writeBatchSize);
        const batch = writeBatch(db);
        
        chunk.forEach(rec => {
          const docRef = doc(collection(db, targetCol), rec.recordId);
          batch.set(docRef, rec.data);
        });

        await batch.commit();
        
        const writePercent = 30 + Math.round(((i + chunk.length) / totalToRestore) * 70);
        setRestoreProgress(writePercent);
        await new Promise(resolve => setTimeout(resolve, 15));
      }

      setRestoreStatus('Updating active version metadata settings...');

      // 4. Set this dataset status to ACTIVE, and other datasets of the same target collection to ARCHIVED
      const datasetsSnap = await getDocs(collection(db, 'excel_datasets'));
      const statusBatch = writeBatch(db);
      datasetsSnap.forEach(dDoc => {
        const data = dDoc.data();
        if (data.targetCollection === targetCol) {
          statusBatch.update(dDoc.ref, { status: data.id === version.id ? 'ACTIVE' : 'ARCHIVED' });
        }
      });
      await statusBatch.commit();

      // 5. Append direct audit log
      await addDoc(collection(db, 'excel_audit_logs'), {
        id: 'audit-' + Date.now(),
        datasetId: version.id,
        collection: targetCol,
        recordId: 'rollback-event',
        editedBy: userEmail,
        editedAt: new Date().toISOString(),
        changes: [{ field: 'version', oldValue: 'ARCHIVED', newValue: 'RESTORED_TO_ACTIVE' }]
      });

      setRestoreSuccess(`Dataset "${version.fileName}" successfully restored to active database!`);
      setRestoringId(null);
      fetchDatasets();
    } catch (err: any) {
      console.error("Restoration failed:", err);
      setError(`Restoration Error: ${err.message || 'Permission denied.'}`);
      setRestoringId(null);
    }
  };

  // Soft delete / archive version
  const handleSoftDelete = async (version: DatasetVersion) => {
    if (!hasWriteAccess) return;
    if (!confirm(`Are you sure you want to archive "${version.fileName}"? The spreadsheet records will be stored securely but hidden from the version manager.`)) return;
    
    setLoading(true);
    try {
      const docRef = doc(db, 'excel_datasets', version.id);
      await writeBatch(db).update(docRef, { status: 'DELETED' }).commit();
      
      // Append audit log
      await addDoc(collection(db, 'excel_audit_logs'), {
        id: 'audit-' + Date.now(),
        datasetId: version.id,
        collection: version.targetCollection,
        recordId: 'soft-delete',
        editedBy: userEmail,
        editedAt: new Date().toISOString(),
        changes: [{ field: 'status', oldValue: version.status, newValue: 'DELETED' }]
      });

      fetchDatasets();
    } catch (err: any) {
      console.error("Archive failed:", err);
      setError(`Archive Error: ${err.message}`);
      setLoading(false);
    }
  };

  const getTargetLabel = (colName: string) => {
    if (colName === 'logs') return 'Portfolio Logs';
    if (colName === 'analysts') return 'Analyst Productivity';
    if (colName === 'teams') return 'Team Performance';
    if (colName === 'invoices') return 'Invoices';
    if (colName === 'vendors') return 'Vendors';
    return colName;
  };

  return (
    <div className="bg-white dark:bg-[#121620] border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-6 shadow-sm space-y-6">
      <div>
        <h3 className="text-sm font-black text-slate-950 dark:text-white tracking-tight">
          Spreadsheet Dataset Version Control
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Track long-term Excel snapshots (preserved for up to 1 year). Restore old records or roll back databases instantly with full data integrity.
        </p>
      </div>

      {restoreSuccess && (
        <div className="p-3.5 bg-green-500/10 border border-green-500/20 text-green-700 rounded-xl text-xs font-bold flex items-center gap-2">
          <span className="material-symbols-outlined">check_circle</span>
          <p>{restoreSuccess}</p>
        </div>
      )}

      {error && (
        <div className="p-3.5 bg-red-500/10 border border-red-500/20 text-red-600 rounded-xl text-xs font-bold flex items-center gap-2">
          <span className="material-symbols-outlined">warning</span>
          <p>{error}</p>
        </div>
      )}

      {restoringId && (
        <div className="p-4 bg-primary/5 border border-primary/15 rounded-xl space-y-3">
          <div className="flex items-center justify-between text-xs font-extrabold text-primary">
            <span className="flex items-center gap-2 animate-pulse">
              <span className="w-2 h-2 rounded-full bg-primary animate-ping"></span>
              {restoreStatus}
            </span>
            <span>{restoreProgress}%</span>
          </div>
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
            <div className="bg-primary h-full transition-all duration-300" style={{ width: `${restoreProgress}%` }}></div>
          </div>
        </div>
      )}

      {loading ? (
        <div className="py-20 text-center text-slate-400 space-y-3">
          <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-xs font-bold">Querying version database history...</p>
        </div>
      ) : datasets.length === 0 ? (
        <div className="py-20 text-center text-slate-400 space-y-2 border-2 border-dashed border-slate-100 dark:border-slate-800/50 rounded-xl">
          <span className="material-symbols-outlined text-48 select-none">history</span>
          <p className="font-extrabold text-sm text-slate-600 dark:text-slate-300">No spreadsheets synced yet</p>
          <p className="text-xs text-slate-400">Head to the "Upload" workspace to synchronize your first Excel file.</p>
        </div>
      ) : (
        <div className="border border-slate-200/50 rounded-xl overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-200/50 text-[10px] font-black uppercase text-slate-500 tracking-wider">
                <th className="p-4">File Name</th>
                <th className="p-4">Worksheet</th>
                <th className="p-4">Destination Table</th>
                <th className="p-4 text-center">Records</th>
                <th className="p-4">Uploaded By</th>
                <th className="p-4">Sync Date</th>
                <th className="p-4 text-center">Status</th>
                <th className="p-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {datasets.map((v) => (
                <tr key={v.id} className="hover:bg-slate-50/20 text-xs font-semibold">
                  <td className="p-4">
                    <p className="font-extrabold text-slate-800 dark:text-slate-200 max-w-xs truncate">{v.fileName}</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">{v.fileSize}</p>
                  </td>
                  <td className="p-4 font-mono font-bold text-slate-600">{v.sheetName}</td>
                  <td className="p-4">
                    <span className="bg-blue-500/10 text-blue-700 px-2.5 py-1 rounded-lg font-bold text-[10px] uppercase">
                      {getTargetLabel(v.targetCollection)}
                    </span>
                  </td>
                  <td className="p-4 text-center font-black text-slate-800 dark:text-slate-200">{v.totalRecords}</td>
                  <td className="p-4 text-slate-500">{v.uploadedBy}</td>
                  <td className="p-4 text-slate-500">{new Date(v.uploadDate).toLocaleString()}</td>
                  <td className="p-4 text-center">
                    <span className={`inline-block px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${
                      v.status === 'ACTIVE' 
                        ? 'bg-green-500/10 text-green-700 border border-green-500/20' 
                        : 'bg-slate-100 text-slate-500 border border-slate-200'
                    }`}>
                      {v.status}
                    </span>
                  </td>
                  <td className="p-4 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      {v.status !== 'ACTIVE' ? (
                        <button
                          onClick={() => handleRestore(v)}
                          disabled={!hasWriteAccess || restoringId !== null}
                          className="px-2 py-1 bg-primary text-white text-[10px] font-black rounded-lg hover:bg-primary/95 transition-all flex items-center gap-0.5 cursor-pointer disabled:opacity-40"
                          title="Restore this version back to the active dashboard"
                        >
                          <span className="material-symbols-outlined text-xs">restore</span>
                          Activate
                        </button>
                      ) : (
                        <span className="text-[9px] font-black text-green-600 uppercase flex items-center gap-0.5">
                          <span className="material-symbols-outlined text-xs">verified</span>
                          Active
                        </span>
                      )}
                      
                      <button
                        onClick={() => handleSoftDelete(v)}
                        disabled={!hasWriteAccess || restoringId !== null}
                        className="p-1 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 rounded transition-all disabled:opacity-40"
                        title="Archive this version"
                      >
                        <span className="material-symbols-outlined text-sm block">delete</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
