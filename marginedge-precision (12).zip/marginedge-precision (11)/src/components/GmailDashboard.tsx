import React, { useState, useEffect, useMemo } from 'react';
import { 
  googleSignIn, 
  getAccessToken, 
  logout, 
  initAuth 
} from '../lib/googleAuth';
import { 
  listGmailMessages, 
  getGmailMessageDetails, 
  sendGmailMessage, 
  modifyMessageLabels,
  getGmailAttachment,
  GmailMessage,
  GmailAttachment
} from '../lib/gmailService';
import * as XLSX from 'xlsx';
import { useRealtime } from '../context/RealtimeContext';
import { PortfolioLog } from '../types';
import { 
  Mail, 
  Send, 
  Archive, 
  Trash2, 
  RefreshCw, 
  Search, 
  Plus, 
  X, 
  ChevronRight, 
  User, 
  Calendar, 
  ArrowLeft, 
  AlertCircle, 
  CheckCircle2, 
  FileText, 
  Layers, 
  LogOut, 
  Inbox, 
  PlusCircle, 
  Check,
  FileSpreadsheet,
  MessageSquare
} from 'lucide-react';

interface GmailDashboardProps {
  userEmail: string;
  userName?: string;
  userPosition?: string;
  onNavigate: (view: any) => void;
  onLogout: () => void;
}

export default function GmailDashboard({ 
  userEmail, 
  userName, 
  userPosition, 
  onNavigate, 
  onLogout 
}: GmailDashboardProps) {
  const { createLog, portfolioLogs, ipaRecords, updateAllIpaRecords, isConnected: isWsConnected } = useRealtime();

  // Authentication states
  const [googleUser, setGoogleUser] = useState<any | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [needsAuth, setNeedsAuth] = useState(true);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Email API states
  const [messages, setMessages] = useState<GmailMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMessage, setSelectedMessage] = useState<GmailMessage | null>(null);
  const [loadingDetails, setLoadingDetails] = useState(false);

  // UI modal states
  const [showComposeModal, setShowComposeModal] = useState(false);
  const [showSyncModal, setShowSyncModal] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  // Compose email form state
  const [composeForm, setComposeForm] = useState({
    to: '',
    subject: '',
    body: ''
  });
  const [isSending, setIsSending] = useState(false);

  // Auto-Detect IPA and Excel Attachment states
  const [gmailFilter, setGmailFilter] = useState<'all' | 'ipa'>('all');
  const [downloadingAttachmentId, setDownloadingAttachmentId] = useState<string | null>(null);
  const [parsedExcelRows, setParsedExcelRows] = useState<any[] | null>(null);
  const [showExcelPreviewModal, setShowExcelPreviewModal] = useState(false);
  const [previewFilename, setPreviewFilename] = useState('');

  // Sync to Ledger form state
  const [syncForm, setSyncForm] = useState({
    analyst: 'Alex Rivera',
    vendor: '',
    taskType: 'Invoice',
    accuracy: '99.2',
    date: ''
  });

  // Gmail Auto-Sync tracking states
  const [processedAttachmentIds, setProcessedAttachmentIds] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('margin_edge_processed_attachments');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [autoSyncingList, setAutoSyncingList] = useState<{filename: string; count: number; date: string}[]>(() => {
    try {
      const stored = localStorage.getItem('margin_edge_auto_sync_history');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [isAutoSyncingInProgress, setIsAutoSyncingInProgress] = useState(false);

  // Track Firebase Auth State on mount
  useEffect(() => {
    const unsubscribe = initAuth(
      (user, cachedToken) => {
        setGoogleUser(user);
        setToken(cachedToken);
        setNeedsAuth(false);
        fetchEmails(cachedToken);
      },
      () => {
        setGoogleUser(null);
        setToken(null);
        setNeedsAuth(true);
      }
    );
    return () => unsubscribe();
  }, []);

  // Automated background refresh interval for real-time inbox updates (no manual refresh needed)
  useEffect(() => {
    if (!token) return;
    const interval = setInterval(() => {
      fetchEmails(token, searchQuery);
    }, 30000); // Poll Gmail every 30 seconds
    return () => clearInterval(interval);
  }, [token, searchQuery]);

  // Fetch emails from Gmail API
  const fetchEmails = async (accessToken: string, query: string = '') => {
    setLoading(true);
    setError(null);
    try {
      const msgList = await listGmailMessages(accessToken, query);
      
      // Fetch full details in parallel for the first 10 messages
      const detailsPromises = msgList.slice(0, 10).map(async (m) => {
        try {
          return await getGmailMessageDetails(accessToken, m.id);
        } catch (err) {
          console.error(`Error fetching details for message ${m.id}:`, err);
          return null;
        }
      });
      
      const detailedMsgs = await Promise.all(detailsPromises);
      const fetched = detailedMsgs.filter((m): m is GmailMessage => m !== null);
      setMessages(fetched);
      
      // Trigger background auto-sync for Excel attachments
      autoSyncExcelAttachments(accessToken, fetched);
    } catch (err: any) {
      console.error('Failed to load Gmail messages:', err);
      setError(err.message || 'Failed to authenticate or fetch emails. Please try signing in again.');
      setNeedsAuth(true);
    } finally {
      setLoading(false);
    }
  };

  // Automatically scan and sync Excel spreadsheets from Gmail list
  const autoSyncExcelAttachments = async (accessToken: string, emailMessages: GmailMessage[]) => {
    if (isAutoSyncingInProgress) return;
    
    // Find all un-processed Excel attachments
    const eligibleAttachments: { msg: GmailMessage; att: GmailAttachment }[] = [];
    
    emailMessages.forEach(msg => {
      if (msg.attachments && msg.attachments.length > 0) {
        msg.attachments.forEach(att => {
          const isExcel = att.filename.endsWith('.xlsx') || att.filename.endsWith('.xls');
          const alreadyProcessed = processedAttachmentIds.includes(att.id);
          if (isExcel && !alreadyProcessed) {
            eligibleAttachments.push({ msg, att });
          }
        });
      }
    });

    if (eligibleAttachments.length === 0) return;

    setIsAutoSyncingInProgress(true);
    let totalImportedRows = 0;
    const newlyProcessedIds = [...processedAttachmentIds];
    const newHistoryItems = [...autoSyncingList];

    try {
      for (const { msg, att } of eligibleAttachments) {
        console.log(`🤖 [Auto-Sync] Automatically processing attachment: ${att.filename} (ID: ${att.id})`);
        const base64Data = await getGmailAttachment(accessToken, msg.id, att.id);
        const normalizedBase64 = base64Data.replace(/-/g, '+').replace(/_/g, '/');
        
        // Parse with XLSX
        const workbook = XLSX.read(normalizedBase64, { type: 'base64' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);

        if (jsonData && jsonData.length > 0) {
          const firstRow = jsonData[0];
          const keys = Object.keys(firstRow);
          // Check if it's an IPA record sheet (contains task-related headers, and no vendor headers)
          const isIpaSheet = keys.some(k => /task|point|volume|count|score/i.test(k)) && 
                              !keys.some(k => /vendor|company|client/i.test(k));

          let addedCount = 0;

          if (isIpaSheet) {
            // Process as IPA Records
            const mergedIpaRecords = [...(ipaRecords || [])];
            jsonData.forEach((row: any, index: number) => {
              const keysList = Object.keys(row);
              const nameKey = keysList.find(k => /name|user|analyst|employee|member/i.test(k)) || keysList[0];
              const teamKey = keysList.find(k => /team|dept|office|group/i.test(k)) || keysList[1];
              const tasksKey = keysList.find(k => /task|point|volume|count|score/i.test(k)) || keysList[2];

              const name = String(row[nameKey] || '').trim();
              if (!name) return;

              const team = String(row[teamKey] || 'Alpha').trim();
              const tasks = Number(row[tasksKey]) || 0;
              const id = String(row.id || `ipa-auto-${att.id}-${index}`);

              const existingIdx = mergedIpaRecords.findIndex(r => r.id === id || r.name.toLowerCase() === name.toLowerCase());
              if (existingIdx > -1) {
                mergedIpaRecords[existingIdx] = {
                  ...mergedIpaRecords[existingIdx],
                  tasks: mergedIpaRecords[existingIdx].tasks + tasks
                };
              } else {
                mergedIpaRecords.push({ id, name, team, tasks });
              }
              addedCount++;
            });

            if (addedCount > 0) {
              updateAllIpaRecords(mergedIpaRecords);
              totalImportedRows += addedCount;
              newHistoryItems.unshift({
                filename: att.filename,
                count: addedCount,
                date: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
              });
              showToast(`🤖 Gmail Auto-Sync: Imported ${addedCount} IPA records from "${att.filename}"!`);
            }
          } else {
            // Process as PortfolioLog records
            jsonData.forEach((row: any, index: number) => {
              const findVal = (keysList: string[]) => {
                const foundKey = Object.keys(row).find(k => keysList.some(target => k.toLowerCase().trim().replace(/_/g, '') === target.toLowerCase()));
                return foundKey ? row[foundKey] : undefined;
              };

              const id = String(findVal(['id', 'invoicenumber', 'invoice', 'recordid']) || `log-auto-${att.id}-${index}`);
              
              // Avoid duplicate inserts if this log row already exists in active ledger logs
              const alreadyExists = portfolioLogs.some(log => log.id === id);
              if (alreadyExists) {
                return; // Skip duplicate record
              }

              const date = String(findVal(['date', 'receiveddate', 'documentdate']) || new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }));
              const analystName = String(findVal(['analystname', 'analyst', 'sender', 'name']) || 'Gmail Auto-Importer');
              const vendorName = String(findVal(['vendorname', 'vendor', 'company']) || 'Excel Auto Vendor');
              const taskType = String(findVal(['tasktype', 'type', 'category']) || 'Invoice');
              const statusStr = String(findVal(['status', 'state']) || 'PENDING').toUpperCase();
              const status = ['MATCHING', 'ALERT', 'PENDING'].includes(statusStr) ? (statusStr as any) : 'PENDING';
              const accuracy = parseFloat(findVal(['accuracy', 'score', 'targetaccuracy']) || '99.5');

              const ir = parseInt(findVal(['ir', 'ircount']) || '10');
              const reco = parseInt(findVal(['reco', 'recocount']) || '8');
              const time = String(findVal(['time', 'duration', 'processingtime']) || '10m');
              const errors = parseInt(findVal(['errors', 'errorcount']) || '0');

              const newLog: PortfolioLog = {
                id,
                date,
                analystName,
                vendorName,
                taskType,
                status,
                accuracy: isNaN(accuracy) ? 99.5 : accuracy,
                ir: isNaN(ir) ? 10 : ir,
                reco: isNaN(reco) ? 8 : reco,
                time,
                errors: isNaN(errors) ? 0 : errors,
                fr: 2,
                qres: 0
              };

              createLog(newLog);
              addedCount++;
            });

            if (addedCount > 0) {
              totalImportedRows += addedCount;
              newHistoryItems.unshift({
                filename: att.filename,
                count: addedCount,
                date: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
              });
              showToast(`🤖 Gmail Auto-Sync: Imported ${addedCount} records from "${att.filename}"!`);
            }
          }
        }
        
        newlyProcessedIds.push(att.id);
      }

      // Persist processed state
      localStorage.setItem('margin_edge_processed_attachments', JSON.stringify(newlyProcessedIds));
      localStorage.setItem('margin_edge_auto_sync_history', JSON.stringify(newHistoryItems.slice(0, 10)));
      setProcessedAttachmentIds(newlyProcessedIds);
      setAutoSyncingList(newHistoryItems.slice(0, 10));

    } catch (err) {
      console.error('🤖 [Auto-Sync] Error automatically syncing Gmail attachments:', err);
    } finally {
      setIsAutoSyncingInProgress(false);
    }
  };

  // Auto-sync interval to poll for new emails
  useEffect(() => {
    if (needsAuth || !token) return;

    // Run first check 5 seconds after mount/login to allow portfolioLogs state to fully populate first
    const startupTimer = setTimeout(() => {
      fetchEmails(token, searchQuery);
    }, 5000);

    const interval = setInterval(() => {
      console.log('🤖 [Auto-Poll] Auto-checking for new Gmail Excel attachments...');
      fetchEmails(token, searchQuery);
    }, 45000); // Check every 45 seconds

    return () => {
      clearTimeout(startupTimer);
      clearInterval(interval);
    };
  }, [token, needsAuth, searchQuery]);

  // Check if an email is an IPA Report email
  const isIPAMessage = (msg: GmailMessage) => {
    const subject = msg.subject.toLowerCase();
    const snippet = msg.snippet.toLowerCase();
    const body = msg.body.toLowerCase();
    
    // Check keywords related to Accuracy, IPA, reconciliation, or audit
    const hasKeywords = 
      subject.includes('ipa') || subject.includes('accuracy') || subject.includes('reconciliation') || subject.includes('audit') || subject.includes('performance') || subject.includes('ledger') ||
      snippet.includes('ipa') || snippet.includes('accuracy') || snippet.includes('reconciliation') || snippet.includes('audit') || snippet.includes('performance') || snippet.includes('ledger') ||
      body.includes('ipa') || body.includes('accuracy') || body.includes('reconciliation') || body.includes('audit') || body.includes('performance') || body.includes('ledger');
      
    // Check if contains Excel file attachment
    const hasExcel = msg.attachments && msg.attachments.some(att => 
      att.filename.endsWith('.xlsx') || att.filename.endsWith('.xls')
    );
    
    return hasKeywords || hasExcel;
  };

  const filteredMessages = useMemo(() => {
    return messages.filter(msg => {
      if (gmailFilter === 'all') return true;
      return isIPAMessage(msg);
    });
  }, [messages, gmailFilter]);

  const ipaMessagesCount = useMemo(() => {
    return messages.filter(isIPAMessage).length;
  }, [messages]);

  // Download attachment handler
  const handleDownloadAttachment = async (msg: GmailMessage, attachment: GmailAttachment) => {
    const currentToken = token || getAccessToken();
    if (!currentToken) {
      alert('Authentication token not available. Please sign in again.');
      return;
    }

    setDownloadingAttachmentId(attachment.id);
    try {
      const base64Data = await getGmailAttachment(currentToken, msg.id, attachment.id);
      
      // Decode and download file
      const normalizedBase64 = base64Data.replace(/-/g, '+').replace(/_/g, '/');
      const byteCharacters = atob(normalizedBase64);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: attachment.mimeType || 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = attachment.filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      showToast(`Successfully downloaded "${attachment.filename}"!`);
    } catch (err: any) {
      console.error('Error downloading attachment:', err);
      alert(`Download failed: ${err.message}`);
    } finally {
      setDownloadingAttachmentId(null);
    }
  };

  // Parse Excel attachment to preview
  const handleParseAttachment = async (msg: GmailMessage, attachment: GmailAttachment) => {
    const currentToken = token || getAccessToken();
    if (!currentToken) {
      alert('Authentication token not available. Please sign in again.');
      return;
    }

    setDownloadingAttachmentId(attachment.id);
    try {
      const base64Data = await getGmailAttachment(currentToken, msg.id, attachment.id);
      const normalizedBase64 = base64Data.replace(/-/g, '+').replace(/_/g, '/');
      
      // Parse using XLSX
      const workbook = XLSX.read(normalizedBase64, { type: 'base64' });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);
      
      if (jsonData && jsonData.length > 0) {
        setParsedExcelRows(jsonData);
        setPreviewFilename(attachment.filename);
        setShowExcelPreviewModal(true);
        showToast(`Successfully parsed ${jsonData.length} rows from "${attachment.filename}"!`);
      } else {
        alert('This Excel spreadsheet seems to be empty.');
      }
    } catch (err: any) {
      console.error('Error parsing attachment:', err);
      alert(`Parsing failed: ${err.message}`);
    } finally {
      setDownloadingAttachmentId(null);
    }
  };

  const handleRefresh = () => {
    const currentToken = token || getAccessToken();
    if (currentToken) {
      fetchEmails(currentToken, searchQuery);
    } else {
      setNeedsAuth(true);
    }
  };

  // Google Sign-In handler
  const handleGoogleLogin = async () => {
    setIsLoggingIn(true);
    setError(null);
    try {
      const result = await googleSignIn();
      if (result) {
        setGoogleUser(result.user);
        setToken(result.accessToken);
        setNeedsAuth(false);
        showToast('Successfully authenticated with Google account!');
        fetchEmails(result.accessToken);
      }
    } catch (err: any) {
      console.error('Google login failed:', err);
      setError(err.message || 'Google Auth Popup closed or failed.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Logout handler
  const handleGoogleLogout = async () => {
    const confirmed = window.confirm('Are you sure you want to disconnect your Google Account and sign out?');
    if (!confirmed) return;

    try {
      await logout();
      setGoogleUser(null);
      setToken(null);
      setMessages([]);
      setSelectedMessage(null);
      setNeedsAuth(true);
      showToast('Disconnected Google Account.');
    } catch (err) {
      console.error('Logout failed:', err);
    }
  };

  // Toast notification trigger
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 4000);
  };

  // Selecting a message
  const handleSelectMessage = async (msg: GmailMessage) => {
    setSelectedMessage(msg);
  };

  // Compose Email submission
  const handleSendEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!composeForm.to || !composeForm.subject || !composeForm.body) {
      alert('Please fill out all compose fields.');
      return;
    }

    // MANDATORY confirmation before performing a write/send mutation via Google Workspace APIs
    const confirmed = window.confirm(`Are you sure you want to send this email to ${composeForm.to}?`);
    if (!confirmed) return;

    setIsSending(true);
    try {
      const currentToken = token || getAccessToken();
      if (!currentToken) throw new Error('No valid OAuth access token available.');

      await sendGmailMessage(currentToken, composeForm.to, composeForm.subject, composeForm.body);
      showToast('Email sent successfully!');
      setShowComposeModal(false);
      setComposeForm({ to: '', subject: '', body: '' });
      handleRefresh();
    } catch (err: any) {
      console.error('Failed to send email:', err);
      alert(`Send Error: ${err.message}`);
    } finally {
      setIsSending(false);
    }
  };

  // Archive email (Removes INBOX label)
  const handleArchiveEmail = async (msg: GmailMessage) => {
    const confirmed = window.confirm('Are you sure you want to archive this email (removes it from Inbox)?');
    if (!confirmed) return;

    try {
      const currentToken = token || getAccessToken();
      if (!currentToken) throw new Error('No valid token.');

      await modifyMessageLabels(currentToken, msg.id, [], ['INBOX']);
      showToast('Email archived.');
      if (selectedMessage?.id === msg.id) {
        setSelectedMessage(null);
      }
      handleRefresh();
    } catch (err: any) {
      console.error('Failed to archive email:', err);
      alert(`Archive Error: ${err.message}`);
    }
  };

  // Move email to trash (Trash label)
  const handleTrashEmail = async (msg: GmailMessage) => {
    const confirmed = window.confirm('Are you sure you want to move this email to trash?');
    if (!confirmed) return;

    try {
      const currentToken = token || getAccessToken();
      if (!currentToken) throw new Error('No valid token.');

      await modifyMessageLabels(currentToken, msg.id, ['TRASH'], ['INBOX']);
      showToast('Email moved to Trash.');
      if (selectedMessage?.id === msg.id) {
        setSelectedMessage(null);
      }
      handleRefresh();
    } catch (err: any) {
      console.error('Failed to trash email:', err);
      alert(`Delete Error: ${err.message}`);
    }
  };

  // Quick Action: Reply to selected email
  const handleInitiateReply = () => {
    if (!selectedMessage) return;
    
    // Extract reply recipient
    let replyTo = selectedMessage.from;
    const emailMatch = selectedMessage.from.match(/<([^>]+)>/);
    if (emailMatch && emailMatch[1]) {
      replyTo = emailMatch[1];
    }

    setComposeForm({
      to: replyTo,
      subject: selectedMessage.subject.startsWith('Re:') 
        ? selectedMessage.subject 
        : `Re: ${selectedMessage.subject}`,
      body: `<br><br><hr><div style="font-family: Arial; font-size: 11pt; color: #555555;"><b>From:</b> ${selectedMessage.from}<br><b>Sent:</b> ${selectedMessage.date}<br><b>To:</b> ${selectedMessage.to}<br><b>Subject:</b> ${selectedMessage.subject}</div><br>${selectedMessage.body || selectedMessage.snippet}`
    });
    setShowComposeModal(true);
  };

  // Pre-fill Sync to Ledger Modal from selected email details
  const handleInitiateSync = () => {
    if (!selectedMessage) return;

    // Try to guess vendor from sender name
    let parsedVendor = selectedMessage.from;
    if (selectedMessage.from.includes('<')) {
      parsedVendor = selectedMessage.from.split('<')[0].trim();
    }
    // Clean quotes
    parsedVendor = parsedVendor.replace(/["']/g, '');

    // Parse date
    const dateObj = new Date(selectedMessage.date);
    const formattedDate = isNaN(dateObj.getTime())
      ? new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
      : dateObj.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

    setSyncForm({
      analyst: 'Alex Rivera',
      vendor: parsedVendor,
      taskType: 'Invoice',
      accuracy: '99.5',
      date: formattedDate
    });
    setShowSyncModal(true);
  };

  // Confirm Sync to Ledger
  const handleConfirmSync = (e: React.FormEvent) => {
    e.preventDefault();
    if (!syncForm.vendor) return;

    // Create real ledger entry
    const newLog: PortfolioLog = {
      id: `log-${Date.now()}`,
      date: syncForm.date || new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      analystName: syncForm.analyst,
      vendorName: syncForm.vendor,
      taskType: syncForm.taskType,
      status: 'PENDING',
      accuracy: parseFloat(syncForm.accuracy) || 99.5,
      ir: 15,
      reco: 12,
      time: '12m',
      errors: 0,
      fr: 4,
      qres: 1
    };

    createLog(newLog);
    showToast(`Successfully synced email payload as ledger log for ${syncForm.vendor}!`);
    setShowSyncModal(false);
  };

  // Sync all parsed Excel spreadsheet rows to the ledger
  const handleSyncParsedRows = () => {
    if (!parsedExcelRows || parsedExcelRows.length === 0) return;

    const firstRow = parsedExcelRows[0];
    const keys = Object.keys(firstRow);
    const isIpaSheet = keys.some(k => /task|point|volume|count|score/i.test(k)) && 
                        !keys.some(k => /vendor|company|client/i.test(k));

    let addedCount = 0;

    if (isIpaSheet) {
      const mergedIpaRecords = [...(ipaRecords || [])];
      parsedExcelRows.forEach((row: any, index: number) => {
        const keysList = Object.keys(row);
        const nameKey = keysList.find(k => /name|user|analyst|employee|member/i.test(k)) || keysList[0];
        const teamKey = keysList.find(k => /team|dept|office|group/i.test(k)) || keysList[1];
        const tasksKey = keysList.find(k => /task|point|volume|count|score/i.test(k)) || keysList[2];

        const name = String(row[nameKey] || '').trim();
        if (!name) return;

        const team = String(row[teamKey] || 'Alpha').trim();
        const tasks = Number(row[tasksKey]) || 0;
        const id = String(row.id || `ipa-manual-${Date.now()}-${index}`);

        const existingIdx = mergedIpaRecords.findIndex(r => r.id === id || r.name.toLowerCase() === name.toLowerCase());
        if (existingIdx > -1) {
          mergedIpaRecords[existingIdx] = {
            ...mergedIpaRecords[existingIdx],
            tasks: mergedIpaRecords[existingIdx].tasks + tasks
          };
        } else {
          mergedIpaRecords.push({ id, name, team, tasks });
        }
        addedCount++;
      });

      if (addedCount > 0) {
        updateAllIpaRecords(mergedIpaRecords);
      }
      showToast(`Successfully imported and synced ${addedCount} IPA records from "${previewFilename}"!`);
    } else {
      parsedExcelRows.forEach((row: any, index: number) => {
        const findVal = (keysList: string[]) => {
          const foundKey = Object.keys(row).find(k => keysList.some(target => k.toLowerCase().trim().replace(/_/g, '') === target.toLowerCase()));
          return foundKey ? row[foundKey] : undefined;
        };

        const id = String(findVal(['id', 'invoicenumber', 'invoice', 'recordid']) || `log-${Date.now()}-${index}`);
        const date = String(findVal(['date', 'receiveddate', 'documentdate']) || new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }));
        const analystName = String(findVal(['analystname', 'analyst', 'sender', 'name']) || 'System Automation');
        const vendorName = String(findVal(['vendorname', 'vendor', 'company']) || 'Excel Imported Vendor');
        const taskType = String(findVal(['tasktype', 'type', 'category']) || 'Invoice');
        const statusStr = String(findVal(['status', 'state']) || 'PENDING').toUpperCase();
        const status = ['MATCHING', 'ALERT', 'PENDING'].includes(statusStr) ? (statusStr as any) : 'PENDING';
        const accuracy = parseFloat(findVal(['accuracy', 'score', 'targetaccuracy']) || '99.5');

        const ir = parseInt(findVal(['ir', 'ircount']) || '10');
        const reco = parseInt(findVal(['reco', 'recocount']) || '8');
        const time = String(findVal(['time', 'duration', 'processingtime']) || '10m');
        const errors = parseInt(findVal(['errors', 'errorcount']) || '0');

        const newLog: PortfolioLog = {
          id,
          date,
          analystName,
          vendorName,
          taskType,
          status,
          accuracy: isNaN(accuracy) ? 99.5 : accuracy,
          ir: isNaN(ir) ? 10 : ir,
          reco: isNaN(reco) ? 8 : reco,
          time,
          errors: isNaN(errors) ? 0 : errors,
          fr: 2,
          qres: 0
        };

        createLog(newLog);
        addedCount++;
      });
      showToast(`Successfully imported and synced ${addedCount} records from "${previewFilename}" to active ledger!`);
    }

    setShowExcelPreviewModal(false);
    setParsedExcelRows(null);
  };

  const searchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const currentToken = token || getAccessToken();
    if (currentToken) {
      fetchEmails(currentToken, searchQuery);
    }
  };

  return (
    <div className="bg-[#f8f9ff] text-on-background font-sans min-h-screen relative flex">
      {/* Sidebar Navigation */}
      <aside className="w-64 bg-[#001d33] text-[#c2e7ff] flex flex-col fixed inset-y-0 left-0 z-40">
        <div className="p-6 border-b border-white/10 flex items-center gap-3">
          <span className="p-2 rounded bg-primary text-on-primary">
            <Mail className="w-5 h-5" />
          </span>
          <div>
            <h1 className="font-headline text-md font-bold text-white tracking-tight leading-none">MarginEdge</h1>
            <span className="text-[10px] text-white/60 tracking-wider font-bold uppercase">Gmail Gateway</span>
          </div>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-1.5">
          <button 
            onClick={() => onNavigate('LIVE_SYNC_DASHBOARD')}
            className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold hover:bg-white/10 transition-colors"
          >
            <Layers className="w-4 h-4" />
            <span>Live Sync Status</span>
          </button>
          
          {(userPosition === 'Admin' || userPosition === 'AM') && (
            <button 
              onClick={() => onNavigate('PRECISION_OPS_DASHBOARD')}
              className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold hover:bg-white/10 transition-colors"
            >
              <FileText className="w-4 h-4" />
              <span>Invoice Manager</span>
            </button>
          )}

          <button 
            onClick={() => onNavigate('DETAILED_PORTFOLIO_LOGS')}
            className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold hover:bg-white/10 transition-colors"
          >
            <Layers className="w-4 h-4" />
            <span>Detailed Portfolio Logs</span>
          </button>

          {(userPosition === 'Admin' || userPosition === 'Team Lead' || userPosition === 'Lead') && (
            <button 
              onClick={() => onNavigate('ANALYST_QUALITY_DASHBOARD')}
              className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold hover:bg-white/10 transition-colors"
            >
              <FileText className="w-4 h-4" />
              <span>Scoring Analytics</span>
            </button>
          )}

          <button 
            onClick={() => onNavigate('GOOGLE_CHAT_DASHBOARD')}
            className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold hover:bg-white/10 transition-colors"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Google Chat Team</span>
          </button>

          {(userPosition === 'Admin' || userPosition === 'AM' || userPosition === 'Team Lead' || userPosition === 'Lead') && (
            <button 
              onClick={() => onNavigate('PRESENTATION_DECK')}
              className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold bg-gradient-to-r from-indigo-500/10 to-purple-500/10 text-purple-300 hover:from-indigo-500/20 transition-colors border-l-2 border-purple-500"
            >
              <Layers className="w-4 h-4" />
              <span>Presentation & Video</span>
            </button>
          )}

          <div className="pt-4 border-t border-white/10 my-4">
            <span className="text-[9px] font-bold text-white/40 uppercase tracking-widest px-3 block mb-2">Conversion Utilities</span>
            <button 
              onClick={() => onNavigate('EXCEL_PARSER_UTILITY')}
              className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-black hover:bg-white/10 text-white/90 transition-colors"
            >
              <FileSpreadsheet className="w-4 h-4 text-[#2997ff]" />
              <span>Excel to JSON Tool</span>
            </button>
          </div>

          <div className="pt-4 border-t border-white/10 my-4">
            <span className="text-[9px] font-bold text-white/40 uppercase tracking-widest px-3 block mb-2">Connected Integration</span>
            <button 
              className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold bg-[#004a77] text-white transition-colors"
            >
              <Mail className="w-4 h-4" />
              <span>Gmail Inbox Sync</span>
            </button>
          </div>
        </nav>

        {/* Google User Profile card or SignIn Button */}
        <div className="p-4 border-t border-white/10 bg-black/20">
          {!needsAuth && googleUser ? (
            <div className="space-y-3">
              <div className="flex items-center gap-2.5">
                {googleUser.photoURL ? (
                  <img 
                    src={googleUser.photoURL} 
                    alt={googleUser.displayName || 'Profile'} 
                    className="w-9 h-9 rounded-full border border-white/20"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-9 h-9 rounded-full bg-primary text-on-primary flex items-center justify-center font-bold text-xs uppercase">
                    {googleUser.displayName?.charAt(0) || googleUser.email?.charAt(0)}
                  </div>
                )}
                <div className="overflow-hidden">
                  <p className="text-[11px] font-bold text-white truncate leading-none mb-1">{googleUser.displayName || 'Google User'}</p>
                  <p className="text-[9px] text-[#c2e7ff]/70 truncate font-mono">{googleUser.email}</p>
                </div>
              </div>
              <button 
                onClick={handleGoogleLogout}
                className="w-full flex items-center justify-center gap-1.5 py-1.5 px-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded text-[10px] uppercase tracking-wider transition-all cursor-pointer"
              >
                <LogOut className="w-3 h-3" />
                <span>Disconnect Google</span>
              </button>
            </div>
          ) : (
            <div className="py-2 text-center">
              <p className="text-[10px] text-white/50 mb-2">Google Sync Disabled</p>
              <button
                onClick={handleGoogleLogin}
                className="w-full py-1.5 px-3 bg-[#0081c5] hover:bg-[#009bf0] text-white font-bold rounded text-[10px] uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Mail className="w-3.5 h-3.5" />
                <span>Sync Google</span>
              </button>
            </div>
          )}
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 pl-64 flex flex-col min-h-screen">
        {/* Top Header navbar */}
        <header className="h-16 bg-white border-b border-[#c1c7d2] flex items-center justify-between px-6 sticky top-0 z-30">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-3">
              <h2 className="text-lg font-bold text-on-surface font-headline flex items-center gap-2">
                <Mail className="w-5 h-5 text-primary" />
                <span>Gmail Workspace Gateway</span>
              </h2>
              <div className="flex items-center gap-1.5 bg-[#eff4ff] px-2.5 py-1 rounded-full border border-[#c1c7d2]">
                <span className={`w-2 h-2 rounded-full ${token ? 'bg-[#006d37] animate-pulse' : 'bg-red-500'}`}></span>
                <span className="text-[10px] text-on-surface-variant font-bold uppercase tracking-wider">
                  {token ? 'Gmail Integrated' : 'OAuth Connection Required'}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 bg-[#f0f4f9] px-2.5 py-1 rounded-full border border-[#e1e4e9]">
              <span className={`w-2 h-2 rounded-full ${isWsConnected ? 'bg-[#006d37] animate-pulse' : 'bg-orange-500'}`}></span>
              <span className="text-[9px] text-[#414752] font-bold uppercase tracking-wider">
                {isWsConnected ? 'Ledger Sync: Connected' : 'Ledger Sync: Offline'}
              </span>
            </div>

            <div className="flex items-center gap-3 pl-2 border-l border-outline-variant">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-bold text-[#191c20]">{userName || 'Ankit Thakur'}</p>
                <p className="text-[10px] text-on-surface-variant font-medium">{userPosition || 'Lead'}</p>
              </div>
              <div className="w-9 h-9 rounded-full bg-primary text-on-primary flex items-center justify-center font-bold text-xs uppercase shadow-sm">
                {userName ? userName.split(' ').map(n => n[0]).join('').slice(0, 2) : 'AT'}
              </div>
            </div>
          </div>
        </header>

        {/* Screen Content */}
        <div className="p-6 flex-1 flex flex-col">
          {/* Toast Alert */}
          {toastMessage && (
            <div className="fixed bottom-6 right-6 z-50 bg-[#003256] text-white py-3 px-5 rounded-lg shadow-2xl flex items-center gap-2.5 border border-white/10 text-xs font-semibold animate-fade-in animate-bounce">
              <CheckCircle2 className="w-4.5 h-4.5 text-green-400" />
              <span>{toastMessage}</span>
            </div>
          )}

          {needsAuth ? (
            /* Connection Portal Screen if oauth not yet fully linked */
            <div className="flex-1 flex flex-col items-center justify-center py-12 max-w-2xl mx-auto text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-6">
                <Mail className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold font-headline text-[#191c20] mb-2">Connect Gmail to Audit Ledger</h3>
              <p className="text-sm text-[#414752] mb-8 max-w-md leading-relaxed">
                Connect your professional Google Workspace or Gmail account to instantly stream incoming vendor invoices, correspondence, and transaction notifications straight into MarginEdge.
              </p>

              <div className="bg-white rounded-xl shadow-sm border border-[#c1c7d2] p-8 w-full max-w-md">
                <h4 className="text-xs font-bold text-[#191c20] uppercase tracking-widest mb-6">Authorize Integration</h4>
                
                {error && (
                  <div className="bg-red-50 border border-red-200 text-red-700 p-3.5 rounded text-xs mb-5 flex items-start gap-2 text-left">
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{error}</span>
                  </div>
                )}

                <button
                  onClick={handleGoogleLogin}
                  disabled={isLoggingIn}
                  className="w-full flex items-center justify-center gap-3 py-3 px-4 bg-primary text-on-primary font-bold rounded-lg hover:opacity-95 transition-all text-xs uppercase tracking-wider cursor-pointer shadow-sm disabled:opacity-50"
                >
                  <Mail className="w-4.5 h-4.5" />
                  <span>{isLoggingIn ? 'Connecting...' : 'Authorize Gmail Account'}</span>
                </button>

                <p className="text-[10px] text-[#414752] mt-4 leading-relaxed">
                  MarginEdge uses the official Google OAuth consent flow. Your connection tokens are cached securely in-memory and deleted immediately when you log out. We protect user privacy.
                </p>
              </div>
            </div>
          ) : (
            /* Gmail Connected View - Premium split view mail client */
            <div className="flex-1 flex flex-col min-h-[500px]">
              
              {/* Toolbar & Search row */}
              <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
                <form onSubmit={searchSubmit} className="flex-1 max-w-lg flex items-center">
                  <div className="relative w-full">
                    <input
                      type="text"
                      placeholder="Search email inbox (e.g. from:US Foods, is:unread, invoice)..."
                      className="w-full pl-10 pr-4 py-2 bg-white border border-[#c1c7d2] rounded-lg text-xs text-on-surface focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-all shadow-sm placeholder-[#414752]/50 h-10"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                    <Search className="w-4 h-4 text-[#414752]/50 absolute left-3.5 top-3" />
                  </div>
                  <button
                    type="submit"
                    className="ml-2 bg-[#e1e4e9] hover:bg-[#d0d3d8] text-[#191c20] px-4 py-2 rounded-lg text-xs font-bold transition-all h-10 cursor-pointer"
                  >
                    Search
                  </button>
                </form>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleRefresh}
                    disabled={loading}
                    className="bg-white hover:bg-slate-50 text-[#191c20] border border-[#c1c7d2] p-2.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm cursor-pointer disabled:opacity-50"
                    title="Refresh Inbox"
                  >
                    <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                    <span className="hidden sm:inline">Refresh</span>
                  </button>
                  
                  <button
                    onClick={() => setShowComposeModal(true)}
                    className="bg-primary hover:opacity-95 text-on-primary px-4 py-2.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm cursor-pointer font-headline"
                  >
                    <Plus className="w-4.5 h-4.5" />
                    <span>Compose Email</span>
                  </button>
                </div>
              </div>

              {/* Gmail Auto-Sync status control panel */}
              <div className="bg-[#edf7ed] border border-[#c1e2c1] rounded-xl p-4 mb-6 flex flex-col gap-4 text-left shadow-sm">
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-[#4caf50]/10 text-[#2e7d32] rounded-lg">
                      <RefreshCw className={`w-5 h-5 ${isAutoSyncingInProgress ? 'animate-spin' : ''}`} />
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-[#1b5e20] flex items-center gap-1.5">
                        <span>Gmail Excel Auto-Sync: Active & Running</span>
                        <span className="inline-block w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                      </h3>
                      <p className="text-[11px] text-[#2e7d32] mt-0.5 font-medium leading-relaxed">
                        Incoming emails containing Excel reports are automatically parsed and written to Firestore. No manual intervention required.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0">
                    <div className="bg-white/80 border border-[#c1e2c1] px-3 py-1.5 rounded-lg text-[10px] font-mono text-[#1b5e20] flex flex-col items-end justify-center">
                      <span className="font-bold">Total Imported Sheets: {processedAttachmentIds.length}</span>
                      <span>Polling Interval: Active (45s)</span>
                    </div>
                  </div>
                </div>

                {autoSyncingList.length > 0 && (
                  <div className="bg-white border border-[#c1e2c1]/40 rounded-lg p-3">
                    <p className="text-[10px] font-bold text-[#1b5e20] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                      <FileSpreadsheet className="w-3.5 h-3.5" />
                      <span>Auto-Imported Spreadsheets Activity Log</span>
                    </p>
                    <div className="max-h-24 overflow-y-auto space-y-1 divide-y divide-slate-100">
                      {autoSyncingList.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between py-1.5 text-[11px]">
                          <span className="font-semibold text-slate-800 truncate max-w-[280px]" title={item.filename}>
                            {item.filename}
                          </span>
                          <span className="text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded font-mono font-bold shrink-0 text-[10px]">
                            +{item.count} rows synced ({item.date})
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Split View Panel */}
              <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 bg-white border border-[#c1c7d2] rounded-xl overflow-hidden min-h-[500px] shadow-sm">
                
                {/* Inbox Left Column (5 columns on large screen) */}
                <div className="lg:col-span-5 border-r border-[#c1c7d2] flex flex-col max-h-[600px] overflow-y-auto">
                  <div className="bg-[#f0f4f9] px-4 py-3 border-b border-[#c1c7d2] flex flex-col gap-2.5 shrink-0">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-[#191c20] uppercase tracking-wider flex items-center gap-2">
                        <Inbox className="w-4 h-4 text-primary" />
                        <span>Inbox Messages ({filteredMessages.length})</span>
                      </span>
                      <span className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full font-bold">Live</span>
                    </div>

                    {/* Auto-Detect IPA Filters */}
                    <div className="grid grid-cols-2 gap-1 bg-slate-200/50 p-0.5 rounded-lg border border-slate-200">
                      <button
                        onClick={() => setGmailFilter('all')}
                        className={`py-1 rounded-md text-[10px] font-bold transition-all cursor-pointer text-center ${
                          gmailFilter === 'all'
                            ? 'bg-white text-primary shadow-sm border border-slate-200/30'
                            : 'text-[#414752] hover:text-[#191c20]'
                        }`}
                      >
                        All ({messages.length})
                      </button>
                      <button
                        onClick={() => setGmailFilter('ipa')}
                        className={`py-1 rounded-md text-[10px] font-bold transition-all cursor-pointer text-center flex items-center justify-center gap-1 ${
                          gmailFilter === 'ipa'
                            ? 'bg-[#854d0e] text-white shadow-sm'
                            : 'text-[#414752] hover:text-[#191c20]'
                        }`}
                        title="Automatically detect Invoice Processing Accuracy & Excel attachment emails"
                      >
                        <span>🎯 IPA Reports</span>
                        {ipaMessagesCount > 0 && (
                          <span className={`px-1.5 py-0.2 rounded-full text-[9px] font-extrabold leading-none ${
                            gmailFilter === 'ipa' ? 'bg-white text-[#854d0e]' : 'bg-[#854d0e] text-white'
                          }`}>
                            {ipaMessagesCount}
                          </span>
                        )}
                      </button>
                    </div>
                  </div>

                  {loading ? (
                    <div className="flex-1 flex flex-col items-center justify-center py-16 space-y-3">
                      <RefreshCw className="w-8 h-8 text-primary animate-spin" />
                      <p className="text-xs text-[#414752] font-semibold">Streaming emails from Google API...</p>
                    </div>
                  ) : filteredMessages.length === 0 ? (
                    <div className="flex-1 flex flex-col items-center justify-center py-20 text-center px-6">
                      <Mail className="w-10 h-10 text-slate-300 mb-2" />
                      <p className="text-xs font-bold text-[#191c20] mb-1">No emails found</p>
                      <p className="text-[11px] text-[#414752] max-w-[200px]">
                        {gmailFilter === 'ipa' 
                          ? 'No IPA or Spreadsheet reports automatically detected in this view.' 
                          : 'Try searching with a different keyword or clicking Refresh.'}
                      </p>
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-100 flex-1 overflow-y-auto">
                      {filteredMessages.map((msg) => (
                        <div
                          key={msg.id}
                          onClick={() => handleSelectMessage(msg)}
                          className={`p-4 hover:bg-slate-50 transition-all cursor-pointer text-left relative ${
                            selectedMessage?.id === msg.id 
                              ? 'bg-[#f0f4f9] border-l-4 border-primary' 
                              : ''
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2 mb-1.5">
                            <span className="text-xs font-bold text-[#191c20] truncate max-w-[180px]">
                              {msg.from.split('<')[0].trim() || 'Unknown'}
                            </span>
                            <span className="text-[9px] text-[#414752] font-semibold shrink-0">
                              {new Date(msg.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                            </span>
                          </div>
                          
                          <h4 className="text-xs font-semibold text-[#191c20] mb-1 truncate">
                            {msg.subject}
                          </h4>
                          
                          <p className="text-[11px] text-[#414752] line-clamp-2 leading-snug">
                            {msg.snippet}
                          </p>

                          <div className="flex flex-wrap gap-1 mt-2">
                            {msg.labels.includes('UNREAD') && (
                              <span className="bg-[#006d37]/10 text-[#006d37] text-[8px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider">Unread</span>
                            )}
                            {isIPAMessage(msg) && (
                              <span className="bg-[#854d0e]/10 text-[#854d0e] text-[8px] font-extrabold px-1.5 py-0.5 rounded uppercase tracking-wider flex items-center gap-0.5 border border-[#854d0e]/10">
                                <span>🎯</span> IPA REPORT
                              </span>
                            )}
                            {msg.attachments && msg.attachments.length > 0 && (
                              <span className="bg-[#004a77]/10 text-[#004a77] text-[8px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider flex items-center gap-1 border border-[#004a77]/10">
                                <FileSpreadsheet className="w-2.5 h-2.5 text-[#004a77]" />
                                {msg.attachments.length} Excel/File
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Email Detail Right Column (7 columns) */}
                <div className="lg:col-span-7 flex flex-col max-h-[600px] bg-slate-50/50">
                  {selectedMessage ? (
                    <div className="flex flex-col flex-1 overflow-hidden">
                      {/* Action headers */}
                      <div className="bg-white border-b border-[#c1c7d2] px-6 py-3 flex items-center justify-between gap-3 shrink-0">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={handleInitiateReply}
                            className="bg-[#e1e4e9] hover:bg-[#d0d3d8] text-[#191c20] px-3 py-1.5 rounded text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer"
                          >
                            <Send className="w-3.5 h-3.5 text-primary" />
                            <span>Reply</span>
                          </button>
                          
                          <button
                            onClick={() => handleArchiveEmail(selectedMessage)}
                            className="bg-white hover:bg-slate-50 text-[#191c20] border border-[#c1c7d2] px-3 py-1.5 rounded text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer"
                          >
                            <Archive className="w-3.5 h-3.5 text-slate-500" />
                            <span>Archive</span>
                          </button>

                          <button
                            onClick={() => handleTrashEmail(selectedMessage)}
                            className="bg-white hover:bg-red-50 text-red-600 border border-red-200 px-3 py-1.5 rounded text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5 text-red-500" />
                            <span>Delete</span>
                          </button>
                        </div>

                        <button
                          onClick={handleInitiateSync}
                          className="bg-[#006d37] hover:bg-[#005a2d] text-white px-3 py-1.5 rounded text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer font-headline shadow-sm"
                        >
                          <PlusCircle className="w-3.5 h-3.5" />
                          <span>Sync to Ledger</span>
                        </button>
                      </div>

                      {/* Message Meta card */}
                      <div className="bg-white border-b border-slate-100 p-6 shrink-0 text-left">
                        <h3 className="text-base font-bold text-[#191c20] font-headline mb-4 leading-snug">
                          {selectedMessage.subject}
                        </h3>

                        <div className="flex items-start justify-between gap-4 text-xs text-[#414752]">
                          <div className="space-y-1">
                            <div>
                              <span className="font-bold text-[#191c20]">From:</span> {selectedMessage.from}
                            </div>
                            <div>
                              <span className="font-semibold">To:</span> {selectedMessage.to}
                            </div>
                          </div>
                          <div className="text-right shrink-0">
                            <div className="font-semibold text-[#191c20]">{selectedMessage.date}</div>
                          </div>
                        </div>
                      </div>

                      {/* Attachments Section */}
                      {selectedMessage.attachments && selectedMessage.attachments.length > 0 && (
                        <div className="bg-[#f0f4f9] border-b border-[#c1c7d2] px-6 py-3 text-left">
                          <h4 className="text-[10px] font-bold text-[#414752] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                            <FileSpreadsheet className="w-3.5 h-3.5 text-primary" />
                            <span>Attachments ({selectedMessage.attachments.length})</span>
                          </h4>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {selectedMessage.attachments.map((attachment) => {
                              const isExcel = attachment.filename.endsWith('.xlsx') || attachment.filename.endsWith('.xls');
                              return (
                                <div 
                                  key={attachment.id}
                                  className="bg-white border border-[#c1c7d2] rounded-lg p-2.5 flex items-center justify-between gap-3 shadow-xs hover:border-primary/50 transition-all"
                                >
                                  <div className="flex items-center gap-2 overflow-hidden">
                                    <FileSpreadsheet className={`w-8 h-8 shrink-0 ${isExcel ? 'text-[#006d37]' : 'text-slate-400'}`} />
                                    <div className="overflow-hidden text-left">
                                      <p className="text-[11px] font-bold text-[#191c20] truncate" title={attachment.filename}>
                                        {attachment.filename}
                                      </p>
                                      <p className="text-[9px] text-slate-500 font-medium">
                                        {(attachment.size / 1024).toFixed(1)} KB
                                      </p>
                                    </div>
                                  </div>

                                  <div className="flex gap-1 shrink-0">
                                    {isExcel && (
                                      <button
                                        onClick={() => handleParseAttachment(selectedMessage, attachment)}
                                        disabled={downloadingAttachmentId !== null}
                                        className="bg-[#006d37] hover:bg-[#005a2d] text-white p-1.5 rounded text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer disabled:opacity-50"
                                        title="Parse & Sync spreadsheet data directly"
                                      >
                                        <span>Parse</span>
                                      </button>
                                    )}
                                    <button
                                      onClick={() => handleDownloadAttachment(selectedMessage, attachment)}
                                      disabled={downloadingAttachmentId !== null}
                                      className="bg-slate-100 hover:bg-slate-200 text-[#191c20] border border-slate-300 p-1.5 rounded text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer disabled:opacity-50"
                                      title="Download attachment file"
                                    >
                                      {downloadingAttachmentId === attachment.id ? '...' : 'Download'}
                                    </button>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Message Body inside safe iframe container */}
                      <div className="flex-1 p-6 overflow-y-auto bg-white">
                        {selectedMessage.body ? (
                          <iframe
                            title="Email Body Preview"
                            sandbox="allow-same-origin"
                            srcDoc={`
                              <!DOCTYPE html>
                              <html>
                                <head>
                                  <style>
                                    body {
                                      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                                      font-size: 13px;
                                      line-height: 1.6;
                                      color: #333333;
                                      margin: 0;
                                      padding: 0;
                                    }
                                    a { color: #0081c5; text-decoration: none; }
                                    a:hover { text-decoration: underline; }
                                  </style>
                                </head>
                                <body>
                                  ${selectedMessage.body}
                                </body>
                              </html>
                            `}
                            className="w-full h-full min-h-[300px] border-0"
                          />
                        ) : (
                          <div className="text-xs text-[#191c20] whitespace-pre-wrap leading-relaxed text-left">
                            {selectedMessage.snippet}
                          </div>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="flex-1 flex flex-col items-center justify-center p-12 text-center text-[#414752]">
                      <Mail className="w-12 h-12 text-slate-300 mb-3" />
                      <h4 className="text-sm font-bold text-[#191c20] mb-1">No Email Selected</h4>
                      <p className="text-xs max-w-xs leading-relaxed">
                        Select an email from the inbox list to read the full body, initiate a reply, or sync invoice details directly to your precision ledger.
                      </p>
                    </div>
                  )}
                </div>

              </div>
            </div>
          )}
        </div>
      </main>

      {/* 1. Compose Draft modal */}
      {showComposeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-[#c1c7d2] w-full max-w-2xl overflow-hidden flex flex-col">
            <div className="bg-[#001d33] text-white p-4 flex items-center justify-between">
              <h3 className="font-headline text-sm font-bold flex items-center gap-2">
                <Send className="w-4.5 h-4.5" />
                <span>Compose New Message</span>
              </h3>
              <button 
                onClick={() => setShowComposeModal(false)}
                className="text-white/70 hover:text-white transition-opacity cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSendEmail} className="p-6 space-y-4 text-left">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-[#414752] mb-1.5">To Recipient</label>
                <input
                  type="email"
                  placeholder="recipient@company.com"
                  className="w-full px-3 py-2 border border-[#c1c7d2] rounded text-xs focus:ring-1 focus:ring-primary focus:outline-none placeholder-slate-400"
                  required
                  value={composeForm.to}
                  onChange={(e) => setComposeForm({ ...composeForm, to: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-[#414752] mb-1.5">Subject</label>
                <input
                  type="text"
                  placeholder="Invoice inquiry, request for ledger sync..."
                  className="w-full px-3 py-2 border border-[#c1c7d2] rounded text-xs focus:ring-1 focus:ring-primary focus:outline-none placeholder-slate-400"
                  required
                  value={composeForm.subject}
                  onChange={(e) => setComposeForm({ ...composeForm, subject: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-[#414752] mb-1.5">Email Message Body</label>
                <textarea
                  rows={8}
                  placeholder="Write message contents here..."
                  className="w-full px-3 py-2 border border-[#c1c7d2] rounded text-xs font-sans focus:ring-1 focus:ring-primary focus:outline-none placeholder-slate-400 leading-relaxed"
                  required
                  value={composeForm.body}
                  onChange={(e) => setComposeForm({ ...composeForm, body: e.target.value })}
                />
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowComposeModal(false)}
                  className="px-4 py-2 border border-[#c1c7d2] rounded text-xs font-bold text-[#191c20] hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSending}
                  className="px-5 py-2 bg-primary text-on-primary rounded text-xs font-bold hover:opacity-95 transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSending ? 'Sending...' : 'Send Email'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 2. Sync to Ledger Form Modal */}
      {showSyncModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-[#c1c7d2] w-full max-w-md overflow-hidden flex flex-col">
            <div className="bg-[#006d37] text-white p-4 flex items-center justify-between">
              <h3 className="font-headline text-sm font-bold flex items-center gap-2">
                <PlusCircle className="w-4.5 h-4.5" />
                <span>Sync Email Invoice to Ledger</span>
              </h3>
              <button 
                onClick={() => setShowSyncModal(false)}
                className="text-white/70 hover:text-white transition-opacity cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConfirmSync} className="p-6 space-y-4 text-left">
              <p className="text-xs text-[#414752] leading-relaxed mb-2 bg-slate-50 p-3 rounded border border-slate-100">
                You are exporting the metadata extracted from this email directly into the live, real-time portfolio logs of MarginEdge Precision.
              </p>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-[#414752] mb-1.5">Assign Analyst</label>
                <select
                  className="w-full px-3 py-2 border border-[#c1c7d2] rounded bg-white text-xs focus:ring-1 focus:ring-primary focus:outline-none"
                  value={syncForm.analyst}
                  onChange={(e) => setSyncForm({ ...syncForm, analyst: e.target.value })}
                >
                  <option value="Alex Rivera">Alex Rivera</option>
                  <option value="Jordan Vance">Jordan Vance</option>
                  <option value="Taylor Brooks">Taylor Brooks</option>
                  <option value="Morgan Chen">Morgan Chen</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-[#414752] mb-1.5">Vendor Name</label>
                <input
                  type="text"
                  placeholder="e.g. US Foods"
                  className="w-full px-3 py-2 border border-[#c1c7d2] rounded text-xs focus:ring-1 focus:ring-primary focus:outline-none"
                  required
                  value={syncForm.vendor}
                  onChange={(e) => setSyncForm({ ...syncForm, vendor: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-[#414752] mb-1.5">Task Type</label>
                  <select
                    className="w-full px-3 py-2 border border-[#c1c7d2] rounded bg-white text-xs focus:ring-1 focus:ring-primary focus:outline-none"
                    value={syncForm.taskType}
                    onChange={(e) => setSyncForm({ ...syncForm, taskType: e.target.value })}
                  >
                    <option value="Invoice">Invoice</option>
                    <option value="Credit Memo">Credit Memo</option>
                    <option value="Audit Task">Audit Task</option>
                    <option value="Statement">Statement</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-[#414752] mb-1.5">Target Accuracy %</label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="99.5"
                    className="w-full px-3 py-2 border border-[#c1c7d2] rounded text-xs focus:ring-1 focus:ring-primary focus:outline-none"
                    value={syncForm.accuracy}
                    onChange={(e) => setSyncForm({ ...syncForm, accuracy: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-[#414752] mb-1.5">Document Date</label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-[#c1c7d2] rounded text-xs focus:ring-1 focus:ring-primary focus:outline-none"
                  value={syncForm.date}
                  onChange={(e) => setSyncForm({ ...syncForm, date: e.target.value })}
                />
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowSyncModal(false)}
                  className="px-4 py-2 border border-[#c1c7d2] rounded text-xs font-bold text-[#191c20] hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#006d37] text-white rounded text-xs font-bold hover:bg-[#005a2d] transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <Check className="w-4 h-4" />
                  <span>Verify & Sync</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3. Excel Spreadsheet Parser Preview Modal */}
      {showExcelPreviewModal && parsedExcelRows && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-[#c1c7d2] w-full max-w-4xl overflow-hidden flex flex-col max-h-[85vh]">
            <div className="bg-[#001d33] text-white p-4 flex items-center justify-between shrink-0">
              <h3 className="font-headline text-sm font-bold flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-green-300" />
                <span>Spreadsheet Data Stream Preview — {previewFilename}</span>
              </h3>
              <button 
                onClick={() => {
                  setShowExcelPreviewModal(false);
                  setParsedExcelRows(null);
                }}
                className="text-white/70 hover:text-white transition-opacity cursor-pointer animate-pulse"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto flex-1 text-left space-y-4">
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wide mb-1">Spreadsheet Audit & Auto-Mapping</h4>
                  <p className="text-[11px] text-slate-500 leading-relaxed max-w-xl">
                    MarginEdge has parsed <b>{parsedExcelRows.length}</b> records from this attachment. Check columns to confirm live synchronization mapping.
                  </p>
                </div>
                <button
                  onClick={handleSyncParsedRows}
                  className="bg-[#006d37] hover:bg-[#005a2d] text-white px-5 py-2.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-md shrink-0 uppercase tracking-wider"
                >
                  <Check className="w-4 h-4" />
                  <span>Sync all {parsedExcelRows.length} rows to Ledger</span>
                </button>
              </div>

              {/* Parsed spreadsheet grid preview */}
              <div className="border border-slate-200 rounded-lg overflow-hidden bg-white shadow-xs">
                <div className="overflow-x-auto max-h-[45vh]">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-100/85 border-b border-slate-200 text-slate-700 uppercase text-[10px] tracking-wider sticky top-0 font-bold">
                        {Object.keys(parsedExcelRows[0] || {}).map((header, idx) => (
                          <th key={idx} className="p-3 whitespace-nowrap border-r border-slate-200/50">
                            {header}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-600">
                      {parsedExcelRows.slice(0, 15).map((row, rowIdx) => (
                        <tr key={rowIdx} className="hover:bg-slate-50 transition-colors">
                          {Object.values(row || {}).map((val: any, valIdx) => (
                            <td key={valIdx} className="p-3 border-r border-slate-100 truncate max-w-xs font-medium">
                              {typeof val === 'object' ? JSON.stringify(val) : String(val)}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {parsedExcelRows.length > 15 && (
                  <div className="p-3 bg-slate-50 border-t border-slate-200 text-center text-[10px] text-slate-500 font-semibold uppercase tracking-wider">
                    + Showing first 15 of {parsedExcelRows.length} total spreadsheet records
                  </div>
                )}
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-[#c1c7d2] flex items-center justify-end shrink-0 gap-3">
              <button
                type="button"
                onClick={() => {
                  setShowExcelPreviewModal(false);
                  setParsedExcelRows(null);
                }}
                className="px-4 py-2 border border-slate-300 rounded text-xs font-bold text-slate-700 bg-white hover:bg-slate-100 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSyncParsedRows}
                className="px-5 py-2 bg-[#006d37] text-white rounded text-xs font-bold hover:bg-[#005a2d] transition-colors cursor-pointer flex items-center gap-1 shadow-xs"
              >
                <Check className="w-4 h-4" />
                <span>Confirm Sync</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
