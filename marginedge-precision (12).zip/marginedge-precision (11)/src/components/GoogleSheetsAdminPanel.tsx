import React, { useState, useEffect } from 'react';
import { 
  FileSpreadsheet, RefreshCw, Save, CheckCircle, AlertTriangle, Info, Clock, ExternalLink, ShieldCheck, Play, HelpCircle
} from 'lucide-react';

interface GoogleSheetSetting {
  id: string;
  name: string;
  spreadsheetId: string;
  worksheetName: string;
  enabled: boolean;
  lastSyncTime?: string;
  status?: 'success' | 'error' | 'idle';
  error?: string | null;
}

interface SyncLog {
  id: string;
  timestamp: string;
  target: string;
  type: 'info' | 'success' | 'error';
  message: string;
}

export default function GoogleSheetsAdminPanel() {
  const [settings, setSettings] = useState<GoogleSheetSetting[]>([]);
  const [logs, setLogs] = useState<SyncLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [syncingId, setSyncingId] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  // Form states cached by setting ID
  const [formStates, setFormStates] = useState<Record<string, { spreadsheetId: string, worksheetName: string, enabled: boolean }>>({});

  useEffect(() => {
    fetchSettingsAndLogs();
    
    // Set periodic logs pooling every 8 seconds to show auto sync in real-time
    const interval = setInterval(() => {
      fetchLogs();
    }, 8000);

    return () => clearInterval(interval);
  }, []);

  const fetchSettingsAndLogs = async () => {
    setLoading(true);
    try {
      const [settingsRes, logsRes] = await Promise.all([
        fetch('/api/sheets/settings'),
        fetch('/api/sheets/logs')
      ]);

      const settingsData = await settingsRes.json();
      const logsData = await logsRes.json();

      if (settingsData.success) {
        setSettings(settingsData.settings);
        
        // Populate initial form states
        const initialForms: typeof formStates = {};
        settingsData.settings.forEach((s: GoogleSheetSetting) => {
          initialForms[s.id] = {
            spreadsheetId: s.spreadsheetId || '',
            worksheetName: s.worksheetName || 'Sheet1',
            enabled: !!s.enabled
          };
        });
        setFormStates(initialForms);
      }

      if (logsData.success) {
        setLogs(logsData.logs);
      }
    } catch (err) {
      console.error("Error fetching sheet settings:", err);
    } finally {
      setLoading(false);
    }
  };

  const fetchLogs = async () => {
    try {
      const res = await fetch('/api/sheets/logs');
      const data = await res.json();
      if (data.success) {
        setLogs(data.logs);
      }
    } catch (err) {
      console.warn("Silent logs refresh failed", err);
    }
  };

  const handleInputChange = (id: string, field: 'spreadsheetId' | 'worksheetName', value: string) => {
    setFormStates(prev => ({
      ...prev,
      [id]: {
        ...prev[id],
        [field]: value
      }
    }));
  };

  const handleToggleChange = (id: string, value: boolean) => {
    setFormStates(prev => ({
      ...prev,
      [id]: {
        ...prev[id],
        enabled: value
      }
    }));
  };

  const saveSetting = async (id: string) => {
    const form = formStates[id];
    if (!form) return;

    setStatusMessage(null);
    try {
      // Extract spreadsheetId if they pasted a full Google Sheets URL
      let cleanId = form.spreadsheetId.trim();
      const match = cleanId.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
      if (match) {
        cleanId = match[1];
        // Auto-update input field value
        handleInputChange(id, 'spreadsheetId', cleanId);
      }

      const res = await fetch('/api/sheets/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id,
          spreadsheetId: cleanId,
          worksheetName: form.worksheetName.trim() || 'Sheet1',
          enabled: form.enabled
        })
      });

      const data = await res.json();
      if (data.success) {
        setStatusMessage({ type: 'success', text: `Successfully saved connection parameters for "${data.setting.name}".` });
        // Refresh settings from server
        const settingsRes = await fetch('/api/sheets/settings');
        const settingsData = await settingsRes.json();
        if (settingsData.success) {
          setSettings(settingsData.settings);
        }
        fetchLogs();
      } else {
        setStatusMessage({ type: 'error', text: data.message || 'Failed to save settings.' });
      }
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: err.message || 'An error occurred while saving.' });
    }
  };

  const triggerManualSync = async (id: string) => {
    setSyncingId(id);
    setStatusMessage(null);
    try {
      // Check if client has a Google Sheets OAuth token in localStorage or cookie
      const googleToken = localStorage.getItem('google_access_token') || undefined;

      const res = await fetch(`/api/sheets/sync/${id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accessToken: googleToken })
      });

      const data = await res.json();
      if (data.success) {
        setStatusMessage({ 
          type: 'success', 
          text: `Synchronization complete! ${data.message}` 
        });
        
        // Refresh settings state
        const settingsRes = await fetch('/api/sheets/settings');
        const settingsData = await settingsRes.json();
        if (settingsData.success) {
          setSettings(settingsData.settings);
        }
        fetchLogs();
      } else {
        setStatusMessage({ 
          type: 'error', 
          text: `Sync Failed: ${data.message || 'Make sure the sheet is shared or authorized.'}` 
        });
      }
    } catch (err: any) {
      setStatusMessage({ 
        type: 'error', 
        text: `Sync Error: ${err.message || 'Network communication failure.'}` 
      });
    } finally {
      setSyncingId(null);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <RefreshCw className="w-10 h-10 text-indigo-500 animate-spin mb-4" />
        <p className="text-sm font-bold text-slate-600 dark:text-slate-400">Loading synchronization console...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Upper Status Banner */}
      <div className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-10 -translate-y-10 w-96 h-96 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider">
                System Administration
              </span>
              <span className="flex items-center gap-1 bg-green-500/20 text-green-300 border border-green-500/30 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider animate-pulse">
                <ShieldCheck className="w-3 h-3" />
                Secure Credentials
              </span>
            </div>
            <h1 className="text-2xl font-bold font-headline tracking-tight">Google Sheets Connection Center</h1>
            <p className="text-xs text-slate-300 max-w-xl">
              Configure robust direct synchronization. All updates are loaded immediately, parsed in the background, validated, and pushed in real-time across all user dashboards without page reload.
            </p>
          </div>
          
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={fetchSettingsAndLogs}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-lg transition-all cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Refresh Console
            </button>
          </div>
        </div>
      </div>

      {statusMessage && (
        <div className={`p-4 rounded-xl flex items-start gap-3 border transition-all ${
          statusMessage.type === 'success' 
            ? 'bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800 text-green-800 dark:text-green-300' 
            : 'bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800 text-red-800 dark:text-red-300'
        }`}>
          {statusMessage.type === 'success' ? (
            <CheckCircle className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
          )}
          <div className="text-xs">
            <p className="font-bold">{statusMessage.type === 'success' ? 'Settings Saved Successfully' : 'Action Failed'}</p>
            <p className="opacity-90 mt-0.5">{statusMessage.text}</p>
          </div>
        </div>
      )}

      {/* Guide Block */}
      <div className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex items-start gap-3.5">
        <Info className="w-5 h-5 text-indigo-500 shrink-0 mt-0.5" />
        <div className="text-xs space-y-1">
          <p className="font-bold text-slate-800 dark:text-slate-100">Direct-to-Sheets Connection Instructions</p>
          <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
            1. Copy the Spreadsheet ID from your Google Sheet URL (the text between <code className="bg-slate-200 dark:bg-slate-800 px-1 py-0.5 rounded text-indigo-600 font-bold">/spreadsheets/d/</code> and <code className="bg-slate-200 dark:bg-slate-800 px-1 py-0.5 rounded text-indigo-600 font-bold">/edit</code>).
            <br />
            2. Share your Google Sheet so that <strong className="text-slate-800 dark:text-slate-200 font-semibold">"Anyone with the link can view"</strong>, OR login using Google Workspace SSO credentials.
            <br />
            3. Save settings first, then click <strong className="text-indigo-600 font-semibold">"Sync Now"</strong> to execute the pipeline.
          </p>
        </div>
      </div>

      {/* Connection Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {settings.map((setting) => {
          const form = formStates[setting.id] || { spreadsheetId: '', worksheetName: 'Sheet1', enabled: false };
          const isSyncing = syncingId === setting.id;

          return (
            <div key={setting.id} className="bg-white dark:bg-[#111827] rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col hover:shadow-md transition-all">
              
              {/* Header */}
              <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-50 dark:bg-indigo-950/60 rounded-xl text-indigo-600 dark:text-indigo-400">
                    <FileSpreadsheet className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-slate-800 dark:text-slate-100 font-headline">{setting.name}</h2>
                    <p className="text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-widest mt-0.5">Target Module</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {setting.status === 'success' && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-green-50 dark:bg-green-950/40 text-green-700 dark:text-green-400 border border-green-200 dark:border-green-900">
                      <CheckCircle className="w-3 h-3" /> Connected
                    </span>
                  )}
                  {setting.status === 'error' && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-400 border border-red-200 dark:border-red-900">
                      <AlertTriangle className="w-3 h-3" /> Sync Failed
                    </span>
                  )}
                  {(!setting.status || setting.status === 'idle') && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
                      Disconnected
                    </span>
                  )}
                </div>
              </div>

              {/* Form Content */}
              <div className="p-5 flex-1 space-y-4">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                    Google Spreadsheet ID or URL
                  </label>
                  <input
                    type="text"
                    placeholder="Enter full URL or sheet ID..."
                    value={form.spreadsheetId}
                    onChange={(e) => handleInputChange(setting.id, 'spreadsheetId', e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 focus:border-indigo-500 rounded-xl py-2 px-3 text-xs focus:outline-none text-slate-800 dark:text-slate-100 font-semibold"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                      Worksheet / Tab Name
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Sheet1"
                      value={form.worksheetName}
                      onChange={(e) => handleInputChange(setting.id, 'worksheetName', e.target.value)}
                      className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 focus:border-indigo-500 rounded-xl py-2 px-3 text-xs focus:outline-none text-slate-800 dark:text-slate-100 font-semibold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                      Background Auto-Sync (30s)
                    </label>
                    <div className="flex items-center h-[34px]">
                      <button
                        type="button"
                        onClick={() => handleToggleChange(setting.id, !form.enabled)}
                        className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                          form.enabled ? 'bg-indigo-600' : 'bg-slate-200 dark:bg-slate-800'
                        }`}
                      >
                        <span
                          className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                            form.enabled ? 'translate-x-5' : 'translate-x-0'
                          }`}
                        />
                      </button>
                      <span className="text-[11px] font-bold ml-2.5 text-slate-700 dark:text-slate-300">
                        {form.enabled ? 'Active' : 'Disabled'}
                      </span>
                    </div>
                  </div>
                </div>

                {setting.spreadsheetId && (
                  <div className="pt-2 flex items-center justify-between text-[11px] border-t border-slate-100 dark:border-slate-800">
                    <span className="text-slate-400 dark:text-slate-500 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      Last Synced: {setting.lastSyncTime ? new Date(setting.lastSyncTime).toLocaleString() : 'Never'}
                    </span>
                    <a 
                      href={`https://docs.google.com/spreadsheets/d/${setting.spreadsheetId}`} 
                      target="_blank" 
                      rel="noreferrer"
                      className="text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-0.5 font-bold"
                    >
                      Open Sheet <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                )}

                {setting.status === 'error' && setting.error && (
                  <div className="p-3 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900 rounded-xl text-[10px] text-red-700 dark:text-red-400 leading-relaxed font-semibold">
                    ❌ {setting.error}
                  </div>
                )}
              </div>

              {/* Action Bar */}
              <div className="p-4 bg-slate-50 dark:bg-[#111827]/30 border-t border-slate-100 dark:border-slate-800/80 flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => saveSetting(setting.id)}
                  className="flex-1 flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs py-2 px-3 rounded-xl transition-all shadow-sm hover:shadow cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  Save Settings
                </button>

                <button
                  type="button"
                  disabled={!setting.spreadsheetId || isSyncing}
                  onClick={() => triggerManualSync(setting.id)}
                  className={`flex-1 flex items-center justify-center gap-2 font-bold text-xs py-2 px-3 rounded-xl border transition-all ${
                    !setting.spreadsheetId 
                      ? 'border-slate-200 dark:border-slate-800 text-slate-300 dark:text-slate-700 cursor-not-allowed'
                      : 'border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer'
                  }`}
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                  {isSyncing ? 'Syncing...' : 'Sync Now'}
                </button>
              </div>

            </div>
          );
        })}
      </div>

      {/* Audit Log / Event Logs */}
      <div className="bg-white dark:bg-[#111827] rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-slate-400 text-[20px]">history</span>
            <h2 className="text-sm font-bold text-slate-800 dark:text-slate-100 font-headline">Audit Synchronization Logs</h2>
          </div>
          <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500">Auto-Refreshes Live</span>
        </div>

        <div className="p-4 max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/80">
          {logs.length === 0 ? (
            <div className="py-12 text-center text-slate-400 dark:text-slate-500 text-xs">
              <Clock className="w-8 h-8 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
              No synchronization audit events recorded yet.
            </div>
          ) : (
            logs.map((log) => (
              <div key={log.id} className="py-3 flex items-start justify-between gap-4 text-xs">
                <div className="flex items-start gap-3">
                  <span className={`w-2 h-2 rounded-full shrink-0 mt-1.5 ${
                    log.type === 'success' ? 'bg-green-500' :
                    log.type === 'error' ? 'bg-red-500' : 'bg-blue-500'
                  }`} />
                  <div>
                    <p className="font-semibold text-slate-700 dark:text-slate-300 leading-normal">{log.message}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="bg-slate-100 dark:bg-slate-800/80 px-1.5 py-0.5 rounded text-[9px] font-bold text-slate-500 dark:text-slate-400 uppercase">
                        Target: {log.target}
                      </span>
                      <span className="text-[10px] text-slate-400 dark:text-slate-500 font-semibold">
                        {new Date(log.timestamp).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

    </div>
  );
}
