import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  googleSignIn, 
  getAccessToken, 
  logout, 
  initAuth 
} from '../lib/googleAuth';
import { 
  listChatSpaces, 
  listChatMessages, 
  sendChatMessage, 
  listChatMembers, 
  createChatSpace, 
  GoogleChatSpace, 
  GoogleChatMessage, 
  GoogleChatMembership 
} from '../lib/chatService';
import { useRealtime } from '../context/RealtimeContext';
import { 
  MessageSquare, 
  Send, 
  Users, 
  RefreshCw, 
  Search, 
  Plus, 
  X, 
  User, 
  ArrowLeft, 
  AlertCircle, 
  CheckCircle2, 
  Layers, 
  LogOut, 
  Check, 
  PlusCircle, 
  FileSpreadsheet, 
  FileText, 
  Volume2, 
  Sparkles, 
  Info 
} from 'lucide-react';

interface GoogleChatDashboardProps {
  userEmail: string;
  userName?: string;
  userPosition?: string;
  onNavigate: (view: any) => void;
  onLogout: () => void;
}

export default function GoogleChatDashboard({ 
  userEmail, 
  userName, 
  userPosition, 
  onNavigate, 
  onLogout 
}: GoogleChatDashboardProps) {
  // Auth States
  const [googleUser, setGoogleUser] = useState<any | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [needsAuth, setNeedsAuth] = useState(true);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // API Data States
  const [spaces, setSpaces] = useState<GoogleChatSpace[]>([]);
  const [activeSpace, setActiveSpace] = useState<GoogleChatSpace | null>(null);
  const [messages, setMessages] = useState<GoogleChatMessage[]>([]);
  const [members, setMembers] = useState<GoogleChatMembership[]>([]);
  const [spaceSearchQuery, setSpaceSearchQuery] = useState('');
  
  // Loading & Action States
  const [loadingSpaces, setLoadingSpaces] = useState(false);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [loadingMembers, setLoadingMembers] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [isCreatingSpace, setIsCreatingSpace] = useState(false);
  
  // Form Input States
  const [newMessageText, setNewMessageText] = useState('');
  const [newSpaceName, setNewSpaceName] = useState('');
  const [showCreateSpaceModal, setShowCreateSpaceModal] = useState(false);
  
  // Security & Confirmation
  const [showConfirmSendModal, setShowConfirmSendModal] = useState(false);
  const [messageToConfirm, setMessageToConfirm] = useState('');
  
  // UI Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Realtime Ledger Context to retrieve statistics for templates
  const { reconciliationRecords, ipaRecords } = useRealtime();

  const messageEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll messages list
  useEffect(() => {
    messageEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Initial Auth listener
  useEffect(() => {
    const unsubscribe = initAuth(
      (user, cachedToken) => {
        setGoogleUser(user);
        setToken(cachedToken);
        setNeedsAuth(false);
        fetchSpaces(cachedToken);
      },
      () => {
        setGoogleUser(null);
        setToken(null);
        setNeedsAuth(true);
      }
    );
    return () => unsubscribe();
  }, []);

  // Fetch Spaces
  const fetchSpaces = async (accessToken: string) => {
    setLoadingSpaces(true);
    setError(null);
    try {
      const fetchedSpaces = await listChatSpaces(accessToken);
      setSpaces(fetchedSpaces);
      
      // Auto-select first space if available and none selected
      if (fetchedSpaces.length > 0 && !activeSpace) {
        handleSelectSpace(fetchedSpaces[0], accessToken);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to retrieve Google Chat Spaces.');
    } finally {
      setLoadingSpaces(false);
    }
  };

  // Fetch Messages & Members for active space
  const fetchSpaceDetails = async (space: GoogleChatSpace, accessToken: string) => {
    setLoadingMessages(true);
    setLoadingMembers(true);
    try {
      // Run in parallel
      const [fetchedMessages, fetchedMembers] = await Promise.all([
        listChatMessages(accessToken, space.name).catch(() => []),
        listChatMembers(accessToken, space.name).catch(() => [])
      ]);

      // Sort messages chronologically (Google Chat can return them in mixed order depending on thread)
      const sortedMessages = [...fetchedMessages].sort(
        (a, b) => new Date(a.createTime).getTime() - new Date(b.createTime).getTime()
      );

      setMessages(sortedMessages);
      setMembers(fetchedMembers);
    } catch (err: any) {
      console.error(err);
      showToast('Error loading space messages or memberships.');
    } finally {
      setLoadingMessages(false);
      setLoadingMembers(false);
    }
  };

  const handleSelectSpace = (space: GoogleChatSpace, currentToken?: string) => {
    setActiveSpace(space);
    const apiToken = currentToken || token || getAccessToken();
    if (apiToken) {
      fetchSpaceDetails(space, apiToken);
    }
  };

  const handleGoogleLogin = async () => {
    setIsLoggingIn(true);
    setError(null);
    try {
      const result = await googleSignIn();
      if (result) {
        setGoogleUser(result.user);
        setToken(result.accessToken);
        setNeedsAuth(false);
        fetchSpaces(result.accessToken);
        showToast('Successfully authenticated with Google Workspace!');
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to authenticate Google account.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleGoogleLogout = async () => {
    try {
      await logout();
      setGoogleUser(null);
      setToken(null);
      setSpaces([]);
      setActiveSpace(null);
      setMessages([]);
      setMembers([]);
      setNeedsAuth(true);
      showToast('Google account disconnected successfully.');
    } catch (err) {
      console.error('Logout failed:', err);
    }
  };

  // Toast System
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Message Send Workflow
  const triggerSendMessage = () => {
    if (!newMessageText.trim() || !activeSpace) return;
    
    // Set message text in security confirmation flow
    setMessageToConfirm(newMessageText.trim());
    setShowConfirmSendModal(true);
  };

  const confirmAndSendMessage = async () => {
    const apiToken = token || getAccessToken();
    if (!apiToken || !activeSpace || !messageToConfirm) return;

    setIsSending(true);
    setShowConfirmSendModal(false);
    try {
      const sentMessage = await sendChatMessage(apiToken, activeSpace.name, messageToConfirm);
      
      // Append and reset
      setMessages(prev => [...prev, sentMessage]);
      setNewMessageText('');
      setMessageToConfirm('');
      showToast('Message broadcasted to Google Chat!');
    } catch (err: any) {
      console.error(err);
      alert(`Failed to send message to Google Chat: ${err.message}`);
    } finally {
      setIsSending(false);
    }
  };

  // Create Space Workflow
  const handleCreateSpaceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSpaceName.trim()) return;

    const apiToken = token || getAccessToken();
    if (!apiToken) return;

    setIsCreatingSpace(true);
    try {
      const created = await createChatSpace(apiToken, newSpaceName.trim());
      setSpaces(prev => [created, ...prev]);
      setActiveSpace(created);
      setNewSpaceName('');
      setShowCreateSpaceModal(false);
      showToast(`Created Space "${created.displayName}" successfully!`);
      
      // Fetch details
      fetchSpaceDetails(created, apiToken);
    } catch (err: any) {
      console.error(err);
      alert(`Failed to create space: ${err.message}`);
    } finally {
      setIsCreatingSpace(false);
    }
  };

  // Quick Share Preset Templates
  const handleApplyTemplate = (type: 'accuracy' | 'status' | 'alert') => {
    const matchedCount = reconciliationRecords.filter(r => r.status === 'MATCHED').length;
    const pendingCount = reconciliationRecords.filter(r => r.status === 'PENDING').length;
    const totalRecords = reconciliationRecords.length;
    const avgAccuracy = totalRecords > 0 
      ? (reconciliationRecords.reduce((acc, curr) => acc + (100 - curr.errorPercentage), 0) / totalRecords).toFixed(1)
      : '99.5';

    let draftedText = '';
    
    if (type === 'accuracy') {
      draftedText = `🎯 *MarginEdge Invoice Processing Accuracy Report*
📅 Date: ${new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
📊 Performance Statistics:
- Total Reconciled Invoices: *${totalRecords}*
- Successfully Matched: *${matchedCount}*
- Pending Verification: *${pendingCount}*
- Current Average Team Precision Accuracy: *${avgAccuracy}%*

🚀 *Great job team! Let's keep the precision standards high!*`;
    } else if (type === 'status') {
      draftedText = `⚡ *MarginEdge System Sync Gateways: Live Status Update*
🌐 Connection Status: *Real-Time Connected*
📧 Active Channels:
- Gmail Sync Integration: *ONLINE*
- Ledger Database Sync: *SYNCHRONIZED*
- Active Analysts On-Duty: *${ipaRecords.length} Users*

🔄 Live synchronization is currently active. Any client-uploaded spreadsheets are parsed and mapped on-the-fly.`;
    } else if (type === 'alert') {
      draftedText = `⚠️ *MarginEdge Action Required: Invoice Exception Alerts*
Our auto-parsing engine has detected unresolved ledger mismatches in the active queue:
📌 Outstanding exceptions pending manual analyst audit: *${pendingCount} records*

👉 Please access the *MarginEdge Live Sync Panel* to verify records and resolve status mismatches as soon as possible.`;
    }

    setNewMessageText(draftedText);
    showToast('Template layout applied to draft!');
  };

  // Filter Spaces
  const filteredSpaces = useMemo(() => {
    return spaces.filter(space => 
      space.displayName?.toLowerCase().includes(spaceSearchQuery.toLowerCase())
    );
  }, [spaces, spaceSearchQuery]);

  return (
    <div className="bg-[#f8f9ff] text-on-background font-sans min-h-screen relative flex">
      {/* Left Navigation Sidebar */}
      <aside className="w-64 bg-[#001d33] text-[#c2e7ff] flex flex-col fixed inset-y-0 left-0 z-40 shadow-xl">
        {/* App Logo */}
        <div className="p-6 border-b border-white/10 flex items-center gap-3">
          <span className="p-2 rounded bg-primary text-on-primary">
            <MessageSquare className="w-5 h-5" />
          </span>
          <div>
            <h1 className="font-headline text-md font-bold text-white tracking-tight leading-none">MarginEdge</h1>
            <span className="text-[10px] text-white/60 tracking-wider font-bold uppercase">Google Chat Spaces</span>
          </div>
        </div>

        {/* Navigation Section */}
        <nav className="flex-1 px-4 py-4 flex flex-col overflow-y-auto">
          {/* Main Views navigation */}
          <div className="space-y-1">
            <button 
              onClick={() => onNavigate('LIVE_SYNC_DASHBOARD')}
              className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold hover:bg-white/10 transition-colors text-left"
            >
              <Layers className="w-4 h-4 text-white/70" />
              <span>Live Sync Status</span>
            </button>

            {(userPosition === 'Admin' || userPosition === 'AM') && (
              <button 
                onClick={() => onNavigate('PRECISION_OPS_DASHBOARD')}
                className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold hover:bg-white/10 transition-colors text-left"
              >
                <FileText className="w-4 h-4 text-white/70" />
                <span>Invoice Manager</span>
              </button>
            )}
            
            <button 
              onClick={() => onNavigate('DETAILED_PORTFOLIO_LOGS')}
              className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold hover:bg-white/10 transition-colors text-left"
            >
              <Layers className="w-4 h-4 text-white/70" />
              <span>Detailed Portfolio Logs</span>
            </button>

            {(userPosition === 'Admin' || userPosition === 'AM') && (
              <button 
                onClick={() => onNavigate('GMAIL_DASHBOARD')}
                className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold hover:bg-white/10 transition-colors text-left"
              >
                <FileText className="w-4 h-4 text-white/70" />
                <span>Gmail Sync Gateway</span>
              </button>
            )}

            {(userPosition === 'Admin' || userPosition === 'Team Lead' || userPosition === 'Lead') && (
              <button 
                onClick={() => onNavigate('ANALYST_QUALITY_DASHBOARD')}
                className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold hover:bg-white/10 transition-colors text-left text-white/70"
              >
                <FileText className="w-4 h-4" />
                <span>Scoring Analytics</span>
              </button>
            )}

            {(userPosition === 'Admin' || userPosition === 'AM' || userPosition === 'Team Lead' || userPosition === 'Lead') && (
              <button 
                onClick={() => onNavigate('PRESENTATION_DECK')}
                className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold bg-gradient-to-r from-indigo-500/10 to-purple-500/10 text-purple-300 hover:from-indigo-500/20 transition-colors border-l-2 border-purple-500 text-left"
              >
                <Layers className="w-4 h-4" />
                <span>Presentation & Video</span>
              </button>
            )}

            <button 
              onClick={() => onNavigate('EXCEL_PARSER_UTILITY')}
              className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold hover:bg-white/10 transition-colors text-left"
            >
              <FileSpreadsheet className="w-4 h-4 text-[#2997ff]" />
              <span>Excel to JSON Tool</span>
            </button>
          </div>

          {/* Connected Active Section */}
          <div className="pt-4 border-t border-white/10 my-4">
            <span className="text-[9px] font-bold text-white/40 uppercase tracking-widest px-3 block mb-2">Connected Integration</span>
            <button 
              className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold bg-[#004a77] text-white transition-colors text-left"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Google Chat Channels</span>
            </button>
          </div>

          {/* List of active rooms / spaces */}
          {!needsAuth && spaces.length > 0 && (
            <div className="flex-1 flex flex-col min-h-0">
              <div className="flex items-center justify-between px-3 mb-2">
                <span className="text-[9px] font-bold text-white/40 uppercase tracking-widest">Active Spaces ({filteredSpaces.length})</span>
                <button 
                  onClick={() => setShowCreateSpaceModal(true)}
                  className="text-white hover:text-primary transition-all p-0.5 rounded cursor-pointer"
                  title="Create a new Google Chat Space"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>

              {/* Spaces Search Bar */}
              <div className="px-2 mb-2 shrink-0">
                <div className="relative">
                  <input 
                    type="text" 
                    placeholder="Search channels..."
                    value={spaceSearchQuery}
                    onChange={(e) => setSpaceSearchQuery(e.target.value)}
                    className="w-full bg-black/30 border border-white/10 text-white placeholder-white/30 rounded px-2.5 py-1.5 pl-8 text-[11px] focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all"
                  />
                  <Search className="w-3.5 h-3.5 text-white/30 absolute left-2.5 top-2" />
                </div>
              </div>

              {/* Spaces List Scrollable */}
              <div className="flex-1 overflow-y-auto space-y-1 pr-1 custom-scrollbar min-h-[120px]">
                {loadingSpaces ? (
                  <div className="py-4 text-center">
                    <RefreshCw className="w-4 h-4 animate-spin mx-auto text-white/50" />
                  </div>
                ) : filteredSpaces.length === 0 ? (
                  <p className="text-[10px] text-white/40 text-center py-4">No matching spaces.</p>
                ) : (
                  filteredSpaces.map((space) => {
                    const isSelected = activeSpace?.name === space.name;
                    return (
                      <button
                        key={space.name}
                        onClick={() => handleSelectSpace(space)}
                        className={`w-full flex items-center gap-2 px-3 py-2 rounded text-left transition-all ${
                          isSelected 
                            ? 'bg-primary text-on-primary font-bold font-sans' 
                            : 'text-[#c2e7ff]/80 hover:bg-white/5 hover:text-white'
                        }`}
                      >
                        <span className="text-[14px] shrink-0">#</span>
                        <span className="text-[11px] truncate leading-tight flex-1">
                          {space.displayName || 'Unnamed Space'}
                        </span>
                      </button>
                    );
                  })
                )}
              </div>
            </div>
          )}
        </nav>

        {/* Google User Profile card or SignIn Button */}
        <div className="p-4 border-t border-white/10 bg-black/20 shrink-0">
          {!needsAuth && googleUser ? (
            <div className="space-y-3">
              <div className="flex items-center gap-2.5 overflow-hidden">
                {googleUser.photoURL ? (
                  <img 
                    src={googleUser.photoURL} 
                    alt={googleUser.displayName || 'Profile'} 
                    className="w-9 h-9 rounded-full border border-white/20 shrink-0"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-9 h-9 rounded-full bg-primary text-on-primary flex items-center justify-center font-bold text-xs uppercase shrink-0">
                    {googleUser.displayName?.charAt(0) || googleUser.email?.charAt(0)}
                  </div>
                )}
                <div className="overflow-hidden text-left">
                  <p className="text-[11px] font-bold text-white truncate leading-none mb-1">
                    {googleUser.displayName || 'Google User'}
                  </p>
                  <p className="text-[9px] text-[#c2e7ff]/70 truncate font-mono">{googleUser.email}</p>
                </div>
              </div>
              <button 
                onClick={handleGoogleLogout}
                className="w-full flex items-center justify-center gap-1.5 py-1.5 px-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded text-[10px] uppercase tracking-wider transition-all cursor-pointer"
              >
                <LogOut className="w-3 h-3" />
                <span>Disconnect Google</span>
              </button>
            </div>
          ) : (
            <div className="py-2 text-center">
              <p className="text-[10px] text-white/50 mb-2">Google Sync Disabled</p>
              <button
                onClick={handleGoogleLogin}
                className="w-full py-1.5 px-3 bg-[#0081c5] hover:bg-[#009bf0] text-white font-bold rounded text-[10px] uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Authorize Google Chat</span>
              </button>
            </div>
          )}
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 pl-64 flex flex-col min-h-screen">
        {/* Top Header navbar */}
        <header className="h-16 bg-white border-b border-[#c1c7d2] flex items-center justify-between px-6 sticky top-0 z-30">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-3">
              <h2 className="text-lg font-bold text-on-surface font-headline flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-primary" />
                <span>Google Chat Dashboard</span>
              </h2>
              <div className="flex items-center gap-1.5 bg-[#eff4ff] px-2.5 py-1 rounded-full border border-[#c1c7d2]">
                <span className={`w-2 h-2 rounded-full ${token ? 'bg-[#006d37] animate-pulse' : 'bg-red-500'}`}></span>
                <span className="text-[10px] text-on-surface-variant font-bold uppercase tracking-wider">
                  {token ? 'Google Chat Workspace Sync Active' : 'OAuth Connection Required'}
                </span>
              </div>
            </div>
          </div>

          {/* User Role & Position indicator */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-bold text-[#191c20]">{userName || 'Ankit Thakur'}</p>
                <p className="text-[10px] text-on-surface-variant font-medium">{userPosition || 'Lead'}</p>
              </div>
              <div className="w-9 h-9 rounded-full bg-primary text-on-primary flex items-center justify-center font-bold text-xs uppercase shadow-sm">
                {userName ? userName.split(' ').map(n => n[0]).join('').slice(0, 2) : 'AT'}
              </div>
            </div>
          </div>
        </header>

        {/* Main Interface Content Canvas */}
        <div className="p-6 flex-1 flex flex-col">
          {/* Toast Alert popups */}
          {toastMessage && (
            <div className="fixed bottom-6 right-6 z-50 bg-[#003256] text-white py-3 px-5 rounded-lg shadow-2xl flex items-center gap-2.5 border border-white/10 text-xs font-semibold animate-fade-in">
              <CheckCircle2 className="w-4.5 h-4.5 text-green-400 animate-pulse" />
              <span>{toastMessage}</span>
            </div>
          )}

          {needsAuth ? (
            /* Connection Portal Screen if OAuth not yet linked */
            <div className="flex-1 flex flex-col items-center justify-center py-12 max-w-2xl mx-auto text-center space-y-6">
              <div className="w-16 h-16 rounded-full bg-primary/10 text-primary flex items-center justify-center">
                <MessageSquare className="w-8 h-8 animate-bounce" />
              </div>
              <div>
                <h3 className="text-xl font-bold font-headline text-[#191c20] mb-2">Connect Google Chat to Coordinate Reports</h3>
                <p className="text-sm text-[#414752] leading-relaxed max-w-md">
                  Collaborate in real-time. Link your corporate Google Workspace profile to broadcast ledger status updates, invoice precision metrics, and daily exception alerts to your team channels immediately.
                </p>
              </div>

              <div className="bg-white rounded-xl shadow-md border border-[#c1c7d2] p-8 w-full max-w-md">
                <h4 className="text-xs font-bold text-[#191c20] uppercase tracking-widest mb-6">Authorize Integration</h4>
                
                {error && (
                  <div className="bg-red-50 border border-red-200 text-red-700 p-3.5 rounded text-xs mb-5 flex items-start gap-2 text-left">
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{error}</span>
                  </div>
                )}

                <button
                  onClick={handleGoogleLogin}
                  disabled={isLoggingIn}
                  className="w-full flex items-center justify-center gap-3 py-3 px-4 bg-primary text-on-primary font-bold rounded-lg hover:opacity-95 transition-all text-xs uppercase tracking-wider cursor-pointer shadow-sm disabled:opacity-50"
                >
                  <MessageSquare className="w-4.5 h-4.5" />
                  <span>{isLoggingIn ? 'Connecting...' : 'Authorize Google Chat Access'}</span>
                </button>
              </div>
            </div>
          ) : (
            /* Connected View Grid */
            <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch max-h-[calc(100vh-140px)]">
              
              {/* Chat Conversation Thread: Left/Center Column (8 columns) */}
              <div className="lg:col-span-8 bg-white rounded-xl border border-[#c1c7d2] shadow-sm flex flex-col overflow-hidden min-h-[500px]">
                
                {/* Active Space Info Bar Header */}
                <div className="bg-[#f0f4f9] px-6 py-4 border-b border-[#c1c7d2] flex items-center justify-between shrink-0">
                  <div className="text-left">
                    <h3 className="text-xs font-bold text-[#191c20] uppercase tracking-wider flex items-center gap-2">
                      <span className="text-primary text-md">#</span>
                      <span>{activeSpace ? activeSpace.displayName : 'Select a Channel'}</span>
                    </h3>
                    <p className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider mt-0.5">
                      {activeSpace ? `${activeSpace.spaceType} Space` : 'Please select or create a space to start collaborating'}
                    </p>
                  </div>
                  
                  <div className="flex items-center gap-2.5">
                    {activeSpace && (
                      <span className="text-[10px] bg-emerald-50 text-[#006d37] border border-emerald-200 font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        <span>{members.length} Members</span>
                      </span>
                    )}

                    <button
                      onClick={() => activeSpace && token && fetchSpaceDetails(activeSpace, token)}
                      disabled={!activeSpace || loadingMessages}
                      className="bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 p-2 rounded-lg transition-all cursor-pointer disabled:opacity-50"
                      title="Refresh current message thread"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${loadingMessages ? 'animate-spin text-primary' : ''}`} />
                    </button>
                  </div>
                </div>

                {/* Message Threads area */}
                <div className="flex-1 p-6 overflow-y-auto bg-slate-50/50 flex flex-col space-y-4">
                  {loadingMessages ? (
                    <div className="flex-1 flex flex-col items-center justify-center py-24 text-center">
                      <RefreshCw className="w-8 h-8 text-primary animate-spin mb-3" />
                      <p className="text-xs text-[#414752] font-semibold">Streaming messages from Google Chat API...</p>
                    </div>
                  ) : !activeSpace ? (
                    <div className="flex-1 flex flex-col items-center justify-center text-center max-w-md mx-auto py-24">
                      <MessageSquare className="w-12 h-12 text-slate-300 mb-3 animate-pulse" />
                      <h4 className="text-sm font-bold text-[#191c20] mb-1">Select a Collaborative Space</h4>
                      <p className="text-xs text-[#414752] leading-relaxed">
                        To post audits, reconciliation statistics, or check daily logs with your colleagues, click on a channel in the left panel or create a new space.
                      </p>
                    </div>
                  ) : messages.length === 0 ? (
                    <div className="flex-1 flex flex-col items-center justify-center text-center max-w-sm mx-auto py-16">
                      <MessageSquare className="w-10 h-10 text-slate-300 mb-3" />
                      <h4 className="text-xs font-bold text-[#191c20] mb-1">Welcome to #{activeSpace.displayName}</h4>
                      <p className="text-[11px] text-[#414752] leading-relaxed">
                        No messages have been posted in this space yet. Be the first to start the conversation by drafting a report!
                      </p>
                    </div>
                  ) : (
                    messages.map((msg, idx) => {
                      const isMe = msg.sender?.displayName?.toLowerCase() === googleUser?.displayName?.toLowerCase() || 
                                   msg.sender?.name?.includes('users/me');
                      const senderInitial = msg.sender?.displayName?.charAt(0) || 'A';
                      const messageTime = msg.createTime 
                        ? new Date(msg.createTime).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
                        : 'Just now';

                      return (
                        <div 
                          key={msg.name || idx} 
                          className={`flex items-start gap-3 text-left max-w-[85%] ${isMe ? 'self-end flex-row-reverse text-right' : 'self-start'}`}
                        >
                          {/* Sender Avatar */}
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs shrink-0 select-none ${
                            isMe ? 'bg-[#004a77] text-white shadow-xs' : 'bg-[#e1e4e9] text-[#191c20]'
                          }`}>
                            {senderInitial}
                          </div>

                          {/* Speech Bubble Container */}
                          <div className="space-y-1">
                            <div className={`flex items-center gap-2 ${isMe ? 'flex-row-reverse' : ''}`}>
                              <span className="text-[10px] font-bold text-slate-700">
                                {isMe ? 'You' : (msg.sender?.displayName || 'Teammate')}
                              </span>
                              <span className="text-[8px] text-slate-400 font-medium">
                                {messageTime}
                              </span>
                            </div>

                            <div className={`p-3 rounded-xl border text-xs leading-relaxed whitespace-pre-wrap ${
                              isMe 
                                ? 'bg-[#eff4ff] border-[#c1c7d2] text-slate-900 rounded-tr-none' 
                                : 'bg-white border-[#e1e4e9] text-slate-800 rounded-tl-none shadow-xs'
                            }`}>
                              {/* Parse bold text helper e.g. *bold* -> <strong> */}
                              {msg.text ? (
                                msg.text.split('\n').map((line, lIdx) => (
                                  <p key={lIdx}>
                                    {line.split('*').map((part, pIdx) => 
                                      pIdx % 2 === 1 ? <strong key={pIdx} className="font-extrabold">{part}</strong> : part
                                    )}
                                  </p>
                                ))
                              ) : (
                                <span className="italic text-slate-400">Empty message</span>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                  <div ref={messageEndRef} />
                </div>

                {/* Text Compose Area */}
                {activeSpace && (
                  <div className="p-4 border-t border-[#c1c7d2] bg-white shrink-0">
                    <form 
                      onSubmit={(e) => {
                        e.preventDefault();
                        triggerSendMessage();
                      }}
                      className="flex items-end gap-3"
                    >
                      <div className="flex-1 relative">
                        <textarea
                          placeholder={`Compose markdown message to #${activeSpace.displayName}... Use *bold* for emphasis.`}
                          rows={2}
                          value={newMessageText}
                          onChange={(e) => setNewMessageText(e.target.value)}
                          className="w-full bg-[#f0f4f9] border border-slate-300 rounded-lg p-3 text-xs placeholder-slate-400 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary focus:bg-white transition-all text-left resize-none"
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' && !e.shiftKey) {
                              e.preventDefault();
                              triggerSendMessage();
                            }
                          }}
                        />
                      </div>
                      <button
                        type="submit"
                        disabled={!newMessageText.trim() || isSending}
                        className="bg-primary hover:bg-primary-high text-on-primary p-3 rounded-lg font-bold text-xs transition-all disabled:opacity-50 flex items-center justify-center cursor-pointer h-10 w-10 shadow-sm"
                        title="Draft message & verify security parameters"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    </form>
                    <p className="text-[9px] text-slate-400 text-left mt-1.5 font-medium flex items-center gap-1 select-none">
                      <Info className="w-3 h-3 text-primary shrink-0" />
                      <span>Workspace Security Policy: Broadcasters are prompted to verify content parameters prior to final dissemination.</span>
                    </p>
                  </div>
                )}
              </div>

              {/* Right Sidebar: Quick Share Preset Templates (4 columns) */}
              <div className="lg:col-span-4 flex flex-col gap-6">
                
                {/* Active Space Members List */}
                {activeSpace && (
                  <div className="bg-white rounded-xl border border-[#c1c7d2] p-5 text-left shadow-sm flex flex-col max-h-[220px]">
                    <h3 className="text-xs font-bold text-[#191c20] uppercase tracking-wider mb-3 flex items-center gap-1.5 shrink-0">
                      <Users className="w-4 h-4 text-primary" />
                      <span>Space Memberships ({members.length})</span>
                    </h3>

                    <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 custom-scrollbar">
                      {loadingMembers ? (
                        <div className="text-center py-4">
                          <RefreshCw className="w-4 h-4 animate-spin mx-auto text-primary" />
                        </div>
                      ) : members.length === 0 ? (
                        <p className="text-[10px] text-slate-500 italic">No memberships retrieved.</p>
                      ) : (
                        members.map((member, idx) => {
                          const stateColor = member.state === 'JOINED' ? 'bg-green-500' : 'bg-orange-400';
                          return (
                            <div key={member.name || idx} className="flex items-center justify-between gap-2.5">
                              <div className="flex items-center gap-2 overflow-hidden">
                                <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center font-bold text-[10px] text-slate-700 shrink-0 uppercase">
                                  {member.member?.displayName?.charAt(0) || 'M'}
                                </div>
                                <div className="overflow-hidden">
                                  <p className="text-[11px] font-bold text-slate-800 truncate leading-none">
                                    {member.member?.displayName || 'Active Member'}
                                  </p>
                                  <p className="text-[9px] text-slate-500 capitalize leading-none mt-0.5">
                                    {member.role?.replace('ROLE_', '').toLowerCase() || 'member'}
                                  </p>
                                </div>
                              </div>
                              <span className="text-[8px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded-full font-bold uppercase shrink-0">
                                Joined
                              </span>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                )}

                {/* Quick Share Preset Templates Container */}
                <div className="bg-white rounded-xl border border-[#c1c7d2] p-5 text-left shadow-sm flex-1 flex flex-col">
                  <h3 className="text-xs font-bold text-[#191c20] uppercase tracking-wider mb-1.5 flex items-center gap-1.5 shrink-0">
                    <Sparkles className="w-4 h-4 text-amber-500" />
                    <span>MarginEdge Shared Presets</span>
                  </h3>
                  <p className="text-[11px] text-slate-500 leading-relaxed mb-4 shrink-0">
                    Instantly compose synchronized updates using actual ledger metrics. Click a preset below to populate your draft, then dispatch with one key.
                  </p>

                  <div className="space-y-3 flex-1 overflow-y-auto pr-1 custom-scrollbar">
                    {/* Template 1 */}
                    <button
                      onClick={() => handleApplyTemplate('accuracy')}
                      disabled={!activeSpace}
                      className="w-full bg-[#f8f9ff] hover:bg-[#eff4ff] border border-slate-200 hover:border-primary/40 rounded-lg p-3 text-left transition-all cursor-pointer group disabled:opacity-50"
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs">🎯</span>
                        <h4 className="text-[11px] font-bold text-[#191c20] group-hover:text-primary transition-colors">
                          Accuracy Metrics Report
                        </h4>
                      </div>
                      <p className="text-[10px] text-slate-500 leading-relaxed">
                        Summarize active accuracy percentages, matched versus pending invoice count, and team audit outputs.
                      </p>
                    </button>

                    {/* Template 2 */}
                    <button
                      onClick={() => handleApplyTemplate('status')}
                      disabled={!activeSpace}
                      className="w-full bg-[#f8f9ff] hover:bg-[#eff4ff] border border-slate-200 hover:border-primary/40 rounded-lg p-3 text-left transition-all cursor-pointer group disabled:opacity-50"
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs">⚡</span>
                        <h4 className="text-[11px] font-bold text-[#191c20] group-hover:text-primary transition-colors">
                          Gateway Sync Status
                        </h4>
                      </div>
                      <p className="text-[10px] text-slate-500 leading-relaxed">
                        Broadcast live channel diagnostics (Gmail ingestion, active on-duty analysts, master database status).
                      </p>
                    </button>

                    {/* Template 3 */}
                    <button
                      onClick={() => handleApplyTemplate('alert')}
                      disabled={!activeSpace}
                      className="w-full bg-[#f8f9ff] hover:bg-[#eff4ff] border border-slate-200 hover:border-primary/40 rounded-lg p-3 text-left transition-all cursor-pointer group disabled:opacity-50"
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs">⚠️</span>
                        <h4 className="text-[11px] font-bold text-[#191c20] group-hover:text-primary transition-colors">
                          Invoice Exception Alerts
                        </h4>
                      </div>
                      <p className="text-[10px] text-slate-500 leading-relaxed">
                        Flag unresolved ledger mismatches in the active queue to trigger urgent manual teammate audits.
                      </p>
                    </button>
                  </div>
                </div>

              </div>
            </div>
          )}
        </div>
      </main>

      {/* 1. Workspace Security Confirmation Dialog Modal (MANDATORY) */}
      {showConfirmSendModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-[#c1c7d2] w-full max-w-lg overflow-hidden flex flex-col">
            <div className="bg-[#001d33] text-white p-4 flex items-center justify-between">
              <h3 className="font-headline text-sm font-bold flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-amber-400 shrink-0" />
                <span>Verify Google Chat Broadcast Content</span>
              </h3>
              <button 
                onClick={() => setShowConfirmSendModal(false)}
                className="text-white/70 hover:text-white transition-opacity cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 text-left space-y-4">
              <div className="bg-amber-50 border border-amber-200 text-amber-800 p-3.5 rounded text-xs leading-relaxed">
                <b>Workspace Action Parameter Check:</b> You are about to post a message into the Google Chat space <b>#{activeSpace?.displayName}</b> on behalf of your verified enterprise account.
              </div>

              <div>
                <h4 className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest mb-1.5">Draft Message Body</h4>
                <div className="border border-slate-200 bg-slate-50 p-4 rounded-lg text-xs text-slate-800 leading-relaxed font-mono whitespace-pre-wrap max-h-[220px] overflow-y-auto">
                  {messageToConfirm}
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-[#c1c7d2] flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowConfirmSendModal(false)}
                className="px-4 py-2 border border-slate-300 rounded text-xs font-bold text-slate-700 bg-white hover:bg-slate-100 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmAndSendMessage}
                disabled={isSending}
                className="px-5 py-2 bg-primary text-on-primary rounded text-xs font-bold hover:opacity-95 transition-all cursor-pointer flex items-center gap-1.5 shadow-md"
              >
                {isSending ? 'Transmitting...' : 'Confirm & Disseminate'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. Create Space Modal */}
      {showCreateSpaceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-[#c1c7d2] w-full max-w-md overflow-hidden flex flex-col animate-fade-in">
            <div className="bg-[#001d33] text-white p-4 flex items-center justify-between">
              <h3 className="font-headline text-sm font-bold flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-primary shrink-0" />
                <span>Create New Google Chat Space</span>
              </h3>
              <button 
                onClick={() => setShowCreateSpaceModal(false)}
                className="text-white/70 hover:text-white transition-opacity cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSpaceSubmit}>
              <div className="p-6 text-left space-y-4">
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">
                    Space Display Name
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Chandigarh Invoice Processors"
                    value={newSpaceName}
                    onChange={(e) => setNewSpaceName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded p-2.5 text-xs text-slate-850 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary focus:bg-white transition-all text-left"
                    autoFocus
                  />
                  <p className="text-[10px] text-slate-500 leading-relaxed italic mt-1">
                    This space will be created in your verified Google Workspace chat workspace and will support direct teammate invites.
                  </p>
                </div>
              </div>

              <div className="p-4 bg-slate-50 border-t border-[#c1c7d2] flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowCreateSpaceModal(false)}
                  className="px-4 py-2 border border-slate-300 rounded text-xs font-bold text-slate-700 bg-white hover:bg-slate-100 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isCreatingSpace || !newSpaceName.trim()}
                  className="px-5 py-2 bg-primary text-on-primary rounded text-xs font-bold hover:opacity-95 transition-all cursor-pointer flex items-center gap-1.5"
                >
                  {isCreatingSpace ? 'Creating...' : 'Create Space'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
