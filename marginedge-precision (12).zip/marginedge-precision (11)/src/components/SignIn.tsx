import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  User, 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  ArrowRight, 
  ShieldCheck, 
  Activity, 
  TrendingUp, 
  Inbox, 
  Award,
  Sparkles,
  Layers,
  Database
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface SignInProps {
  onLogin: (email: string, name: string, position: 'Admin' | 'AM' | 'Team Lead' | 'Analyst') => void;
}

export default function SignIn({ onLogin }: SignInProps) {
  const { loginWithEmail, loginWithGoogle, simulateGoogleLogin, resetPassword } = useAuth();
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [position, setPosition] = useState<'Admin' | 'AM' | 'Team Lead' | 'Analyst'>('Analyst');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showGoogleSimulation, setShowGoogleSimulation] = useState(false);

  // Pre-configured personas for lightning fast testing and highly attractive presentation
  const personas = [
    {
      name: 'Ankit Thakur',
      email: 'ankit.thakur@marginedge.com',
      role: 'Admin' as const,
      desc: 'System & Ops Administrator',
      badge: 'Full Admin Access',
      color: 'from-purple-900 to-indigo-950'
    },
    {
      name: 'Sarah Jenkins',
      email: 'sarah.jenkins@marginedge.com',
      role: 'AM' as const,
      desc: 'Assistant Operations Manager',
      badge: 'Portfolio Management',
      color: 'from-blue-800 to-cyan-900'
    },
    {
      name: 'Vikram Singh',
      email: 'vikram.singh@marginedge.com',
      role: 'Team Lead' as const,
      desc: 'Chandigarh Hub Lead',
      badge: 'Quality & SLA Supervision',
      color: 'from-teal-800 to-emerald-900'
    },
    {
      name: 'Rahul Sharma',
      email: 'rahul.sharma@marginedge.com',
      role: 'Analyst' as const,
      desc: 'Data Entry & Reconciliation Specialist',
      badge: 'Scoring & Verification',
      color: 'from-slate-700 to-slate-900'
    }
  ];

  const handleSelectPersona = async (p: typeof personas[0]) => {
    setName(p.name);
    setEmail(p.email);
    setPosition(p.role);
    setPassword('password123'); // Preset password for persona
    setError('');
    setIsSubmitting(true);
    
    try {
      // Try standard persona login first
      await loginWithEmail(p.email, p.name, p.role as any, 'password123');
      onLogin(p.email, p.name, p.role as any);
    } catch (err: any) {
      console.warn('Standard persona login failed, attempting fallback persona email:', err);
      // If the account already exists but with a different password/auth provider (e.g. Google auth),
      // we append a +persona suffix to create a unique address under the same @marginedge.com domain.
      // This satisfies Firestore domain rules and guarantees a successful sign-in.
      const [localPart, domain] = p.email.split('@');
      const fallbackEmail = `${localPart}+persona@${domain}`;
      
      try {
        await loginWithEmail(fallbackEmail, p.name, p.role as any, 'password123');
        onLogin(fallbackEmail, p.name, p.role as any);
      } catch (fallbackErr: any) {
        console.error('Persona login completely failed:', fallbackErr);
        setError(fallbackErr.message || 'Persona login failed. Please verify that your Firebase configuration has Email/Password authentication enabled.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setError('Please enter a valid email address.');
      return;
    }
    if (!password) {
      setError('Please enter your password.');
      return;
    }
    setError('');
    setIsSubmitting(true);
    const finalName = name.trim() || email.split('@')[0];
    
    try {
      await loginWithEmail(email, finalName, position as any, password);
      onLogin(email, finalName, position);
    } catch (err: any) {
      console.error('Manual login failed:', err);
      if (err.code === 'auth/wrong-password') {
        setError('Incorrect password. Please try again.');
      } else if (err.code === 'auth/invalid-email') {
        setError('Invalid email address.');
      } else if (err.code === 'auth/weak-password') {
        setError('Password must be at least 6 characters.');
      } else {
        setError(err.message || 'Authentication failed. Please check your network or verify that your Firebase configuration has Email/Password authentication enabled.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };


  return (
    <div className="min-h-screen bg-[#f7f9ff] dark:bg-[#0b0e14] text-on-background flex lg:grid lg:grid-cols-12 overflow-x-hidden font-sans">
      
      {/* LEFT VISUAL PANEL - Modern Operations Showcase (Desktop Only) */}
      <div className="hidden lg:flex lg:col-span-5 bg-gradient-to-br from-[#002540] via-[#003256] to-[#0d538c] text-white p-12 flex-col justify-between relative overflow-hidden border-r border-[#1a2d42]">
        
        {/* Abstract Glowing Grid and Orbs */}
        <div className="absolute inset-0 opacity-15 pointer-events-none select-none">
          <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] rounded-full bg-cyan-400 blur-[100px]" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] rounded-full bg-emerald-400 blur-[100px]" />
          <div className="w-full h-full bg-[linear-gradient(rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.05)_1px,transparent_1px)] bg-[size:24px_24px]" />
        </div>

        {/* Logo and Brand */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="z-10 flex items-center space-x-3"
        >
          <div className="p-2.5 bg-white/10 backdrop-blur-md rounded-xl border border-white/20 shadow-lg">
            <Layers className="w-6 h-6 text-cyan-300" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight bg-gradient-to-r from-white via-slate-100 to-cyan-200 bg-clip-text text-transparent">
              MarginEdge
            </h1>
            <p className="text-[10px] text-cyan-200/80 uppercase tracking-widest font-bold">
              Precision-ME Ops Suite
            </p>
          </div>
        </motion.div>

        {/* Live Operations KPIs & Stats Carousel */}
        <div className="z-10 my-auto py-10 space-y-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="space-y-2"
          >
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 shadow-inner">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5 animate-pulse" />
              Live Operations Dashboard
            </span>
            <h2 className="text-3xl font-extrabold tracking-tight text-white leading-tight">
              Real-time Document Matching & Error Reconciliation
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed max-w-md">
              Harness predictive analytics, seamless Gmail routing, and precise operational auditing designed specifically for high-velocity finance teams.
            </p>
          </motion.div>

          {/* Quick Stats Grid */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="grid grid-cols-2 gap-4"
          >
            <div className="bg-white/5 backdrop-blur-sm p-4 rounded-xl border border-white/10 hover:border-white/20 transition-all shadow-md group">
              <div className="flex items-center justify-between mb-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                <span className="text-[10px] bg-cyan-400/10 text-cyan-300 px-1.5 py-0.5 rounded font-mono font-bold">99.72%</span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">Quality Rate</p>
              <h3 className="text-lg font-bold text-white group-hover:text-cyan-200 transition-colors">Excellent Target</h3>
            </div>

            <div className="bg-white/5 backdrop-blur-sm p-4 rounded-xl border border-white/10 hover:border-white/20 transition-all shadow-md group">
              <div className="flex items-center justify-between mb-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <span className="text-[10px] bg-emerald-400/10 text-emerald-300 px-1.5 py-0.5 rounded font-mono font-bold">Active</span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">Live Sync status</p>
              <h3 className="text-lg font-bold text-white group-hover:text-emerald-200 transition-colors">Real-time Stream</h3>
            </div>
          </motion.div>

          {/* Feature highlights */}
          <div className="space-y-3.5 pt-4">
            <div className="flex items-start space-x-3 text-xs text-slate-200">
              <div className="p-1 rounded-md bg-white/10 mt-0.5 text-cyan-300">
                <Database className="w-3.5 h-3.5" />
              </div>
              <div>
                <strong className="text-white">Precision Invoices:</strong> Dynamic status grids with flexible sorting & customizable export tools.
              </div>
            </div>
            <div className="flex items-start space-x-3 text-xs text-slate-200">
              <div className="p-1 rounded-md bg-white/10 mt-0.5 text-emerald-300">
                <Inbox className="w-3.5 h-3.5" />
              </div>
              <div>
                <strong className="text-white">Gmail Integration:</strong> Direct invoice extraction and automated forwarding alerts.
              </div>
            </div>
            <div className="flex items-start space-x-3 text-xs text-slate-200">
              <div className="p-1 rounded-md bg-white/10 mt-0.5 text-amber-300">
                <Award className="w-3.5 h-3.5" />
              </div>
              <div>
                <strong className="text-white">Analyst Quality Tracker:</strong> Complete metrics on productivity scores, errors, and performance heatmaps.
              </div>
            </div>
          </div>
        </div>

        {/* Small Footer Info */}
        <div className="z-10 text-xs text-slate-400 flex items-center justify-between border-t border-white/10 pt-6">
          <span>Enterprise Grade Security</span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse-dot" />
            All Systems Nominal
          </span>
        </div>
      </div>

      {/* RIGHT PANEL - Clean, High-Contrast Login Form */}
      <div className="col-span-12 lg:col-span-7 flex flex-col justify-between p-6 sm:p-12 md:p-16 relative overflow-hidden bg-white dark:bg-[#0b0e14]">
        
        {/* Single Premium Fancy Watermark */}
        <div className="absolute top-4 right-4 z-25 pointer-events-none select-none">
          <div className="relative group overflow-hidden rounded-full p-[1.5px] bg-gradient-to-r from-cyan-500 via-indigo-500 to-emerald-500 shadow-md shadow-cyan-500/10 dark:shadow-cyan-950/20">
            <div className="flex items-center gap-2 px-4.5 py-2.5 bg-white/95 dark:bg-slate-950/95 backdrop-blur-md rounded-full border border-white/20">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[11px] font-bold tracking-wider uppercase text-slate-800 dark:text-slate-200 font-mono">
                Presented the web By <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 dark:from-cyan-400 dark:via-blue-400 dark:to-indigo-400 font-extrabold">Ankit Thakur</span> <span className="px-1.5 py-0.5 rounded bg-purple-100 dark:bg-purple-950/50 text-[9px] text-purple-700 dark:text-purple-300 font-sans font-black">ADMIN</span>
              </span>
            </div>
          </div>
        </div>

        {/* Mobile Header Logo */}
        <div className="lg:hidden flex items-center justify-between mb-8 pb-4 border-b border-slate-100 dark:border-slate-800 relative z-10">
          <div className="flex items-center space-x-2">
            <div className="p-1.5 bg-primary/10 rounded-lg text-primary">
              <Layers className="w-5 h-5" />
            </div>
            <span className="font-bold text-lg text-primary tracking-tight">MarginEdge</span>
          </div>
          <span className="text-[10px] bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 font-bold px-2.5 py-0.5 rounded-full border border-emerald-100 dark:border-emerald-900/30">
            Precision Suite
          </span>
        </div>

        {/* Center Login Form Box */}
        <div className="w-full max-w-[520px] mx-auto my-auto space-y-8 py-8 relative z-10">

          {/* QUICK-ACCESS PERSONAS (Extremely satisfying, gorgeous layout) */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <span>Quick-Access Administrator Profile (Click to Log In)</span>
            </h3>
            <div className="grid grid-cols-1 gap-3">
              {personas.map((p) => (
                <button
                  key={p.name}
                  onClick={() => handleSelectPersona(p)}
                  type="button"
                  className="group flex items-center p-3 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/40 hover:border-primary/50 dark:hover:border-primary/50 hover:bg-slate-50 dark:hover:bg-slate-900/80 text-left transition-all duration-200 transform hover:scale-[1.01] hover:shadow-md cursor-pointer relative overflow-hidden"
                >
                  <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${p.color} text-white flex items-center justify-center font-bold text-xs shadow-md`}>
                    {p.name.charAt(0)}
                  </div>
                  <div className="ml-3 flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-bold text-slate-950 dark:text-white truncate">{p.name}</p>
                      <span className="text-[8px] font-bold uppercase tracking-wider text-primary/80 bg-primary/5 px-1 rounded border border-primary/10">
                        {p.role}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">{p.desc}</p>
                  </div>
                  
                  {/* Subtle right-chevron hover indicator */}
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity ml-1.5 text-primary">
                    <ArrowRight className="w-4 h-4 transform group-hover:translate-x-0.5 transition-transform" />
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Form Divider */}
          <div className="relative flex py-2 items-center">
            <div className="flex-grow border-t border-slate-200 dark:border-slate-800"></div>
            <span className="flex-shrink mx-4 text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest">
              Or Manual Sign-In
            </span>
            <div className="flex-grow border-t border-slate-200 dark:border-slate-800"></div>
          </div>

          {/* Login Card/Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="bg-red-50 dark:bg-red-950/30 text-red-600 dark:text-red-400 p-3 rounded-lg text-xs font-semibold border border-red-200 dark:border-red-900/40 flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                {error}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Full Name */}
              <div>
                <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-1.5 uppercase tracking-wider font-bold" htmlFor="name">
                  Full Name
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    className="block w-full pl-9 pr-3 py-1.5 h-10 border border-slate-200 dark:border-slate-800 rounded-xl bg-slate-50 dark:bg-slate-900/40 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all placeholder-slate-400 text-xs font-medium"
                    id="name"
                    type="text"
                    placeholder="e.g. Ankit Thakur"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
              </div>

              {/* Email */}
              <div>
                <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-1.5 uppercase tracking-wider font-bold" htmlFor="email">
                  Email Address
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    className="block w-full pl-9 pr-3 py-1.5 h-10 border border-slate-200 dark:border-slate-800 rounded-xl bg-slate-50 dark:bg-slate-900/40 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all placeholder-slate-400 text-xs font-medium"
                    id="email"
                    type="email"
                    placeholder="name@company.com"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>
            </div>

            {/* Position / Role Selector */}
            <div className="space-y-1.5">
              <label className="block text-[11px] text-slate-600 dark:text-slate-400 uppercase tracking-wider font-bold">
                Your Position / Role (Customizes View)
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(['Admin', 'AM', 'Team Lead', 'Analyst'] as const).map((role) => (
                  <button
                    key={role}
                    type="button"
                    onClick={() => setPosition(role)}
                    className={`py-2 px-2.5 border rounded-xl text-xs font-bold transition-all flex flex-col items-center justify-center gap-1 cursor-pointer text-center leading-tight ${
                      position === role
                        ? 'border-primary bg-primary/5 dark:bg-primary/20 text-primary dark:text-cyan-400 ring-2 ring-primary/20'
                        : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/20 hover:bg-slate-100 dark:hover:bg-slate-900/50 text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    <span className="text-xs">{role}</span>
                    <span className="text-[8px] opacity-65 font-medium tracking-wide">
                      {role === 'Admin' && 'Full Access'}
                      {role === 'AM' && 'Portfolio'}
                      {role === 'Team Lead' && 'Hub Quality'}
                      {role === 'Analyst' && 'Scoring'}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Password */}
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="block text-[11px] text-slate-600 dark:text-slate-400 uppercase tracking-wider font-bold" htmlFor="password">
                  Password
                </label>
                <button
                  type="button"
                  onClick={async (e) => {
                    e.preventDefault();
                    if (!email) {
                      setError('Please enter your email address first to reset password.');
                      return;
                    }
                    setError('');
                    try {
                      await resetPassword(email);
                      alert(`A password reset link has been sent to ${email}`);
                    } catch (err: any) {
                      console.error('Password reset failed:', err);
                      setError(err.message || 'Failed to send password reset email.');
                    }
                  }}
                  className="text-[10px] text-primary hover:underline font-bold cursor-pointer bg-transparent border-none p-0 inline"
                >
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  className="block w-full pl-9 pr-10 py-1.5 h-10 border border-slate-200 dark:border-slate-800 rounded-xl bg-slate-50 dark:bg-slate-900/40 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all placeholder-slate-400 font-mono text-xs font-semibold"
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                  <button
                    className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 focus:outline-none transition-colors cursor-pointer"
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>

            {/* Remember Me */}
            <div className="flex items-center pt-1">
              <input
                className="h-4 w-4 text-primary focus:ring-primary/30 border-slate-200 dark:border-slate-800 rounded-md bg-slate-50 cursor-pointer"
                id="remember-me"
                type="checkbox"
              />
              <label className="ml-2 block text-xs text-slate-500 dark:text-slate-400 select-none cursor-pointer" htmlFor="remember-me">
                Remember me on this workstation
              </label>
            </div>

            {/* Submit Button */}
            <button
              className="w-full flex justify-center py-3 px-4 border border-transparent rounded-xl bg-primary hover:opacity-95 text-on-primary text-xs font-bold transition-all duration-150 items-center space-x-2 shadow-md cursor-pointer mt-4 hover:translate-y-[-1px] active:translate-y-0 active:scale-[0.99] disabled:opacity-50"
              type="submit"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  <span>Sign into Operations Suite</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Continue with Google Account */}
          <div className="space-y-4">
            <button
              onClick={async () => {
                setError('');
                setIsSubmitting(true);
                try {
                  const res = await loginWithGoogle();
                  if (res) {
                    onLogin(res.email, res.name, res.role as any);
                  }
                } catch (err: any) {
                  console.error('Google Sign-In failed:', err);
                  if (err.code === 'auth/popup-closed-by-user' || err.message?.includes('popup-closed-by-user') || err.message?.includes('cancelled-popup-request') || err.message?.includes('popup')) {
                    setError('Google Sign-In popup was closed or blocked. Since the application is running inside a secure iframe, please open the application in a new tab or use the simulation below.');
                    setShowGoogleSimulation(true);
                  } else {
                    setError(err.message || 'Google authentication failed.');
                  }
                } finally {
                  setIsSubmitting(false);
                }
              }}
              disabled={isSubmitting}
              className="w-full inline-flex justify-center py-2.5 px-4 border border-slate-200 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900/30 text-slate-700 dark:text-slate-200 text-xs font-bold hover:bg-slate-50 dark:hover:bg-slate-900/60 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-all items-center space-x-2 shadow-sm cursor-pointer disabled:opacity-50"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#EA4335"
                  d="M12.24 10.285V14.4h6.887c-.275 1.565-1.88 4.604-6.887 4.604-4.33 0-7.859-3.578-7.859-8s3.53-8 7.859-8c2.46 0 4.105 1.025 5.047 1.926l3.258-3.133C18.29 1.844 15.44 1 12.24 1c-6.075 0-11 4.925-11 11s4.925 11 11 11c6.34 0 10.56-4.453 10.56-10.75 0-.725-.078-1.275-.175-1.68H12.24z"
                />
              </svg>
              <span>Continue with Google Account</span>
            </button>

            {showGoogleSimulation && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 bg-amber-50 dark:bg-amber-950/20 rounded-xl border border-amber-200 dark:border-amber-900/40 space-y-3"
              >
                <div className="flex items-start gap-2.5">
                  <Sparkles className="w-4 h-4 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0 animate-pulse" />
                  <div>
                    <h4 className="text-xs font-bold text-amber-800 dark:text-amber-300">
                      AI Studio Sandbox Google Access
                    </h4>
                    <p className="text-[10px] text-amber-600 dark:text-amber-400 leading-normal mt-0.5">
                      Standard Google Auth popups can be blocked inside safe sandbox previews. Log in instantly with your workspace email below:
                    </p>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="email"
                    placeholder="Enter Google Email (e.g. ankit.thakur@marginedge.com)"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="flex-1 px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-500 font-medium text-slate-900 dark:text-white"
                  />
                  <button
                    type="button"
                    onClick={async () => {
                      setError('');
                      setIsSubmitting(true);
                      try {
                        const targetEmail = email || 'ankit.thakur@marginedge.com';
                        const targetName = name || targetEmail.split('@')[0];
                        const res = await simulateGoogleLogin(targetEmail, targetName);
                        if (res) {
                          onLogin(res.email, res.name, res.role as any);
                        }
                      } catch (simErr: any) {
                        setError(simErr.message || 'Simulated Google sign-in failed.');
                      } finally {
                        setIsSubmitting(false);
                      }
                    }}
                    className="px-3.5 py-1.5 text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white rounded-lg transition-colors cursor-pointer whitespace-nowrap shadow-sm text-center"
                  >
                    Simulate Google Login
                  </button>
                </div>
              </motion.div>
            )}
          </div>
        </div>

        {/* Footer Links */}
        <footer className="w-full py-4 flex flex-wrap justify-center gap-x-6 gap-y-2 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 dark:text-slate-500 relative z-10">
          <a className="hover:text-primary transition-colors" href="#help">Help Center</a>
          <span className="text-slate-200 dark:text-slate-800">•</span>
          <a className="hover:text-primary transition-colors" href="#security">Security Protocol</a>
          <span className="text-slate-200 dark:text-slate-800">•</span>
          <a className="hover:text-primary transition-colors" href="#support">Contact Support</a>
        </footer>
      </div>
    </div>
  );
}

