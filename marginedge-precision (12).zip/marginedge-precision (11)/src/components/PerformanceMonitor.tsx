import React, { Profiler, ProfilerOnRenderCallback, useState, useEffect, useCallback } from 'react';

export interface RenderStat {
  id: string;
  count: number;
  totalDuration: number;
  maxDuration: number;
  avgDuration: number;
  lastPhase: 'mount' | 'update';
  lastDuration: number;
  history: number[];
}

// Global registry of render statistics to share between Profiler and HUD
const globalStats: Record<string, RenderStat> = {};
const listeners = new Set<() => void>();

const notifyListeners = () => {
  listeners.forEach(listener => listener());
};

/**
 * React Profiler wrapper that measures render performance.
 * Emits beautiful styled logs to the console and updates the in-app HUD.
 */
export const PerformanceProfiler: React.FC<{ id: string; children: React.ReactNode }> = ({ id, children }) => {
  const handleRender: ProfilerOnRenderCallback = useCallback((
    profilerId,
    phase,
    actualDuration,
    baseDuration,
    startTime,
    commitTime
  ) => {
    // 1. Update global registry
    const existing = globalStats[profilerId] || {
      id: profilerId,
      count: 0,
      totalDuration: 0,
      maxDuration: 0,
      avgDuration: 0,
      lastPhase: 'mount',
      lastDuration: 0,
      history: []
    };

    existing.count += 1;
    existing.totalDuration += actualDuration;
    existing.lastPhase = phase as 'mount' | 'update';
    existing.lastDuration = actualDuration;
    if (actualDuration > existing.maxDuration) {
      existing.maxDuration = actualDuration;
    }
    existing.avgDuration = existing.totalDuration / existing.count;
    existing.history = [...existing.history.slice(-9), actualDuration]; // keep last 10 runs

    globalStats[profilerId] = existing;
    notifyListeners();

    // 2. Format beautiful, developer-friendly colored console outputs
    let color = '#10B981'; // Fast (<16ms, green)
    let label = 'FAST (60 FPS)';
    if (actualDuration > 50) {
      color = '#EF4444'; // Slow (>50ms, red)
      label = 'SLOW (Jank risk)';
    } else if (actualDuration > 16) {
      color = '#F59E0B'; // Moderate (>16ms, amber)
      label = 'MODERATE';
    }

    console.groupCollapsed(
      `%c⚡ [Render Log] ${profilerId} - ${phase.toUpperCase()} in ${actualDuration.toFixed(2)}ms [%c${label}%c]`,
      'color: #6366f1; font-weight: bold;',
      `color: ${color}; font-weight: bold;`,
      'color: #6366f1; font-weight: normal;'
    );

    console.log(
      `%cComponent ID:       %c${profilerId}\n` +
      `%cRender Phase:       %c${phase}\n` +
      `%cDuration:           %c${actualDuration.toFixed(2)}ms (Actual) / ${baseDuration.toFixed(2)}ms (Base without memo)\n` +
      `%cAccumulated Runs:   %c#${existing.count}\n` +
      `%cAverage Duration:   %c${existing.avgDuration.toFixed(2)}ms\n` +
      `%cMax Recorded Time:  %c${existing.maxDuration.toFixed(2)}ms\n` +
      `%cPipeline Overhead:   %c${(commitTime - startTime).toFixed(2)}ms`,
      'color: #94a3b8; font-weight: normal;', 'color: #3b82f6; font-weight: bold;',
      'color: #94a3b8; font-weight: normal;', phase === 'mount' ? 'color: #10b981; font-weight: bold;' : 'color: #eab308; font-weight: bold;',
      'color: #94a3b8; font-weight: normal;', `color: ${color}; font-weight: bold;`,
      'color: #94a3b8; font-weight: normal;', 'color: #64748b; font-weight: bold;',
      'color: #94a3b8; font-weight: normal;', 'color: #475569; font-weight: bold;',
      'color: #94a3b8; font-weight: normal;', 'color: #ef4444; font-weight: bold;',
      'color: #94a3b8; font-weight: normal;', 'color: #94a3b8; font-style: italic;'
    );

    if (phase === 'update' && actualDuration > 16) {
      console.warn(
        `%c⚠️ [Performance Recommendation] ${profilerId} took ${actualDuration.toFixed(2)}ms to update.\n` +
        `Check for unneeded re-renders, use React.memo, useCallback, or useMemo to cache state calculations.`,
        'color: #f59e0b; font-weight: bold;'
      );
    }

    console.groupEnd();
  }, []);

  return (
    <Profiler id={id} onRender={handleRender}>
      {children}
    </Profiler>
  );
};

/**
 * Interactive floating Performance Dashboard Hud for visualizing transitioning render stats.
 */
export const PerformanceMonitorHUD: React.FC = () => {
  const [stats, setStats] = useState<RenderStat[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [filterSlow, setFilterSlow] = useState(false);

  useEffect(() => {
    const updateStats = () => {
      setStats(Object.values(globalStats));
    };

    listeners.add(updateStats);
    updateStats();

    return () => {
      listeners.delete(updateStats);
    };
  }, []);

  const handleClear = () => {
    Object.keys(globalStats).forEach(key => {
      delete globalStats[key];
    });
    setStats([]);
    notifyListeners();
  };

  const filteredStats = stats.filter(s => !filterSlow || s.maxDuration > 16);

  return (
    <div className="fixed bottom-6 right-6 z-50 font-sans text-xs">
      {/* HUD Trigger Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-slate-900 dark:bg-slate-800 text-white border border-slate-700/50 shadow-2xl hover:bg-slate-800 dark:hover:bg-slate-700 hover:scale-105 transition-all duration-200 transform active:scale-95 cursor-pointer"
          title="Open Performance Monitor HUD"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="material-symbols-outlined text-[16px]">monitoring</span>
          <span className="font-semibold tracking-wide text-[11px]">Performance Monitor</span>
        </button>
      )}

      {/* Floating Panel */}
      {isOpen && (
        <div className="w-96 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden max-h-[460px] animate-in slide-in-from-bottom-5 duration-200">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2 text-slate-800 dark:text-slate-100">
              <span className="material-symbols-outlined text-indigo-500 text-[18px]">analytics</span>
              <span className="font-bold text-[12px] tracking-tight">Render Performance HUD</span>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={handleClear}
                className="p-1 rounded text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                title="Reset Statistics"
              >
                <span className="material-symbols-outlined text-[16px]">rotate_left</span>
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1 rounded text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                title="Collapse HUD"
              >
                <span className="material-symbols-outlined text-[16px]">close</span>
              </button>
            </div>
          </div>

          {/* Filtering and Mode Info */}
          <div className="flex items-center justify-between px-4 py-2 bg-slate-100/50 dark:bg-slate-900/50 border-b border-slate-200/50 dark:border-slate-800/50 text-[10px] text-slate-500">
            <div className="flex items-center gap-2">
              <label className="flex items-center gap-1 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={filterSlow}
                  onChange={(e) => setFilterSlow(e.target.checked)}
                  className="rounded border-slate-300 dark:border-slate-700 text-indigo-600 focus:ring-indigo-500"
                />
                <span>Show slow only (&gt;16ms)</span>
              </label>
            </div>
            <div>
              <span>Active Profilers: {stats.length}</span>
            </div>
          </div>

          {/* Body List */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2.5 max-h-[320px]">
            {filteredStats.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-10 text-center text-slate-400 dark:text-slate-500">
                <span className="material-symbols-outlined text-[28px] mb-1">dashboard_customize</span>
                <p className="font-medium text-[11px]">No active components tracked yet</p>
                <p className="text-[9px] max-w-[200px] mt-0.5">Navigate around and trigger lazy-loaded dashboard transitions to collect data.</p>
              </div>
            ) : (
              filteredStats.map(item => {
                const isSlow = item.lastDuration > 16;
                const isJank = item.lastDuration > 50;
                const speedColorClass = isJank
                  ? 'text-rose-500 dark:text-rose-400 font-bold'
                  : isSlow
                  ? 'text-amber-500 dark:text-amber-400 font-bold'
                  : 'text-emerald-500 dark:text-emerald-400 font-medium';

                const maxPercentage = Math.min((item.lastDuration / 100) * 100, 100);

                return (
                  <div
                    key={item.id}
                    className="p-3.5 rounded-xl border border-slate-100 dark:border-slate-800/70 bg-slate-50/50 dark:bg-slate-950/40 hover:bg-slate-100/50 dark:hover:bg-slate-950/80 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="truncate">
                        <h4 className="font-bold text-slate-800 dark:text-slate-100 truncate text-[11px]" title={item.id}>
                          {item.id.replace('_DASHBOARD', '').replace('_UTILITY', '').replace('_LOGS', '')}
                        </h4>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className={`text-[9px] px-1 rounded font-semibold tracking-wider ${
                            item.lastPhase === 'mount' 
                              ? 'bg-emerald-100 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400' 
                              : 'bg-blue-100 dark:bg-blue-950/50 text-blue-700 dark:text-blue-400'
                          }`}>
                            {item.lastPhase.toUpperCase()}
                          </span>
                          <span className="text-[9px] text-slate-400">runs: {item.count}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className={speedColorClass}>{item.lastDuration.toFixed(1)} ms</span>
                        <div className="text-[9px] text-slate-400 mt-0.5">avg: {item.avgDuration.toFixed(1)}ms</div>
                      </div>
                    </div>

                    {/* Simple Sparkbar representation of the transition load */}
                    <div className="w-full bg-slate-200 dark:bg-slate-800 rounded-full h-1 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          isJank ? 'bg-rose-500' : isSlow ? 'bg-amber-500' : 'bg-emerald-500'
                        }`}
                        style={{ width: `${maxPercentage}%` }}
                      ></div>
                    </div>

                    {/* Stats details pill box */}
                    <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-slate-100 dark:border-slate-800/50 text-[9px] text-slate-500">
                      <div>
                        Max Time: <span className="font-semibold text-slate-700 dark:text-slate-300">{item.maxDuration.toFixed(1)}ms</span>
                      </div>
                      <div className="text-right">
                        Last 5 Runs: <span className="font-semibold text-slate-700 dark:text-slate-300">[{item.history.slice(-5).map(v => Math.round(v)).join(', ')}]</span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer details */}
          <div className="p-3 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-[9px] text-slate-400">
            <span className="flex items-center gap-1 text-slate-400">
              <span className="material-symbols-outlined text-[10px] text-emerald-500 animate-pulse">check_circle</span>
              Development Profiler Active
            </span>
            <span>Logs piped to JS Console</span>
          </div>
        </div>
      )}
    </div>
  );
};
