import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { useRealtime } from '../context/RealtimeContext';
import { PortfolioLog, ReconciliationRecord, IPARecord } from '../types';

interface GlobalSearchProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function GlobalSearch({ isOpen, onClose }: GlobalSearchProps) {
  const { portfolioLogs, reconciliationRecords, ipaRecords, teamPerformance, amAlerts } = useRealtime();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'vendor' | 'analyst' | 'invoice' | 'team' | 'date'>('all');
  const [returnCodeType, setReturnCodeType] = useState<'json' | 'sql' | 'typescript' | 'express_api'>('json');
  const [hasCopiedCode, setHasCopiedCode] = useState(false);
  const [showCodeOnly, setShowCodeOnly] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Focus input on open
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 150);
    }
  }, [isOpen]);

  // Clean and sanitize input
  const cleanQuery = useMemo(() => {
    return searchQuery.toLowerCase().trim();
  }, [searchQuery]);

  // Analyst to Team mapping helper
  const getAnalystTeam = useCallback((analystName: string): string => {
    const normName = (analystName || '').toLowerCase().replace(/[\s_]+/g, '');
    const ipaMatch = ipaRecords.find(r => 
      (r.name || '').toLowerCase().replace(/[\s_]+/g, '') === normName
    );
    if (ipaMatch) return ipaMatch.team;
    
    const reconMatch = reconciliationRecords.find(r => 
      (r.user || '').toLowerCase().replace(/[\s_]+/g, '') === normName
    );
    if (reconMatch) return reconMatch.office || reconMatch.team;
    
    return 'Global Ops';
  }, [ipaRecords, reconciliationRecords]);

  // 1. VENDOR SEARCH & COMPILATION
  const matchedVendors = useMemo(() => {
    if (!cleanQuery && activeFilter !== 'vendor') return [];
    
    const uniqueVendors = new Set<string>();
    const logsByVendor: Record<string, PortfolioLog[]> = {};

    portfolioLogs.forEach(log => {
      const vendor = log.vendorName || 'Unknown Vendor';
      if (cleanQuery && !vendor.toLowerCase().includes(cleanQuery)) return;
      uniqueVendors.add(vendor);
      if (!logsByVendor[vendor]) logsByVendor[vendor] = [];
      logsByVendor[vendor].push(log);
    });

    return Array.from(uniqueVendors).map(vendorName => {
      const logs = logsByVendor[vendorName] || [];
      const totalInvoices = logs.reduce((sum, l) => sum + (l.ir || 12), 0);
      const totalErrors = logs.reduce((sum, l) => sum + (l.errors || 0), 0);
      const avgAccuracy = logs.length > 0 
        ? Math.round((logs.reduce((sum, l) => sum + l.accuracy, 0) / logs.length) * 10) / 10 
        : 100;

      return {
        id: `vendor_${vendorName.toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
        type: 'vendor' as const,
        title: vendorName,
        subtitle: `Food Supply Vendor`,
        metrics: [
          { label: 'Invoices Resolved', value: totalInvoices },
          { label: 'Avg Accuracy', value: `${avgAccuracy}%` },
          { label: 'Errors recorded', value: totalErrors }
        ],
        rawData: {
          vendorName,
          totalInvoicesResolved: totalInvoices,
          averageAccuracy: avgAccuracy,
          totalErrors,
          logsCount: logs.length
        }
      };
    });
  }, [portfolioLogs, cleanQuery, activeFilter]);

  // 2. ANALYST SEARCH & COMPILATION
  const matchedAnalysts = useMemo(() => {
    if (!cleanQuery && activeFilter !== 'analyst') return [];

    const uniqueAnalysts = new Set<string>();
    const logsByAnalyst: Record<string, PortfolioLog[]> = {};

    portfolioLogs.forEach(log => {
      const analyst = log.analystName || 'Unknown Analyst';
      if (cleanQuery && !analyst.toLowerCase().includes(cleanQuery)) return;
      uniqueAnalysts.add(analyst);
      if (!logsByAnalyst[analyst]) logsByAnalyst[analyst] = [];
      logsByAnalyst[analyst].push(log);
    });

    // Also look into ipaRecords / reconciliationRecords for additional matches
    ipaRecords.forEach(rec => {
      if (cleanQuery && !rec.name.toLowerCase().includes(cleanQuery)) return;
      uniqueAnalysts.add(rec.name);
    });
    reconciliationRecords.forEach(rec => {
      if (cleanQuery && !rec.user.toLowerCase().includes(cleanQuery)) return;
      uniqueAnalysts.add(rec.user);
    });

    return Array.from(uniqueAnalysts).map(analystName => {
      const logs = logsByAnalyst[analystName] || [];
      const totalInvoices = logs.reduce((sum, l) => sum + (l.ir || 12), 0);
      const totalErrors = logs.reduce((sum, l) => sum + (l.errors || 0), 0);
      const avgAccuracy = logs.length > 0 
        ? Math.round((logs.reduce((sum, l) => sum + l.accuracy, 0) / logs.length) * 10) / 10 
        : 100;
      const team = getAnalystTeam(analystName);

      return {
        id: `analyst_${analystName.toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
        type: 'analyst' as const,
        title: analystName,
        subtitle: `Operational Analyst • ${team}`,
        metrics: [
          { label: 'Invoices Resolved', value: totalInvoices },
          { label: 'Avg Accuracy', value: `${avgAccuracy}%` },
          { label: 'Hub / Team', value: team }
        ],
        rawData: {
          analystName,
          team,
          totalInvoicesResolved: totalInvoices,
          averageAccuracy: avgAccuracy,
          totalErrors,
          logsCount: logs.length
        }
      };
    });
  }, [portfolioLogs, ipaRecords, reconciliationRecords, cleanQuery, activeFilter, getAnalystTeam]);

  // 3. INVOICE SEARCH & COMPILATION
  const matchedInvoices = useMemo(() => {
    if (!cleanQuery && activeFilter !== 'invoice') return [];

    // Match portfolioLogs representing invoice tasks
    return portfolioLogs
      .filter(log => {
        const matchesQuery = cleanQuery 
          ? log.id.toLowerCase().includes(cleanQuery) || 
            (log.vendorName || '').toLowerCase().includes(cleanQuery) ||
            (log.analystName || '').toLowerCase().includes(cleanQuery) ||
            (log.taskType || '').toLowerCase().includes(cleanQuery)
          : true;
        return matchesQuery;
      })
      .slice(0, 15) // limit to avoid flooding
      .map(log => {
        return {
          id: log.id,
          type: 'invoice' as const,
          title: `Invoice Audit #${log.id.slice(-6).toUpperCase()}`,
          subtitle: `${log.vendorName || 'Acme'} • Resolved by ${log.analystName || 'Staff'}`,
          metrics: [
            { label: 'Date', value: log.date },
            { label: 'Accuracy', value: `${log.accuracy}%` },
            { label: 'Status', value: log.status }
          ],
          rawData: {
            invoiceId: log.id,
            date: log.date,
            vendorName: log.vendorName,
            analystName: log.analystName,
            taskType: log.taskType,
            accuracy: log.accuracy,
            status: log.status,
            errors: log.errors || 0
          }
        };
      });
  }, [portfolioLogs, cleanQuery, activeFilter]);

  // 4. TEAM SEARCH & COMPILATION
  const matchedTeams = useMemo(() => {
    if (!cleanQuery && activeFilter !== 'team') return [];

    const uniqueTeams = new Set<string>();
    
    teamPerformance.forEach(t => {
      if (cleanQuery && !t.teamName.toLowerCase().includes(cleanQuery)) return;
      uniqueTeams.add(t.teamName);
    });

    reconciliationRecords.forEach(r => {
      const office = r.office || r.team;
      if (cleanQuery && !office.toLowerCase().includes(cleanQuery)) return;
      uniqueTeams.add(office);
    });

    return Array.from(uniqueTeams).map(teamName => {
      const perf = teamPerformance.find(t => t.teamName.toLowerCase() === teamName.toLowerCase());
      const recs = reconciliationRecords.filter(r => (r.office || r.team).toLowerCase() === teamName.toLowerCase());
      
      const totalPoints = recs.reduce((sum, r) => sum + r.points, 0);
      const totalErrors = recs.reduce((sum, r) => sum + r.errors, 0);
      const efficiency = perf?.efficiency || 95;
      const lead = perf?.lead || 'Team Lead';

      return {
        id: `team_${teamName.toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
        type: 'team' as const,
        title: `${teamName} Hub`,
        subtitle: `Ops Team • Lead: ${lead}`,
        metrics: [
          { label: 'Hub Efficiency', value: `${efficiency}%` },
          { label: 'Total Errors', value: totalErrors },
          { label: 'Activity Points', value: totalPoints }
        ],
        rawData: {
          teamName,
          lead,
          efficiency,
          totalErrors,
          totalPoints,
          membersCount: recs.length
        }
      };
    });
  }, [teamPerformance, reconciliationRecords, cleanQuery, activeFilter]);

  // 5. DATE SEARCH & COMPILATION
  const matchedDates = useMemo(() => {
    if (!cleanQuery && activeFilter !== 'date') return [];

    const uniqueDates = new Set<string>();
    const logsByDate: Record<string, PortfolioLog[]> = {};

    portfolioLogs.forEach(log => {
      if (cleanQuery && !log.date.toLowerCase().includes(cleanQuery)) return;
      uniqueDates.add(log.date);
      if (!logsByDate[log.date]) logsByDate[log.date] = [];
      logsByDate[log.date].push(log);
    });

    return Array.from(uniqueDates).map(dateStr => {
      const logs = logsByDate[dateStr] || [];
      const totalInvoices = logs.reduce((sum, l) => sum + (l.ir || 12), 0);
      const avgAccuracy = logs.length > 0 
        ? Math.round((logs.reduce((sum, l) => sum + l.accuracy, 0) / logs.length) * 10) / 10 
        : 100;
      const uniqueStaff = Array.from(new Set(logs.map(l => l.analystName)));

      return {
        id: `date_${dateStr.replace(/[^0-9]/g, '_')}`,
        type: 'date' as const,
        title: dateStr,
        subtitle: `Operational Workday Logs`,
        metrics: [
          { label: 'Total Invoices', value: totalInvoices },
          { label: 'Avg Day Accuracy', value: `${avgAccuracy}%` },
          { label: 'Active Staff', value: `${uniqueStaff.length} active` }
        ],
        rawData: {
          date: dateStr,
          totalInvoicesResolved: totalInvoices,
          averageAccuracy: avgAccuracy,
          activeAnalysts: uniqueStaff,
          logsCount: logs.length
        }
      };
    });
  }, [portfolioLogs, cleanQuery, activeFilter]);

  // Consolidated Results List based on active filter
  const allSearchResults = useMemo(() => {
    let results: any[] = [];
    
    if (activeFilter === 'all' || activeFilter === 'vendor') {
      results = [...results, ...matchedVendors];
    }
    if (activeFilter === 'all' || activeFilter === 'analyst') {
      results = [...results, ...matchedAnalysts];
    }
    if (activeFilter === 'all' || activeFilter === 'invoice') {
      results = [...results, ...matchedInvoices];
    }
    if (activeFilter === 'all' || activeFilter === 'team') {
      results = [...results, ...matchedTeams];
    }
    if (activeFilter === 'all' || activeFilter === 'date') {
      results = [...results, ...matchedDates];
    }

    return results;
  }, [activeFilter, matchedVendors, matchedAnalysts, matchedInvoices, matchedTeams, matchedDates]);

  // Return Code Only representation of matching records
  const generatedReturnCode = useMemo(() => {
    const rawItems = allSearchResults.map(res => res.rawData);
    
    if (returnCodeType === 'json') {
      return JSON.stringify({
        searchQuery: searchQuery,
        filterType: activeFilter,
        resultsCount: rawItems.length,
        timestamp: new Date().toISOString(),
        searchResults: rawItems
      }, null, 2);
    }

    if (returnCodeType === 'sql') {
      return `-- Automated MarginEdge SQL Search Export
-- Search Query: "${searchQuery}"
-- Filter Type: ${activeFilter.toUpperCase()}
-- Generated at: ${new Date().toLocaleString()}

CREATE TABLE IF NOT EXISTS global_search_results (
  result_id VARCHAR(100) PRIMARY KEY,
  result_type VARCHAR(50),
  search_query VARCHAR(100),
  compiled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  payload JSONB
);

INSERT INTO global_search_results (result_id, result_type, search_query, payload)
VALUES (
  'search_${Date.now()}',
  '${activeFilter}',
  '${searchQuery.replace(/'/g, "''")}',
  '${JSON.stringify(rawItems).replace(/'/g, "''")}'
) ON CONFLICT DO NOTHING;`;
    }

    if (returnCodeType === 'typescript') {
      return `/**
 * TypeScript Definitions for Global Search Outcomes
 * Query: "${searchQuery}" | Type: ${activeFilter}
 */

export interface GlobalSearchOutcome {
  searchQuery: string;
  filterType: '${activeFilter}';
  generatedAt: string;
  resultsCount: number;
  data: Array<any>;
}

export const SEARCH_RESULTS_EXPORT: GlobalSearchOutcome = {
  searchQuery: "${searchQuery}",
  filterType: "${activeFilter}",
  generatedAt: "${new Date().toISOString()}",
  resultsCount: ${rawItems.length},
  data: ${JSON.stringify(rawItems, null, 2)}
};`;
    }

    if (returnCodeType === 'express_api') {
      return `/**
 * Express API Route Proxy for Search Queries
 */
import express from 'express';
const router = express.Router();

router.get('/api/search', async (req, res) => {
  try {
    const { q, type } = req.query;
    
    // Matched parameters: query="${searchQuery}", type="${activeFilter}"
    const results = ${JSON.stringify(rawItems, null, 2)};
    
    res.status(200).json({
      success: true,
      query: q || "${searchQuery}",
      type: type || "${activeFilter}",
      count: results.length,
      timestamp: new Date().toISOString(),
      data: results
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

export default router;`;
    }

    return '';
  }, [allSearchResults, searchQuery, activeFilter, returnCodeType]);

  const handleCopyCodeToClipboard = () => {
    navigator.clipboard.writeText(generatedReturnCode);
    setHasCopiedCode(true);
    setTimeout(() => setHasCopiedCode(false), 2000);
  };

  // Close search on Esc key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-[10vh] px-4 md:px-0">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-[2px] transition-opacity cursor-pointer" 
        onClick={onClose}
      />

      {/* Search dialog window */}
      <div className="bg-surface border border-outline-variant w-full max-w-3xl rounded-2xl shadow-2xl flex flex-col overflow-hidden max-h-[80vh] relative z-10 transition-all duration-300 transform scale-100 font-sans">
        
        {/* Search Input bar */}
        <div className="px-5 py-4 border-b border-outline-variant flex items-center gap-3 bg-surface-container-low">
          <span className="material-symbols-outlined text-primary text-2xl select-none">search</span>
          <input
            ref={inputRef}
            type="text"
            className="flex-1 bg-transparent border-none text-on-surface placeholder-on-surface-variant/60 focus:outline-none text-base font-medium"
            placeholder="Search by Vendor, Analyst, Invoice ID, Team or Date..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button 
              onClick={() => setSearchQuery('')}
              className="p-1 rounded-full hover:bg-surface-container text-on-surface-variant cursor-pointer flex items-center justify-center"
            >
              <span className="material-symbols-outlined text-sm">close</span>
            </button>
          )}
          <span className="text-[10px] bg-surface-container text-on-surface-variant border border-outline-variant px-2 py-0.5 rounded font-mono font-bold uppercase tracking-wider select-none hidden sm:inline-block">
            ESC
          </span>
        </div>

        {/* Filter Quick-Select Chips */}
        <div className="px-5 py-3 border-b border-outline-variant/60 bg-surface flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap gap-2">
            {[
              { id: 'all', label: 'All Results', icon: 'grid_view' },
              { id: 'vendor', label: 'Vendor', icon: 'store' },
              { id: 'analyst', label: 'Analyst', icon: 'person_search' },
              { id: 'invoice', label: 'Invoice', icon: 'receipt_long' },
              { id: 'team', label: 'Team', icon: 'groups' },
              { id: 'date', label: 'Date', icon: 'calendar_month' }
            ].map(f => (
              <button
                key={f.id}
                onClick={() => {
                  setActiveFilter(f.id as any);
                  if (f.id !== 'all' && !searchQuery) {
                    // pre-fill or guide
                  }
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border ${
                  activeFilter === f.id
                    ? 'bg-primary text-on-primary border-primary shadow-sm'
                    : 'bg-surface-container-low text-on-surface-variant border-outline-variant hover:bg-surface-container'
                }`}
              >
                <span className="material-symbols-outlined text-[14px]">{f.icon}</span>
                <span>{f.label}</span>
              </button>
            ))}
          </div>

          {/* Toggle Code-Only View Mode */}
          <button
            onClick={() => setShowCodeOnly(!showCodeOnly)}
            className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer border ${
              showCodeOnly 
                ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm' 
                : 'bg-surface-container-low text-emerald-600 border-emerald-500/30 hover:bg-emerald-50'
            }`}
            title="Toggle code-only compilation of query outcomes"
          >
            <span className="material-symbols-outlined text-[14px]">code</span>
            <span>Return Code Only</span>
          </button>
        </div>

        {/* Content Box */}
        <div className="flex-1 overflow-y-auto flex flex-col md:flex-row min-h-[350px]">
          
          {/* Main results listing or return code only mode */}
          {showCodeOnly ? (
            /* CODE ONLY DISPLAY */
            <div className="flex-1 flex flex-col p-5 bg-slate-950 text-slate-100 min-h-[350px]">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-emerald-500 font-bold text-xs uppercase tracking-wider flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    Search Return Code
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    ({allSearchResults.length} matches compiled)
                  </span>
                </div>
                
                {/* Format selection tabs */}
                <div className="flex bg-slate-900 border border-slate-800 rounded-lg p-0.5 overflow-hidden">
                  {[
                    { id: 'json', label: 'JSON' },
                    { id: 'sql', label: 'SQL' },
                    { id: 'typescript', label: 'TS Types' },
                    { id: 'express_api', label: 'Express API' }
                  ].map(tab => (
                    <button
                      key={tab.id}
                      onClick={() => setReturnCodeType(tab.id as any)}
                      className={`px-2.5 py-1 text-[9px] font-black uppercase rounded transition-all cursor-pointer ${
                        returnCodeType === tab.id 
                          ? 'bg-emerald-600 text-white' 
                          : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Code Panel */}
              <div className="flex-1 bg-slate-900/40 border border-slate-900 rounded-xl p-4 font-mono text-[10px] overflow-auto select-all relative group">
                <pre className="whitespace-pre leading-relaxed text-emerald-400">{generatedReturnCode}</pre>
                
                <button
                  onClick={handleCopyCodeToClipboard}
                  className="absolute top-3 right-3 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white p-2 rounded-lg border border-slate-700 transition-all flex items-center justify-center cursor-pointer shadow-lg"
                  title="Copy Code to Clipboard"
                >
                  <span className="material-symbols-outlined text-sm">
                    {hasCopiedCode ? 'check_circle' : 'content_copy'}
                  </span>
                  {hasCopiedCode && <span className="text-[9px] font-bold ml-1">Copied!</span>}
                </button>
              </div>

              <div className="mt-3 text-[9px] text-slate-500 font-mono flex items-center justify-between">
                <span>Active Search Filter: {activeFilter.toUpperCase()}</span>
                <span>Press Esc to dismiss search panel</span>
              </div>
            </div>
          ) : (
            /* STANDARD SPLIT VIEW (RESULTS + PREVIEW CODE CARD) */
            <>
              {/* Left results column */}
              <div className="flex-1 p-5 overflow-y-auto divide-y divide-outline-variant/50">
                {allSearchResults.length > 0 ? (
                  allSearchResults.map(res => (
                    <div 
                      key={res.id} 
                      className="py-4 first:pt-0 last:pb-0 flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
                    >
                      <div className="flex items-start gap-3">
                        <div className={`p-2.5 rounded-xl bg-surface-container border border-outline-variant/60 flex items-center justify-center text-primary`}>
                          <span className="material-symbols-outlined text-[18px]">
                            {res.type === 'vendor' ? 'store' : 
                             res.type === 'analyst' ? 'badge' : 
                             res.type === 'invoice' ? 'receipt_long' : 
                             res.type === 'team' ? 'groups' : 'calendar_month'}
                          </span>
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-sm font-bold text-on-surface group-hover:text-primary transition-colors">
                              {res.title}
                            </h4>
                            <span className="text-[9px] font-bold uppercase tracking-wider bg-surface-container px-2 py-0.5 rounded text-on-surface-variant border border-outline-variant/40">
                              {res.type}
                            </span>
                          </div>
                          <p className="text-[11px] text-on-surface-variant font-medium mt-0.5 opacity-80">
                            {res.subtitle}
                          </p>
                        </div>
                      </div>

                      {/* Metrics row */}
                      <div className="flex items-center gap-4 bg-surface-container-low/60 border border-outline-variant/30 px-3 py-1.5 rounded-lg">
                        {res.metrics.map((m: any, idx: number) => (
                          <div key={idx} className="text-right min-w-[60px] border-r last:border-none border-outline-variant/50 pr-4 last:pr-0">
                            <p className="text-[8px] text-on-surface-variant uppercase tracking-wider font-extrabold">{m.label}</p>
                            <p className="text-[11px] text-on-surface font-bold font-mono mt-0.5">{m.value}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-center py-12 px-4">
                    <span className="material-symbols-outlined text-4xl text-on-surface-variant opacity-40">find_in_page</span>
                    <h4 className="text-sm font-bold text-on-surface mt-3">No matching logs or records found</h4>
                    <p className="text-[11px] text-on-surface-variant mt-1 leading-relaxed max-w-[280px] opacity-75 font-medium">
                      {searchQuery 
                        ? `We couldn't find matches for "${searchQuery}" in our system.`
                        : 'Type your search query to find records instantly.'}
                    </p>
                  </div>
                )}
              </div>

              {/* Right preview/export code panel */}
              <div className="w-full md:w-[260px] bg-surface-container-low border-t md:border-t-0 md:border-l border-outline-variant p-4 flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h5 className="text-[10px] font-black uppercase text-on-surface-variant tracking-widest flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                      Search return code
                    </h5>
                    
                    {/* Format Selector inside right sidebar */}
                    <select
                      className="bg-surface border border-outline-variant text-[10px] font-bold rounded-lg px-2 py-1 text-on-surface focus:outline-none"
                      value={returnCodeType}
                      onChange={(e) => setReturnCodeType(e.target.value as any)}
                    >
                      <option value="json">JSON Object</option>
                      <option value="sql">SQL Script</option>
                      <option value="typescript">TS Typings</option>
                      <option value="express_api">Express API</option>
                    </select>
                  </div>

                  <p className="text-[10px] text-on-surface-variant leading-relaxed font-semibold opacity-80">
                    Extract live database structure and schemas matching these search outcomes automatically.
                  </p>

                  <div className="bg-slate-900 text-slate-100 rounded-lg p-3 font-mono text-[9px] max-h-[160px] overflow-auto select-all relative border border-slate-800">
                    <pre className="whitespace-pre leading-relaxed">{generatedReturnCode}</pre>
                  </div>
                </div>

                <div className="pt-4 border-t border-outline-variant/60">
                  <button
                    onClick={handleCopyCodeToClipboard}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-3 rounded-lg text-xs flex items-center justify-center gap-2 cursor-pointer shadow active:scale-95 transition-all"
                  >
                    <span className="material-symbols-outlined text-sm">
                      {hasCopiedCode ? 'check_circle' : 'content_copy'}
                    </span>
                    <span>{hasCopiedCode ? 'Copied Snippet!' : 'Copy Return Code'}</span>
                  </button>
                  <p className="text-center text-[9px] text-on-surface-variant opacity-70 mt-2 font-medium">
                    Found {allSearchResults.length} records matching search.
                  </p>
                </div>
              </div>
            </>
          )}

        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-outline-variant bg-surface-container flex items-center justify-between text-[10px] font-bold text-on-surface-variant">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <span className="bg-surface border border-outline-variant/80 px-1 py-0.5 rounded font-mono font-bold text-[9px]">Esc</span> Close
            </span>
            <span className="flex items-center gap-1">
              <span className="bg-surface border border-outline-variant/80 px-1 py-0.5 rounded font-mono font-bold text-[9px]">Tab</span> Filter
            </span>
            <span className="flex items-center gap-1">
              <span className="bg-surface border border-outline-variant/80 px-1.5 py-0.5 rounded font-mono font-bold text-[9px]">Ctrl+K</span> Trigger Search
            </span>
          </div>
          <div>
            <span>MarginEdge Search Console v1.0</span>
          </div>
        </div>

      </div>
    </div>
  );
}
