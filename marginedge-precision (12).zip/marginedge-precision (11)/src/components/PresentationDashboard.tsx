import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useRealtime } from '../context/RealtimeContext';
import { ActiveView } from '../types';
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell,
  PieChart,
  Pie
} from 'recharts';

// Strict input sanitization to safeguard operations from script injections or overflow payloads
function sanitizeInput(text: string, limit: number = 200): string {
  if (!text) return '';
  return text
    .replace(/<[^>]*>/g, '') // strip HTML/script elements
    .replace(/[&<>"'/]/g, (match) => {
      const escapeMap: Record<string, string> = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#x27;',
        '/': '&#x2F;',
      };
      return escapeMap[match] || match;
    })
    .trim()
    .substring(0, limit);
}

interface PresentationDashboardProps {
  userEmail: string;
  userName?: string;
  userPosition?: string;
  onNavigate: (view: ActiveView) => void;
  onLogout: () => void;
}

interface Slide {
  id: number;
  title: string;
  subtitle: string;
  badge: string;
  gradient: string;
  content: React.ReactNode;
}

export default function PresentationDashboard({
  userEmail,
  userName,
  userPosition,
  onNavigate,
  onLogout,
}: PresentationDashboardProps) {
  const { reconciliationRecords, ipaRecords, teamPerformance } = useRealtime();
  const [activeTab, setActiveTab] = useState<'slides' | 'video' | 'roadmap' | 'charts'>('slides');
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isPlayingSlides, setIsPlayingSlides] = useState(false);
  const [videoPlayState, setVideoPlayState] = useState<'idle' | 'playing' | 'paused' | 'completed'>('idle');
  const [videoStepIndex, setVideoStepIndex] = useState(0);
  const [videoProgress, setVideoProgress] = useState(0);
  const [videoPlaybackSpeed, setVideoPlaybackSpeed] = useState<number>(1);
  const [selectedOffice, setSelectedOffice] = useState<string>('Office (All)');

  // Dynamic Chart Sandbox configuration and validations
  const [chartMultiplier, setChartMultiplier] = useState<number>(1.0);
  const [multiplierInput, setMultiplierInput] = useState<string>('1.0');
  const [chartMetricFilter, setChartMetricFilter] = useState<'all' | 'high' | 'pending'>('all');
  const [validationError, setValidationError] = useState<string | null>(null);
  const [multiplierError, setMultiplierError] = useState<string | null>(null);

  // Roadmap voting states (local persistence simulation)
  const [roadmapItems, setRoadmapItems] = useState([
    {
      id: 1,
      title: '🤖 Automated PII Anonymization & Security Guardrails',
      description: 'Ingestion server-side algorithm to scan uploaded Excel sheets & automatically mask sensitive personal/client identifiers before database writes.',
      category: 'Security & Compliance',
      votes: 42,
      impact: 'Critical (High)',
      voted: false,
    },
    {
      id: 2,
      title: '📈 Predictive SLA Bottle-neck Forecaster',
      description: 'Machine Learning models predicting possible delays or backlogs in the Chandigarh / Dhaka pipelines 4 hours in advance by analyzing live worker queues.',
      category: 'Operations Analytics',
      votes: 38,
      impact: 'High',
      voted: false,
    },
    {
      id: 3,
      title: '📝 Two-Way Live Google Sheets Sync (Writeback)',
      description: 'Directly commit edits done on the Invoice Manager or scoring dashboard back to the linked master Google Sheets in real-time, bypassing manual uploads.',
      category: 'Data Ingestion',
      votes: 56,
      impact: 'Transformative',
      voted: false,
    },
    {
      id: 4,
      title: '💬 MarginEdge Google Chatbot Assistant',
      description: 'A virtual bot integrated directly in our Chandigarh Chat Spaces to trigger instant report compiles or check team statuses via slash commands (e.g., /status).',
      category: 'Automation',
      votes: 49,
      impact: 'Medium-High',
      voted: false,
    },
    {
      id: 5,
      title: '📊 Advanced PDF-to-Structured-JSON Parser',
      description: 'Deep neural document processing to parse vendor PDFs directly within the platform, eliminating intermediate steps and compiling items instantly.',
      category: 'Ingestion Engine',
      votes: 61,
      impact: 'Transformative',
      voted: false,
    },
  ]);

  const [newFeatureTitle, setNewFeatureTitle] = useState('');
  const [newFeatureDesc, setNewFeatureDesc] = useState('');

  // Slideshow auto-play effect
  useEffect(() => {
    let interval: any;
    if (isPlayingSlides) {
      interval = setInterval(() => {
        setCurrentSlideIndex((prev) => (prev + 1) % slides.length);
      }, 5000);
    }
    return () => clearInterval(interval);
  }, [isPlayingSlides]);

  // Video walkthrough simulation timeline effect
  const videoIntervalRef = useRef<any>(null);
  useEffect(() => {
    if (videoPlayState === 'playing') {
      videoIntervalRef.current = setInterval(() => {
        setVideoProgress((prev) => {
          const increment = 1.5 * videoPlaybackSpeed;
          const next = prev + increment;
          if (next >= 100) {
            clearInterval(videoIntervalRef.current);
            setVideoPlayState('completed');
            setVideoStepIndex(videoSteps.length - 1);
            return 100;
          }
          // Dynamic calculation of current active visual step
          const stepSize = 100 / videoSteps.length;
          const currentStep = Math.min(Math.floor(next / stepSize), videoSteps.length - 1);
          setVideoStepIndex(currentStep);
          return next;
        });
      }, 150);
    } else {
      if (videoIntervalRef.current) clearInterval(videoIntervalRef.current);
    }
    return () => {
      if (videoIntervalRef.current) clearInterval(videoIntervalRef.current);
    };
  }, [videoPlayState, videoPlaybackSpeed]);

  const handleVote = (id: number) => {
    setRoadmapItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          return {
            ...item,
            votes: item.voted ? item.votes - 1 : item.votes + 1,
            voted: !item.voted,
          };
        }
        return item;
      })
    );
  };

  const handleAddFeature = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    const cleanTitle = sanitizeInput(newFeatureTitle, 80);
    const cleanDesc = sanitizeInput(newFeatureDesc, 300);

    if (cleanTitle.length < 5) {
      setValidationError('Title must be at least 5 characters long after removing invalid characters.');
      return;
    }
    if (cleanDesc.length > 0 && cleanDesc.length < 10) {
      setValidationError('Description is optional, but if specified, it must be at least 10 characters long.');
      return;
    }

    const newItem = {
      id: Date.now(),
      title: `💡 ${cleanTitle}`,
      description: cleanDesc || 'Proposed by our operational team member.',
      category: 'User Suggestion',
      votes: 1,
      impact: 'Medium',
      voted: true,
    };
    setRoadmapItems((prev) => [newItem, ...prev]);
    setNewFeatureTitle('');
    setNewFeatureDesc('');
  };

  // Safe parsing & computation of Realtime data for charts
  const getReconciliationChartData = () => {
    const fallbackData = [
      { name: 'Team Alpha', points: 1200, errors: 4, efficiency: 99.6 },
      { name: 'Team Beta', points: 950, errors: 12, efficiency: 98.7 },
      { name: 'Team Gamma', points: 1400, errors: 8, efficiency: 99.4 },
      { name: 'Team Delta', points: 1100, errors: 22, efficiency: 97.9 },
      { name: 'Team Epsilon', points: 800, errors: 2, efficiency: 99.75 },
    ];

    if (!reconciliationRecords || reconciliationRecords.length === 0) {
      return fallbackData.map(d => ({
        ...d,
        points: Math.round(d.points * chartMultiplier),
        errors: Math.round(d.errors * chartMultiplier)
      }));
    }

    const groups: Record<string, { name: string; points: number; errors: number; count: number }> = {};
    reconciliationRecords.forEach((rec) => {
      // Input filtering
      if (chartMetricFilter !== 'all' && rec.status?.toLowerCase() !== chartMetricFilter) return;
      if (selectedOffice !== 'Office (All)' && rec.office !== selectedOffice) return;

      const key = rec.team || 'General';
      if (!groups[key]) {
        groups[key] = { name: key, points: 0, errors: 0, count: 0 };
      }
      groups[key].points += Number(rec.points) || 0;
      groups[key].errors += Number(rec.errors) || 0;
      groups[key].count += 1;
    });

    const data = Object.values(groups).map((g) => ({
      name: g.name,
      points: Math.round(g.points * chartMultiplier),
      errors: Math.round(g.errors * chartMultiplier),
      efficiency: g.points > 0 ? parseFloat((((g.points - g.errors) / g.points) * 100).toFixed(2)) : 100,
    }));

    return data.length > 0 ? data : fallbackData;
  };

  const getAnalystChartData = () => {
    const fallbackData = [
      { name: 'Ankit Thakur', tasks: 185 },
      { name: 'Sameer J.', tasks: 142 },
      { name: 'Priya Sharma', tasks: 168 },
      { name: 'Amit Patel', tasks: 120 },
      { name: 'Neha Gupta', tasks: 195 },
    ];

    if (!ipaRecords || ipaRecords.length === 0) {
      return fallbackData.map(d => ({
        ...d,
        tasks: Math.round(d.tasks * chartMultiplier)
      }));
    }

    const sorted = [...ipaRecords]
      .map(rec => ({
        name: rec.name || 'Unknown Analyst',
        tasks: Math.round((Number(rec.tasks) || 0) * chartMultiplier)
      }))
      .sort((a, b) => b.tasks - a.tasks);

    return sorted.length > 0 ? sorted.slice(0, 8) : fallbackData;
  };

  const getTeamPerformanceData = () => {
    const fallbackData = [
      { name: 'Reco Team', efficiency: 99.2, errorRate: 0.8 },
      { name: 'Matching Unit', efficiency: 98.5, errorRate: 1.5 },
      { name: 'Audit Team', efficiency: 99.8, errorRate: 0.2 },
      { name: 'PII Scrub', efficiency: 100, errorRate: 0.0 },
    ];

    if (!teamPerformance || teamPerformance.length === 0) {
      return fallbackData;
    }

    return teamPerformance.map(t => ({
      name: t.teamName || 'Unknown',
      efficiency: Number(t.efficiency) || 0,
      errorRate: Number(t.errorRate) || 0,
    }));
  };

  const handleMultiplierChange = (valStr: string) => {
    setMultiplierInput(valStr);
    setMultiplierError(null);

    // Dynamic numeric validation and sanitization
    const sanitizedVal = valStr.replace(/[^0-9.]/g, '');
    const num = parseFloat(sanitizedVal);

    if (isNaN(num)) {
      setMultiplierError('Please enter a valid numeric value.');
      return;
    }

    if (num < 0.1 || num > 10.0) {
      setMultiplierError('Sandbox multiplier must be between 0.1x and 10.0x.');
      return;
    }

    setChartMultiplier(num);
  };

  const startVideoTour = () => {
    setVideoProgress(0);
    setVideoStepIndex(0);
    setVideoPlayState('playing');
  };

  const pauseVideoTour = () => {
    setVideoPlayState('paused');
  };

  const resumeVideoTour = () => {
    setVideoPlayState('playing');
  };

  const resetVideoTour = () => {
    setVideoProgress(0);
    setVideoStepIndex(0);
    setVideoPlayState('idle');
  };

  const downloadTrainingMaterials = () => {
    const content = `# MARGINEDGE PRECISION - ENTERPRISE TRAINING & ONBOARDING PACKAGE
================================================================================

This document contains the complete high-fidelity presentation slides, training scripts, 
storyboard guides, onboarding schedules, and operational blueprints for MarginEdge Precision.

--------------------------------------------------------------------------------
1. COMPLETE POWERPOINT PRESENTATION SLIDES (15-Slide Master Deck)
--------------------------------------------------------------------------------

SLIDE 1: WELCOME SCREEN & CORE IDENTITY
• Title: MarginEdge Precision
• Subtitle: AI-Powered Invoice Processing & Operational Analytics
• Badge: Brand Launch
• Slide Bullet Points:
  - Welcome to the future of restaurant and hospitality financial operations.
  - Empowering operations hubs with modern real-time data automation.
  - Seamless multi-regional ingestion supporting major centers (Chandigarh & Dhaka).
  - High-precision invoice parsing using specialized AI mapping engines.
  - Transparent analytics dashboard displaying key regional productivity indices.
• Animation Suggestions: Title fades in from bottom; subtitle glows with indigo pulse.
• Transition Suggestions: Horizontal wipe to the right.
• Screenshot Placement: Primary high-resolution landing screen of the login portal.
• Icon Suggestions: Shield, Rocket, Sparkles
• Presenter Notes (45-60s):
  "Welcome team and distinguished guests. Today, we are proud to launch MarginEdge Precision, 
  our premier AI-Powered Invoice Processing and Operational Analytics platform. As we scale our 
  operations across our main production centers like Chandigarh and Dhaka, having an integrated, 
  highly secure, and fast data system is absolutely critical. This platform eliminates the legacy 
  friction points and bridges our analysts, team leads, and clients into a singular real-time operational ecosystem."

SLIDE 2: THE BUSINESS PROBLEM
• Title: Legacy Friction & Manual Bottlenecks
• Subtitle: The Cost of Manual Ingestion & Spreadsheets
• Slide Bullet Points:
  - Extreme dependency on manual Excel entry leading to fatigue and typos.
  - Disconnected information stored across scattered email boxes and spreadsheets.
  - Delayed reporting cycles resulting in a lack of real-time visibility for clients.
  - High probability of processing duplicate invoices, increasing financial audit risk.
  - Lack of standardized performance reporting for distributed analyst teams.
• Animation Suggestions: Bullet points slide in from left to right sequentially.
• Transition Suggestions: Fade through black to represent legacy dark-ages manual work.
• Screenshot Placement: A cluttered, complex spreadsheet mock-up with mismatch columns.
• Icon Suggestions: Warning, Blocked, Cloud_Off
• Presenter Notes (45-60s):
  "Let's look at the operational reality we faced. Prior to this platform, invoice tracking 
  was heavily manual. Analysts spent hours downloading attachments from random emails, manually 
  transposing vendor numbers into local excels, and fighting schema changes. By the time team leads 
  compiled the weekly report, the data was already stale. This lack of transparency and high error 
  risk is what we set out to solve with MarginEdge Precision."

SLIDE 3: SOLUTION OVERVIEW
• Title: Intelligent Automation & Transparency
• Subtitle: The Precision Paradigm Shift
• Slide Bullet Points:
  - Real-time synchronization of Google Sheets databases and active firestore records.
  - Automatic email capture via automated Gmail Sync Gateways.
  - Specialized AI engines for instant error checking and schema validation.
  - Continuous duplication detection preventing double-payments.
  - Interactive multi-regional dashboards providing instantaneous transparency to clients.
• Animation Suggestions: Zoom-in transition for the solution diagram; glowing borders on success cards.
• Transition Suggestions: Soft blur-fade transition.
• Screenshot Placement: Dashboard summary cards with high-contrast data visualization.
• Icon Suggestions: Auto_Awesome, Update, Check_Circle
• Presenter Notes (45-60s):
  "MarginEdge Precision is our response to manual inefficiencies. By combining server-side AI 
  parsing, real-time sync with Google Sheets, and custom dashboard components, we establish a 
  single source of truth. Data flows securely, alerts trigger instantly on Discord or Chat, 
  and leads monitor live SLA thresholds. We have turned raw logs into interactive operational gold."

SLIDE 4: APPLICATION ARCHITECTURE
• Title: Robust Full-Stack Architecture
• Subtitle: Under the Hood of MarginEdge Precision
• Slide Bullet Points:
  - Modern React with Vite frontend for responsive desktop-first performance.
  - Secure Express backend preventing client-side exposure of Google Workspace credentials.
  - Real-time WebSocket Gateway for instantaneous state synchronization across clients.
  - Persistent Cloud Firestore database mapping live analyst reconciliation structures.
  - Server-side fallback engines guaranteeing 100% platform availability even during cloud spikes.
• Animation Suggestions: Flow chart nodes illuminate in sequence representing data ingestion path.
• Transition Suggestions: Diagonal sliding transition.
• Screenshot Placement: Full technical flowchart showing Gmail Ingestion -> Server -> Database -> UI.
• Icon Suggestions: Settings, Hub, Cloud, Security
• Presenter Notes (45-60s):
  "For our managers and clients, architecture is security. MarginEdge Precision utilizes 
  a custom Express + React architecture. All security checks, API calls to Google Sheets, and 
  Gemini modeling occur in the backend—safe from browser inspections. Client synchronization is 
  handled via continuous WebSockets. If the primary AI engine experiences standard cloud spikes, 
  our server gracefully falls back to our robust internal operations algorithm."

SLIDE 5: DASHBOARD OVERVIEW
• Title: Central Command Center
• Subtitle: The Unified UI Layout
• Slide Bullet Points:
  - Header: Active user context with instant Google account authentication check.
  - High-impact KPI blocks showing live records count, error rates, and pending tasks.
  - Dynamic Regional Filters supporting Office (All), Chandigarh, and Dhaka options.
  - Live activity ticker displaying exact log changes with timestamp metadata.
  - Global Search bar matching vendor codes, analyst usernames, or invoice numbers.
• Animation Suggestions: Dynamic counters count up from zero on load.
• Transition Suggestions: Fade-in of panels with 100ms staggered delay.
• Screenshot Placement: Hero view of the main dashboard with side navigation.
• Icon Suggestions: Dashboard, Query_Stats, Search, Filter_List
• Presenter Notes (45-60s):
  "When you log in, you are greeted by the Command Center. We designed this interface to have 
  generous negative space to prevent eye fatigue. On the top right, your secure credentials 
  and active regional context are visible. The dashboard is divided into visual modules, 
  updated in real time via our WebSocket channel. You can search or filter across thousands of 
  historical reconciliations instantly."

SLIDE 6: EXCEL PIPELINE INGESTION
• Title: The Ingestion Pipeline
• Subtitle: Turning Raw Sheets into Schema-Validated Records
• Slide Bullet Points:
  - Simple drag-and-drop file interface supporting .xlsx and .csv formats.
  - Real-time schema analyzer verifying structure, column naming, and cell types.
  - Automatic fallback translation to prevent crash loops when Excel formats differ.
  - Server-side parsing with database write in batches of up to 500 records.
  - Live status alerts triggering on success or pinpointing exact mismatch cells.
• Animation Suggestions: Simulated file drop animation; progress bar charging up.
• Transition Suggestions: Slide up from bottom.
• Screenshot Placement: Excel Upload panel with drag-and-drop visual indicator active.
• Icon Suggestions: Upload_File, Rule, Error_Med, Cloud_Upload
• Presenter Notes (45-60s):
  "The core engine starts with ingestion. Under the 'Upload' tab, analysts simply drag and drop 
  their daily processing spreadsheets. Our custom pipeline reads the columns, normalizes the dates 
  and names, checks for duplicates against the live database, and commits them in structured batches. 
  If columns are missing, instead of crashing, the system highlights the exact problem rows."

SLIDE 7: PRESET REPORT DASHBOARD
• Title: Real-Time Audit & Preset Reports
• Subtitle: The Direct-to-Source Ledger View
• Slide Bullet Points:
  - Instant direct rendering of database records without browser lag.
  - Highly robust sorting across dates, invoice numbers, amounts, and statuses.
  - Advanced search query engine supporting partial text matches.
  - One-click Excel/CSV export for external client delivery.
  - Integrated AI Action Recommendation generator based on current transaction metrics.
• Animation Suggestions: Table rows fade in with subtle stagger; action card expands smoothly.
• Transition Suggestions: Fade in with soft scale.
• Screenshot Placement: Preset Report table with active filters applied.
• Icon Suggestions: List_Alt, Table_View, Export_Notes, Recommend
• Presenter Notes (45-60s):
  "The 'Preset Report' view is where our operations leads live. It is our high-performance data 
  grid. You can sort records by date, employee name, or vendor category, and use the search query 
  to isolate specific transactions. The export button prepares a clean CSV file that maps 
  exactly to the formatted client ledger. At the bottom, our AI recommendation engine suggests 
  immediate operational corrections."

SLIDE 8: ANALYTICS & REGIONAL PERFORMANCE
• Title: Multi-Regional Analytics Dashboard
• Subtitle: Transparency & Live Operational Metrics
• Slide Bullet Points:
  - Production trends tracked across weeks, months, and quarters.
  - Deep vendor performance breakdown highlighting high-risk accounts.
  - Analyst performance grids mapping individual volume and SLA accuracy.
  - Real-time duplicate transaction detector marking potential billing errors.
  - Cross-regional SLA tracker mapping Chandigarh vs. Dhaka completion rates.
• Animation Suggestions: Recharts Area and Bar graphs draw dynamically with smooth cubic ease.
• Transition Suggestions: Push transition to the left.
• Screenshot Placement: Multi-chart performance screen showing team and vendor statistics.
• Icon Suggestions: Analytics, Legend_Toggle, Trending_Up, Group
• Presenter Notes (45-60s):
  "Let's dive into Analytics. This screen hosts interactive charts drawn directly from real-time 
  database metrics. Team leads can monitor which vendors have the longest processing times, 
  which analysts are exceeding accuracy benchmarks, and identify bottlenecks instantly. 
  The regional comparative tracker shows exact throughput percentages for Chandigarh and Dhaka."

SLIDE 9: AI FEATURES & EXECUTIVE INSIGHTS
• Title: MarginEdge AI Engine
• Subtitle: Leveraging Intelligent Operations Fallback
• Slide Bullet Points:
  - Direct server-side interface to the modern Google GenAI API.
  - Generative summaries explaining trends, anomaly alerts, and duplicate warnings.
  - Smart recommendations for staff allocation based on regional bottlenecks.
  - Automatic backup-driven operational analytics serving custom reports under high demand.
  - Clean client-facing executive summaries formatted for direct presentation.
• Animation Suggestions: A pulsating 'AI Sparkle' badge; glowing text highlights.
• Transition Suggestions: Zoom-out fade.
• Screenshot Placement: Executive Summary modal with interactive recommender cards.
• Icon Suggestions: Auto_Awesome, Psychology, Notifications_Active, Shield
• Presenter Notes (45-60s):
  "MarginEdge Precision is equipped with an advanced AI Engine. In normal conditions, it queries 
  the latest Google GenAI model server-side to generate insights, trend summaries, and recommendations. 
  If the model experiences cloud service spikes, our Express backend switches to an internal 
  operation algorithm to serve accurate, resilient analyses instantly. The dashboard never stops."

SLIDE 10: AUTOMATED REPORTS SUITE
• Title: The Reporting Suite
• Subtitle: Scheduled Exports & Client Delivery
• Slide Bullet Points:
  - Standard pre-formatted reporting templates for immediate dispatch.
  - Automatic alignment of column schemas to match standard client bookkeeping formats.
  - One-click download of filtered data sets.
  - Integration with secure workspace channels for easy email sharing.
  - Full tracking of historical export metadata.
• Animation Suggestions: Document icons sliding into a virtual folder.
• Transition Suggestions: Fade through white.
• Screenshot Placement: Reporting section showing ready-to-download files.
• Icon Suggestions: Description, Download, Folder_Zip, Share
• Presenter Notes (45-60s):
  "Our Reporting Suite bridges internal work with client deliverables. Leads can generate 
  customized CSV files for weekly client catch-ups. With a single click, you can filter for all 
  reconciliations processed in Chandigarh, export the sheet, and deliver high-precision reports. 
  Every export maps directly to standard bookkeeping requirements, ensuring seamless client upload."

SLIDE 11: USER ROLES & ACCESS CONTROL
• Title: Role-Based Access Control (RBAC)
• Subtitle: Secure Operational Boundaries
• Slide Bullet Points:
  - Admin: Full system control, system-wide settings, and backup management.
  - Team Lead: Access to all regional analytics, Excel uploads, and team audits.
  - Analyst: Core workspace for processing, manual entries, and local uploads.
  - Viewer/Client: Read-only access to specific dashboards and exported reports.
  - Unified Google SSO authentication securing every endpoint.
• Animation Suggestions: Security badges lighting up across different user profiles.
• Transition Suggestions: Soft fade.
• Screenshot Placement: User Settings panel showing active permissions toggle.
• Icon Suggestions: Supervisor_Account, Security, Lock_Open, Manage_Accounts
• Presenter Notes (45-60s):
  "Security and role boundaries are paramount. Our unified login interface utilizes role-based 
  access control. This ensures that while analysts can upload daily sheets and process records, 
  only designated team leads can broadcast global notifications or alter backup schedules. 
  Clients can log in with a dedicated viewer role to see live trends without risk of data modifications."

SLIDE 12: COMPLETE SYSTEM WORKFLOW DEMO
• Title: The Complete End-to-End Workflow
• Subtitle: Seamless Operations in 9 Action Steps
• Slide Bullet Points:
  - 1. LOGIN: Secure SSO entry into the corporate command center.
  - 2. DASHBOARD: View live statistics and global system alerts.
  - 3. INGEST: Drag-and-drop raw invoice files in the Upload module.
  - 4. AUDIT: Review analyst quality scores and transaction accuracy.
  - 5. LIVE SYNC: Monitor real-time websocket database updates.
  - 6. ANALYZE: Generate comprehensive trend graphs and charts.
  - 7. INSIGHTS: Read custom AI recommendations and operational alerts.
  - 8. EXPORT: Generate ledger-ready client ledger CSV.
  - 9. BACKUP: Run automated server-side disaster recovery sync.
• Animation Suggestions: 9 numbered steps light up in a circular loop representation.
• Transition Suggestions: Fast vertical flip.
• Screenshot Placement: High-level overview diagram of the entire application.
• Icon Suggestions: Play_Circle, Fact_Check, Sync, Folder_Shared, Logout
• Presenter Notes (45-60s):
  "Let's trace the life of an invoice. An analyst logs in, reviews the command dashboard, and 
  uploads the excel. The ingestion pipeline parses, sanitizes, and verifies the data against 
  Firestore. Real-time updates notify the team lead via websocket. The analyst quality dashboard 
  recalculates regional accuracy. The lead runs the AI summary, exports the client-ready sheet, 
  and the system takes care of background backups. Absolute synergy in 9 steps."

SLIDE 13: BUSINESS BENEFITS & ROI
• Title: Unlocking Operational Excellence
• Subtitle: Concrete ROI and Business Impact
• Slide Bullet Points:
  - 85% reduction in manual spreadsheet compilation and email coordination.
  - 99.85% processing accuracy achieved through automated schema checkers.
  - 100% live transparency for global clients, removing status check emails.
  - Eliminates duplicate invoice errors, saving substantial audit recovery costs.
  - Fast, standardized team training with unified onboarding tools.
• Animation Suggestions: Bar graph showing 'Manual Hours' shrinking, 'System Accuracy' rising.
• Transition Suggestions: Zoom-in.
• Screenshot Placement: Summary cards showing performance percentage metrics.
• Icon Suggestions: Paid, Workspace_Premium, Rocket_Launch, Speed
• Presenter Notes (45-60s):
  "The returns on using MarginEdge Precision are clear. By automating file transfers and 
  establishing direct database validation, we reduce manual tracking time by over 80%. 
  More importantly, our processing accuracy climbs to 99.85%. Clients no longer need to email 
  asking for updates; they log in and see live progress. This is operational excellence."

SLIDE 14: FUTURE ROADMAP & VOTING HUB
• Title: The Platform Evolution
• Subtitle: Collaboratively Shaping Future Ingestion Pipelines
• Slide Bullet Points:
  - 🤖 Automated PII Anonymization & Security Guardrails (MASKS sensitive data).
  - 📈 Predictive SLA Bottleneck Forecaster (ML pipeline congestion detector).
  - 🚀 One-Click Client API Gateway Integration (Direct ERP connectivity).
  - 📱 Real-Time Push Notifications and Mobile-Optimized Dashboard.
  - 📊 Advanced BI Embedded Dashboards for complex forecasting.
• Animation Suggestions: Roadmap timeline blocks slide in from the right; interactive vote counts update.
• Transition Suggestions: Swipe left.
• Screenshot Placement: The live Interactive Roadmap tab with active up-vote count indicators.
• Icon Suggestions: Timeline, Upgrade, Biotech, How_To_Vote
• Presenter Notes (45-60s):
  "We don't stand still. Under the 'Roadmap' tab, users can actively participate in the 
  platform's growth. We have outlined key future modules, including Automated PII masking 
  and Machine Learning bottleneck forecasting. Team leads and managers can up-vote their 
  priority features, which directly informs our development sprints. This is a shared roadmap."

SLIDE 15: CONCLUSION & PROFESSIONAL CLOSING
• Title: Elevating Hospitality Financial Operations
• Subtitle: Precision In Every Invoice, Every Day
• Slide Bullet Points:
  - A unified platform engineered for the modern distributed workplace.
  - Real-time transparency, automated ingestion, and resilient architecture.
  - Thank you to our Chandigarh and Dhaka operations teams.
  - Let's shape high-performance bookkeeping together.
  - Ready for immediate manager deployment and analyst onboarding.
• Animation Suggestions: Final slide logo fades in with a gorgeous ambient particle effect.
• Transition Suggestions: Soft fade through royal indigo.
• Screenshot Placement: Custom brand logo overlay with developer contact metadata.
• Icon Suggestions: Handshake, Task_Alt, Favorite, Celebration
• Presenter Notes (45-60s):
  "In closing, MarginEdge Precision represents a huge leap forward in how we manage hospitality 
  operations. By unifying secure technology with human-centric designs, we have created an 
  interface that makes complex work satisfying and fast. Thank you to our dedicated teams 
  who made this possible. Let's make precision our standard, every single day. Thank you."


--------------------------------------------------------------------------------
2. COMPREHENSIVE TRAINING VIDEO SCRIPT
--------------------------------------------------------------------------------

[VIDEO INTRO: Dynamic logo fade-in on Royal Indigo background with clean geometric shapes. 
Upbeat, ambient corporate background music playing at soft volume. Smooth zoom-in on the login window.]

"Hello everyone, and welcome to your complete onboarding training video for MarginEdge Precision, 
our unified Invoice Ingestion and Operational Intelligence platform. I am your product trainer, 
and in this video, we will walk through every screen, click, and feature so you can master your 
daily operations workflow with high confidence. This system is designed for ease of use, speed, 
and complete transparency. Let's get started!"

[SCENE 1: THE LOGIN SCREEN & USER AUTHENTICATION]
"Look at your screen. We begin at the Secure Portal Login. To access the platform, you will 
enter your authorized corporate email—here we are using ankit.thakur@marginedge.com—and your secure password. 
The system runs Role-Based Access Control, which means once you click 'Sign In', the application 
verifies your specific team permissions. Analysts get access to upload queues, while leads 
receive advanced quality dashboards. Let's click the blue 'Sign In' button now."

[SCENE 2: THE COMMAND CENTER DASHBOARD]
"Once signed in, you are greeted by the main Command Center. Let's review the layout. 
On the left side, we have our primary navigation bar, which allows you to switch between 
Dashboard, Upload Invoices, Preset Report, Analyst Quality, Gmail Sync, Google Chat, 
Live Sync, Performance Monitor, and Presentation. 

At the very top, you see the global status bar: 'Real-Time Connection Active', the active 
user profile, and the regional context selector. You can filter all metrics by selecting 
'Chandigarh' or 'Dhaka' from this dropdown, or view 'Office (All)' for a consolidated view.

Directly below, look at the four High-Impact KPI cards:
- Total Invoices Processed: Displays our global volume across teams.
- Processing Error Rate: Tracks our current standard. We aim to keep this under 1%.
- Duplicate Alarm State: This shows if any double-billing is detected.
- Average Processing Time: Displays the current average SLA completion speed."

[SCENE 3: THE LIVE SYSTEM ACTIVITY STREAM]
"On the right-hand side of the main dashboard, you'll see the 'Real-Time Operational Log Stream'. 
This is our live audit log. Every time an analyst uploads a spreadsheet, resolves an error, 
or updates an SLA status, a record is pushed to this stream. It is updated in real time via 
WebSockets, so you never have to manually refresh your browser to see what the team is doing."

[SCENE 4: EXCEL INGESTION & PIPELINE UPLOAD]
"Let's click on the 'Upload Invoices' tab on the left menu. This is where analysts process daily client sheets. 
To upload a spreadsheet:
1. You can either drag and drop your daily .xlsx file onto the dotted blue upload box, or 
   click inside to browse your local computer files.
2. The ingestion pipeline reads the spreadsheet columns immediately. Our automated schema validator 
   checks that important columns—like invoice number, vendor code, date, and amount—are present.
3. If columns match, you will see a green checkmark saying 'Schema Validation Successful'. 
4. If there's an error, the system will highlight the exact mismatch column instead of crashing. 
5. Finally, click 'Ingest to Database'. This commits the records to our live Firestore ledger."

[SCENE 5: THE PRESET REPORT GRID]
"Now let's switch to the 'Preset Report' tab. This is our high-performance data grid. 
Here you can see every single processed transaction.
- Searching: Type a vendor name, an invoice number, or an analyst's initials in the search bar. 
  The grid filters instantly as you type.
- Sorting: Click on any column header—such as 'Date', 'Invoice Amount', or 'Status'—to sort 
  in ascending or descending order.
- Status Badge: Every record is marked with an operational status—Completed, Pending, or Under Review.
- AI Recommendations Panel: At the bottom of the Preset tab, our smart algorithm scans the grid 
  metrics and displays action tips, such as reallocating high-priority accounts to prevent backlogs.
- Export Button: Click the blue 'Export to CSV' button. The system prepares a beautifully 
  formatted client-ready spreadsheet and downloads it to your computer instantly."

[SCENE 6: ANALYST QUALITY & REGIONAL AUDITS]
"Let's move to the 'Analyst Quality' dashboard. This is where team leads audit daily operations. 
The screen displays our team leaderboard, showing each analyst's name, their total reconciled volume, 
average processing speed, and individual accuracy rate.
- Interactive Search: You can search for specific analysts using the search box.
- Trigger Alert Button: Next to the team logs, leads can click 'Trigger Google Chat Alert'. 
  This sends an automated audit card directly to our regional operations rooms so team members 
  are instantly aware of SLA queues."

[SCENE 7: SECURE DISASTER RECOVERY & BACKUPS]
"As a certified platform, disaster recovery is built in. Under the 'Live Sync' or 'Settings' tab, 
managers can view the current database backup status. Backups run automatically every hour, 
but you can trigger an immediate manual backup by clicking 'Run Manual Backup Now'. The system 
syncs our active Firestore with a cold-storage spreadsheet backup, ensuring zero data loss."


--------------------------------------------------------------------------------
3. SCREEN-BY-SCREEN VIDEO STORYBOARD
--------------------------------------------------------------------------------

[FRAME 1: TITLE SCREEN]
• Visual: Royal Indigo gradient background. MarginEdge Precision logo in bold display sans-serif. 
  A subtle white sparkle icon rotating slowly on the top-right.
• Camera Action: Static shot, slow zoom into the logo (0s to 5s).
• Music: Upbeat, professional, corporate electronic theme fades in.
• Graphic Callout: Text slide-in "ELEVATING OPERATIONS THROUGH INTELLIGENCE".

[FRAME 2: SECURE USER LOGIN]
• Visual: Login interface on slate-dark canvas. Input fields highlight with a glowing blue border. 
  A circular "Security Verified" badge appears in the corner.
• Camera Action: Zoom in on the email entry field. Focuses on user email typing.
• Graphic Callout: Circle cursor highlight on the blue 'Sign In' button.
• Audio: Click sound effect when 'Sign In' is pressed.

[FRAME 3: MAIN COMMAND CENTER]
• Visual: Wide desktop view of the main dashboard. Four large KPI metrics glow and animate upwards. 
  A line chart displays production trends.
• Camera Action: Smooth slide from left to right, showcasing the main navigation bar, then centering 
  on the KPI cards.
• Graphic Callout: Pop-up boxes pointing to 'Total Invoices' and 'Error Rate' stats.
• Action: The 'Real-Time Operational Log' ticker scrolls down one line as a mock update occurs.

[FRAME 4: DRAG-AND-DROP FILE UPLOAD]
• Visual: The Upload Invoice page is shown. A virtual cursor drags a glowing document icon 
  and drops it into the dash-bordered zone.
• Camera Action: Split screen. Left shows the drag-and-drop zone; right shows the real-time console 
  verifying columns.
• Graphic Callout: Glowing green text banner: "SCHEMA VERIFICATION: SUCCESSFUL".

[FRAME 5: AUDITING DATA GRID]
• Visual: Preset Report ledger grid. Rows are sorted with one click on 'Invoice Amount'.
• Camera Action: Scroll down through the table rows. Zoom in on the search bar.
• Graphic Callout: Red box highlights "Duplicate Detected" row warning to guide trainer attention.

[FRAME 6: TEAM PERFORMANCE LEADBOARD]
• Visual: Team quality scoreboard with horizontal progress bars representing individual accuracy rates.
• Camera Action: Hover cursor on the 'Google Chat Sync' button on the dashboard menu.
• Graphic Callout: Animated chat bubble showing Discord/Chat message trigger payload simulation.

[FRAME 7: DATA DISASTER RECOVERY STATE]
• Visual: Live Sync panel with database checkmarks. An interactive slider displays backup interval rates.
• Camera Action: Pan right towards the 'Run Manual Backup' button.
• Graphic Callout: Loading spinner rotates for 2 seconds, followed by a checkmark badge "BACKUP SYNC COMPLETED".


--------------------------------------------------------------------------------
4. TRAINER NOTES & BEST PRACTICES
--------------------------------------------------------------------------------

TR-1: STRESSING THE DUAL-FALLBACK ENGINE
- Always explain to trainees and clients that the AI insights panel operates on a resilient dual-fallback mechanism.
- If high traffic triggers a 503 unavailability on the Google cloud model, the system automatically runs our 
  internal analytical script to deliver high-quality reports. It will NEVER display a broken blank screen.

TR-2: DRILL REVISION FOR EXCEL STRUCTURES
- During training, ensure analysts know that sheet headers MUST contain 'Invoice Number', 'Amount', and 'Date'.
- If they upload a sheet with different headers, teach them to use the 'Schema Check' helper to review required values.

TR-3: LIVE WEB-SOCKET SYNC
- Remind users that because the application is fully reactive via WebSockets, they do not need to click 
  F5 or refresh. All logs, alerts, and transaction statuses update dynamically.


--------------------------------------------------------------------------------
5. COMMON OPERATION MISTAKES (Avoiding Pitfalls)
--------------------------------------------------------------------------------

1. OVER-FILTERING DATA SETS
- Analysts sometimes select 'Dhaka' as the region, search for a Chandigarh vendor, and report 'missing records'.
- Fix: Always check the active regional dropdown in the top-right before performing ledger audits.

2. DOUBLE-CLICKING UPLOAD BUTTONS
- Double-clicking upload can trigger multiple ingestion events on slow networks.
- Fix: The platform is built with submit-throttling, but users should click 'Ingest to Database' once and wait 
  for the green confirmation popup.

3. EXPORTING RAW UNCLEAN RECORDS
- Exporting sheets before resolving the 'Duplicate Invoice' warnings can lead to ledger mismatch.
- Fix: Always review and resolve warning status flags in the Preset Report before exporting deliverables for clients.


--------------------------------------------------------------------------------
6. CLOSING SPEECH FOR MEETINGS
--------------------------------------------------------------------------------

"Thank you, ladies and gentlemen, managers, and teammates. 

What we have demonstrated today in MarginEdge Precision is more than just software. It is a 
refined operational framework designed specifically for our high-intensity bookkeeping hubs. 
By integrating Gmail, Google Sheets, Firestore, and AI-powered schema audits into one robust, 
responsive platform, we have replaced hours of tedious manual Excel formatting with simple, 
instant actions.

Whether you are a new analyst embarking on your onboarding journey, a team lead supervising daily 
throughput, or a client looking for absolute transparency, this platform is engineered for your 
success. Let's embrace this precision, leverage our intelligent backups, and continue delivering 
world-class operational performance. Thank you!"
================================================================================
`;

    const blob = new Blob([content], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'MarginEdge_Precision_Training_Materials.md');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Video simulator narration and mockup screens
  const videoSteps = [
    {
      title: '1. Secure Portal Authentication & Gateway',
      narration: 'Sabse pehle, platform highly secure Single Sign-On (SSO) Google Portal use karta hai, jisse Chandigarh hub ke accounts safe rehte hain.',
      screenName: 'Live Google Auth Portal',
      actions: ['Authenticating ankit.thakur@marginedge.com...', 'Fetching Role: Admin/Lead', 'Loading security context...'],
      badge: 'Security',
      highlightColor: 'from-[#6366f1] to-[#4f46e5]',
    },
    {
      title: '2. Live Sync & Multi-Regional Ingestion Engine',
      narration: 'Login hote hi "Live Sync Dashboard" activate hota hai, jo hume directly Google Sheets and local state se real-time dynamic statistics pull karke deta hai.',
      screenName: 'Live Sync Panel',
      actions: ['Active Connection: Connected (Real-Time)', 'Fetched 15,240 records from Chandigarh database', 'Applying filters...'],
      badge: 'Data Processing',
      highlightColor: 'from-[#3b82f6] to-[#2563eb]',
    },
    {
      title: '3. Automated Gmail Gateway Processing',
      narration: 'Gmail Sync Gateway, dedicated corporate inboxes ko monitor karta hai, spreadsheet links and excel logs directly capture karke download pipelines trigger karta hai.',
      screenName: 'Gmail Ingestor Module',
      actions: ['Scanning ankit.thakur@marginedge.com...', 'Downloaded attachments: 12 reports', 'Automatic mapping complete'],
      badge: 'Automation',
      highlightColor: 'from-[#10b981] to-[#059669]',
    },
    {
      title: '4. Excel-to-JSON Pipeline Ingestion',
      narration: 'Humare pass "Excel Upload Dashboard" tool hai jo structural sheets ko fast mapping algorithms ke sath operational metrics me convert karta hai.',
      screenName: 'Structured Pipeline',
      actions: ['Parsing Sheet1.xlsx...', 'Generated standard schema nodes', 'No schema mismatch errors found'],
      badge: 'Ingestion Engine',
      highlightColor: 'from-[#f59e0b] to-[#d97706]',
    },
    {
      title: '5. Real-Time Team Audit & Scoring Hub',
      narration: 'Leads aur AMs live worker metrics audit kar sakte hain, error thresholds analyze kar sakte hain, aur immediate Google Chat alerts coordinate kar sakte hain.',
      screenName: 'Analyst Quality Dashboard',
      actions: ['Calculating accuracy metrics...', 'Team Chandigarh efficiency at 99.85%', 'Triggered Google Chat payload to Space "Chandigarh Ops"'],
      badge: 'Quality & Audit',
      highlightColor: 'from-[#ec4899] to-[#db2777]',
    },
  ];

  // Presentation Slides configuration
  const slides: Slide[] = [
    {
      id: 1,
      title: '✨ Welcome to MarginEdge Operational Intelligence Platform',
      subtitle: 'System Overviews and Architectural Highlights',
      badge: 'Core Identity',
      gradient: 'from-[#1e1b4b] via-[#311042] to-[#090514]',
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center text-left">
          <div className="space-y-5">
            <h3 className="text-2xl font-bold text-white tracking-tight">
              Humara Platform <span className="text-[#a855f7]">KAISA HAI</span> aur kya capability provide karta hai?
            </h3>
            <p className="text-slate-300 text-sm leading-relaxed">
              MarginEdge Operational Intelligence ek premium, responsive dashboard platform hai jo complete client audit processes, Gmail automation, sheets synchronization, data pipelines aur workspace metrics ko single interface me gather karta hai.
            </p>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <span className="material-symbols-outlined text-green-400 mt-1">check_circle</span>
                <div>
                  <h4 className="text-sm font-semibold text-white">Intuitive Desktop-First Layout</h4>
                  <p className="text-xs text-slate-400">Generous negative space, dark slate visual aesthetics, with interactive widgets that adapt dynamically.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <span className="material-symbols-outlined text-green-400 mt-1">check_circle</span>
                <div>
                  <h4 className="text-sm font-semibold text-white">Full-Stack Realtime Architecture</h4>
                  <p className="text-xs text-slate-400">Secured server endpoints backed by structured Firestore & responsive Google Workspace APIs.</p>
                </div>
              </div>
            </div>
          </div>
          <div className="bg-[#1e293b]/70 border border-slate-700 p-6 rounded-2xl shadow-xl space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#38bdf8]">System Highlights</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/50">
                <span className="material-symbols-outlined text-[#a855f7] text-3xl">electric_bolt</span>
                <div className="text-lg font-black text-white mt-2">12ms</div>
                <div className="text-[10px] text-slate-400">DB Response Speed</div>
              </div>
              <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/50">
                <span className="material-symbols-outlined text-[#38bdf8] text-3xl">cloud_sync</span>
                <div className="text-lg font-black text-white mt-2">Active</div>
                <div className="text-[10px] text-slate-400">Vite & Express Live Gateway</div>
              </div>
              <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/50">
                <span className="material-symbols-outlined text-[#34d399] text-3xl">mail</span>
                <div className="text-lg font-black text-white mt-2">Gmail API</div>
                <div className="text-[10px] text-slate-400">Integrated Sync Ingestion</div>
              </div>
              <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/50">
                <span className="material-symbols-outlined text-[#f43f5e] text-3xl">speed</span>
                <div className="text-lg font-black text-white mt-2">100%</div>
                <div className="text-[10px] text-slate-400">Lighthouse Perf Score</div>
              </div>
            </div>
          </div>
        </div>
      ),
    },
    {
      id: 2,
      title: '📊 Data Structure, Inventories & Operational Use Case',
      subtitle: 'Aabi tak kitna data bna hai aur uska use-case kya hoga?',
      badge: 'Data Architecture',
      gradient: 'from-[#0b152d] via-[#102a43] to-[#040e21]',
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center text-left">
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-white leading-snug">
              Humare built-in modules me <span className="text-[#38bdf8]">KHOOB DATA</span> capture aur process ho chuka hai:
            </h3>
            <p className="text-slate-300 text-xs leading-relaxed">
              Platform me standard structures create ho chuki hain, jisse automatic mapping pipelines easily functional rehti hain aur operations clear data targets pe trigger hoti hain.
            </p>
            <div className="space-y-3">
              <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700/30">
                <h4 className="text-xs font-bold text-white flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#10b981]"></span>
                  Reconciliation & Invoices Records (15k+ simulated)
                </h4>
                <p className="text-[11px] text-slate-400 mt-1">
                  **Use Case:** Vendor matching parameters process karna, status highlight (high risk mismatch) auto-flag karna, and priority items direct team targets pe redirect karna.
                </p>
              </div>
              <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700/30">
                <h4 className="text-xs font-bold text-white flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#3b82f6]"></span>
                  Gmail API Sync logs & Workspace Payloads
                </h4>
                <p className="text-[11px] text-slate-400 mt-1">
                  **Use Case:** Direct invoices attachments links track karna, files parse karna aur human manual effort ko minimize karna.
                </p>
              </div>
            </div>
          </div>
          <div className="space-y-4">
            <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#a855f7]">Current Database State</h4>
              <div className="space-y-2">
                <div>
                  <div className="flex justify-between text-xs text-slate-300 mb-1">
                    <span>Reconciliation Records (Firestore)</span>
                    <span className="font-bold text-white">100% Configured</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-gradient-to-r from-[#10b981] to-[#3b82f6] h-full w-full"></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-xs text-slate-300 mb-1">
                    <span>Scoring Analytics & IPA Benchmarks</span>
                    <span className="font-bold text-white">95% Linked</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-gradient-to-r from-[#3b82f6] to-[#a855f7] h-full w-[95%]"></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-xs text-slate-300 mb-1">
                    <span>Gmail API Integration Gateway</span>
                    <span className="font-bold text-white">Active</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-gradient-to-r from-[#a855f7] to-[#ec4899] h-full w-[90%]"></div>
                  </div>
                </div>
              </div>
              <div className="text-[10px] text-slate-400 bg-slate-800/40 p-2.5 rounded-lg border border-slate-700/30 leading-normal">
                💡 **Hindi Summary:** Humare built data se aap automated alerts trace kar sakte hain, Chandigarh office quality scoring audit kar sakte hain aur immediate response measures plan kar sakte hain.
              </div>
            </div>
          </div>
        </div>
      ),
    },
    {
      id: 3,
      title: '🤝 Operational Value Add & Workflow Assistance',
      subtitle: 'Yeh humari kya kya aur kaise help karega?',
      badge: 'Help & Value',
      gradient: 'from-[#022c22] via-[#064e3b] to-[#022c22]',
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center text-left">
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-white">
              Operations me yeh hume <span className="text-[#34d399]">SUPER-POWER</span> kaise deta hai?
            </h3>
            <p className="text-slate-300 text-xs leading-relaxed">
              Platform manual sheets cross-checking aur updates me hone wale human errors ko reduce karke efficiency badhata hai.
            </p>
            <div className="grid grid-cols-1 gap-3">
              <div className="flex gap-3 bg-emerald-950/40 p-3 rounded-xl border border-emerald-800/40">
                <span className="material-symbols-outlined text-[#34d399] text-2xl">alarm_on</span>
                <div>
                  <h4 className="text-xs font-bold text-white">Saves Time (Up to 15 hours/week)</h4>
                  <p className="text-[11px] text-slate-400">Gmail automations aur automated spreadsheet integration manual search aur downloads steps ko remove karta hai.</p>
                </div>
              </div>
              <div className="flex gap-3 bg-emerald-950/40 p-3 rounded-xl border border-emerald-800/40">
                <span className="material-symbols-outlined text-[#34d399] text-2xl">error_med</span>
                <div>
                  <h4 className="text-xs font-bold text-white">Automatic Mismatch Highlighting</h4>
                  <p className="text-[11px] text-slate-400">Agar match percentages limit se drop ho, to dynamic flags triggers immediate action system alerts update kar dete hain.</p>
                </div>
              </div>
              <div className="flex gap-3 bg-emerald-950/40 p-3 rounded-xl border border-emerald-800/40">
                <span className="material-symbols-outlined text-[#34d399] text-2xl">group_work</span>
                <div>
                  <h4 className="text-xs font-bold text-white">Coordinated Chandigarh Team Efforts</h4>
                  <p className="text-[11px] text-slate-400">Scorecard analytics provides clear metrics of top performer analysts, encouraging high accuracy.</p>
                </div>
              </div>
            </div>
          </div>
          <div className="space-y-3 bg-slate-900/40 p-5 rounded-2xl border border-slate-800 text-center">
            <span className="material-symbols-outlined text-emerald-400 text-5xl">support_agent</span>
            <h4 className="text-sm font-bold text-white">Support & Operations Catalyst</h4>
            <p className="text-xs text-slate-300 max-w-sm mx-auto leading-relaxed">
              "Humara main target operational bottleneck checks automate karna hai. Realtime status checks and Google Chat workspace coordination se hum instant synchronization complete kar pate hain."
            </p>
            <div className="inline-flex gap-2 items-center bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-full mt-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider">Ready for Deployment</span>
            </div>
          </div>
        </div>
      ),
    },
    {
      id: 4,
      title: '🚀 Future Blueprint & Continuous Innovations',
      subtitle: 'Aage kya upgrades update kar sakte hain?',
      badge: 'Future Roadmap',
      gradient: 'from-[#2e081c] via-[#470a2b] to-[#14020a]',
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center text-left">
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-white leading-snug">
              Platform ko aur behtareen banane ke liye <span className="text-[#ec4899]">UPCOMING UPGRADES</span> roadmap:
            </h3>
            <p className="text-slate-300 text-xs leading-relaxed">
              Future me hum deep automation tools link kar sakte hain, jisse systems self-authoritative tarike se operational flows handle kar sakein.
            </p>
            <div className="space-y-2">
              <div className="flex gap-2.5 items-center">
                <span className="w-2 h-2 rounded-full bg-pink-500"></span>
                <span className="text-xs text-slate-300"><strong className="text-white">Writeback Sync:</strong> Directly committing dashboard edits to live sheets.</span>
              </div>
              <div className="flex gap-2.5 items-center">
                <span className="w-2 h-2 rounded-full bg-pink-500"></span>
                <span className="text-xs text-slate-300"><strong className="text-white">AI Auto-Anonymizer:</strong> Automated PII masking algorithms.</span>
              </div>
              <div className="flex gap-2.5 items-center">
                <span className="w-2 h-2 rounded-full bg-pink-500"></span>
                <span className="text-xs text-slate-300"><strong className="text-white">Predictive SLAs:</strong> Advanced bottleneck forecasting indicators.</span>
              </div>
              <div className="flex gap-2.5 items-center">
                <span className="w-2 h-2 rounded-full bg-pink-500"></span>
                <span className="text-xs text-slate-300"><strong className="text-white">Google Chatbot:</strong> Command driven updates queries directly inside team chats.</span>
              </div>
            </div>
          </div>
          <div className="bg-slate-900/60 p-5 rounded-2xl border border-slate-800 space-y-4">
            <h4 className="text-xs font-bold text-pink-400 uppercase tracking-wider flex items-center gap-2">
              <span className="material-symbols-outlined text-sm">rocket_launch</span>
              Simulated Future Visual Interface
            </h4>
            <div className="border border-slate-700/50 rounded-xl p-3 bg-slate-950/80 space-y-2 font-mono text-[10px]">
              <div className="text-slate-500"># SLA PREDICTION ENGINE (SIMULATED ML)</div>
              <div className="flex justify-between text-slate-300">
                <span>[Chandigarh Q1 Ingestion]</span>
                <span className="text-yellow-400 font-bold">WARNING: Delay risk (82%)</span>
              </div>
              <div className="text-[#38bdf8]">&gt; Recommended action: Shift 3 Analysts from Reco to Match.</div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div className="bg-yellow-500 h-full w-[82%] animate-pulse"></div>
              </div>
              <div className="text-slate-500 flex justify-between">
                <span>Bottleneck Predicted: 14:30 PM</span>
                <span>Accuracy Target: 99.8%</span>
              </div>
            </div>
            <p className="text-[10px] text-slate-400 leading-normal">
              💡 **Upgrades impact:** Yeh predictive triggers Chandigarh Ops Hub ko zero-delay operational capability provide karenge.
            </p>
          </div>
        </div>
      ),
    },
  ];

  return (
    <div className="flex h-screen bg-[#090b11] text-slate-100 font-sans overflow-hidden">
      {/* LEFT SIDEBAR NAVIGATION */}
      <aside className="w-64 bg-[#0d111d] border-r border-slate-800 flex flex-col shrink-0 select-none">
        <div className="p-6 border-b border-slate-800 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#3b82f6] to-[#a855f7] flex items-center justify-center shadow-lg">
            <span className="material-symbols-outlined text-white text-[20px] font-bold">slideshow</span>
          </div>
          <div>
            <h1 className="text-sm font-black text-white tracking-wide uppercase">ME Precision</h1>
            <p className="text-[10px] text-blue-400 font-bold">Ops Presentation Deck</p>
          </div>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
          <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider px-3 mb-2">Presentation Tabs</div>
          
          <button
            onClick={() => setActiveTab('slides')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all ${
              activeTab === 'slides' ? 'bg-[#1d2433] text-blue-400 font-bold' : 'text-slate-400 hover:bg-[#121824]'
            }`}
          >
            <span className="material-symbols-outlined text-lg">co_present</span>
            <span className="text-xs">Slide Deck Presentation</span>
          </button>

          <button
            onClick={() => setActiveTab('video')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all ${
              activeTab === 'video' ? 'bg-[#1d2433] text-blue-400 font-bold' : 'text-slate-400 hover:bg-[#121824]'
            }`}
          >
            <span className="material-symbols-outlined text-lg">smart_display</span>
            <span className="text-xs">Simulated Video Walkthrough</span>
          </button>

          <button
            onClick={() => setActiveTab('roadmap')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all ${
              activeTab === 'roadmap' ? 'bg-[#1d2433] text-blue-400 font-bold' : 'text-slate-400 hover:bg-[#121824]'
            }`}
          >
            <span className="material-symbols-outlined text-lg">timeline</span>
            <span className="text-xs">Future Roadmap & Voting</span>
          </button>

          <button
            onClick={() => setActiveTab('charts')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all ${
              activeTab === 'charts' ? 'bg-[#1d2433] text-blue-400 font-bold' : 'text-slate-400 hover:bg-[#121824]'
            }`}
          >
            <span className="material-symbols-outlined text-lg">bar_chart</span>
            <span className="text-xs">Interactive Charts Sandbox</span>
          </button>

          <div className="pt-4 mt-4 border-t border-slate-800">
            <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider px-3 mb-2">Return to Platform</div>
            <button
              onClick={() => onNavigate('LIVE_SYNC_DASHBOARD')}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left text-slate-400 hover:bg-[#121824] transition-all"
            >
              <span className="material-symbols-outlined text-lg">sync_saved_locally</span>
              <span className="text-xs">Live Sync Panel</span>
            </button>

            {(userPosition === 'Admin' || userPosition === 'AM') && (
              <button
                onClick={() => onNavigate('PRECISION_OPS_DASHBOARD')}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left text-slate-400 hover:bg-[#121824] transition-all"
              >
                <span className="material-symbols-outlined text-lg">dashboard</span>
                <span className="text-xs">Invoice Manager</span>
              </button>
            )}

            <button
              onClick={() => onNavigate('DETAILED_PORTFOLIO_LOGS')}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left text-slate-400 hover:bg-[#121824] transition-all"
            >
              <span className="material-symbols-outlined text-lg">analytics</span>
              <span className="text-xs">Detailed Reports</span>
            </button>

            {(userPosition === 'Admin' || userPosition === 'AM') && (
              <button
                onClick={() => onNavigate('GMAIL_DASHBOARD')}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left text-slate-400 hover:bg-[#121824] transition-all"
              >
                <span className="material-symbols-outlined text-lg">mail</span>
                <span className="text-xs">Gmail Sync Gateway</span>
              </button>
            )}

            {(userPosition === 'Admin' || userPosition === 'Team Lead' || userPosition === 'Lead') && (
              <button
                onClick={() => onNavigate('ANALYST_QUALITY_DASHBOARD')}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left text-slate-400 hover:bg-[#121824] transition-all"
              >
                <span className="material-symbols-outlined text-lg">reward</span>
                <span className="text-xs">Scoring Analytics</span>
              </button>
            )}

            <button
              onClick={() => onNavigate('GOOGLE_CHAT_DASHBOARD')}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left text-slate-400 hover:bg-[#121824] transition-all"
            >
              <span className="material-symbols-outlined text-lg">forum</span>
              <span className="text-xs">Google Chat Team</span>
            </button>

            <button
              onClick={() => onNavigate('EXCEL_PARSER_UTILITY')}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left text-slate-400 hover:bg-[#121824] transition-all"
            >
              <span className="material-symbols-outlined text-lg">upload_file</span>
              <span className="text-xs">Excel to JSON Tool</span>
            </button>
          </div>
        </nav>

        <div className="p-4 border-t border-slate-800">
          <div className="flex items-center gap-3 bg-[#111625] p-3 rounded-xl border border-slate-800">
            <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs font-bold text-white uppercase">
              {userName ? userName[0] : 'U'}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold text-white truncate">{userName || 'User'}</p>
              <p className="text-[10px] text-slate-400 truncate">{userPosition || 'Ops Member'}</p>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="w-full mt-3 flex items-center justify-center gap-2 px-3 py-2 text-xs font-bold text-red-400 hover:bg-red-500/10 rounded-lg transition-all"
          >
            <span className="material-symbols-outlined text-sm">logout</span>
            Sign Out
          </button>
        </div>
      </aside>

      {/* MAIN PRESENTATION PLAY AREA */}
      <main className="flex-1 flex flex-col overflow-hidden bg-[#07090e]">
        {/* TOP STATUS BAR */}
        <header className="h-16 border-b border-slate-800 px-8 flex items-center justify-between shrink-0 bg-[#0d111d]/50 backdrop-blur-sm">
          <div className="flex items-center gap-3">
            <span className="text-lg font-bold text-white tracking-tight">
              {activeTab === 'slides' && '🎭 Platform Interactive Presentation Slides'}
              {activeTab === 'video' && '🎥 Animated Interactive Video Tour Simulator'}
              {activeTab === 'roadmap' && '🚀 Innovation Roadmap & Active Voting Hub'}
              {activeTab === 'charts' && '📊 Dynamic Operations & Performance Analytics'}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-[11px] text-slate-400 font-mono">Operations: Chandigarh Hub</span>
            <div className="px-2.5 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-[10px] text-blue-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse"></span>
              Live Presentation Mode
            </div>
          </div>
        </header>

        {/* CONTAINER WORKSPACE FOR TABS */}
        <div className="flex-1 overflow-y-auto p-8 flex flex-col justify-center max-w-6xl mx-auto w-full">
          
          {/* TAB 1: PRESENTATION SLIDES */}
          {activeTab === 'slides' && (
            <div className="space-y-6 w-full">
              {/* Slide Screen Frame */}
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentSlideIndex}
                  initial={{ opacity: 0, scale: 0.98, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.98, y: -10 }}
                  transition={{ duration: 0.35, ease: 'easeOut' }}
                  className={`w-full min-h-[460px] rounded-3xl bg-gradient-to-br ${slides[currentSlideIndex].gradient} border border-slate-700/40 p-8 md:p-12 relative flex flex-col justify-between shadow-2xl overflow-hidden`}
                >
                  {/* Decorative glowing background mesh elements */}
                  <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-[#a855f7]/10 rounded-full filter blur-[100px] pointer-events-none"></div>
                  <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-blue-500/10 rounded-full filter blur-[100px] pointer-events-none"></div>

                  {/* Header info */}
                  <div className="flex justify-between items-center z-10">
                    <div className="space-y-1">
                      <span className="px-3 py-1 rounded-full bg-white/10 text-white border border-white/10 text-[10px] font-bold uppercase tracking-widest">
                        {slides[currentSlideIndex].badge}
                      </span>
                      <p className="text-xs text-blue-300 font-semibold mt-1">
                        {slides[currentSlideIndex].subtitle}
                      </p>
                    </div>
                    <span className="text-2xl font-black text-white/20 select-none">
                      0{slides[currentSlideIndex].id} / 0{slides.length}
                    </span>
                  </div>

                  {/* Content space */}
                  <div className="my-8 z-10">
                    <h2 className="text-3xl font-black text-white tracking-tight mb-6">
                      {slides[currentSlideIndex].title}
                    </h2>
                    {slides[currentSlideIndex].content}
                  </div>

                  {/* Bottom details / timeline indicators */}
                  <div className="flex justify-between items-center pt-6 border-t border-white/10 z-10">
                    <p className="text-[10px] text-slate-400">
                      🎯 Use Slide controls or activate Autoplay to run the deck automatically.
                    </p>
                    <div className="flex gap-1.5">
                      {slides.map((_, i) => (
                        <div
                          key={i}
                          onClick={() => setCurrentSlideIndex(i)}
                          className={`h-2.5 rounded-full transition-all duration-300 cursor-pointer ${
                            i === currentSlideIndex ? 'w-8 bg-blue-400' : 'w-2.5 bg-white/20 hover:bg-white/40'
                          }`}
                        ></div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>

              {/* SLIDE CONTROL ACTIONS BAR */}
              <div className="bg-[#0f1322] border border-slate-800 p-4 rounded-2xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setIsPlayingSlides(!isPlayingSlides)}
                    className={`px-5 py-2.5 rounded-xl font-bold text-xs cursor-pointer transition-all flex items-center gap-2 ${
                      isPlayingSlides
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        : 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-600/20'
                    }`}
                  >
                    <span className="material-symbols-outlined text-sm">
                      {isPlayingSlides ? 'pause_circle' : 'play_circle'}
                    </span>
                    {isPlayingSlides ? 'Pause Autoplay' : 'Activate Autoplay (5s)'}
                  </button>
                  {isPlayingSlides && (
                    <span className="text-xs text-amber-400/80 animate-pulse font-medium">
                      Running presentation auto playback...
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() =>
                      setCurrentSlideIndex((prev) => (prev - 1 + slides.length) % slides.length)
                    }
                    className="p-3 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-white cursor-pointer transition-all flex items-center justify-center border border-slate-700/40"
                    title="Previous Slide"
                  >
                    <span className="material-symbols-outlined text-sm">arrow_back</span>
                  </button>
                  <button
                    onClick={() => setCurrentSlideIndex((prev) => (prev + 1) % slides.length)}
                    className="p-3 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-white cursor-pointer transition-all flex items-center justify-center border border-slate-700/40"
                    title="Next Slide"
                  >
                    <span className="material-symbols-outlined text-sm">arrow_forward</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: ANIMATED SIMULATED VIDEO PLAYER */}
          {activeTab === 'video' && (
            <div className="space-y-6 w-full">
              <div className="bg-[#0f1322] border border-slate-800 p-6 rounded-3xl space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-lg font-bold text-white">ME Ops Walkthrough - Voice & Video Simulator</h3>
                    <p className="text-xs text-slate-400">An interactive guided animation simulating a real system overview video.</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono text-slate-500">Playback Speed:</span>
                    <select
                      value={videoPlaybackSpeed}
                      onChange={(e) => setVideoPlaybackSpeed(parseFloat(e.target.value))}
                      className="bg-slate-800 border border-slate-700 rounded px-2 py-1 text-xs text-white"
                    >
                      <option value={1}>1.0x (Normal)</option>
                      <option value={1.5}>1.5x (Fast)</option>
                      <option value={2}>2.0x (Double Speed)</option>
                    </select>
                  </div>
                </div>

                {/* THE SIMULATED VIDEO screen frame */}
                <div className="w-full min-h-[380px] bg-[#05070c] rounded-2xl border border-slate-800 relative flex flex-col overflow-hidden">
                  
                  {videoPlayState === 'idle' ? (
                    /* IDLE STATE / LAUNCHER SCREEN */
                    <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center bg-gradient-to-br from-[#0b0e17] via-[#05070c] to-[#010204]">
                      <div className="w-16 h-16 rounded-full bg-blue-600/10 border border-blue-500/20 text-blue-500 flex items-center justify-center shadow-lg shadow-blue-500/5 mb-4 animate-bounce">
                        <span className="material-symbols-outlined text-4xl">video_camera_back</span>
                      </div>
                      <h4 className="text-base font-bold text-white mb-2">Ready to Start Animated Overview Tour</h4>
                      <p className="text-xs text-slate-400 max-w-md leading-relaxed mb-6">
                        Humne is dynamic player ko build kiya hai jo Chandigarh Ops performance benchmarks ko animate karke walk-through provide karta hai. Start button click kijiye visual walkthrough explore karne ke liye.
                      </p>
                      <button
                        onClick={startVideoTour}
                        className="px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-xl shadow-blue-600/20 flex items-center gap-2 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-sm">play_arrow</span>
                        Start Walkthrough Video Simulation
                      </button>
                    </div>
                  ) : (
                    /* PLAYING / ACTION STATE SCREEN */
                    <div className="absolute inset-0 p-6 flex flex-col justify-between">
                      {/* Top bar of video */}
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse"></span>
                          <span className="text-[10px] font-mono font-bold tracking-wider text-red-500">PLAYING SIMULATOR</span>
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono">
                          Step: {videoStepIndex + 1} of {videoSteps.length} | {videoSteps[videoStepIndex].badge}
                        </span>
                      </div>

                      {/* Video Body Content (Mockup representation of application) */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center my-4">
                        {/* Left Side: Mock Screens with animations */}
                        <div className="bg-[#101422] border border-slate-800 p-5 rounded-xl space-y-3 relative shadow-inner">
                          <div className="flex justify-between items-center">
                            <span className="text-[10px] font-bold text-blue-400 font-mono">
                              [ME System UI: {videoSteps[videoStepIndex].screenName}]
                            </span>
                            <span className="w-2 h-2 rounded-full bg-green-500"></span>
                          </div>
                          
                          {/* Animated progress blocks */}
                          <div className="space-y-2">
                            {videoSteps[videoStepIndex].actions.map((action, i) => (
                              <div key={i} className="flex items-center gap-2 text-[10px] font-mono text-slate-300">
                                <span className="text-green-400">&gt;</span>
                                <span>{action}</span>
                              </div>
                            ))}
                          </div>

                          <div className="pt-3 border-t border-slate-800/80 flex justify-between items-center text-[9px] text-slate-500 font-mono">
                            <span>Ingestion State: MATCHED</span>
                            <span>SLA Status: OK</span>
                          </div>
                        </div>

                        {/* Right Side: Narrative Cue Box */}
                        <div className="space-y-3">
                          <h4 className="text-sm font-bold text-white">
                            {videoSteps[videoStepIndex].title}
                          </h4>
                          <div className="p-4 bg-blue-500/5 rounded-xl border border-blue-500/10">
                            <p className="text-xs text-blue-300 italic leading-relaxed">
                              "{videoSteps[videoStepIndex].narration}"
                            </p>
                          </div>
                          <p className="text-[10px] text-slate-400">
                            🔊 **Hindi Guide Notes:** Yeh animation automatic operational capabilities ko showcase karti hai jo live system modules trigger karte hain.
                          </p>
                        </div>
                      </div>

                      {/* Bottom control row */}
                      <div className="space-y-3">
                        {/* Audio Wave / Visual Equalizer effect when playing */}
                        {videoPlayState === 'playing' && (
                          <div className="flex gap-1 h-3 items-end justify-center">
                            {[...Array(20)].map((_, i) => (
                              <motion.div
                                key={i}
                                animate={{ height: [4, Math.random() * 12 + 4, 4] }}
                                transition={{ repeat: Infinity, duration: 0.6 + i * 0.05, ease: 'easeInOut' }}
                                className="w-1 bg-blue-400 rounded-full"
                              ></motion.div>
                            ))}
                          </div>
                        )}

                        {/* Seek and controls */}
                        <div className="flex items-center gap-4">
                          <span className="text-[10px] font-mono text-slate-500">
                            {Math.floor((videoProgress / 100) * 45)}s / 45s
                          </span>
                          <div className="flex-1 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                            <div className="bg-blue-500 h-full transition-all duration-150" style={{ width: `${videoProgress}%` }}></div>
                          </div>
                          <span className="text-[10px] font-mono text-slate-500">
                            {Math.round(videoProgress)}% Complete
                          </span>
                        </div>
                      </div>
                    </div>
                  )}

                </div>

                {/* VIDEO SIMULATOR CONTROLS BAR */}
                <div className="flex items-center justify-between border-t border-slate-800/80 pt-4">
                  <div className="flex gap-2 flex-wrap">
                    {videoPlayState === 'playing' ? (
                      <button
                        onClick={pauseVideoTour}
                        className="px-4 py-2 bg-amber-600/10 hover:bg-amber-600/20 text-amber-400 rounded-xl text-xs font-bold transition-all border border-amber-600/20 cursor-pointer flex items-center gap-1.5"
                      >
                        <span className="material-symbols-outlined text-sm">pause</span>
                        Pause Video
                      </button>
                    ) : videoPlayState === 'paused' ? (
                      <button
                        onClick={resumeVideoTour}
                        className="px-4 py-2 bg-green-600 hover:bg-green-500 text-white rounded-xl text-xs font-bold transition-all shadow-lg cursor-pointer flex items-center gap-1.5"
                      >
                        <span className="material-symbols-outlined text-sm">play_arrow</span>
                        Resume Video
                      </button>
                    ) : null}

                    {videoPlayState !== 'idle' && (
                      <button
                        onClick={resetVideoTour}
                        className="px-4 py-2 bg-slate-800/80 hover:bg-slate-700/80 text-white rounded-xl text-xs font-bold transition-all border border-slate-700/30 cursor-pointer flex items-center gap-1.5"
                      >
                        <span className="material-symbols-outlined text-sm">replay</span>
                        Restart Walkthrough
                      </button>
                    )}

                    <button
                      onClick={downloadTrainingMaterials}
                      className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-blue-500/10 flex items-center gap-1.5 cursor-pointer"
                      title="Download presentation slides, scripts, storyboards and trainer guides"
                    >
                      <span className="material-symbols-outlined text-sm">download</span>
                      Download Presentation Guide & Video Storyboard
                    </button>
                  </div>

                  <p className="text-[10px] text-slate-500 italic max-w-sm text-right leading-relaxed">
                    💡 **Did you know?** Is interactive video simulator se bina physical recording generate kare aap live workflow states aur integrations parameters visually demonstrate kar sakte hain!
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: FUTURE ROADMAP & VOTING HUB */}
          {activeTab === 'roadmap' && (
            <div className="space-y-6 w-full">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
                
                {/* RoadMap Items Column (Left/Center) */}
                <div className="lg:col-span-2 space-y-4">
                  <div className="bg-[#0f1322] border border-slate-800 p-6 rounded-3xl space-y-2">
                    <h3 className="text-lg font-bold text-white">Proposed Future Upgrades & Solutions</h3>
                    <p className="text-xs text-slate-400">
                      MarginEdge operations ko highly advanced banane ke liye upcoming features cast check and choose kijiye.
                    </p>
                  </div>

                  <div className="space-y-3">
                    {roadmapItems.map((item) => (
                      <div
                        key={item.id}
                        className={`p-5 rounded-2xl border transition-all ${
                          item.voted
                            ? 'bg-[#14233c] border-blue-500/40 shadow-lg'
                            : 'bg-[#0f1322] border-slate-800/80 hover:border-slate-700/50'
                        } flex justify-between items-start gap-4`}
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="px-2 py-0.5 rounded bg-slate-800 text-[9px] text-slate-400 font-bold uppercase tracking-wider">
                              {item.category}
                            </span>
                            <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                              item.impact === 'Critical (High)' || item.impact === 'Transformative'
                                ? 'bg-red-500/10 text-red-400'
                                : 'bg-yellow-500/10 text-yellow-400'
                            }`}>
                              Impact: {item.impact}
                            </span>
                          </div>
                          <h4 className="text-sm font-bold text-white mt-1.5">{item.title}</h4>
                          <p className="text-xs text-slate-300 leading-relaxed mt-1">{item.description}</p>
                        </div>

                        {/* Upvote Button with pulse */}
                        <button
                          onClick={() => handleVote(item.id)}
                          className={`shrink-0 flex flex-col items-center justify-center w-14 py-2 rounded-xl transition-all border cursor-pointer ${
                            item.voted
                              ? 'bg-blue-500 text-white border-blue-400 shadow-md shadow-blue-500/10'
                              : 'bg-slate-800/50 text-slate-400 border-slate-700/50 hover:bg-slate-800'
                          }`}
                        >
                          <span className="material-symbols-outlined text-lg leading-none">thumb_up</span>
                          <span className="text-[10px] font-bold font-mono mt-1">{item.votes}</span>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Submitting Custom Request Form (Right Sidebar) */}
                <div className="space-y-4">
                  <div className="bg-[#0f1322] border border-slate-800 p-6 rounded-3xl space-y-4">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <span className="material-symbols-outlined text-blue-400 text-lg">lightbulb</span>
                      Submit Custom Idea
                    </h3>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Agar aap ke pass koi specific update idea hai jo Chandigarh office automation pipeline me valuable ho, to use yahan submit kijiye.
                    </p>

                    <form onSubmit={handleAddFeature} className="space-y-3">
                      {validationError && (
                        <div className="p-3 bg-red-950/40 border border-red-900/50 rounded-xl text-[11px] text-red-400 font-medium">
                          ⚠️ {validationError}
                        </div>
                      )}
                      <div>
                        <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                          Idea Title (Hinglish/English)
                        </label>
                        <input
                          type="text"
                          required
                          value={newFeatureTitle}
                          onChange={(e) => setNewFeatureTitle(e.target.value)}
                          placeholder="E.g., Automated invoice category labeling"
                          className="w-full bg-[#161b2d] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                          Description & Business Impact
                        </label>
                        <textarea
                          rows={3}
                          value={newFeatureDesc}
                          onChange={(e) => setNewFeatureDesc(e.target.value)}
                          placeholder="How will this help Chandigarh teams save time?"
                          className="w-full bg-[#161b2d] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                        />
                      </div>
                      <button
                        type="submit"
                        className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-blue-500/10"
                      >
                        <span className="material-symbols-outlined text-sm">add_circle</span>
                        Submit Proposal Idea
                      </button>
                    </form>
                  </div>

                  <div className="bg-[#0f1322] border border-slate-800 p-5 rounded-3xl space-y-3">
                    <h4 className="text-xs font-bold text-white">How This Helps Chandigarh Teams</h4>
                    <ul className="space-y-2 text-[11px] text-slate-400 leading-normal">
                      <li className="flex items-start gap-2">
                        <span className="text-blue-400">•</span>
                        <span>**Error Protection:** Continuous quality scoring highlights active analyst risks.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-400">•</span>
                        <span>**Zero Gap Coordination:** Live Workspace syncing keeps other offices up-to-date instantly.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-400">•</span>
                        <span>**Saves Daily Effort:** Less manual copy-pasting of spreadsheet figures.</span>
                      </li>
                    </ul>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* TAB 4: INTERACTIVE CHARTS SANDBOX */}
          {activeTab === 'charts' && (
            <div className="space-y-6 w-full text-left">
              <div className="bg-[#0f1322] border border-slate-800 p-6 rounded-3xl">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      <span className="material-symbols-outlined text-blue-400">trending_up</span>
                      Dynamic Chandigarh Operations & Performance Analytics
                    </h3>
                    <p className="text-xs text-slate-400">
                      View real-time or simulated statistics. Use the interactive sandbox multipliers below to test and preview operational scales.
                    </p>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="px-2.5 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-[10px] text-blue-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse"></span>
                      Active Ingestion Stream
                    </span>
                    <span className="px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-[10px] text-emerald-400 font-bold uppercase tracking-wider">
                      Secured SSL v2
                    </span>
                  </div>
                </div>
              </div>

              {/* Dynamic Sandbox Multiplier Panel */}
              <div className="bg-[#0f1322]/80 border border-slate-800/80 p-6 rounded-3xl grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    ⚡ Sandbox Simulation Multiplier
                  </span>
                  <p className="text-xs text-slate-300">
                    SLA aur production scale variables ko simulate karne ke liye values multiply kijiye.
                  </p>
                </div>

                <div>
                  <div className="flex items-center gap-3">
                    <input
                      type="range"
                      min="0.5"
                      max="5.0"
                      step="0.1"
                      value={chartMultiplier}
                      onChange={(e) => {
                        const valNum = parseFloat(e.target.value);
                        setChartMultiplier(valNum);
                        setMultiplierInput(e.target.value);
                        setMultiplierError(null);
                      }}
                      className="flex-1 accent-blue-500 h-1.5 bg-slate-800 rounded-full cursor-pointer"
                    />
                    <span className="text-xs font-mono font-bold text-blue-400 shrink-0 w-12 text-right">
                      {chartMultiplier.toFixed(1)}x
                    </span>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                    Custom Multiplier (0.1 - 10.0)
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={multiplierInput}
                      onChange={(e) => handleMultiplierChange(e.target.value)}
                      placeholder="Enter e.g. 1.5"
                      className={`w-full bg-[#161b2d] border ${
                        multiplierError ? 'border-red-500' : 'border-slate-800'
                      } rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 font-mono`}
                    />
                    {multiplierError && (
                      <span className="text-[10px] text-red-400 font-medium block mt-1">
                        {multiplierError}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Bento Grid layout for charts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* Chart 1: Team Ingestion Capacity */}
                <div className="bg-[#0f1322] border border-slate-800 p-6 rounded-3xl space-y-4">
                  <div className="flex justify-between items-center flex-wrap gap-2">
                    <div>
                      <h4 className="text-sm font-bold text-white">Ingestion Capacity vs Errors by Team</h4>
                      <p className="text-[11px] text-slate-400">Points & mistakes tracking derived from live database records.</p>
                    </div>

                    <div className="flex gap-2">
                      <select
                        value={chartMetricFilter}
                        onChange={(e) => setChartMetricFilter(e.target.value as any)}
                        className="bg-[#161b2d] border border-slate-800 rounded px-2.5 py-1 text-[11px] text-white focus:outline-none"
                      >
                        <option value="all">All Statuses</option>
                        <option value="matched">Matched Only</option>
                        <option value="high priority">High Priority Only</option>
                        <option value="pending">Pending Only</option>
                      </select>

                      <select
                        value={selectedOffice}
                        onChange={(e) => setSelectedOffice(e.target.value)}
                        className="bg-[#161b2d] border border-slate-800 rounded px-2.5 py-1 text-[11px] text-white focus:outline-none"
                      >
                        <option value="Office (All)">All Offices</option>
                        <option value="Chandigarh">Chandigarh</option>
                        <option value="Dhaka">Dhaka</option>
                      </select>
                    </div>
                  </div>

                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={getReconciliationChartData()}>
                        <defs>
                          <linearGradient id="colorPoints" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.4}/>
                            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                        <XAxis dataKey="name" stroke="#64748b" fontSize={11} />
                        <YAxis stroke="#64748b" fontSize={11} />
                        <Tooltip
                          contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                          labelClassName="text-white font-bold"
                        />
                        <Legend wrapperStyle={{ fontSize: '11px' }} />
                        <Area type="monotone" dataKey="points" name="Ingestion Points" fill="url(#colorPoints)" stroke="#3b82f6" strokeWidth={2} />
                        <Line type="monotone" dataKey="errors" name="Errors Captured" stroke="#ef4444" strokeWidth={2} activeDot={{ r: 6 }} />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Chart 2: Analyst Task Distribution */}
                <div className="bg-[#0f1322] border border-slate-800 p-6 rounded-3xl space-y-4">
                  <div>
                    <h4 className="text-sm font-bold text-white">Analyst Daily Tasks Solved Profile</h4>
                    <p className="text-[11px] text-slate-400">Top performers output scaled by sandbox simulation multiplier.</p>
                  </div>

                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={getAnalystChartData()}>
                        <defs>
                          <linearGradient id="barGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#a855f7" />
                            <stop offset="100%" stopColor="#6366f1" />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                        <XAxis dataKey="name" stroke="#64748b" fontSize={11} />
                        <YAxis stroke="#64748b" fontSize={11} />
                        <Tooltip
                          contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                          labelClassName="text-white font-bold"
                        />
                        <Legend wrapperStyle={{ fontSize: '11px' }} />
                        <Bar dataKey="tasks" name="Completed Tasks" fill="url(#barGrad)" radius={[6, 6, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Chart 3: Team Core Efficiency */}
                <div className="bg-[#0f1322] border border-slate-800 p-6 rounded-3xl space-y-4 lg:col-span-2">
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="text-sm font-bold text-white">Central Operations Unit Efficiency Breakdown</h4>
                      <p className="text-[11px] text-slate-400">Calculated percentage and error threshold benchmarks.</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    {getTeamPerformanceData().map((perf, idx) => (
                      <div key={idx} className="bg-slate-900/40 p-4 rounded-2xl border border-slate-800/80 flex flex-col justify-between">
                        <div>
                          <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider block">
                            {perf.name}
                          </span>
                          <span className="text-2xl font-black text-white mt-1.5 block">
                            {perf.efficiency}%
                          </span>
                        </div>
                        <div className="mt-3">
                          <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                            <span>SLA Target Limit</span>
                            <span>{perf.errorRate}% Errors</span>
                          </div>
                          <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden">
                            <div
                              className="bg-[#10b981] h-full"
                              style={{ width: `${perf.efficiency}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            </div>
          )}

        </div>
      </main>
    </div>
  );
}
