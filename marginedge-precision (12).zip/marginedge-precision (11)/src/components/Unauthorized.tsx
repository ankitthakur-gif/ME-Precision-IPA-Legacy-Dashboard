import React, { useState, useMemo } from 'react';
import { ActiveView } from '../types';

interface UnauthorizedProps {
  userPosition: string;
  attemptedView: string;
  allowedViews: ActiveView[];
  onNavigate: (view: ActiveView) => void;
  onLogout: () => void;
}

export default function Unauthorized({
  userPosition,
  attemptedView,
  allowedViews,
  onNavigate,
  onLogout
}: UnauthorizedProps) {
  const [showCodeOnly, setShowCodeOnly] = useState(false);
  const [returnCodeType, setReturnCodeType] = useState<'json' | 'sql' | 'typescript' | 'express_middleware'>('json');
  const [hasCopied, setHasCopied] = useState(false);

  // Format view name for presentation
  const formatViewName = (view: string) => {
    return view
      .replace(/_/g, ' ')
      .toLowerCase()
      .replace(/\b\w/g, (char) => char.toUpperCase());
  };

  // Roles description mapping
  const roleDescriptions: Record<string, { desc: string; target: string; color: string }> = {
    'Admin': {
      desc: 'Master operator with full system-wide configuration, audit database access, quality scoring overview, integrations control, and analytical dashboards.',
      target: 'Full Platform Access',
      color: 'from-purple-500 to-indigo-600'
    },
    'AM': {
      desc: 'Account & Portfolio Manager overseeing invoice pipelines, vendor reconciliations, gmail communications, and area operations. Restricted from analyst scorecard dashboard.',
      target: 'Operations & Comms Access',
      color: 'from-blue-500 to-cyan-600'
    },
    'Team Lead': {
      desc: 'Supervisor managing Chandigarh / Dhaka / Havanna hub analyst operations, scorecards, SLA targets, error monitoring, and training metrics. Restricted from direct client Gmail integrations and financial portfolios.',
      target: 'SLA & Team Performance Access',
      color: 'from-teal-500 to-emerald-600'
    },
    'Analyst': {
      desc: 'Task specialist focused on processing line-item matching, food supply invoice verification, error correction, and manual sheet logging.',
      target: 'Execution level Access',
      color: 'from-slate-500 to-slate-700'
    }
  };

  const activeRoleInfo = roleDescriptions[userPosition] || roleDescriptions['Analyst'];

  // All role permission config for code compilation
  const rbacPermissions = {
    Admin: [
      'LIVE_SYNC_DASHBOARD',
      'PRECISION_OPS_DASHBOARD',
      'DETAILED_PORTFOLIO_LOGS',
      'GMAIL_DASHBOARD',
      'ANALYST_QUALITY_DASHBOARD',
      'EXCEL_PARSER_UTILITY',
      'GOOGLE_CHAT_DASHBOARD',
      'PRESENTATION_DECK'
    ],
    AM: [
      'LIVE_SYNC_DASHBOARD',
      'PRECISION_OPS_DASHBOARD',
      'DETAILED_PORTFOLIO_LOGS',
      'GMAIL_DASHBOARD',
      'EXCEL_PARSER_UTILITY',
      'GOOGLE_CHAT_DASHBOARD',
      'PRESENTATION_DECK'
    ],
    'Team Lead': [
      'LIVE_SYNC_DASHBOARD',
      'DETAILED_PORTFOLIO_LOGS',
      'ANALYST_QUALITY_DASHBOARD',
      'EXCEL_PARSER_UTILITY',
      'GOOGLE_CHAT_DASHBOARD',
      'PRESENTATION_DECK'
    ],
    Analyst: [
      'LIVE_SYNC_DASHBOARD',
      'DETAILED_PORTFOLIO_LOGS',
      'EXCEL_PARSER_UTILITY',
      'GOOGLE_CHAT_DASHBOARD'
    ]
  };

  // Compile Return Code based on tabs
  const generatedCode = useMemo(() => {
    if (returnCodeType === 'json') {
      return JSON.stringify({
        system: "MarginEdge Precision Ops",
        authModel: "Role Based Access Control (RBAC)",
        roles: ["Admin", "AM", "Team Lead", "Analyst"],
        restrictions: {
          PRECISION_OPS_DASHBOARD: ["Admin", "AM"],
          GMAIL_DASHBOARD: ["Admin", "AM"],
          ANALYST_QUALITY_DASHBOARD: ["Admin", "Team Lead"],
          PRESENTATION_DECK: ["Admin", "AM", "Team Lead"],
          EXCEL_PARSER_UTILITY: ["Admin", "AM", "Team Lead", "Analyst"],
          GOOGLE_CHAT_DASHBOARD: ["Admin", "AM", "Team Lead", "Analyst"],
          LIVE_SYNC_DASHBOARD: ["Admin", "AM", "Team Lead", "Analyst"],
          DETAILED_PORTFOLIO_LOGS: ["Admin", "AM", "Team Lead", "Analyst"]
        },
        permissionsSchema: rbacPermissions
      }, null, 2);
    }

    if (returnCodeType === 'sql') {
      return `-- PostgreSQL Schema for MarginEdge Role Based Access Control (RBAC)
-- Generated: ${new Date().toLocaleString()}

-- Create roles enum
CREATE TYPE user_role AS ENUM ('Admin', 'AM', 'Team Lead', 'Analyst');

-- Create system modules table
CREATE TABLE IF NOT EXISTS platform_modules (
  module_id VARCHAR(100) PRIMARY KEY,
  module_name VARCHAR(150) NOT NULL,
  description TEXT
);

-- Create module permissions table
CREATE TABLE IF NOT EXISTS module_access_control (
  module_id VARCHAR(100) REFERENCES platform_modules(module_id) ON DELETE CASCADE,
  role_name user_role NOT NULL,
  is_permitted BOOLEAN DEFAULT TRUE,
  PRIMARY KEY (module_id, role_name)
);

-- Seed platform modules
INSERT INTO platform_modules (module_id, module_name, description) VALUES
('LIVE_SYNC_DASHBOARD', 'Real-Time Operational Log Sync', 'Live streaming of task updates'),
('PRECISION_OPS_DASHBOARD', 'Invoice Manager Operations', 'AM client portfolios and verification'),
('DETAILED_PORTFOLIO_LOGS', 'Detailed Auditor Ledger', 'Comprehensive operations audit ledger'),
('GMAIL_DASHBOARD', 'Client Gmail Automation Pipeline', 'Access to email synchronization'),
('ANALYST_QUALITY_DASHBOARD', 'Analyst Performance Scorecard', 'Quality ranking, points, and scorecards'),
('EXCEL_PARSER_UTILITY', 'Dynamic Excel Parser & Sync', 'Spreadsheet importing and sync'),
('GOOGLE_CHAT_DASHBOARD', 'Operational GChat Client', 'Real-time alert coordination'),
('PRESENTATION_DECK', 'Operational Overview Briefing', 'Briefing decks and slides')
ON CONFLICT (module_id) DO NOTHING;

-- Seed Access Control Rules
-- ADMIN FULL ACCESS
INSERT INTO module_access_control (module_id, role_name) VALUES
('LIVE_SYNC_DASHBOARD', 'Admin'), ('PRECISION_OPS_DASHBOARD', 'Admin'),
('DETAILED_PORTFOLIO_LOGS', 'Admin'), ('GMAIL_DASHBOARD', 'Admin'),
('ANALYST_QUALITY_DASHBOARD', 'Admin'), ('EXCEL_PARSER_UTILITY', 'Admin'),
('GOOGLE_CHAT_DASHBOARD', 'Admin'), ('PRESENTATION_DECK', 'Admin')
ON CONFLICT DO NOTHING;

-- AM ACCESS RULES
INSERT INTO module_access_control (module_id, role_name) VALUES
('LIVE_SYNC_DASHBOARD', 'AM'), ('PRECISION_OPS_DASHBOARD', 'AM'),
('DETAILED_PORTFOLIO_LOGS', 'AM'), ('GMAIL_DASHBOARD', 'AM'),
('EXCEL_PARSER_UTILITY', 'AM'), ('GOOGLE_CHAT_DASHBOARD', 'AM'),
('PRESENTATION_DECK', 'AM')
ON CONFLICT DO NOTHING;

-- TEAM LEAD ACCESS RULES
INSERT INTO module_access_control (module_id, role_name) VALUES
('LIVE_SYNC_DASHBOARD', 'Team Lead'), ('DETAILED_PORTFOLIO_LOGS', 'Team Lead'),
('ANALYST_QUALITY_DASHBOARD', 'Team Lead'), ('EXCEL_PARSER_UTILITY', 'Team Lead'),
('GOOGLE_CHAT_DASHBOARD', 'Team Lead'), ('PRESENTATION_DECK', 'Team Lead')
ON CONFLICT DO NOTHING;

-- ANALYST ACCESS RULES
INSERT INTO module_access_control (module_id, role_name) VALUES
('LIVE_SYNC_DASHBOARD', 'Analyst'), ('DETAILED_PORTFOLIO_LOGS', 'Analyst'),
('EXCEL_PARSER_UTILITY', 'Analyst'), ('GOOGLE_CHAT_DASHBOARD', 'Analyst')
ON CONFLICT DO NOTHING;`;
    }

    if (returnCodeType === 'typescript') {
      return `/**
 * TypeScript Typings and Static Configuration for RBAC
 * System: MarginEdge Precision Ops
 */

export type PlatformRole = 'Admin' | 'AM' | 'Team Lead' | 'Analyst';

export type PlatformModule =
  | 'LIVE_SYNC_DASHBOARD'
  | 'PRECISION_OPS_DASHBOARD'
  | 'DETAILED_PORTFOLIO_LOGS'
  | 'GMAIL_DASHBOARD'
  | 'ANALYST_QUALITY_DASHBOARD'
  | 'EXCEL_PARSER_UTILITY'
  | 'GOOGLE_CHAT_DASHBOARD'
  | 'PRESENTATION_DECK';

export interface RBACRuleset {
  roles: PlatformRole[];
  modulePermissions: Record<PlatformRole, PlatformModule[]>;
}

export const MARGINEDGE_RBAC_RULES: RBACRuleset = {
  roles: ['Admin', 'AM', 'Team Lead', 'Analyst'],
  modulePermissions: ${JSON.stringify(rbacPermissions, null, 2)}
};

export function hasPermission(role: PlatformRole, module: PlatformModule): boolean {
  const allowed = MARGINEDGE_RBAC_RULES.modulePermissions[role];
  return allowed ? allowed.includes(module) : false;
}`;
    }

    if (returnCodeType === 'express_middleware') {
      return `/**
 * Express.js Authorization Middleware for MarginEdge RBAC
 */
import { Request, Response, NextFunction } from 'express';

export type PlatformRole = 'Admin' | 'AM' | 'Team Lead' | 'Analyst';

export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    role: PlatformRole;
    name: string;
  };
}

// Map of module permissions
const MODULE_PERMISSIONS: Record<string, PlatformRole[]> = {
  'LIVE_SYNC_DASHBOARD': ['Admin', 'AM', 'Team Lead', 'Analyst'],
  'DETAILED_PORTFOLIO_LOGS': ['Admin', 'AM', 'Team Lead', 'Analyst'],
  'EXCEL_PARSER_UTILITY': ['Admin', 'AM', 'Team Lead', 'Analyst'],
  'GOOGLE_CHAT_DASHBOARD': ['Admin', 'AM', 'Team Lead', 'Analyst'],
  'PRECISION_OPS_DASHBOARD': ['Admin', 'AM'],
  'GMAIL_DASHBOARD': ['Admin', 'AM'],
  'ANALYST_QUALITY_DASHBOARD': ['Admin', 'Team Lead'],
  'PRESENTATION_DECK': ['Admin', 'AM', 'Team Lead']
};

/**
 * Express middleware to restrict route access based on role permissions
 */
export function requireModuleAccess(moduleKey: string) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const user = req.user;
      
      if (!user || !user.role) {
        return res.status(401).json({
          success: false,
          error: 'Unauthorized: No active credentials found'
        });
      }

      const allowedRoles = MODULE_PERMISSIONS[moduleKey];
      if (!allowedRoles) {
        return res.status(500).json({
          success: false,
          error: 'Configuration Error: Invalid system module requested'
        });
      }

      if (!allowedRoles.includes(user.role)) {
        return res.status(403).json({
          success: false,
          error: 'Access Restricted',
          details: \`Your active role '\${user.role}' lacks clearance for '\${moduleKey}'\`
        });
      }

      // User has required permission, proceed
      next();
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  };
}`;
    }

    return '';
  }, [returnCodeType]);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(generatedCode);
    setHasCopied(true);
    setTimeout(() => setHasCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#f7f9ff] dark:bg-[#0b0e14] flex items-center justify-center font-sans p-4 md:p-6 transition-colors duration-300">
      <div className="max-w-4xl w-full bg-white dark:bg-[#121620] border border-outline-variant/60 rounded-3xl shadow-2xl overflow-hidden relative">
        {/* Top abstract subtle restriction header bar */}
        <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-red-500 via-amber-500 to-red-600"></div>

        {/* Top bar with Code Toggle */}
        <div className="px-6 py-4 border-b border-outline-variant/50 flex items-center justify-between bg-surface-container-low/50">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse"></span>
            <span className="text-[10px] font-black uppercase text-on-surface-variant tracking-wider">
              Security Boundary Active
            </span>
          </div>

          <button
            onClick={() => setShowCodeOnly(!showCodeOnly)}
            className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer border ${
              showCodeOnly 
                ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm' 
                : 'bg-surface-container text-emerald-600 border-emerald-500/20 hover:bg-emerald-50 dark:hover:bg-emerald-950/20'
            }`}
            title="Toggle code-only authorization details view"
          >
            <span className="material-symbols-outlined text-sm">code</span>
            <span>Return Code Only</span>
          </button>
        </div>

        {showCodeOnly ? (
          /* CODE-ONLY VIEW FOR EXPANDED RBAC INSIGHTS */
          <div className="p-6 md:p-8 bg-slate-950 text-slate-100 flex flex-col min-h-[450px]">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-4 border-b border-slate-800 mb-4 gap-3">
              <div>
                <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                  <span className="material-symbols-outlined text-emerald-400">admin_panel_settings</span>
                  RBAC Config Compiler
                </h3>
                <p className="text-[11px] text-slate-400 mt-1">
                  Export, debug, and implement the platform authorization blueprint directly.
                </p>
              </div>

              {/* Code tabs selector */}
              <div className="flex bg-slate-900 border border-slate-800 rounded-lg p-0.5 self-start sm:self-auto">
                {[
                  { id: 'json', label: 'JSON Model' },
                  { id: 'sql', label: 'SQL Seed' },
                  { id: 'typescript', label: 'TS Types' },
                  { id: 'express_middleware', label: 'Express MW' }
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setReturnCodeType(tab.id as any)}
                    className={`px-2.5 py-1 text-[10px] font-black uppercase rounded transition-all cursor-pointer ${
                      returnCodeType === tab.id 
                        ? 'bg-emerald-600 text-white shadow' 
                        : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Code presentation */}
            <div className="flex-1 bg-slate-900/40 border border-slate-900 rounded-2xl p-5 font-mono text-[11px] overflow-auto select-all relative min-h-[300px]">
              <pre className="whitespace-pre leading-relaxed text-emerald-400">{generatedCode}</pre>
              
              <button
                onClick={handleCopyCode}
                className="absolute top-4 right-4 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white px-3 py-2 rounded-xl border border-slate-700 transition-all flex items-center gap-1.5 cursor-pointer shadow-lg"
                title="Copy Code to Clipboard"
              >
                <span className="material-symbols-outlined text-sm">
                  {hasCopied ? 'check_circle' : 'content_copy'}
                </span>
                <span className="text-[10px] font-bold">{hasCopied ? 'Copied!' : 'Copy Code'}</span>
              </button>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-900 text-[10px] text-slate-500 font-mono flex items-center justify-between">
              <span>Security Access Level: Admin Control Plane</span>
              <button 
                onClick={() => setShowCodeOnly(false)}
                className="text-emerald-400 hover:underline cursor-pointer font-bold"
              >
                Return to standard message
              </button>
            </div>
          </div>
        ) : (
          /* STANDARD BEAUTIFULLY STYLED UNAUTHORIZED USER INTERFACE */
          <div className="p-6 md:p-10 flex flex-col md:flex-row gap-8 items-stretch">
            
            {/* Left Column: Restriction Details */}
            <div className="flex-1 flex flex-col justify-between space-y-6">
              
              <div className="space-y-4">
                {/* Shield Icon Container with dual pulsing rings */}
                <div className="w-16 h-16 bg-red-500/10 dark:bg-red-500/20 rounded-2xl flex items-center justify-center text-red-600 dark:text-red-400 border border-red-200/50 dark:border-red-500/30">
                  <span className="material-symbols-outlined text-[32px] select-none">gpp_maybe</span>
                </div>

                <div className="space-y-2">
                  <h2 className="text-2xl font-black tracking-tight text-slate-900 dark:text-white">
                    Access Restricted
                  </h2>
                  <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed font-medium">
                    Your authenticated role as <span className="font-extrabold text-red-600 dark:text-red-400 px-1.5 py-0.5 bg-red-50 dark:bg-red-950/30 rounded border border-red-100 dark:border-red-950/50">{userPosition}</span> lacks clearance to enter the <span className="font-bold text-slate-800 dark:text-slate-200">{formatViewName(attemptedView)}</span> module.
                  </p>
                </div>
              </div>

              {/* Active Role Card Overview */}
              <div className="bg-slate-50 dark:bg-[#161b29] border border-outline-variant/40 rounded-2xl p-4 space-y-2.5">
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${activeRoleInfo.color}`}></div>
                  <h4 className="text-[11px] font-black uppercase text-on-surface-variant tracking-wider">
                    Role Profile: {userPosition}
                  </h4>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed font-medium">
                  {activeRoleInfo.desc}
                </p>
                <div className="text-[10px] text-primary font-bold bg-[#eff4ff] dark:bg-primary/10 px-2 py-0.5 rounded-md inline-block">
                  Scope: {activeRoleInfo.target}
                </div>
              </div>

              {/* Action Controls */}
              <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                <button
                  onClick={() => {
                    const defaultView = allowedViews[0] || 'LIVE_SYNC_DASHBOARD';
                    onNavigate(defaultView);
                  }}
                  className="w-full sm:w-auto flex-1 bg-primary text-on-primary py-3 px-6 rounded-xl font-bold text-xs hover:opacity-95 active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md hover:shadow-lg hover:shadow-primary/15"
                >
                  <span className="material-symbols-outlined text-sm">home</span>
                  Go to Authorized Home
                </button>
                
                <button
                  onClick={onLogout}
                  className="w-full sm:w-auto flex-1 bg-slate-100 dark:bg-slate-800/40 text-slate-700 dark:text-slate-300 py-3 px-6 rounded-xl font-bold text-xs border border-slate-200/50 dark:border-slate-700/30 hover:bg-slate-200/50 dark:hover:bg-slate-800/80 active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <span className="material-symbols-outlined text-sm">logout</span>
                  Sign Out
                </button>
              </div>

            </div>

            {/* Right Column: Allowed Workspaces Dashboard Index */}
            <div className="w-full md:w-[320px] border-t md:border-t-0 md:border-l border-outline-variant/60 pt-6 md:pt-0 md:pl-8 flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300 font-extrabold text-xs uppercase tracking-wider">
                  <span className="material-symbols-outlined text-sm text-slate-400">lock_open</span>
                  Your Authorized Modules ({allowedViews.length})
                </div>
                
                <div className="space-y-2 max-h-[250px] overflow-y-auto pr-1">
                  {allowedViews.map((view) => (
                    <button
                      key={view}
                      onClick={() => onNavigate(view)}
                      className="w-full flex items-center gap-3 px-3.5 py-3 rounded-xl border border-slate-200/60 dark:border-slate-800/50 bg-white dark:bg-[#11141e] text-slate-700 dark:text-slate-300 hover:border-primary/50 dark:hover:border-primary/50 hover:bg-slate-100/50 dark:hover:bg-[#1a202e] hover:text-primary dark:hover:text-primary-light text-left transition-all duration-200 cursor-pointer group text-xs font-semibold"
                    >
                      <span className="material-symbols-outlined text-lg text-slate-400 group-hover:text-primary transition-colors">
                        {view === 'LIVE_SYNC_DASHBOARD' && 'sync'}
                        {view === 'PRECISION_OPS_DASHBOARD' && 'dashboard'}
                        {view === 'DETAILED_PORTFOLIO_LOGS' && 'analytics'}
                        {view === 'GMAIL_DASHBOARD' && 'mail'}
                        {view === 'ANALYST_QUALITY_DASHBOARD' && 'reward'}
                        {view === 'EXCEL_PARSER_UTILITY' && 'grid_on'}
                        {view === 'GOOGLE_CHAT_DASHBOARD' && 'forum'}
                        {view === 'PRESENTATION_DECK' && 'slideshow'}
                      </span>
                      <span className="truncate">{formatViewName(view)}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Developer Tip */}
              <div className="pt-4 border-t border-outline-variant/40 mt-4 text-[10px] text-on-surface-variant font-medium opacity-75">
                <p className="leading-relaxed">
                  Need access to other components? Contact the system administrator to request higher credential elevation.
                </p>
              </div>

            </div>

          </div>
        )}

        {/* Footer info bar */}
        <div className="px-6 py-3 border-t border-outline-variant/50 bg-surface-container flex items-center justify-between text-[9px] font-bold text-on-surface-variant">
          <span>Confidential • Internal MarginEdge Operational Security Boundary</span>
          <span>Access Level: Verified</span>
        </div>

      </div>
    </div>
  );
}
