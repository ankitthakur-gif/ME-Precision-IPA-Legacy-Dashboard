import React, { useEffect } from 'react';
import { useAuth } from '../context/AuthContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
  onRedirectToLogin: () => void;
}

export default function ProtectedRoute({ children, onRedirectToLogin }: ProtectedRouteProps) {
  const { currentUser, loading } = useAuth();

  useEffect(() => {
    if (!loading && !currentUser) {
      onRedirectToLogin();
    }
  }, [currentUser, loading, onRedirectToLogin]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f7f9ff] dark:bg-[#0b0e14] flex flex-col items-center justify-center font-sans">
        <div className="relative flex items-center justify-center">
          <div className="w-12 h-12 border-4 border-primary/20 border-t-primary rounded-full animate-spin"></div>
          <div className="absolute w-6 h-6 border-4 border-cyan-400/20 border-t-cyan-400 rounded-full animate-spin [animation-direction:reverse]"></div>
        </div>
        <p className="mt-4 text-xs text-slate-500 dark:text-slate-400 font-bold tracking-wider uppercase">
          Verifying Security Credentials...
        </p>
      </div>
    );
  }

  if (!currentUser) {
    return null;
  }

  return <>{children}</>;
}
