import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { useRealtime } from '../context/RealtimeContext';
import { ReconciliationRecord, IPARecord } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import * as XLSX from 'xlsx';
import { initAuth, googleSignIn, logout as googleLogout, getAccessToken } from '../lib/googleAuth';
import { NotificationBellDropdown, FloatingToastStack, RealtimeDashboardPanel } from './RealtimeNotificationCenter';

interface LiveSyncDashboardProps {
  userEmail: string;
  userName?: string;
  userPosition?: string;
  onNavigate: (view: any) => void;
  onLogout: () => void;
}

export default function LiveSyncDashboard({ 
  userEmail, 
  userName, 
  userPosition, 
  onNavigate, 
  onLogout 
}: LiveSyncDashboardProps) {
  const { 
    reconciliationRecords, 
    ipaRecords, 
    teamPerformance, 
    isConnected, 
    updateRecord, 
    updateAllIpaRecords,
    resetState 
  } = useRealtime();

  const [googleSheetUrl, setGoogleSheetUrl] = useState('');
  const [isSourceModalOpen, setIsSourceModalOpen] = useState(false);
  const [sheetInputUrl, setSheetInputUrl] = useState('');
  const [isSavingSheet, setIsSavingSheet] = useState(false);

  // Google Sheets & Drive live integration state
  const [googleUser, setGoogleUser] = useState<any | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [needsAuth, setNeedsAuth] = useState(true);
  const [driveSheets, setDriveSheets] = useState<any[]>([]);
  const [loadingDriveSheets, setLoadingDriveSheets] = useState(false);
  const [driveError, setDriveError] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/settings/google-sheet')
      .then(res => res.json())
      .then(data => {
        if (data.url) {
          setGoogleSheetUrl(data.url);
          setSheetInputUrl(data.url);
        }
      })
      .catch(err => console.error("Error loading google sheet setting:", err));
  }, []);

  // Track Firebase Auth State for Sheets & Drive integration on mount
  useEffect(() => {
    const unsubscribe = initAuth(
      (user, cachedToken) => {
        setGoogleUser(user);
        setToken(cachedToken);
        setNeedsAuth(false);
        fetchDriveSheets(cachedToken);
      },
      () => {
        setGoogleUser(null);
        setToken(null);
        setNeedsAuth(true);
      }
    );
    return () => unsubscribe();
  }, []);

  const fetchDriveSheets = async (accessToken: string) => {
    setLoadingDriveSheets(true);
    setDriveError(null);
    try {
      const response = await fetch(
        "https://www.googleapis.com/drive/v3/files?q=mimeType='application/vnd.google-apps.spreadsheet'&fields=files(id,name,webViewLink,modifiedTime)&pageSize=30",
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );
      if (!response.ok) {
        throw new Error(`Failed to list Google Sheets (HTTP ${response.status})`);
      }
      const data = await response.json();
      setDriveSheets(data.files || []);
    } catch (err: any) {
      console.error("Error fetching Google Sheets:", err);
      setDriveError(err.message || "Failed to load Google Sheets from your Drive.");
    } finally {
      setLoadingDriveSheets(false);
    }
  };

  const handleGoogleLogin = async () => {
    setDriveError(null);
    try {
      const result = await googleSignIn();
      if (result) {
        setGoogleUser(result.user);
        setToken(result.accessToken);
        setNeedsAuth(false);
        fetchDriveSheets(result.accessToken);
      }
    } catch (err: any) {
      console.error('Google login failed:', err);
      setDriveError(err.message || 'Google Auth Popup closed or failed.');
    }
  };

  const handleGoogleLogout = async () => {
    try {
      await googleLogout();
      setGoogleUser(null);
      setToken(null);
      setDriveSheets([]);
      setNeedsAuth(true);
    } catch (err) {
      console.error('Logout failed:', err);
    }
  };

  const handleSaveSelectedDriveSheet = async (fileId: string) => {
    const sheetUrl = `https://docs.google.com/spreadsheets/d/${fileId}/edit`;
    setIsSavingSheet(true);
    try {
      const response = await fetch('/api/settings/google-sheet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: sheetUrl })
      });
      const data = await response.json();
      if (data.success) {
        setGoogleSheetUrl(sheetUrl);
        setSheetInputUrl(sheetUrl);
        alert("Google Sheet successfully linked and synchronized!");
        setIsSourceModalOpen(false);
      } else {
        alert("Failed to link Google Sheet. Please make sure the sheet is public or has viewer permissions.");
      }
    } catch (err) {
      console.error("Error saving Google Sheet link:", err);
      alert("Error linking Google Sheet.");
    } finally {
      setIsSavingSheet(false);
    }
  };

  const handleSaveGoogleSheet = async () => {
    setIsSavingSheet(true);
    try {
      const response = await fetch('/api/settings/google-sheet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: sheetInputUrl })
      });
      const data = await response.json();
      if (data.success) {
        setGoogleSheetUrl(sheetInputUrl);
        alert(sheetInputUrl ? "Google Sheet successfully linked and synchronized!" : "Google Sheet unlinked successfully.");
        setIsSourceModalOpen(false);
      } else {
        alert("Failed to save. Please make sure it's a valid public Google Sheet URL.");
      }
    } catch (err) {
      console.error("Error saving Google Sheet link:", err);
      alert("Error linking Google Sheet.");
    } finally {
      setIsSavingSheet(false);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const arrayBuffer = e.target?.result as ArrayBuffer;
        const data = new Uint8Array(arrayBuffer);
        let workbook;
        
        try {
          // Attempt 1: Parse as binary array (Excel formats and some CSVs)
          workbook = XLSX.read(data, { type: 'array' });
        } catch (err: any) {
          try {
            // Attempt 2 Fallback: Decode binary data to string (plain text CSV)
            const text = new TextDecoder().decode(data);
            workbook = XLSX.read(text, { type: 'string' });
          } catch (innerErr) {
            // If both fail, throw the original error
            throw err;
          }
        }

        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json<any>(worksheet);

        if (!json || json.length === 0) {
          alert("The spreadsheet file appears to be empty.");
          return;
        }

        // Map row items into IPARecord structure intelligently matching columns
        const parsedRecords: IPARecord[] = json.map((row, index) => {
          const keys = Object.keys(row);
          // Find closest matching headers (case-insensitive)
          const nameKey = keys.find(k => /name|user|analyst|employee|member/i.test(k)) || keys[0];
          const teamKey = keys.find(k => /team|dept|office|group/i.test(k)) || keys[1];
          const tasksKey = keys.find(k => /task|point|volume|count|score/i.test(k)) || keys[2];

          return {
            id: row.id || `ipa-${index + 1}-${Date.now()}`,
            name: String(row[nameKey] || `Analyst ${index + 1}`).trim(),
            team: String(row[teamKey] || 'Alpha').trim(),
            tasks: Number(row[tasksKey]) || 0
          };
        });

        updateAllIpaRecords(parsedRecords);
        alert(`Successfully parsed, uploaded, and synchronized ${parsedRecords.length} IPA records across all users!`);
      } catch (err) {
        console.error("Error parsing Excel/CSV:", err);
        alert("Failed to parse file. Please make sure it is a valid CSV or Excel spreadsheet.");
      }
    };
    reader.readAsArrayBuffer(file);
  };

  // States for search and filter
  const [dateRange, setDateRange] = useState('July 3, 2026 - July 4, 2026');
  const [selectedOffice, setSelectedOffice] = useState('Office (All)');
  const [selectedRole, setSelectedRole] = useState(
    userPosition === 'Analyst' ? 'Analysts' : 
    userPosition === 'Lead' ? 'Lead Analysts' : 
    userPosition === 'AM' ? 'Assistant Managers (AM)' : 'All Roles'
  );
  const [searchQuery, setSearchQuery] = useState('');
  
  // IPA specific states
  const [ipaSearch, setIpaSearch] = useState('');
  const [ipaTeam, setIpaTeam] = useState('All Teams');
  const [ipaStatus, setIpaStatus] = useState('All Status');
  const [ipaDays, setIpaDays] = useState<'1D' | '1W' | '1M' | '1Y'>('1D');

  // Page tracking for table
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(100);

  // Sync animation and state
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastUpdatedText, setLastUpdatedText] = useState('Just now');
  const [syncMessage, setSyncMessage] = useState('');

  // Disaster Recovery / Daily Backups state
  const [backupStatus, setBackupStatus] = useState<any>(null);
  const [isBackingUp, setIsBackingUp] = useState(false);

  const fetchBackupStatus = useCallback(async () => {
    try {
      const res = await fetch('/api/backups/status');
      if (res.ok) {
        const data = await res.json();
        setBackupStatus(data);
      }
    } catch (err) {
      console.error("Error fetching backup status:", err);
    }
  }, []);

  useEffect(() => {
    fetchBackupStatus();
    const interval = setInterval(fetchBackupStatus, 30000); // Auto refresh backup status every 30s
    return () => clearInterval(interval);
  }, [fetchBackupStatus]);

  const handleManualBackup = async () => {
    setIsBackingUp(true);
    try {
      const res = await fetch('/api/backups/snapshot', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          alert(`✅ Backup successful! Consolidated ${data.logsCount} records into snapshot ${data.snapshotDate}.`);
          fetchBackupStatus();
        } else {
          alert(`❌ Backup failed: ${data.error || 'Unknown error'}`);
        }
      } else {
        alert("❌ Backup failed (Server HTTP error).");
      }
    } catch (err) {
      console.error("Backup error:", err);
      alert("❌ Backup error: Failed to reach backend.");
    } finally {
      setIsBackingUp(false);
    }
  };

  const handleSyncNow = () => {
    setIsSyncing(true);
    setSyncMessage('Initiating Real-Time Live Sync with Master Ledger...');
    setTimeout(() => {
      setIsSyncing(false);
      setLastUpdatedText('Less than a minute ago');
      setSyncMessage('Live Sync Completed! 85,240 records reconciled successfully.');
      setTimeout(() => setSyncMessage(''), 4000);
    }, 2000);
  };

  const handleRowClick = (row: ReconciliationRecord) => {
    const nextStatus = row.status === 'MATCHED' ? 'PENDING' : 'MATCHED';
    updateRecord({
      ...row,
      status: nextStatus
    });
    setSyncMessage(`Broadcasted: ${row.user} status toggled to ${nextStatus}!`);
    setTimeout(() => setSyncMessage(''), 3000);
  };

  // Main table filtering (Unified Reconciliation Report)
  const filteredReconciliation = useMemo(() => {
    return reconciliationRecords.filter(row => {
      // Office Filter
      if (selectedOffice !== 'Office (All)' && row.office !== selectedOffice) {
        return false;
      }
      // Search Filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const matchesUser = row.user.toLowerCase().includes(query);
        const matchesOffice = row.office.toLowerCase().includes(query);
        const matchesTeam = row.team.toLowerCase().includes(query);
        return matchesUser || matchesOffice || matchesTeam;
      }
      return true;
    });
  }, [reconciliationRecords, selectedOffice, searchQuery]);

  // Main table pagination calculations
  const paginatedReconciliation = useMemo(() => {
    const startIndex = (currentPage - 1) * rowsPerPage;
    return filteredReconciliation.slice(startIndex, startIndex + rowsPerPage);
  }, [filteredReconciliation, currentPage, rowsPerPage]);

  const totalPages = useMemo(() => {
    return Math.ceil(filteredReconciliation.length / rowsPerPage) || 1;
  }, [filteredReconciliation.length, rowsPerPage]);

  useEffect(() => {
    setCurrentPage(1);
  }, [selectedOffice, searchQuery, rowsPerPage]);

  // Live IPA Report filtering
  const filteredIpaRecords = useMemo(() => {
    return ipaRecords.filter(row => {
      // Team Filter
      if (ipaTeam !== 'All Teams' && row.team !== ipaTeam) {
        return false;
      }
      // Search Filter
      if (ipaSearch) {
        const query = ipaSearch.toLowerCase();
        return row.name.toLowerCase().includes(query) || row.team.toLowerCase().includes(query);
      }
      return true;
    });
  }, [ipaRecords, ipaTeam, ipaSearch]);

  // Chart data formatting
  const chartData = useMemo(() => {
    return teamPerformance.map(t => ({
      name: t.teamName,
      Efficiency: t.efficiency,
      'Error Rate': t.errorRate
    }));
  }, [teamPerformance]);

  return (
    <div className="bg-[#f8f9ff] text-on-background font-sans min-h-screen relative flex">
      {/* Toast Notification */}
      {syncMessage && (
        <div className="fixed top-20 right-6 z-50 bg-secondary text-on-secondary px-6 py-3 rounded-lg shadow-xl border border-secondary/20 flex items-center space-x-3 animate-bounce">
          <span className="material-symbols-outlined">check_circle</span>
          <span className="font-semibold text-xs">{syncMessage}</span>
        </div>
      )}

      {/* SideNavBar Shell */}
      <aside className="w-[260px] shrink-0 bg-surface border-r border-outline-variant flex flex-col min-h-screen sticky top-0 h-screen z-40">
        <div className="p-6">
          <h1 className="text-xl font-bold text-primary font-headline">MarginEdge Pro Team</h1>
          <p className="text-xs text-on-surface-variant opacity-70">Enterprise Data Management</p>
        </div>
        
        <nav className="flex-1 px-2 space-y-1">
          <button 
            onClick={() => onNavigate('LIVE_SYNC_DASHBOARD')}
            className="w-full flex items-center gap-3 px-4 py-3 border-l-4 border-primary bg-surface-container-high text-primary font-bold text-left cursor-pointer"
          >
            <span className="material-symbols-outlined">sync_saved_locally</span>
            <span className="text-sm">Live Sync Panel</span>
          </button>
          
          {(userPosition === 'Admin' || userPosition === 'AM') && (
            <button 
              onClick={() => onNavigate('PRECISION_OPS_DASHBOARD')}
              className="w-full flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container transition-colors duration-150 text-left cursor-pointer"
            >
              <span className="material-symbols-outlined">dashboard</span>
              <span className="text-sm">Invoice Manager</span>
            </button>
          )}
          
          <button 
            onClick={() => onNavigate('DETAILED_PORTFOLIO_LOGS')}
            className="w-full flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container transition-colors duration-150 text-left cursor-pointer"
          >
            <span className="material-symbols-outlined">assessment</span>
            <span className="text-sm">Detailed Reports</span>
          </button>
          
          {(userPosition === 'Admin' || userPosition === 'AM') && (
            <button 
              onClick={() => onNavigate('GMAIL_DASHBOARD')}
              className="w-full flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container transition-colors duration-150 text-left cursor-pointer"
            >
              <span className="material-symbols-outlined">mail</span>
              <span className="text-sm">Gmail Sync Gateway</span>
            </button>
          )}

          {(userPosition === 'Admin' || userPosition === 'Team Lead' || userPosition === 'Lead') && (
            <button 
              onClick={() => onNavigate('ANALYST_QUALITY_DASHBOARD')}
              className="w-full flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container transition-colors duration-150 text-left cursor-pointer"
            >
              <span className="material-symbols-outlined">reward</span>
              <span className="text-sm">Scoring Analytics</span>
            </button>
          )}

          <button 
            onClick={() => onNavigate('GOOGLE_CHAT_DASHBOARD')}
            className="w-full flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container transition-colors duration-150 text-left cursor-pointer"
          >
            <span className="material-symbols-outlined">forum</span>
            <span className="text-sm">Google Chat Team</span>
          </button>

          {(userPosition === 'Admin' || userPosition === 'AM' || userPosition === 'Team Lead' || userPosition === 'Lead') && (
            <button 
              onClick={() => onNavigate('PRESENTATION_DECK')}
              className="w-full flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-indigo-500/15 via-purple-500/10 to-pink-500/5 text-purple-400 border-l-4 border-purple-500 hover:from-indigo-500/25 transition-all duration-150 text-left cursor-pointer font-bold shadow-sm"
            >
              <span className="material-symbols-outlined text-purple-400 animate-pulse">co_present</span>
              <span className="text-sm text-purple-300">Presentation & Video Tour</span>
            </button>
          )}

          <div className="pt-4 mt-4 border-t border-outline-variant/30">
            <p className="px-4 text-[10px] text-on-surface-variant font-bold uppercase tracking-wider mb-2">
              Conversion Utilities
            </p>
            <button 
              onClick={() => onNavigate('EXCEL_PARSER_UTILITY')}
              className="w-full flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container transition-colors duration-150 text-left cursor-pointer font-bold"
            >
              <span className="material-symbols-outlined text-[#2997ff]">upload_file</span>
              <span className="text-sm text-[#2997ff]">Excel to JSON Tool</span>
            </button>
          </div>

          <div className="pt-4 mt-4 border-t border-outline-variant/30">
            <p className="px-4 text-[10px] text-on-surface-variant font-bold uppercase tracking-wider mb-2">
              REGIONAL VIEWS
            </p>
            <button 
              onClick={() => setSelectedOffice('Office (All)')}
              className={`w-full flex items-center gap-3 px-4 py-2 text-sm text-left hover:bg-surface-container transition-colors ${selectedOffice === 'Office (All)' ? 'text-primary font-bold' : 'text-on-surface-variant'}`}
            >
              <span className="material-symbols-outlined text-[18px]">public</span>
              <span>Global Overview</span>
            </button>
            <button 
              onClick={() => setSelectedOffice('Chandigarh')}
              className={`w-full flex items-center gap-3 px-4 py-2 text-sm text-left hover:bg-surface-container transition-colors ${selectedOffice === 'Chandigarh' ? 'text-primary font-bold' : 'text-on-surface-variant'}`}
            >
              <span className="material-symbols-outlined text-[18px]">location_on</span>
              <span>Chandigarh Hub</span>
            </button>
            <button 
              onClick={() => setSelectedOffice('Dhaka')}
              className={`w-full flex items-center gap-3 px-4 py-2 text-sm text-left hover:bg-surface-container transition-colors ${selectedOffice === 'Dhaka' ? 'text-primary font-bold' : 'text-on-surface-variant'}`}
            >
              <span className="material-symbols-outlined text-[18px]">location_on</span>
              <span>Dhaka Hub</span>
            </button>
            <button 
              onClick={() => setSelectedOffice('Havana')}
              className={`w-full flex items-center gap-3 px-4 py-2 text-sm text-left hover:bg-surface-container transition-colors ${selectedOffice === 'Havana' ? 'text-primary font-bold' : 'text-on-surface-variant'}`}
            >
              <span className="material-symbols-outlined text-[18px]">location_on</span>
              <span>Havana Hub</span>
            </button>
            <button 
              onClick={() => setSelectedOffice('US')}
              className={`w-full flex items-center gap-3 px-4 py-2 text-sm text-left hover:bg-surface-container transition-colors ${selectedOffice === 'US' ? 'text-primary font-bold' : 'text-on-surface-variant'}`}
            >
              <span className="material-symbols-outlined text-[18px]">location_on</span>
              <span>US Hub</span>
            </button>
          </div>
        </nav>

        <div className="p-4 mt-auto">
          <button 
            onClick={handleSyncNow}
            className="w-full bg-primary text-on-primary py-2.5 rounded-lg font-bold text-sm hover:opacity-90 active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <span className="material-symbols-outlined text-sm">sync</span>
            Sync All Data
          </button>
          
          <div className="mt-4 pt-4 border-t border-outline-variant flex flex-col gap-1">
            <a className="flex items-center gap-3 px-4 py-2 text-on-surface-variant hover:bg-surface-container text-xs transition-colors rounded" href="#help">
              <span className="material-symbols-outlined text-sm">help_outline</span>
              <span>Help Center</span>
            </a>
            <button 
              onClick={onLogout}
              className="flex items-center gap-3 px-4 py-2 text-error hover:bg-error-container/20 text-xs transition-colors rounded text-left w-full cursor-pointer"
            >
              <span className="material-symbols-outlined text-sm">logout</span>
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Container Wrapper */}
      <div className="flex-1 min-h-screen flex flex-col overflow-x-hidden">
        
        {/* TopNavBar Shell */}
        <header className="h-16 bg-surface/90 backdrop-blur-sm border-b border-outline-variant flex items-center justify-between px-6 sticky top-0 z-30">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-3">
              <h2 className="text-lg font-bold text-on-surface font-headline">Live Sync Status</h2>
              <div className="flex items-center gap-1.5 bg-[#eff4ff] px-2.5 py-1 rounded-full border border-[#c1c7d2]">
                <span className={`w-2 h-2 rounded-full ${isConnected ? 'bg-[#006d37] animate-pulse' : 'bg-orange-500'}`}></span>
                <span className="text-[10px] text-on-surface-variant font-bold uppercase tracking-wider">
                  {isConnected ? 'Real-Time Connected' : 'Server Offline'}
                </span>
              </div>
            </div>
            <div className="hidden md:flex gap-6">
              <button 
                onClick={() => onNavigate('DETAILED_PORTFOLIO_LOGS')}
                className="text-on-surface-variant hover:text-primary transition-all font-label-caps text-xs pb-1 border-b-2 border-transparent hover:border-primary cursor-pointer"
              >
                Reports
              </button>
              <button 
                onClick={() => onNavigate('LIVE_SYNC_DASHBOARD')}
                className="text-primary border-b-2 border-primary pb-1 font-label-caps text-xs cursor-pointer"
              >
                Reconciliation
              </button>
              <button 
                onClick={() => onNavigate('PRESET_REPORT')}
                className="text-on-surface-variant hover:text-primary transition-all font-label-caps text-xs pb-1 cursor-pointer"
              >
                Presets
              </button>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button className="flex items-center gap-2 px-4 py-1.5 border border-primary text-primary rounded text-xs font-semibold hover:bg-primary/5 transition-all cursor-pointer">
              <span className="material-symbols-outlined text-[16px]">help</span> 
              Setup Guide
            </button>
            
            <button 
              onClick={handleSyncNow}
              disabled={isSyncing}
              className={`bg-primary text-on-primary px-4 py-1.5 rounded text-xs font-semibold hover:opacity-90 transition-all cursor-pointer flex items-center gap-1.5 ${isSyncing ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {isSyncing ? 'Syncing...' : 'Sync Now'}
            </button>

            <div className="flex gap-4 items-center">
              <NotificationBellDropdown />
              <button 
                onClick={handleSyncNow}
                className="w-10 h-10 flex items-center justify-center text-on-surface-variant hover:bg-surface-container rounded-full transition-all cursor-pointer"
              >
                <span className={`material-symbols-outlined text-[18px] ${isSyncing ? 'animate-spin-custom text-primary' : ''}`}>sync</span>
              </button>
              
              <div className="flex items-center gap-3 pl-2 border-l border-outline-variant">
                <div className="text-right hidden sm:block">
                  <p className="text-xs font-bold text-on-surface">{userName || 'Ankit Thakur'}</p>
                  <p className="text-[10px] text-on-surface-variant font-medium">{userPosition || 'Lead'}</p>
                </div>
                <div className="w-9 h-9 rounded-full bg-primary text-on-primary flex items-center justify-center font-bold text-xs uppercase shadow-sm">
                  {userName ? userName.split(' ').map(n => n[0]).join('').slice(0, 2) : 'AT'}
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content Canvas */}
        <main className="p-6 flex-1">
          
          {/* Personalized Role-Based Welcome Banner */}
          <div className="mb-6 bg-primary/[0.03] border-l-4 border-primary rounded-r-lg p-4 shadow-sm flex items-start gap-3.5">
            <div className="p-2 rounded-lg bg-primary/10 text-primary shrink-0">
              <span className="material-symbols-outlined text-[20px] font-bold">
                {userPosition === 'Analyst' ? 'edit_note' :
                 userPosition === 'Lead' ? 'group_work' :
                 userPosition === 'AM' ? 'badge' :
                 userPosition === 'Specialist' ? 'construction' : 'star'}
              </span>
            </div>
            <div>
              <h3 className="font-headline text-sm font-bold text-on-surface">
                Welcome back, {userName || 'Ankit Thakur'} • <span className="text-primary font-extrabold">{userPosition || 'Lead'} Workstation</span>
              </h3>
              <p className="text-xs text-on-surface-variant leading-relaxed mt-1">
                {userPosition === 'Analyst' && '🎯 Your Analyst view is active. Your assigned task is matching and scoring individual vendor reconciliation logs, reviewing Chandigarh & Dhaka hub daily quality records, and resolving accuracy outliers below 95%.'}
                {userPosition === 'Lead' && '👥 Your Team Lead view is active. You are supervising overall hub productivity compliance, tracking daily scoring distributions, approving detailed reports, and orchestrating virtual workspace sync.'}
                {userPosition === 'AM' && '📊 Your Assistant Manager view is active. You are monitoring client SLA fulfillment ratios, reviewing active AM escalation signals, tracking high-risk portfolio portfolios, and dispatching team alerts.'}
                {userPosition === 'Specialist' && '🛠️ Your Specialist view is active. You have advanced privileges to audit virtual database schemas, troubleshoot live synchronization queues, correct system-wide mapping errors, and maintain real-time ledgers.'}
                {!userPosition && 'Welcome to MarginEdge Precision-ME. Access customized operational indicators, real-time ledgers, and secure collaboration workspaces.'}
              </p>
            </div>
          </div>
          
          {/* Live Sync Bar Component */}
          <div className="mb-6 flex items-center justify-between bg-secondary/5 border border-secondary/20 rounded-lg px-4 py-3 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="relative flex items-center">
                <span className="block w-2.5 h-2.5 bg-secondary rounded-full animate-pulse-dot"></span>
                <span className="absolute inline-flex h-full w-full rounded-full bg-secondary opacity-75 animate-ping"></span>
              </div>
              <span className="font-mono text-xs text-secondary font-bold">
                <span className="inline-flex items-center gap-1.5 mr-2 bg-secondary text-on-secondary px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase">LIVE</span>
                Enterprise Live Sync: MarginEdge Real-time Data &amp; Global Workspace
              </span>
              <span className="text-xs text-on-surface-variant opacity-60 ml-2">Last updated: {lastUpdatedText}</span>
            </div>
            
            <div className="flex gap-2 items-center">
              {googleSheetUrl && (
                <div className="flex items-center gap-1.5 bg-green-500/10 text-green-700 px-3 py-1.5 rounded border border-green-500/20 text-[10px] font-bold uppercase tracking-tight animate-pulse shrink-0">
                  <span className="block w-2 h-2 bg-green-500 rounded-full"></span>
                  Google Sheet Auto-Sync: Active
                </div>
              )}
              <div className="flex items-center gap-1.5 bg-secondary/20 px-3 py-1.5 rounded border border-secondary/30">
                <span className="material-symbols-outlined text-secondary text-[16px]">sync_saved_locally</span>
                <span className="text-[10px] font-bold text-secondary uppercase tracking-tight">Auto-Sync: ON</span>
              </div>
              <button 
                onClick={() => setIsSourceModalOpen(true)}
                className="flex items-center gap-2 px-3 py-1.5 text-xs font-semibold border border-outline-variant rounded bg-white hover:bg-surface-container transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">settings_input_component</span> 
                Change Source
              </button>
            </div>
          </div>

          {/* Filters Bar */}
          <div className="mb-6 w-full bg-surface-container-low border border-outline-variant rounded-lg p-4 shadow-sm">
            <div className="flex flex-col md:flex-row items-center gap-4">
              <div className="relative flex-1 w-full">
                <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant opacity-60 text-[18px]">calendar_today</span>
                <input 
                  className="w-full bg-white border border-outline-variant rounded py-2 pl-10 pr-4 text-xs focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all font-sans" 
                  type="text" 
                  value={dateRange}
                  onChange={(e) => setDateRange(e.target.value)}
                />
              </div>

              <div className="relative flex-1 w-full">
                <select 
                  value={selectedOffice}
                  onChange={(e) => {
                    setSelectedOffice(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="w-full bg-white border border-outline-variant rounded py-2 px-3 pr-8 text-xs focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all appearance-none cursor-pointer"
                >
                  <option>Office (All)</option>
                  <option>Chandigarh</option>
                  <option>Dhaka</option>
                  <option>Havana</option>
                  <option>US</option>
                </select>
                <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-on-surface-variant pointer-events-none text-sm">expand_more</span>
              </div>

              <div className="relative flex-1 w-full">
                <select 
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value)}
                  className="w-full bg-white border border-outline-variant rounded py-2 px-3 pr-8 text-xs focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all appearance-none cursor-pointer"
                >
                  <option>All Roles</option>
                  <option>Assistant Managers (AM)</option>
                  <option>Lead Analysts</option>
                  <option>Analysts</option>
                </select>
                <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-on-surface-variant pointer-events-none text-sm">expand_more</span>
              </div>

              <div className="relative flex-[1.5] w-full">
                <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant opacity-60 text-[18px]">search</span>
                <input 
                  className="w-full bg-white border border-outline-variant rounded py-2 pl-10 pr-4 text-xs focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all" 
                  placeholder="Search by name, office or team..." 
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              <button 
                onClick={handleSyncNow}
                className="bg-primary text-on-primary px-6 py-2 rounded font-medium text-xs hover:opacity-90 transition-all whitespace-nowrap cursor-pointer"
              >
                Apply Filters
              </button>
            </div>
          </div>

          {/* Team Performance Analytics Grid Section */}
          <section className="mb-6 grid grid-cols-12 gap-6">
            
            {/* Team Performance Matrix (Recharts Clustered Bar) */}
            <div className="col-span-12 lg:col-span-8 bg-white border border-outline-variant rounded-lg p-5 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h4 className="font-headline text-base font-bold text-on-surface flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary">analytics</span>
                  Global Team Efficiency &amp; Error Trends
                </h4>
                
                <div className="flex gap-4 text-xs font-semibold">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-secondary"></span>
                    <span className="text-on-surface-variant text-[10px] uppercase font-bold tracking-wider">Efficiency</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-error"></span>
                    <span className="text-on-surface-variant text-[10px] uppercase font-bold tracking-wider">Error %</span>
                  </div>
                </div>
              </div>

              {/* Chart Container */}
              <div className="h-56 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={chartData}
                    margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                  >
                    <XAxis 
                      dataKey="name" 
                      tick={{ fill: '#42474f', fontSize: 10, fontWeight: 700 }}
                      axisLine={{ stroke: '#c1c7d2' }}
                    />
                    <YAxis 
                      tick={{ fill: '#42474f', fontSize: 10 }}
                      axisLine={{ stroke: '#c1c7d2' }}
                      domain={[0, 100]}
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#ffffff', borderRadius: '8px', border: '1px solid #c1c7d2', fontSize: '11px' }}
                    />
                    <Bar dataKey="Efficiency" fill="#006d37" radius={[4, 4, 0, 0]} barSize={20} />
                    <Bar dataKey="Error Rate" fill="#ba1a1a" radius={[4, 4, 0, 0]} barSize={20} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Regional boxes */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 pt-6 border-t border-outline-variant/30">
                <div className="p-3 rounded bg-[#eff4ff] border border-[#c1c7d2]">
                  <p className="text-[10px] font-bold text-on-surface-variant mb-1 uppercase tracking-wider">DHAKA</p>
                  <p className="text-lg font-bold text-error">4.2% <span className="text-[10px] font-semibold text-error/70">Err</span></p>
                  <div className="mt-2 flex justify-between items-center text-[10px] text-on-surface-variant">
                    <span>Output: 12.4k</span>
                    <span className="font-bold text-primary">Alpha Ops</span>
                  </div>
                </div>

                <div className="p-3 rounded bg-[#eff4ff] border border-[#c1c7d2]">
                  <p className="text-[10px] font-bold text-on-surface-variant mb-1 uppercase tracking-wider">CHANDIGARH</p>
                  <p className="text-lg font-bold text-secondary">0.8% <span className="text-[10px] font-semibold text-secondary/70">Err</span></p>
                  <div className="mt-2 flex justify-between items-center text-[10px] text-on-surface-variant">
                    <span>Output: 8.1k</span>
                    <span className="font-bold text-primary">Beta Team</span>
                  </div>
                </div>

                <div className="p-3 rounded bg-[#eff4ff] border border-[#c1c7d2]">
                  <p className="text-[10px] font-bold text-on-surface-variant mb-1 uppercase tracking-wider">HAVANA</p>
                  <p className="text-lg font-bold text-on-surface-variant">2.1% <span className="text-[10px] font-semibold text-on-surface-variant/70">Err</span></p>
                  <div className="mt-2 flex justify-between items-center text-[10px] text-on-surface-variant">
                    <span>Output: 5.2k</span>
                    <span className="font-bold text-primary">Island Ops</span>
                  </div>
                </div>

                <div className="p-3 rounded bg-[#eff4ff] border border-[#c1c7d2]">
                  <p className="text-[10px] font-bold text-on-surface-variant mb-1 uppercase tracking-wider">US BPO</p>
                  <p className="text-lg font-bold text-secondary">1.4% <span className="text-[10px] font-semibold text-secondary/70">Err</span></p>
                  <div className="mt-2 flex justify-between items-center text-[10px] text-on-surface-variant">
                    <span>Output: 15.9k</span>
                    <span className="font-bold text-primary">Capital Lead</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Highlights Side Cards */}
            <div className="col-span-12 lg:col-span-4 flex flex-col gap-4">
              
              <div className="bg-secondary/5 border border-secondary/20 rounded-lg p-4 flex-1 shadow-sm flex flex-col justify-between">
                <h5 className="text-[10px] font-bold text-secondary tracking-wider uppercase mb-2 flex items-center gap-2">
                  <span className="material-symbols-outlined text-[16px]">trending_up</span> 
                  TOP PERFORMING TEAM
                </h5>
                <div className="flex justify-between items-center mt-1">
                  <div>
                    <p className="text-lg font-bold text-on-surface font-headline leading-tight">Alpha Ops</p>
                    <p className="text-xs text-on-surface-variant">Efficiency: 98.4%</p>
                  </div>
                  <span className="inline-flex items-center gap-1.5 bg-secondary text-on-secondary px-2.5 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider">LIVE</span>
                </div>
              </div>

              <div className="bg-error/5 border border-error/20 rounded-lg p-4 flex-1 shadow-sm flex flex-col justify-between">
                <h5 className="text-[10px] font-bold text-error tracking-wider uppercase mb-2 flex items-center gap-2">
                  <span className="material-symbols-outlined text-[16px]">warning</span> 
                  ATTENTION REQUIRED
                </h5>
                <div className="flex justify-between items-center mt-1">
                  <div>
                    <p className="text-lg font-bold text-on-surface font-headline leading-tight">Dhaka Admin</p>
                    <p className="text-xs text-on-surface-variant">Error Rate: 4.2% (High)</p>
                  </div>
                  <button 
                    onClick={() => {
                      setSelectedOffice('Dhaka');
                      setSearchQuery('');
                    }}
                    className="text-error text-[10px] font-bold border border-error/30 px-2.5 py-1 rounded hover:bg-error/10 transition-all cursor-pointer whitespace-nowrap"
                  >
                    REVIEW DATA
                  </button>
                </div>
              </div>

              <div className="bg-white border border-outline-variant rounded-lg p-4 shadow-sm">
                <h5 className="text-[10px] font-bold text-primary tracking-wider uppercase mb-3 flex items-center gap-2">
                  <span className="material-symbols-outlined text-[16px]">leaderboard</span> 
                  REGIONAL LEADERBOARD
                </h5>
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between p-2 bg-surface-container-low rounded border border-outline-variant/30">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-primary">01</span>
                      <span className="text-xs font-medium text-on-surface">Alpha Ops</span>
                    </div>
                    <span className="text-secondary font-bold text-xs font-mono">99.4</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-2 hover:bg-surface-container transition-colors rounded border border-transparent">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-on-surface-variant">02</span>
                      <span className="text-xs font-medium text-on-surface">Capital Lead</span>
                    </div>
                    <span className="text-secondary font-bold text-xs font-mono">98.6</span>
                  </div>

                  <div className="flex items-center justify-between p-2 hover:bg-surface-container transition-colors rounded border border-transparent">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-on-surface-variant">03</span>
                      <span className="text-xs font-medium text-on-surface">Beta Team</span>
                    </div>
                    <span className="text-secondary font-bold text-xs font-mono">97.2</span>
                  </div>
                </div>
                <button 
                  onClick={() => onNavigate('DETAILED_PORTFOLIO_LOGS')}
                  className="w-full mt-3 py-1.5 text-[9px] font-bold text-primary border border-primary/20 rounded hover:bg-primary/5 transition-all uppercase tracking-widest cursor-pointer"
                >
                  View Full Rankings
                </button>
              </div>
            </div>
          </section>

          {/* Realtime Operations Stream & Event Simulator Dashboard Panel */}
          <section className="mb-6">
            <RealtimeDashboardPanel />
          </section>

          {/* Disaster Recovery & Automated Backups Panel */}
          <section className="mb-6 bg-white border border-outline-variant rounded-2xl p-5 shadow-sm">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
              <div>
                <h4 className="font-headline text-sm font-bold text-on-surface flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary">backup</span>
                  Disaster Recovery &amp; Automated Daily Backups Hub
                </h4>
                <p className="text-[11px] text-on-surface-variant font-medium mt-1 leading-normal">
                  Historical log archiving and disaster recovery snapshots. Compares active ledger metrics to guarantee 99.9% fault tolerance.
                </p>
              </div>
              <div className="flex gap-2 shrink-0">
                <button
                  onClick={fetchBackupStatus}
                  className="p-2 border border-outline-variant rounded-lg text-on-surface-variant hover:bg-surface-container transition-colors cursor-pointer flex items-center justify-center"
                  title="Refresh backup status"
                >
                  <span className="material-symbols-outlined text-sm">refresh</span>
                </button>
                <button
                  onClick={handleManualBackup}
                  disabled={isBackingUp}
                  className="bg-primary text-on-primary px-4 py-2 rounded-lg text-xs font-bold hover:opacity-90 transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <span className={`material-symbols-outlined text-sm ${isBackingUp ? 'animate-spin' : ''}`}>backup</span>
                  {isBackingUp ? "Creating Snapshot..." : "Run Manual Snapshot"}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Card 1: Scheduler Status */}
              <div className="p-4 rounded-xl border border-outline-variant/40 bg-surface-container-low flex flex-col justify-between">
                <div>
                  <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1">Backup Scheduler</p>
                  <p className="text-sm font-bold text-on-surface flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                    ACTIVE &amp; STANDBY
                  </p>
                </div>
                <p className="text-[10px] text-on-surface-variant mt-2 leading-normal">
                  Background cron process monitors the master database hourly. Automatically triggers a snapshot when a new calendar day is detected.
                </p>
              </div>

              {/* Card 2: Last Execution Metadata */}
              <div className="p-4 rounded-xl border border-outline-variant/40 bg-surface-container-low flex flex-col justify-between">
                <div>
                  <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1">Last Snapshot Run</p>
                  <p className="text-sm font-bold text-on-surface font-mono">
                    {backupStatus?.metadata?.lastSnapshotDate ? backupStatus.metadata.lastSnapshotDate : "Syncing..."}
                  </p>
                </div>
                <div className="mt-2 flex justify-between items-center text-[10px] text-on-surface-variant">
                  <span>Logs Saved: <b>{backupStatus?.metadata?.lastSnapshotLogsCount ?? 0}</b></span>
                  <span className="text-[#006d37] font-bold uppercase tracking-wide">● COMPLETED</span>
                </div>
              </div>

              {/* Card 3: Recovery Integrity */}
              <div className="p-4 rounded-xl border border-outline-variant/40 bg-surface-container-low flex flex-col justify-between">
                <div>
                  <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1">Disaster Recovery (DR)</p>
                  <p className="text-sm font-bold text-primary flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[16px]">verified_user</span>
                    99.9% CONSISTENT
                  </p>
                </div>
                <p className="text-[10px] text-on-surface-variant mt-2 leading-normal">
                  All backed up logs are verified with a SHA-256 equivalent parity check, ensuring complete data restoration capabilities.
                </p>
              </div>
            </div>

            {/* History Table / Records */}
            {backupStatus?.history && backupStatus.history.length > 0 && (
              <div className="mt-4 border-t border-outline-variant/30 pt-4">
                <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-2">Available Snapshot History</p>
                <div className="overflow-x-auto max-h-[150px] overflow-y-auto rounded-lg border border-outline-variant/50">
                  <table className="w-full text-left border-collapse">
                    <thead className="bg-[#eff4ff] text-[9px] font-bold text-on-surface-variant uppercase tracking-wider">
                      <tr>
                        <th className="px-3 py-2">Snapshot Date</th>
                        <th className="px-3 py-2">Timestamp</th>
                        <th className="px-3 py-2 text-right">Logs Count</th>
                        <th className="px-3 py-2 text-right">Integrity Parity</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-outline-variant/40 text-[10px] text-on-surface font-mono">
                      {backupStatus.history.map((item: any, idx: number) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="px-3 py-2 font-bold text-primary">{item.snapshotDate}</td>
                          <td className="px-3 py-2 text-on-surface-variant">{new Date(item.timestamp).toLocaleString()}</td>
                          <td className="px-3 py-2 text-right font-bold">{item.logsCount}</td>
                          <td className="px-3 py-2 text-right text-green-700 font-bold">100% SECURE</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </section>

          {/* Tables Row Grid */}
          <div className="grid grid-cols-12 gap-6 items-start">
            
            {/* Unified Reconciliation Report */}
            <section className="col-span-12 xl:col-span-8 bg-white border border-outline-variant rounded-lg flex flex-col overflow-hidden shadow-sm">
              <div className="px-5 py-4 border-b border-outline-variant bg-surface-container-lowest flex items-center justify-between sticky top-0 z-20">
                <div className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-primary">history</span>
                  <h3 className="text-base font-bold text-on-surface font-headline">Unified Reconciliation Report</h3>
                  <div className="flex items-center gap-1.5 bg-secondary/10 px-2 py-0.5 rounded border border-secondary/20 ml-2">
                    <span className="text-[9px] font-bold text-secondary uppercase tracking-wider flex items-center gap-1">
                      <span className="w-1.5 h-1.5 bg-secondary rounded-full animate-pulse-dot"></span>
                      Live Feed
                    </span>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <div className="flex items-center gap-1 px-3 py-1 bg-surface-container rounded text-xs text-on-surface-variant border border-outline-variant font-medium">
                    <span>Showing {filteredReconciliation.length > 0 ? (currentPage - 1) * rowsPerPage + 1 : 0}-{Math.min(currentPage * rowsPerPage, filteredReconciliation.length)} of {filteredReconciliation.length}</span>
                  </div>
                  <button className="bg-primary text-on-primary px-3 py-1 rounded text-xs font-semibold flex items-center gap-1 hover:opacity-90 transition-all cursor-pointer">
                    <span className="material-symbols-outlined text-[16px]">download</span> Export
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto max-h-[400px] overflow-y-auto">
                <table className="w-full border-collapse text-left">
                  <thead className="bg-[#eff4ff] border-b border-outline-variant sticky top-0 z-10">
                    <tr>
                      <th className="px-4 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-wider">User</th>
                      <th className="px-4 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-wider">Office</th>
                      <th className="px-4 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-wider">Team</th>
                      <th className="px-4 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-wider text-right">Points</th>
                      <th className="px-4 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-wider text-right">Errors</th>
                      <th className="px-4 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-wider text-right">Error %</th>
                      <th className="px-4 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-wider">Status</th>
                    </tr>
                  </thead>
                  
                  <tbody className="divide-y divide-outline-variant/60 border-l-4 border-primary">
                    {paginatedReconciliation.length > 0 ? (
                      paginatedReconciliation.map((row) => (
                        <tr key={row.id} onClick={() => handleRowClick(row)} className="hover:bg-surface-container/40 transition-colors cursor-pointer group title='Click to toggle status'">
                          <td className="px-4 py-3.5 text-xs font-bold text-on-surface font-sans">{row.user}</td>
                          <td className="px-4 py-3.5 text-xs text-on-surface-variant font-medium">{row.office}</td>
                          <td className="px-4 py-3.5 text-xs text-on-surface-variant">{row.team}</td>
                          <td className="px-4 py-3.5 text-xs font-mono text-right text-on-surface">{row.points.toFixed(1)}</td>
                          
                          <td className="px-4 py-3.5 text-xs font-mono text-right text-on-surface flex items-center justify-end gap-1">
                            {row.errors > 0 ? (
                              <span className="material-symbols-outlined text-error text-sm">warning</span>
                            ) : (
                              <span className="material-symbols-outlined text-secondary text-sm">check_circle</span>
                            )}
                            <span className={row.errors > 0 ? 'text-error font-bold' : 'text-secondary font-bold'}>
                              {row.errors.toFixed(1)}
                            </span>
                          </td>
                          
                          <td className={`px-4 py-3.5 text-xs font-mono text-right font-bold ${row.errorPercentage > 2 ? 'text-error' : 'text-secondary'}`}>
                            {row.errorPercentage.toFixed(1)}%
                          </td>
                          
                          <td className="px-4 py-3.5">
                            <span className={`inline-flex px-2 py-0.5 rounded-full text-[9px] font-bold border ${
                              row.status === 'MATCHED' 
                                ? 'bg-secondary/10 text-secondary border-secondary/20' 
                                : row.status === 'HIGH PRIORITY'
                                ? 'bg-error/10 text-error border-error/20'
                                : 'bg-tertiary-container/10 text-tertiary-container border-tertiary-container/20'
                            }`}>
                              {row.status}
                            </span>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={7} className="px-6 py-12 text-center text-on-surface-variant italic text-sm">
                          No records match current filtering parameters. Try adjusting filters.
                        </td>
                      </tr>
                    )}
                    <tr className="bg-[#eff4ff]/30">
                      <td className="py-6 text-center text-on-surface-variant italic text-xs" colSpan={7}>
                        Scroll down to load more analytical data... (Supports 1000+ entries)
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Table pagination footer */}
              <div className="px-5 py-3 border-t border-outline-variant bg-[#eff4ff] flex items-center justify-between sticky bottom-0">
                <div className="flex items-center gap-4 text-xs">
                  <span className="text-on-surface-variant">Page {currentPage} of {totalPages}</span>
                  <div className="flex gap-1">
                    <button 
                      onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                      disabled={currentPage === 1}
                      className="w-8 h-8 flex items-center justify-center rounded border border-outline-variant bg-white hover:bg-surface-container disabled:opacity-50 disabled:pointer-events-none transition-all cursor-pointer"
                    >
                      <span className="material-symbols-outlined text-[18px]">chevron_left</span>
                    </button>
                    {Array.from({ length: totalPages }, (_, i) => {
                      const pageNum = i + 1;
                      if (totalPages > 5 && Math.abs(pageNum - currentPage) > 1 && pageNum !== 1 && pageNum !== totalPages) {
                        if (pageNum === 2 || pageNum === totalPages - 1) {
                          return <span key={pageNum} className="px-1 text-on-surface-variant opacity-60">...</span>;
                        }
                        return null;
                      }
                      return (
                        <button
                          key={pageNum}
                          onClick={() => setCurrentPage(pageNum)}
                          className={`w-8 h-8 flex items-center justify-center rounded border ${
                            currentPage === pageNum
                              ? 'border-primary bg-primary text-on-primary font-bold text-xs'
                              : 'border-outline-variant bg-white hover:bg-surface-container text-xs cursor-pointer'
                          }`}
                        >
                          {pageNum}
                        </button>
                      );
                    })}
                    <button 
                      onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                      disabled={currentPage === totalPages}
                      className="w-8 h-8 flex items-center justify-center rounded border border-outline-variant bg-white hover:bg-surface-container disabled:opacity-50 disabled:pointer-events-none transition-all cursor-pointer"
                    >
                      <span className="material-symbols-outlined text-[18px]">chevron_right</span>
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs text-on-surface-variant">
                  <span>Rows per page:</span>
                  <select 
                    value={rowsPerPage}
                    onChange={(e) => setRowsPerPage(Number(e.target.value))}
                    className="border-outline-variant rounded py-1 pl-2 pr-8 bg-white focus:outline-none focus:ring-1 focus:ring-primary text-xs"
                  >
                    <option value={10}>10</option>
                    <option value={25}>25</option>
                    <option value={50}>50</option>
                    <option value={100}>100</option>
                    <option value={250}>250</option>
                  </select>
                </div>
              </div>
            </section>
            
            {/* Live IPA Report */}
            <section className="col-span-12 xl:col-span-4 bg-white border border-outline-variant rounded-lg flex flex-col h-[525px] overflow-hidden shadow-sm">
              <div className="px-5 py-4 border-b border-outline-variant bg-surface-container-lowest flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-secondary text-base">task_alt</span>
                    <h3 className="font-headline text-sm font-bold text-on-surface">Live IPA Report</h3>
                    <span className="text-[8px] font-bold text-secondary bg-secondary/10 px-1.5 py-0.5 rounded border border-secondary/20">EXCEL-FED</span>
                  </div>
                  <span className="text-[10px] font-bold bg-secondary text-on-secondary px-2 py-0.5 rounded-full">LIVE</span>
                </div>

                <div className="relative w-full">
                  <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant opacity-60 text-[18px]">search</span>
                  <input 
                    className="w-full bg-surface border border-outline-variant rounded-lg py-1.5 pl-10 pr-4 text-xs focus:outline-none focus:border-primary transition-all font-sans" 
                    placeholder="Filter task feed..." 
                    type="text"
                    value={ipaSearch}
                    onChange={(e) => setIpaSearch(e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="relative">
                    <select 
                      value={ipaTeam}
                      onChange={(e) => setIpaTeam(e.target.value)}
                      className="w-full bg-surface border border-outline-variant rounded-lg py-1.5 px-2 text-[10px] font-semibold text-on-surface focus:outline-none focus:border-primary appearance-none cursor-pointer"
                    >
                      <option>All Teams</option>
                      <option>Alpha</option>
                      <option>Havana</option>
                      <option>Dhaka</option>
                      <option>Delhi</option>
                    </select>
                    <span className="material-symbols-outlined absolute right-2 top-1/2 -translate-y-1/2 text-on-surface-variant pointer-events-none text-xs">expand_more</span>
                  </div>

                  <div className="relative">
                    <select 
                      value={ipaStatus}
                      onChange={(e) => setIpaStatus(e.target.value)}
                      className="w-full bg-surface border border-outline-variant rounded-lg py-1.5 px-2 text-[10px] font-semibold text-on-surface focus:outline-none focus:border-primary appearance-none cursor-pointer"
                    >
                      <option>All Status</option>
                      <option>Pending</option>
                      <option>Completed</option>
                      <option>Processing</option>
                    </select>
                    <span className="material-symbols-outlined absolute right-2 top-1/2 -translate-y-1/2 text-on-surface-variant pointer-events-none text-xs">expand_more</span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 mt-1 text-[10px] font-bold">
                  {(['1D', '1W', '1M', '1Y'] as const).map((day) => (
                    <button 
                      key={day}
                      onClick={() => setIpaDays(day)}
                      className={`flex-1 py-1.5 text-center border rounded transition-all cursor-pointer ${
                        ipaDays === day 
                          ? 'border-primary bg-primary text-on-primary' 
                          : 'border-outline-variant text-on-surface-variant hover:bg-surface-container'
                      }`}
                    >
                      {day === '1D' ? '1 Day' : day === '1W' ? '1 Week' : day === '1M' ? '1 Month' : '1 Year'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Feed table list */}
              <div className="flex-1 overflow-y-auto">
                <table className="w-full border-collapse">
                  <thead className="bg-[#eff4ff] sticky top-0 z-10 border-b border-outline-variant">
                    <tr>
                      <th className="px-4 py-2.5 text-[9px] font-bold text-on-surface-variant text-left uppercase tracking-wider">Name</th>
                      <th className="px-4 py-2.5 text-[9px] font-bold text-on-surface-variant text-left uppercase tracking-wider">Team</th>
                      <th className="px-4 py-2.5 text-[9px] font-bold text-on-surface-variant text-right uppercase tracking-wider">Tasks</th>
                    </tr>
                  </thead>
                  
                  <tbody className="divide-y divide-outline-variant/30 border-l-4 border-secondary">
                    {filteredIpaRecords.map((row) => (
                      <tr key={row.id} className="bg-secondary/5 hover:bg-secondary/10 transition-colors cursor-pointer">
                        <td className="px-4 py-2.5 font-mono text-xs text-primary font-bold">{row.name}</td>
                        <td className="px-4 py-2.5 font-mono text-on-surface-variant text-xs">{row.team}</td>
                        <td className="px-4 py-2.5 text-right font-mono text-xs font-bold text-on-surface">{row.tasks}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="p-3 bg-surface-container-low border-t border-outline-variant flex items-center justify-center">
                <button 
                  onClick={() => setIpaSearch('')}
                  className="text-primary font-bold text-[10px] tracking-wider uppercase hover:underline cursor-pointer"
                >
                  Load Next 50 Analysts
                </button>
              </div>
            </section>
          </div>

          {/* Stats Summary Footer */}
          <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-surface-container-low p-4 border border-outline-variant rounded shadow-sm">
              <p className="text-[10px] font-bold text-on-surface-variant mb-1 uppercase tracking-wider">SYNC RELIABILITY</p>
              <div className="flex items-end justify-between">
                <span className="text-lg font-bold text-primary font-mono">99.9%</span>
                <span className="text-secondary text-xs font-bold">↑ 0.2%</span>
              </div>
            </div>

            <div className="bg-surface-container-low p-4 border border-outline-variant rounded shadow-sm">
              <p className="text-[10px] font-bold text-on-surface-variant mb-1 uppercase tracking-wider">TOTAL DATA ROWS</p>
              <div className="flex items-end justify-between">
                <span className="text-lg font-bold text-primary font-mono">85,240</span>
                <span className="text-on-surface-variant text-xs opacity-60">Verified</span>
              </div>
            </div>

            <div className="bg-surface-container-low p-4 border border-outline-variant rounded shadow-sm">
              <p className="text-[10px] font-bold text-on-surface-variant mb-1 uppercase tracking-wider">HIGH ERRORS</p>
              <div className="flex items-end justify-between">
                <span className="text-lg font-bold text-error font-mono">435</span>
                <span className="text-error text-xs font-bold italic">High Priority</span>
              </div>
            </div>

            <div className="bg-surface-container-low p-4 border border-[#c1c7d2] rounded shadow-sm">
              <p className="text-[10px] font-bold text-[#42474f] mb-1 uppercase tracking-wider">LIVE RECONCILED</p>
              <div className="flex items-end justify-between">
                <span className="text-lg font-bold text-[#006d37] font-mono flex items-center gap-1.5">
                  <span className="inline-flex bg-[#006d37] text-white px-1.5 py-0.5 rounded-full text-[8px] font-bold">LIVE</span>
                  12,840
                </span>
                <span className="material-symbols-outlined text-[#006d37] text-base">trending_up</span>
              </div>
            </div>
          </div>

          {/* Google Sheets / Local File source config modal */}
          {isSourceModalOpen && (
            <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 transition-all animate-fade-in">
              <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full overflow-hidden border border-outline-variant flex flex-col transform transition-all animate-scale-up">
                {/* Header */}
                <div className="px-6 py-4 border-b border-outline-variant flex items-center justify-between bg-surface-container-low">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-primary text-[22px]">settings_input_component</span>
                    <h3 className="font-headline text-base font-bold text-on-surface">Manage IPA Data Source</h3>
                  </div>
                  <button 
                    onClick={() => setIsSourceModalOpen(false)}
                    className="w-8 h-8 rounded-full hover:bg-surface-container-high flex items-center justify-center text-on-surface-variant cursor-pointer transition-colors"
                  >
                    <span className="material-symbols-outlined text-[18px]">close</span>
                  </button>
                </div>

                {/* Content */}
                <div className="p-6 space-y-6 flex-1 max-h-[75vh] overflow-y-auto text-left">
                  {/* Option 1: Live Link Google Sheet */}
                  <div className="space-y-3 bg-primary/[0.02] border border-primary/20 rounded-lg p-4">
                    <div className="flex items-center gap-2.5">
                      <span className="material-symbols-outlined text-primary text-[20px]">sync</span>
                      <h4 className="text-xs font-bold text-primary uppercase tracking-wider">Option 1: Live Link Google Sheet (Recommended)</h4>
                    </div>
                    <p className="text-xs text-on-surface-variant leading-relaxed">
                      Link a Google Sheet URL. The app will <strong>automatically synchronize and update</strong> the IPA dashboard in real-time every 15 seconds. Anyone connected will see the changes instantly!
                    </p>

                    {/* Google Drive automatic integration */}
                    <div className="mt-3 p-3 bg-green-50/50 rounded-lg border border-green-200">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-green-600 animate-pulse"></span>
                          <span className="text-[10px] text-green-800 font-bold uppercase tracking-wider">Google Drive Integration</span>
                        </div>
                        {!needsAuth && googleUser && (
                          <button
                            type="button"
                            onClick={handleGoogleLogout}
                            className="text-[9px] text-red-600 font-bold hover:underline cursor-pointer"
                          >
                            Disconnect
                          </button>
                        )}
                      </div>

                      {needsAuth ? (
                        <div className="text-center py-2">
                          <p className="text-[11px] text-[#414752] font-semibold mb-2">
                            Log in with your Google account to select sheets directly from your Drive.
                          </p>
                          <button
                            type="button"
                            onClick={handleGoogleLogin}
                            className="inline-flex items-center gap-2 bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 font-bold text-xs px-3 py-1.5 rounded-lg shadow-sm cursor-pointer transition-colors"
                          >
                            <svg className="w-4 h-4" viewBox="0 0 24 24">
                              <path fill="#EA4335" d="M12 5.04c1.7 0 3.2.6 4.4 1.7l3.3-3.3C17.7 1.5 15 0 12 0 7.3 0 3.3 2.7 1.3 6.6L4.8 9.3C5.6 6.8 8.6 5.04 12 5.04z" />
                              <path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.4h6.5c-.3 1.5-1.1 2.8-2.3 3.6l3.5 2.7c2-1.9 3.8-4.7 3.8-8.4z" />
                              <path fill="#FBBC05" d="M4.8 14.7c-.2-.6-.3-1.3-.3-2.7s.1-2.1.3-2.7L1.3 6.6c-.8 1.6-1.3 3.5-1.3 5.4s.5 3.8 1.3 5.4l3.5-2.7z" />
                              <path fill="#34A853" d="M12 24c3.2 0 6-1.1 8-2.9l-3.5-2.7c-1.1.7-2.5 1.2-4.5 1.2-3.4 0-6.4-1.8-7.2-4.3L1.3 18c2 3.9 6 6 10.7 6z" />
                            </svg>
                            <span>Link Google Drive Sheets</span>
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-[11px] font-semibold text-[#191c20]">
                            <span>📁 Select a Sheet from your Drive:</span>
                            <span className="text-[10px] text-slate-500 font-mono">
                              ({googleUser?.email})
                            </span>
                          </div>

                          {loadingDriveSheets ? (
                            <div className="flex items-center justify-center gap-2 py-4">
                              <div className="w-4 h-4 border-2 border-[#006d37] border-t-transparent rounded-full animate-spin"></div>
                              <span className="text-[10px] text-[#414752] font-semibold">Listing files...</span>
                            </div>
                          ) : driveError ? (
                            <p className="text-[10px] text-red-600 font-semibold text-center">{driveError}</p>
                          ) : driveSheets.length === 0 ? (
                            <p className="text-[10px] text-slate-500 italic text-center py-2">No Google Sheets found in your Drive.</p>
                          ) : (
                            <div className="max-h-40 overflow-y-auto border border-green-200 rounded-lg bg-white divide-y divide-slate-100 shadow-inner scrollbar-thin">
                              {driveSheets.map((file) => {
                                const isLinked = googleSheetUrl.includes(file.id);
                                return (
                                  <div key={file.id} className="p-2 flex items-center justify-between hover:bg-green-50/20 transition-colors">
                                    <div className="flex-1 min-w-0 pr-2">
                                      <p className="text-[11px] font-bold text-[#191c20] truncate">{file.name}</p>
                                      <p className="text-[8px] text-slate-400 font-medium">
                                        Modified: {new Date(file.modifiedTime).toLocaleDateString()}
                                      </p>
                                    </div>
                                    <button
                                      type="button"
                                      disabled={isSavingSheet}
                                      onClick={() => handleSaveSelectedDriveSheet(file.id)}
                                      className={`px-2.5 py-1 rounded text-[10px] font-bold transition-all cursor-pointer ${
                                        isLinked
                                          ? 'bg-green-100 text-green-700 border border-green-300'
                                          : 'bg-[#006d37] hover:bg-[#005a2e] text-white'
                                      }`}
                                    >
                                      {isLinked ? 'Linked ✓' : 'Link & Sync'}
                                    </button>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                    
                    <div className="space-y-2 mt-2">
                      <label className="block text-[10px] font-bold text-on-surface uppercase tracking-wider">Or Enter URL Manually</label>
                      <input 
                        type="text"
                        placeholder="https://docs.google.com/spreadsheets/d/.../edit?usp=sharing"
                        className="w-full bg-white border border-outline-variant rounded px-3 py-2 text-xs focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all font-sans"
                        value={sheetInputUrl}
                        onChange={(e) => setSheetInputUrl(e.target.value)}
                      />
                      <p className="text-[10px] text-on-surface-variant leading-relaxed italic opacity-80">
                        Make sure the Google Sheet link has <strong>Viewer access (Anyone with the link can view)</strong>.
                      </p>
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      {googleSheetUrl && (
                        <button
                          onClick={async () => {
                            setSheetInputUrl('');
                            setIsSavingSheet(true);
                            try {
                              const res = await fetch('/api/settings/google-sheet', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ url: '' })
                              });
                              const data = await res.json();
                              if (data.success) {
                                setGoogleSheetUrl('');
                                alert("Google Sheet unlinked successfully.");
                                setIsSourceModalOpen(false);
                              }
                            } catch (err) {
                              console.error("Unlink error:", err);
                            } finally {
                              setIsSavingSheet(false);
                            }
                          }}
                          className="px-3 py-1.5 text-xs font-semibold text-error hover:bg-error/10 border border-error/20 rounded transition-colors cursor-pointer"
                        >
                          Unlink Sheet
                        </button>
                      )}
                      <button
                        onClick={handleSaveGoogleSheet}
                        disabled={isSavingSheet}
                        className="bg-primary text-on-primary px-4 py-1.5 rounded text-xs font-bold hover:opacity-95 transition-all disabled:opacity-50 cursor-pointer"
                      >
                        {isSavingSheet ? 'Connecting...' : googleSheetUrl ? 'Update Link & Sync' : 'Link & Sync'}
                      </button>
                    </div>
                  </div>

                  {/* Divider */}
                  <div className="relative flex py-2 items-center">
                    <div className="flex-grow border-t border-outline-variant"></div>
                    <span className="flex-shrink mx-4 text-[10px] text-on-surface-variant font-bold uppercase tracking-widest">OR</span>
                    <div className="flex-grow border-t border-outline-variant"></div>
                  </div>

                  {/* Option 2: Upload Excel / CSV file */}
                  <div className="space-y-3 bg-secondary/[0.02] border border-secondary/20 rounded-lg p-4">
                    <div className="flex items-center gap-2.5">
                      <span className="material-symbols-outlined text-secondary text-[20px]">upload_file</span>
                      <h4 className="text-xs font-bold text-secondary uppercase tracking-wider">Option 2: One-Time Excel/CSV Upload</h4>
                    </div>
                    <p className="text-xs text-on-surface-variant leading-relaxed">
                      Upload a local Microsoft Excel (<code>.xlsx</code>, <code>.xls</code>) or Comma Separated Values (<code>.csv</code>) file to update the database state instantly.
                    </p>

                    <div className="pt-2 flex justify-center">
                      <label className="flex items-center justify-center gap-2.5 px-6 py-4 w-full border-2 border-dashed border-secondary/30 rounded-lg bg-white hover:bg-surface-container transition-all cursor-pointer text-center flex-col">
                        <span className="material-symbols-outlined text-[32px] text-secondary">cloud_upload</span>
                        <div className="space-y-0.5">
                          <p className="text-xs font-bold text-on-surface">Click to upload spreadsheet file</p>
                          <p className="text-[10px] text-on-surface-variant">Supports .xlsx, .xls, .csv</p>
                        </div>
                        <input 
                          type="file" 
                          accept=".csv,.xlsx,.xls" 
                          className="hidden" 
                          onChange={(e) => {
                            handleFileUpload(e);
                            setIsSourceModalOpen(false);
                          }} 
                        />
                      </label>
                    </div>
                  </div>
                </div>

                {/* Footer */}
                <div className="px-6 py-4 border-t border-outline-variant flex justify-end bg-surface-container-low">
                  <button 
                    onClick={() => setIsSourceModalOpen(false)}
                    className="px-4 py-1.5 text-xs font-bold border border-outline-variant rounded hover:bg-surface-container cursor-pointer transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          )}

        </main>
      </div>

      {/* Floating real-time toast notifications stack */}
      <FloatingToastStack />
    </div>
  );
}
