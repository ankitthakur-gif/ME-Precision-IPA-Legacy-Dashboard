import React, { useState, useRef, useEffect } from 'react';
import * as XLSX from 'xlsx';
import { collection, doc, getDocs, writeBatch, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { 
  ValidationError, 
  ValidationPreset, 
  TargetSchema, 
  DatasetVersion 
} from '../types';

interface ExcelUploadTabProps {
  userEmail: string;
  userName: string;
  userPosition: string;
  hasWriteAccess: boolean;
  onNavigate: (view: any) => void;
  onUploadSuccess: () => void;
}

const VALIDATION_PRESETS: ValidationPreset[] = [
  {
    id: 'invoice',
    name: 'Invoice Manager Preset',
    columns: ['invoice_number', 'vendor', 'date', 'amount'],
    description: 'Validates standard accounts payable billing sheets.'
  },
  {
    id: 'reconciliation',
    name: 'Live Sync Preset',
    columns: ['record_id', 'amount', 'status', 'analyst_id'],
    description: 'Checks for portfolio synchronization & auditing.'
  },
  {
    id: 'gmail',
    name: 'Gmail Metadata Preset',
    columns: ['message_id', 'sender', 'subject', 'received_date'],
    description: 'Ensures email transmission logs are structured.'
  },
  {
    id: 'custom',
    name: 'Custom Defined Columns',
    columns: [],
    description: 'Specify your own comma-separated required headers.'
  }
];

const TARGET_SCHEMAS: Record<string, TargetSchema> = {
  logs: {
    name: 'Portfolio Logs (/logs)',
    collection: 'logs',
    fields: [
      { key: 'id', label: 'ID / Invoice Number', type: 'string', required: true, description: 'Unique invoice identifier' },
      { key: 'date', label: 'Date', type: 'string', required: true, description: 'E.g. 2026-07-10' },
      { key: 'analystName', label: 'Analyst Name', type: 'string', required: true, description: 'Name of the analyst' },
      { key: 'vendorName', label: 'Vendor Name', type: 'string', required: true, description: 'Name of the vendor' },
      { key: 'taskType', label: 'Task Type', type: 'string', required: true, description: 'E.g. Food Invoice, Utility' },
      { key: 'status', label: 'Status', type: 'enum', required: true, enumValues: ['MATCHING', 'ALERT', 'PENDING'], description: 'Must be MATCHING, ALERT, or PENDING' },
      { key: 'accuracy', label: 'Accuracy (%)', type: 'number', required: true, description: 'Numerical accuracy score (0-100)' },
      { key: 'ir', label: 'IR Count (Optional)', type: 'number', required: false, description: 'Optional invoice count' },
      { key: 'reco', label: 'Reco Count (Optional)', type: 'number', required: false, description: 'Optional reconciliation count' },
      { key: 'time', label: 'Processing Time (Optional)', type: 'string', required: false, description: 'Optional processing time' },
      { key: 'errors', label: 'Errors Count (Optional)', type: 'number', required: false, description: 'Optional error count' }
    ]
  },
  analysts: {
    name: 'Analyst Productivity Logs (/analysts)',
    collection: 'analysts',
    fields: [
      { key: 'id', label: 'Analyst ID', type: 'string', required: true, description: 'Unique analyst identifier' },
      { key: 'name', label: 'Analyst Name', type: 'string', required: true, description: 'Full name' },
      { key: 'team', label: 'Team Name', type: 'string', required: true, description: 'E.g. Alpha, Beta' },
      { key: 'tasks', label: 'Tasks Completed', type: 'number', required: true, description: 'Completed task volume' }
    ]
  },
  teams: {
    name: 'Team Performance Summary (/teams)',
    collection: 'teams',
    fields: [
      { key: 'teamName', label: 'Team Name', type: 'string', required: true, description: 'E.g. Team Alpha' },
      { key: 'efficiency', label: 'Efficiency (%)', type: 'number', required: true, description: 'Efficiency percentage' },
      { key: 'errorRate', label: 'Error Rate (%)', type: 'number', required: true, description: 'Error rate percentage' },
      { key: 'output', label: 'Output Description', type: 'string', required: true, description: 'E.g. 500 tasks, high performance' },
      { key: 'lead', label: 'Team Lead Name', type: 'string', required: true, description: 'Full name' }
    ]
  },
  invoices: {
    name: 'Invoices (/invoices)',
    collection: 'invoices',
    fields: [
      { key: 'id', label: 'ID', type: 'string', required: true, description: 'E.g. inv-1' },
      { key: 'invoiceNumber', label: 'Invoice Number', type: 'string', required: true, description: 'E.g. INV-2026-001' },
      { key: 'vendorName', label: 'Vendor Name', type: 'string', required: true, description: 'E.g. US Foods' },
      { key: 'amount', label: 'Amount', type: 'number', required: true, description: 'Invoice total amount' },
      { key: 'status', label: 'Status', type: 'enum', required: true, enumValues: ['MATCHED', 'ALERT', 'PENDING'], description: 'Must be MATCHED, ALERT, or PENDING' },
      { key: 'date', label: 'Date', type: 'string', required: true, description: 'E.g. 2026-07-10' },
      { key: 'analystName', label: 'Analyst Name', type: 'string', required: true, description: 'Analyst name' },
      { key: 'accuracy', label: 'Accuracy (%)', type: 'number', required: true, description: 'Accuracy percentage' }
    ]
  },
  vendors: {
    name: 'Vendors (/vendors)',
    collection: 'vendors',
    fields: [
      { key: 'id', label: 'Vendor ID', type: 'string', required: true, description: 'Unique vendor ID' },
      { key: 'name', label: 'Vendor Name', type: 'string', required: true, description: 'Full vendor name' }
    ]
  }
};

export default function ExcelUploadTab({
  userEmail,
  userName,
  userPosition,
  hasWriteAccess,
  onNavigate,
  onUploadSuccess
}: ExcelUploadTabProps) {
  const [dragActive, setDragActive] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // File details
  const [fileName, setFileName] = useState<string | null>(null);
  const [fileSize, setFileSize] = useState<string | null>(null);
  const [workbook, setWorkbook] = useState<XLSX.WorkBook | null>(null);
  const [sheetNames, setSheetNames] = useState<string[]>([]);
  const [selectedSheet, setSelectedSheet] = useState<string>('');
  const [parsedData, setParsedData] = useState<any[]>([]);
  
  // Preview and Validation states
  const [viewMode, setViewMode] = useState<'table' | 'json'>('table');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  
  const [activePresetId, setActivePresetId] = useState<string>('invoice');
  const [customColumnsText, setCustomColumnsText] = useState<string>('id, name, total, email');
  const [validationErrors, setValidationErrors] = useState<ValidationError[]>([]);
  const [columnStatus, setColumnStatus] = useState<Record<string, 'present' | 'missing'>>({});
  const [validationRun, setValidationRun] = useState(false);
  
  // Target mappings
  const [targetCollection, setTargetCollection] = useState<string>('logs');
  const [fieldMappings, setFieldMappings] = useState<Record<string, string>>({});
  const [uniqueKeyField, setUniqueKeyField] = useState<string>('id');
  
  // Deduplication & Commits
  const [duplicateCheckState, setDuplicateCheckState] = useState<'idle' | 'checking' | 'checked' | 'saving' | 'saved'>('idle');
  const [duplicateRowsList, setDuplicateRowsList] = useState<any[]>([]);
  const [newRowsList, setNewRowsList] = useState<any[]>([]);
  const [saveConflictOption, setSaveConflictOption] = useState<'skip' | 'overwrite'>('skip');
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [uploadResult, setUploadResult] = useState<{ writtenCount: number; duplicateCount: number } | null>(null);
  const [firestoreError, setFirestoreError] = useState<string | null>(null);
  
  // Telemetry metrics for background processing
  const [processingStats, setProcessingStats] = useState({
    rowsPerSec: 0,
    elapsedSeconds: 0,
    secondsRemaining: 0
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-align targets with validation presets
  useEffect(() => {
    if (activePresetId === 'invoice') {
      setTargetCollection('logs');
    } else if (activePresetId === 'reconciliation') {
      setTargetCollection('analysts');
    }
  }, [activePresetId]);

  // Handle header synonym mapping automatically
  useEffect(() => {
    if (parsedData.length === 0) return;
    const excelHeaders = Object.keys(parsedData[0]);
    const newMappings: Record<string, string> = {};
    const schema = TARGET_SCHEMAS[targetCollection];
    
    if (schema) {
      schema.fields.forEach(field => {
        const matchedHeader = excelHeaders.find(h => {
          const hLower = h.toLowerCase().trim();
          const fLower = field.key.toLowerCase().trim();
          if (hLower === fLower) return true;
          if (hLower.includes(fLower) || fLower.includes(hLower)) return true;
          
          // Synonyms mapping helper
          if (field.key === 'id' && (hLower.includes('number') || hLower.includes('key') || hLower.includes('uid') || hLower.includes('code'))) return true;
          if (field.key === 'analystName' && (hLower.includes('analyst') || hLower.includes('user') || hLower.includes('person'))) return true;
          if (field.key === 'vendorName' && (hLower.includes('vendor') || hLower.includes('client') || hLower.includes('merchant'))) return true;
          if (field.key === 'taskType' && (hLower.includes('type') || hLower.includes('category') || hLower.includes('task'))) return true;
          if (field.key === 'teamName' && (hLower.includes('team') || hLower.includes('dept') || hLower.includes('department'))) return true;
          return false;
        });
        
        if (matchedHeader) {
          newMappings[field.key] = matchedHeader;
        } else {
          const exactFallback = excelHeaders.find(h => h.trim() === field.key);
          newMappings[field.key] = exactFallback || '';
        }
      });
      
      setFieldMappings(newMappings);
      setUniqueKeyField(targetCollection === 'teams' ? 'teamName' : 'id');
    }
    
    setDuplicateCheckState('idle');
    setUploadResult(null);
    setFirestoreError(null);
  }, [parsedData, targetCollection]);

  // Run validation on sheet
  const runValidation = (data: any[]) => {
    if (data.length === 0) {
      setValidationErrors([]);
      setColumnStatus({});
      setValidationRun(false);
      return;
    }

    const required = getRequiredColumns();
    const headers = Object.keys(data[0]).map(h => h.trim().toLowerCase());
    
    const status: Record<string, 'present' | 'missing'> = {};
    const missingColumns: string[] = [];
    
    required.forEach(reqCol => {
      const matched = headers.some(h => h === reqCol || h.includes(reqCol));
      if (matched) {
        status[reqCol] = 'present';
      } else {
        status[reqCol] = 'missing';
        missingColumns.push(reqCol);
      }
    });

    setColumnStatus(status);
    const errorsList: ValidationError[] = [];

    if (missingColumns.length > 0) {
      errorsList.push({
        severity: 'error',
        message: `Workbook headers are missing required column(s): ${missingColumns.join(', ')}`
      });
    }

    const presentRequired = required.filter(col => !missingColumns.includes(col));
    data.slice(0, 500).forEach((row, idx) => { // limit deep validations to 500 rows for performance
      presentRequired.forEach(reqCol => {
        const rowKeys = Object.keys(row);
        const actualKey = rowKeys.find(k => k.trim().toLowerCase() === reqCol || k.trim().toLowerCase().includes(reqCol));
        const value = actualKey ? row[actualKey] : undefined;
        
        if (value === undefined || value === null || String(value).trim() === '') {
          errorsList.push({
            row: idx + 1,
            column: reqCol,
            message: `Row ${idx + 1}: Required field "${reqCol}" is empty.`,
            severity: 'warning'
          });
        } else {
          const valStr = String(value).trim();
          if (reqCol.includes('amount') || reqCol.includes('total')) {
            const numeric = Number(valStr.replace(/[^0-9.-]/g, ''));
            if (isNaN(numeric)) {
              errorsList.push({
                row: idx + 1,
                column: reqCol,
                message: `Row ${idx + 1}: "${reqCol}" is non-numeric: "${valStr}".`,
                severity: 'warning'
              });
            }
          }
        }
      });
    });

    setValidationErrors(errorsList);
    setValidationRun(true);
  };

  useEffect(() => {
    if (parsedData.length > 0) {
      runValidation(parsedData);
    }
  }, [parsedData, activePresetId, customColumnsText]);

  const getRequiredColumns = (): string[] => {
    if (activePresetId === 'custom') {
      return customColumnsText.split(',').map(col => col.trim().toLowerCase()).filter(col => col.length > 0);
    }
    const preset = VALIDATION_PRESETS.find(p => p.id === activePresetId);
    return preset ? preset.columns : [];
  };

  const getKeys = () => {
    if (parsedData.length === 0) return [];
    const keysSet = new Set<string>();
    parsedData.slice(0, 5).forEach(row => {
      Object.keys(row).forEach(k => keysSet.add(k));
    });
    return Array.from(keysSet);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(e.type === "dragenter" || e.type === "dragover");
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const processFile = (file: File) => {
    const isExcel = file.name.endsWith('.xlsx') || file.name.endsWith('.xls') || file.name.endsWith('.csv') || file.name.endsWith('.ods');
    if (!isExcel) {
      setError("Unsupported file format. Please upload an Excel (.xlsx, .xls) or CSV (.csv) file.");
      return;
    }

    setLoading(true);
    setError(null);
    setFileName(file.name);
    setFileSize(formatBytes(file.size));

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const arrayBuffer = e.target?.result as ArrayBuffer;
        const data = new Uint8Array(arrayBuffer);
        let wb = XLSX.read(data, { type: 'array' });
        
        setWorkbook(wb);
        setSheetNames(wb.SheetNames);
        
        if (wb.SheetNames.length > 0) {
          const firstSheet = wb.SheetNames[0];
          setSelectedSheet(firstSheet);
          const worksheet = wb.Sheets[firstSheet];
          const json = XLSX.utils.sheet_to_json<any>(worksheet, { defval: "" });
          setParsedData(json);
        }
        setLoading(false);
      } catch (err: any) {
        console.error("Error parsing Excel:", err);
        setError("Error parsing spreadsheet file. Ensure it is not corrupted.");
        setLoading(false);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleSheetChange = (sheetName: string) => {
    if (!workbook) return;
    setSelectedSheet(sheetName);
    setCurrentPage(1);
    try {
      const worksheet = workbook.Sheets[sheetName];
      const json = XLSX.utils.sheet_to_json<any>(worksheet, { defval: "" });
      setParsedData(json);
    } catch (err) {
      setError("Failed to read the selected worksheet.");
    }
  };

  const checkForDuplicates = async () => {
    if (parsedData.length === 0) return;
    setDuplicateCheckState('checking');
    setFirestoreError(null);
    
    try {
      const colRef = collection(db, targetCollection);
      const snapshot = await getDocs(colRef);
      const existingIds = new Set<string>();
      
      snapshot.forEach(doc => {
        existingIds.add(doc.id);
      });
      
      const duplicates: any[] = [];
      const news: any[] = [];
      
      parsedData.forEach((row, index) => {
        const excelHeader = fieldMappings[uniqueKeyField];
        const rawValue = excelHeader ? row[excelHeader] : undefined;
        let docId = rawValue !== undefined && rawValue !== null && rawValue !== ''
          ? String(rawValue).trim()
          : `row-${index + 1}`;
          
        const sanitizedId = docId.replace(/[^a-zA-Z0-9_\-]/g, '_');
        
        if (existingIds.has(sanitizedId)) {
          duplicates.push({ ...row, __sanitizedId: sanitizedId, __originalIndex: index });
        } else {
          news.push({ ...row, __sanitizedId: sanitizedId, __originalIndex: index });
        }
      });
      
      setDuplicateRowsList(duplicates);
      setNewRowsList(news);
      setDuplicateCheckState('checked');
    } catch (err: any) {
      console.error("Failed to check duplicates:", err);
      setFirestoreError(`Deduplication Check Failed: ${err.message || 'Permission denied.'}`);
      setDuplicateCheckState('idle');
    }
  };

  // Robust background uploader with progress speed and remaining timer (Supports 100,000+ rows)
  const saveToFirestore = async () => {
    if (!hasWriteAccess) return;
    if (parsedData.length === 0) return;
    setDuplicateCheckState('saving');
    setUploadProgress(0);
    setFirestoreError(null);
    
    const startTime = Date.now();
    const rowsToSave = saveConflictOption === 'skip' ? newRowsList : [...newRowsList, ...duplicateRowsList];
    const totalToSave = rowsToSave.length;
    
    const datasetId = 'dataset-' + Date.now();
    
    try {
      // 1. Create a Dataset Version registry
      const datasetVersionDoc: DatasetVersion = {
        id: datasetId,
        fileName: fileName || 'spreadsheet_upload.xlsx',
        fileSize: fileSize || 'Unknown size',
        uploadedBy: userEmail || userName || 'system',
        uploadDate: new Date().toISOString(),
        totalRecords: totalToSave,
        sheetName: selectedSheet || 'Sheet1',
        targetCollection: targetCollection,
        status: 'ACTIVE',
        schemaKeys: getKeys()
      };
      
      await setDoc(doc(db, 'excel_datasets', datasetId), datasetVersionDoc);

      // 2. Soft-archive other datasets mapped to this collection
      const otherDatasetsSnap = await getDocs(collection(db, 'excel_datasets'));
      const archiveBatch = writeBatch(db);
      otherDatasetsSnap.forEach(dDoc => {
        const data = dDoc.data();
        if (data.targetCollection === targetCollection && data.id !== datasetId && data.status === 'ACTIVE') {
          archiveBatch.update(dDoc.ref, { status: 'ARCHIVED' });
        }
      });
      await archiveBatch.commit();

      // 3. Chunked saving with recursive asynchronous intervals (background process)
      const batchSize = 100;
      let successCount = 0;
      
      for (let i = 0; i < totalToSave; i += batchSize) {
        const chunk = rowsToSave.slice(i, i + batchSize);
        const batch = writeBatch(db);
        
        chunk.forEach((row, idx) => {
          const globalIdx = i + idx;
          const docData: Record<string, any> = {};
          const schema = TARGET_SCHEMAS[targetCollection];
          
          if (schema) {
            schema.fields.forEach(field => {
              const excelHeader = fieldMappings[field.key];
              const rawValue = excelHeader ? row[excelHeader] : undefined;
              
              if (rawValue === undefined || rawValue === null || rawValue === '') {
                if (field.required) {
                  if (field.type === 'number') docData[field.key] = 0;
                  else if (field.type === 'enum' && field.enumValues) docData[field.key] = field.enumValues[0];
                  else docData[field.key] = "N/A";
                }
              } else {
                if (field.type === 'number') {
                  const cleanedNum = Number(String(rawValue).replace(/[^0-9.-]/g, ''));
                  docData[field.key] = isNaN(cleanedNum) ? 0 : cleanedNum;
                } else if (field.type === 'enum' && field.enumValues) {
                  const valUpper = String(rawValue).trim().toUpperCase();
                  docData[field.key] = field.enumValues.includes(valUpper) ? valUpper : field.enumValues[0];
                } else {
                  docData[field.key] = String(rawValue).substring(0, 128).trim();
                }
              }
            });
          } else {
            Object.keys(row).forEach(k => {
              if (!k.startsWith('__')) docData[k] = row[k];
            });
          }
          
          const excelHeader = fieldMappings[uniqueKeyField];
          const rawIdValue = excelHeader ? row[excelHeader] : undefined;
          const docId = rawIdValue !== undefined && rawIdValue !== null && rawIdValue !== ''
            ? String(rawIdValue).trim()
            : `row-${globalIdx + 1}`;
            
          const sanitizedId = docId.replace(/[^a-zA-Z0-9_\-]/g, '_');
          
          if (schema) {
            docData[uniqueKeyField] = sanitizedId;
          } else {
            docData['id'] = sanitizedId;
          }

          // Active database collection document
          const docRef = doc(collection(db, targetCollection), sanitizedId);
          batch.set(docRef, docData);
          
          // History records document for rollbacks
          const recordDocId = `${datasetId}_row_${globalIdx}`;
          const historyDocRef = doc(collection(db, 'excel_datasets_records'), recordDocId);
          batch.set(historyDocRef, {
            id: recordDocId,
            datasetId,
            targetCollection,
            data: docData,
            recordId: sanitizedId,
            createdAt: new Date().toISOString()
          });
        });
        
        await batch.commit();
        successCount += chunk.length;
        
        // Progress speed estimation
        const elapsedMs = Date.now() - startTime;
        const rowsPerSec = (successCount / (elapsedMs / 1000)) || 1;
        const percent = Math.round((successCount / totalToSave) * 100);
        const remaining = totalToSave - successCount;
        const remainingSecs = Math.round(remaining / rowsPerSec);
        
        setUploadProgress(percent);
        setProcessingStats({
          rowsPerSec: Math.round(rowsPerSec),
          elapsedSeconds: Math.round(elapsedMs / 1000),
          secondsRemaining: remainingSecs
        });
        
        // Relinquish control briefly to avoid blocking main renderer UI
        await new Promise(resolve => setTimeout(resolve, 15));
      }
      
      setUploadResult({
        writtenCount: successCount,
        duplicateCount: duplicateRowsList.length
      });
      setDuplicateCheckState('saved');
      onUploadSuccess();
    } catch (err: any) {
      console.error("Batch save failed:", err);
      setFirestoreError(`Batch Save Failed: ${err.message || 'Permission denied.'}`);
      setDuplicateCheckState('checked');
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const filteredData = parsedData.filter(row => {
    if (!searchQuery) return true;
    return Object.values(row).some(v => String(v).toLowerCase().includes(searchQuery.toLowerCase()));
  });

  const totalPages = Math.ceil(filteredData.length / rowsPerPage) || 1;
  const paginatedData = filteredData.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage);

  return (
    <div className="space-y-6">
      {/* ROLE GATED ACCESS WARNING */}
      {!hasWriteAccess && (
        <div className="p-4 bg-amber-500/10 border border-amber-500/20 text-amber-700 dark:text-amber-400 rounded-2xl text-xs font-semibold flex items-center gap-3">
          <span className="material-symbols-outlined text-[20px] text-amber-500">lock</span>
          <div>
            <p className="font-extrabold text-[13px]">Analyst Mode (Read-Only)</p>
            <p className="font-medium mt-0.5">Uploading spreadsheets, executing dataset replacements, and running rollback actions are restricted to Admins and Managers.</p>
          </div>
        </div>
      )}

      {/* 1. Configure Required Column Rules */}
      <div className="bg-white dark:bg-[#121620] border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-6 shadow-sm space-y-4">
        <div>
          <h3 className="text-sm font-black text-slate-950 dark:text-white tracking-tight">
            1. Configure Required Column Rules
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Select a standard MarginEdge metadata schema or input your custom required headers to run active checks.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {VALIDATION_PRESETS.map((preset) => (
            <button
              key={preset.id}
              onClick={() => setActivePresetId(preset.id)}
              className={`p-4 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between h-28 ${
                activePresetId === preset.id
                  ? 'border-primary bg-primary/[0.03] text-primary shadow-sm'
                  : 'border-slate-200 dark:border-slate-800 bg-transparent hover:bg-slate-50 dark:hover:bg-slate-800/35 text-slate-700 dark:text-slate-300'
              }`}
            >
              <div>
                <p className="text-xs font-black truncate">{preset.name}</p>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 leading-normal line-clamp-2">
                  {preset.description}
                </p>
              </div>
              <div className="text-[9px] font-mono font-bold uppercase truncate tracking-wider opacity-90">
                {preset.id === 'custom' ? 'Custom fields' : `${preset.columns.length} columns`}
              </div>
            </button>
          ))}
        </div>

        {activePresetId === 'custom' && (
          <div className="bg-slate-50 dark:bg-slate-800/20 p-4 rounded-xl border border-slate-200/60 dark:border-slate-800 space-y-2">
            <label className="block text-[10px] font-black uppercase text-slate-500 dark:text-slate-400 tracking-wider">
              Custom Comma-Separated Required Headers:
            </label>
            <input
              type="text"
              value={customColumnsText}
              onChange={(e) => setCustomColumnsText(e.target.value)}
              placeholder="e.g. id, first_name, email, salary"
              className="w-full bg-white dark:bg-[#11141e] border border-slate-200 dark:border-slate-800 rounded-lg py-2 px-3 text-xs font-mono outline-none focus:border-primary/50"
            />
          </div>
        )}
      </div>

      {/* TWO PANEL WORKSPACE */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT PANEL */}
        <div className="lg:col-span-4 space-y-5">
          <div className="bg-white dark:bg-[#121620] border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 shadow-sm space-y-4">
            <h3 className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-widest flex items-center gap-2">
              <span className="material-symbols-outlined text-primary text-base">cloud_upload</span>
              Upload Spreadsheet
            </h3>

            <div
              onDragEnter={handleDrag}
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
              onClick={() => hasWriteAccess && fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-6 text-center flex flex-col items-center justify-center gap-3 transition-all relative select-none ${
                !hasWriteAccess 
                  ? "border-slate-200 dark:border-slate-800 bg-slate-50/50 cursor-not-allowed"
                  : dragActive 
                    ? "border-primary bg-primary/5 cursor-pointer" 
                    : "border-slate-300 dark:border-slate-800 hover:border-primary/50 hover:bg-slate-50/50 cursor-pointer"
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                disabled={!hasWriteAccess}
                className="hidden"
                accept=".xlsx, .xls, .csv, .ods"
                onChange={handleFileChange}
              />

              <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800/60 flex items-center justify-center text-slate-500">
                <span className="material-symbols-outlined text-[28px]">{hasWriteAccess ? 'cloud_upload' : 'lock'}</span>
              </div>

              <div className="space-y-1">
                <p className="text-xs font-extrabold text-slate-800 dark:text-slate-200">
                  {hasWriteAccess ? 'Drag & Drop file here' : 'Uploader is Locked'}
                </p>
                <p className="text-[10px] text-slate-500">
                  {hasWriteAccess ? 'or browse files on your computer' : 'Only Admins & Managers can upload files'}
                </p>
              </div>
            </div>

            {error && (
              <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-600 rounded-xl text-xs font-medium flex items-start gap-2">
                <span className="material-symbols-outlined text-sm shrink-0">error</span>
                <p>{error}</p>
              </div>
            )}

            {fileName && (
              <div className="p-3 bg-slate-50 dark:bg-[#161b29] border border-slate-100 dark:border-slate-800/50 rounded-xl space-y-2.5">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-green-500/10 text-green-600 flex items-center justify-center">
                    <span className="material-symbols-outlined text-[20px]">description</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-extrabold truncate text-slate-800 dark:text-slate-200">{fileName}</p>
                    <p className="text-[10px] text-slate-500 font-bold">{fileSize}</p>
                  </div>
                </div>

                {sheetNames.length > 1 && (
                  <div className="space-y-1 pt-1.5 border-t border-slate-200/50">
                    <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest">
                      Active Worksheet
                    </label>
                    <select
                      value={selectedSheet}
                      onChange={(e) => handleSheetChange(e.target.value)}
                      className="w-full bg-white dark:bg-[#11141e] border border-slate-200 dark:border-slate-800 rounded-lg py-1.5 px-2 text-xs font-bold focus:border-primary/50 outline-none"
                    >
                      {sheetNames.map((sheet, idx) => (
                        <option key={idx} value={sheet}>{sheet}</option>
                      ))}
                    </select>
                  </div>
                )}
              </div>
            )}
          </div>

          {parsedData.length > 0 && (
            <div className="bg-white dark:bg-[#121620] border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 shadow-sm space-y-4">
              <h3 className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-widest flex items-center gap-2">
                <span className="material-symbols-outlined text-primary text-base">analytics</span>
                Column Integrity Checklist
              </h3>

              <div className="space-y-2">
                {getRequiredColumns().map((col) => {
                  const isPresent = columnStatus[col] === 'present';
                  return (
                    <div 
                      key={col} 
                      className={`flex items-center justify-between p-2.5 rounded-lg border text-xs font-semibold ${
                        isPresent 
                          ? 'bg-green-500/10 border-green-500/20 text-green-700' 
                          : 'bg-red-500/10 border-red-500/20 text-red-600'
                      }`}
                    >
                      <span className="font-mono">{col}</span>
                      <span className="flex items-center gap-1 text-[10px] font-bold">
                        <span className="material-symbols-outlined text-sm">
                          {isPresent ? 'check_circle' : 'cancel'}
                        </span>
                        {isPresent ? 'Ok' : 'Missing'}
                      </span>
                    </div>
                  );
                })}
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <div className="p-3 bg-primary/5 rounded-xl border border-primary/10">
                  <p className="text-[9px] text-slate-500 uppercase font-black tracking-widest">Total Rows</p>
                  <p className="text-lg font-black text-primary mt-0.5">{parsedData.length}</p>
                </div>
                <div className="p-3 bg-emerald-500/5 rounded-xl border border-emerald-500/10">
                  <p className="text-[9px] text-slate-500 uppercase font-black tracking-widest">Headers</p>
                  <p className="text-lg font-black text-emerald-600 mt-0.5">{getKeys().length}</p>
                </div>
              </div>
            </div>
          )}

          {parsedData.length > 0 && (
            <div className="bg-white dark:bg-[#121620] border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 shadow-sm space-y-4">
              <h3 className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-widest flex items-center gap-2">
                <span className="material-symbols-outlined text-primary text-base">cloud_sync</span>
                Cloud DB Synchronizer
              </h3>

              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest">
                    Target Collection Destination
                  </label>
                  <select
                    value={targetCollection}
                    onChange={(e) => setTargetCollection(e.target.value)}
                    className="w-full bg-white dark:bg-[#11141e] border border-slate-200 dark:border-slate-800 rounded-lg py-1.5 px-2 text-xs font-bold focus:border-primary/50 outline-none"
                  >
                    <option value="logs">Portfolio Logs (/logs)</option>
                    <option value="analysts">Analyst Productivity (/analysts)</option>
                    <option value="teams">Team Performance Summary (/teams)</option>
                    <option value="invoices">Invoices (/invoices)</option>
                    <option value="vendors">Vendors (/vendors)</option>
                  </select>
                </div>

                <div className="p-3 bg-slate-50 dark:bg-[#161b29] border border-slate-100 rounded-xl space-y-1.5">
                  <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Header Synonym Mapping:</p>
                  <div className="grid grid-cols-2 gap-y-1 gap-x-2 text-[10px] font-semibold text-slate-600 dark:text-slate-400">
                    {TARGET_SCHEMAS[targetCollection]?.fields.map(field => {
                      const mapped = fieldMappings[field.key];
                      return (
                        <div key={field.key} className="flex justify-between border-b border-slate-200/50 pb-0.5">
                          <span className="font-mono text-slate-400">{field.key}:</span>
                          <span className={mapped ? "text-emerald-600 font-bold" : "text-slate-400 italic"}>
                            {mapped ? mapped : "unmapped"}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {duplicateCheckState === 'idle' && (
                  <button
                    onClick={checkForDuplicates}
                    className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                  >
                    <span className="material-symbols-outlined text-sm">search</span>
                    Scan Database for Duplicates
                  </button>
                )}

                {duplicateCheckState === 'checking' && (
                  <div className="py-2.5 text-center bg-slate-50 rounded-xl flex items-center justify-center gap-2">
                    <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                    <span className="text-xs font-bold text-slate-500">Checking cloud database...</span>
                  </div>
                )}

                {(duplicateCheckState === 'checked' || duplicateCheckState === 'saving' || duplicateCheckState === 'saved') && (
                  <div className="space-y-3.5">
                    <div className="grid grid-cols-2 gap-2 text-center text-xs font-bold">
                      <div className="p-2 bg-green-500/10 border border-green-500/20 text-green-700 rounded-xl">
                        <p className="text-[9px] font-black uppercase tracking-wider">New Rows</p>
                        <p className="text-sm font-black mt-0.5">{newRowsList.length}</p>
                      </div>
                      <div className={`p-2 border rounded-xl ${
                        duplicateRowsList.length > 0 
                          ? 'bg-amber-500/10 border-amber-500/20 text-amber-700'
                          : 'bg-slate-50 border-slate-200 text-slate-500'
                      }`}>
                        <p className="text-[9px] font-black uppercase tracking-wider">Duplicates</p>
                        <p className="text-sm font-black mt-0.5">{duplicateRowsList.length}</p>
                      </div>
                    </div>

                    {duplicateRowsList.length > 0 && duplicateCheckState === 'checked' && (
                      <div className="p-3 bg-amber-500/5 border border-amber-500/10 rounded-xl space-y-2">
                        <p className="text-[9px] font-black text-amber-800 uppercase tracking-widest">
                          Replacement Settings (Duplicate Resolution)
                        </p>
                        <div className="space-y-1">
                          <label className="flex items-center gap-2 text-xs font-bold cursor-pointer">
                            <input
                              type="radio"
                              name="conflict"
                              value="skip"
                              checked={saveConflictOption === 'skip'}
                              onChange={() => setSaveConflictOption('skip')}
                              className="accent-primary"
                            />
                            <span>Skip duplicates (import {newRowsList.length} rows)</span>
                          </label>
                          <label className="flex items-center gap-2 text-xs font-bold cursor-pointer">
                            <input
                              type="radio"
                              name="conflict"
                              value="overwrite"
                              checked={saveConflictOption === 'overwrite'}
                              onChange={() => setSaveConflictOption('overwrite')}
                              className="accent-primary"
                            />
                            <span>Overwrite / Replace previous duplicate keys</span>
                          </label>
                        </div>
                      </div>
                    )}

                    {duplicateCheckState === 'checked' && (
                      <div className="flex gap-2">
                        <button
                          onClick={() => setDuplicateCheckState('idle')}
                          className="px-3 py-2 border rounded-xl text-xs font-bold hover:bg-slate-50 cursor-pointer"
                        >
                          Reset Scan
                        </button>
                        <button
                          onClick={saveToFirestore}
                          disabled={!hasWriteAccess}
                          className="flex-1 py-2 px-4 bg-primary text-white hover:bg-primary/90 text-on-primary rounded-xl text-xs font-black flex items-center justify-center gap-1.5 disabled:opacity-40"
                        >
                          <span className="material-symbols-outlined text-sm">cloud_upload</span>
                          Commit to DB
                        </button>
                      </div>
                    )}

                    {duplicateCheckState === 'saving' && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-xs font-extrabold text-slate-700">
                          <span className="text-primary flex items-center gap-1 animate-pulse">
                            Processing background chunks...
                          </span>
                          <span>{uploadProgress}%</span>
                        </div>
                        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                          <div className="bg-primary h-full transition-all duration-150" style={{ width: `${uploadProgress}%` }}></div>
                        </div>
                        <div className="grid grid-cols-3 gap-1 text-[9px] font-bold text-slate-500 uppercase tracking-wider text-center pt-1.5 border-t border-slate-100">
                          <div>
                            <p>Speed</p>
                            <p className="text-slate-800 font-extrabold text-[10px] mt-0.5">{processingStats.rowsPerSec} row/s</p>
                          </div>
                          <div>
                            <p>Elapsed</p>
                            <p className="text-slate-800 font-extrabold text-[10px] mt-0.5">{processingStats.elapsedSeconds}s</p>
                          </div>
                          <div>
                            <p>Remaining</p>
                            <p className="text-slate-800 font-extrabold text-[10px] mt-0.5">{processingStats.secondsRemaining}s</p>
                          </div>
                        </div>
                      </div>
                    )}

                    {duplicateCheckState === 'saved' && (
                      <div className="p-3 bg-green-500/10 border border-green-500/20 text-green-800 rounded-xl space-y-2.5 text-xs font-semibold">
                        <p className="flex items-center gap-1.5 font-black">
                          <span className="material-symbols-outlined text-base">check_circle</span>
                          Sync Succeeded
                        </p>
                        <p className="text-[11px] leading-relaxed">
                          Records written: {uploadResult?.writtenCount}. Previous datasets archived. This data is now propagated globally across the MarginEdge IPA dashboards!
                        </p>
                        <button
                          onClick={() => setDuplicateCheckState('idle')}
                          className="w-full py-1.5 bg-green-700 text-white hover:bg-green-800 font-bold rounded-lg cursor-pointer"
                        >
                          Upload New Sheet
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {firestoreError && (
                  <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-600 rounded-xl text-xs font-semibold flex items-start gap-2">
                    <span className="material-symbols-outlined text-sm shrink-0 mt-0.5">warning</span>
                    <p>{firestoreError}</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* RIGHT PANEL: VISUAL GRID PREVIEW */}
        <div className="lg:col-span-8 bg-white dark:bg-[#121620] border border-slate-200/60 dark:border-slate-800/60 rounded-2xl shadow-sm overflow-hidden flex flex-col min-h-[500px]">
          <div className="h-14 border-b border-slate-200/60 dark:border-slate-800/60 px-6 flex items-center justify-between bg-slate-50/50 dark:bg-[#161b29]/20">
            <div className="flex gap-1.5">
              <button
                onClick={() => setViewMode('table')}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 cursor-pointer transition-all ${
                  viewMode === 'table' 
                    ? 'bg-primary text-white shadow-sm' 
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100'
                }`}
              >
                <span className="material-symbols-outlined text-sm">table_chart</span>
                Visual Table Preview
              </button>
              <button
                onClick={() => setViewMode('json')}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 cursor-pointer transition-all ${
                  viewMode === 'json' 
                    ? 'bg-primary text-white shadow-sm' 
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100'
                }`}
              >
                <span className="material-symbols-outlined text-sm">javascript</span>
                Raw JSON
              </button>
            </div>

            {parsedData.length > 0 && (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Search table..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="px-2.5 py-1 bg-white dark:bg-[#11141e] border border-slate-200 dark:border-slate-800 rounded-lg text-xs shadow-sm outline-none w-44"
                />
              </div>
            )}
          </div>

          <div className="p-6 flex-1 overflow-auto">
            {parsedData.length === 0 ? (
              <div className="h-96 flex flex-col items-center justify-center text-center text-slate-400 space-y-2">
                <span className="material-symbols-outlined text-[48px] text-slate-300">upload_file</span>
                <div>
                  <p className="font-extrabold text-sm text-slate-600 dark:text-slate-300">No active spreadsheet file loaded</p>
                  <p className="text-xs text-slate-400 mt-0.5">Select validation preset rules and upload a workbook in .xlsx or .csv format to preview details.</p>
                </div>
              </div>
            ) : viewMode === 'table' ? (
              <div className="space-y-4">
                <div className="border border-slate-200/50 rounded-xl overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200/50 text-[10px] font-black uppercase text-slate-500 tracking-wider">
                        <th className="p-3 text-center w-12 bg-slate-100">#</th>
                        {getKeys().map((header) => (
                          <th key={header} className="p-3 font-mono">{header}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {paginatedData.length === 0 ? (
                        <tr>
                          <td colSpan={getKeys().length + 1} className="p-6 text-center text-xs text-slate-400 font-bold">
                            No records matched your search query.
                          </td>
                        </tr>
                      ) : (
                        paginatedData.map((row, index) => (
                          <tr key={index} className="hover:bg-slate-50/50 transition-colors">
                            <td className="p-3 text-[10px] font-mono font-bold text-slate-400 text-center bg-slate-50/30">
                              {(currentPage - 1) * rowsPerPage + index + 1}
                            </td>
                            {getKeys().map((header) => {
                              const reqColMatched = getRequiredColumns().find(col => header.toLowerCase().trim() === col.toLowerCase() || header.toLowerCase().trim().includes(col.toLowerCase()));
                              const value = row[header];
                              const isEmpty = value === undefined || value === null || String(value).trim() === '';
                              
                              return (
                                <td 
                                  key={header} 
                                  className={`p-3 text-xs font-semibold max-w-xs truncate ${
                                    reqColMatched && isEmpty 
                                      ? 'bg-red-500/10 text-red-600 font-black' 
                                      : 'text-slate-700 dark:text-slate-300'
                                  }`}
                                >
                                  {!isEmpty ? String(value) : <span className="text-red-500 font-mono text-[9px]">empty</span>}
                                </td>
                              );
                            })}
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>

                {filteredData.length > 0 && (
                  <div className="flex items-center justify-between pt-1 text-xs">
                    <p className="text-slate-500 font-medium">
                      Showing <span className="font-bold">{(currentPage - 1) * rowsPerPage + 1}</span> to{' '}
                      <span className="font-bold">{Math.min(currentPage * rowsPerPage, filteredData.length)}</span> of{' '}
                      <span className="font-bold">{filteredData.length}</span> rows
                    </p>
                    
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                        disabled={currentPage === 1}
                        className="p-1.5 rounded-lg border hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-sm block">chevron_left</span>
                      </button>
                      
                      <span className="text-slate-500 font-bold px-1 select-none">
                        Page {currentPage} of {totalPages}
                      </span>

                      <button
                        onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                        disabled={currentPage === totalPages}
                        className="p-1.5 rounded-lg border hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-sm block">chevron_right</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <pre className="p-5 rounded-xl bg-slate-900 text-emerald-400 font-mono text-[11px] leading-relaxed overflow-x-auto max-h-[500px]">
                {JSON.stringify(parsedData, null, 2)}
              </pre>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
