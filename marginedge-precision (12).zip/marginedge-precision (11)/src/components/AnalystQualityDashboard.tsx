import React, { useState, useMemo, useEffect } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, LineChart, Line, AreaChart, Area, CartesianGrid
} from 'recharts';
import { 
  Users, Percent, AlertCircle, Award, TrendingUp, Layers, Search, Filter, ShieldAlert,
  ArrowUpDown, ChevronDown, ChevronRight, Download, RefreshCw, Sparkles, Sliders, CheckCircle, Info,
  Calendar, Clock, Plus, Trophy, Flame, ChevronLeft, FileSpreadsheet, Code, Copy, Check, MessageSquare
} from 'lucide-react';
import { useRealtime } from '../context/RealtimeContext';

interface AnalystQualityDashboardProps {
  userEmail: string;
  userName?: string;
  userPosition?: string;
  onNavigate: (view: any) => void;
  onLogout: () => void;
}

// Extensive and detailed analyst dataset based on the video
const INITIAL_ANALYST_RECORDS = [
  { compl_date: '2026-06-25', analyst_login: 'salesh_salaria', team_lead_name: 'shivalika', vendor_name: 'us_foods', errors: 13, possible_error_points: 2400, error_rate: 0.54, final_score: 182.5, median_error_rate: 0.4, median_final_score: 191.0, delta_from_median_error_rate: 0.14 },
  { compl_date: '2026-06-25', analyst_login: 'r_karan', team_lead_name: 'pritika', vendor_name: 'sysco_corp', errors: 46, possible_error_points: 9200, error_rate: 0.50, final_score: 179.8, median_error_rate: 0.4, median_final_score: 191.0, delta_from_median_error_rate: 0.10 },
  { compl_date: '2026-06-25', analyst_login: 'vijaygopal', team_lead_name: 'harish', vendor_name: 'baldor_foods', errors: 2, possible_error_points: 500, error_rate: 0.40, final_score: 194.2, median_error_rate: 0.4, median_final_score: 191.0, delta_from_median_error_rate: 0.00 },
  { compl_date: '2026-06-24', analyst_login: 'manpreet', team_lead_name: 'abdulrahman', vendor_name: 'gordon_food', errors: 8, possible_error_points: 1600, error_rate: 0.50, final_score: 176.5, median_error_rate: 0.4, median_final_score: 191.0, delta_from_median_error_rate: 0.10 },
  { compl_date: '2026-06-24', analyst_login: 'deepnarawat', team_lead_name: 'alok', vendor_name: 'performance_food', errors: 14, possible_error_points: 2800, error_rate: 0.50, final_score: 178.5, median_error_rate: 0.4, median_final_score: 191.0, delta_from_median_error_rate: 0.10 },
  { compl_date: '2026-06-24', analyst_login: 'dimpiyadav', team_lead_name: 'ashish', vendor_name: 'us_foods', errors: 15, possible_error_points: 1000, error_rate: 1.50, final_score: 142.1, median_error_rate: 0.4, median_final_score: 191.0, delta_from_median_error_rate: 1.10 },
  { compl_date: '2026-06-23', analyst_login: 'garimasohal', team_lead_name: 'kamal', vendor_name: 'sysco_corp', errors: 3, possible_error_points: 750, error_rate: 0.40, final_score: 191.0, median_error_rate: 0.4, median_final_score: 191.0, delta_from_median_error_rate: 0.00 },
  { compl_date: '2026-06-23', analyst_login: 'kovalverma', team_lead_name: 'nidhi', vendor_name: 'baldor_foods', errors: 0, possible_error_points: 1200, error_rate: 0.00, final_score: 210.5, median_error_rate: 0.4, median_final_score: 191.0, delta_from_median_error_rate: -0.40 },
  { compl_date: '2026-06-23', analyst_login: 'muskandhiman', team_lead_name: 'taniya', vendor_name: 'us_foods', errors: 5, possible_error_points: 1100, error_rate: 0.45, final_score: 188.0, median_error_rate: 0.4, median_final_score: 191.0, delta_from_median_error_rate: 0.05 },
  { compl_date: '2026-06-22', analyst_login: 'harpreetdhaliwal', team_lead_name: 'shivalika', vendor_name: 'gordon_food', errors: 22, possible_error_points: 4400, error_rate: 0.50, final_score: 175.0, median_error_rate: 0.4, median_final_score: 191.0, delta_from_median_error_rate: 0.10 },
  { compl_date: '2026-06-22', analyst_login: 'harpreetthani', team_lead_name: 'pritika', vendor_name: 'performance_food', errors: 4, possible_error_points: 1000, error_rate: 0.40, final_score: 191.2, median_error_rate: 0.4, median_final_score: 191.0, delta_from_median_error_rate: 0.00 },
  { compl_date: '2026-06-22', analyst_login: 'harpreetsingh', team_lead_name: 'harish', vendor_name: 'us_foods', errors: 19, possible_error_points: 3800, error_rate: 0.50, final_score: 174.5, median_error_rate: 0.4, median_final_score: 191.0, delta_from_median_error_rate: 0.10 },
  { compl_date: '2026-06-21', analyst_login: 'harshitalohat', team_lead_name: 'abdulrahman', vendor_name: 'sysco_corp', errors: 12, possible_error_points: 2500, error_rate: 0.48, final_score: 181.0, median_error_rate: 0.4, median_final_score: 191.0, delta_from_median_error_rate: 0.08 },
  { compl_date: '2026-06-21', analyst_login: 'jaspreetsaini', team_lead_name: 'alok', vendor_name: 'us_foods', errors: 24, possible_error_points: 1100, error_rate: 2.18, final_score: 118.4, median_error_rate: 0.4, median_final_score: 191.0, delta_from_median_error_rate: 1.78 },
  { compl_date: '2026-06-21', analyst_login: 'kashishbawa', team_lead_name: 'ashish', vendor_name: 'baldor_foods', errors: 1, possible_error_points: 400, error_rate: 0.25, final_score: 199.5, median_error_rate: 0.4, median_final_score: 191.0, delta_from_median_error_rate: -0.15 },
  { compl_date: '2026-06-20', analyst_login: 'kirandeep', team_lead_name: 'kamal', vendor_name: 'gordon_food', errors: 3, possible_error_points: 800, error_rate: 0.38, final_score: 193.0, median_error_rate: 0.4, median_final_score: 191.0, delta_from_median_error_rate: -0.02 }
];

const WEEKLY_ERROR_RATES = [
  { analyst: 'salesh_salaria', w1: '0.4%', w2: '0.5%', w3: '0.3%', w4: '0.6%', w5: '0.4%', average: '0.44%' },
  { analyst: 'r_karan', w1: '0.5%', w2: '0.4%', w3: '0.6%', w4: '0.5%', w5: '0.5%', average: '0.50%' },
  { analyst: 'vijaygopal', w1: '0.3%', w2: '0.4%', w3: '0.4%', w4: '0.3%', w5: '0.5%', average: '0.38%' },
  { analyst: 'manpreet', w1: '0.4%', w2: '0.6%', w3: '0.5%', w4: '0.5%', w5: '0.4%', average: '0.48%' },
  { analyst: 'deepnarawat', w1: '0.5%', w2: '0.5%', w3: '0.5%', w4: '0.4%', w5: '0.6%', average: '0.50%' },
  { analyst: 'dimpiyadav', w1: '1.2%', w2: '1.5%', w3: '1.4%', w4: '1.6%', w5: '1.3%', average: '1.40%' },
  { analyst: 'garimasohal', w1: '0.4%', w2: '0.4%', w3: '0.3%', w4: '0.4%', w5: '0.5%', average: '0.40%' },
  { analyst: 'kovalverma', w1: '0.1%', w2: '0.0%', w3: '0.1%', w4: '0.0%', w5: '0.2%', average: '0.08%' }
];

const TEAM_LEAD_METRICS = [
  { team_lead: 'shivalika', lead_analysts: 5, avg_productivity: 181.2, avg_error_rate: 0.48, avg_final_score: 185.4, avg_delta: 0.08 },
  { team_lead: 'pritika', lead_analysts: 6, avg_productivity: 178.5, avg_error_rate: 0.52, avg_final_score: 179.2, avg_delta: 0.12 },
  { team_lead: 'harish', lead_analysts: 4, avg_productivity: 189.4, avg_error_rate: 0.42, avg_final_score: 191.0, avg_delta: 0.02 },
  { team_lead: 'abdulrahman', lead_analysts: 7, avg_productivity: 175.0, avg_error_rate: 0.49, avg_final_score: 177.1, avg_delta: 0.09 },
  { team_lead: 'alok', lead_analysts: 5, avg_productivity: 169.8, avg_error_rate: 0.54, avg_final_score: 168.0, avg_delta: 0.14 },
  { team_lead: 'ashish', lead_analysts: 6, avg_productivity: 151.2, avg_error_rate: 1.15, avg_final_score: 139.5, avg_delta: 0.75 }
];

const ANALYST_PRODUCTIVITY_DETAILS = [
  { analyst_login: 'salesh_salaria', productivity_score: 1981.5, initial_reviews: 197, non_edi_recs: 308, edi_recs: 59, non_edi_line_items: 2.34, edi_line_items: 2.45 },
  { analyst_login: 'r_karan', productivity_score: 1970.6, initial_reviews: 179, non_edi_recs: 238, edi_recs: 53, non_edi_line_items: 2.21, edi_line_items: 2.56 },
  { analyst_login: 'vijaygopal', productivity_score: 1857.4, initial_reviews: 161, non_edi_recs: 225, edi_recs: 80, non_edi_line_items: 2.05, edi_line_items: 2.38 },
  { analyst_login: 'manpreet', productivity_score: 1810.4, initial_reviews: 185, non_edi_recs: 222, edi_recs: 40, non_edi_line_items: 1.95, edi_line_items: 2.11 },
  { analyst_login: 'deepnarawat', productivity_score: 1613.4, initial_reviews: 200, non_edi_recs: 228, edi_recs: 70, non_edi_line_items: 1.82, edi_line_items: 1.89 },
  { analyst_login: 'dimpiyadav', productivity_score: 1600.8, initial_reviews: 243, non_edi_recs: 328, edi_recs: 23, non_edi_line_items: 1.54, edi_line_items: 1.45 },
  { analyst_login: 'garimasohal', productivity_score: 1528.6, initial_reviews: 148, non_edi_recs: 215, edi_recs: 64, non_edi_line_items: 2.06, edi_line_items: 2.12 },
  { analyst_login: 'kovalverma', productivity_score: 1493.0, initial_reviews: 182, non_edi_recs: 197, edi_recs: 53, non_edi_line_items: 1.85, edi_line_items: 1.98 }
];

export interface PdfSpreadsheetRecord {
  id: string;
  user: string;
  office: string;
  points: number;
  initialReview: number;
  irAvgTime: number;
  initialMistakes: number;
  reconcile: number;
  totalLines: number;
  normalLines: number;
  ediLines: number;
  ocrLines: number;
  recAvgTime: number;
  reconcileMistakes: number;
  finalReview: number;
  frAvgTime: number;
  finalMistakes: number;
  qoRed: number;
}

export const INITIAL_PDF_SPREADSHEET_RECORDS: PdfSpreadsheetRecord[] = [
  { id: 'pdf-1', user: 'harpreet', office: 'Chandigarh', points: 429.578, initialReview: 147, irAvgTime: 0.68, initialMistakes: 3, reconcile: 38, totalLines: 330, normalLines: 304, ediLines: 24, ocrLines: 2, recAvgTime: 3.75, reconcileMistakes: 1, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 1 },
  { id: 'pdf-2', user: 'gurveen kaur', office: 'Chandigarh', points: 327.863, initialReview: 21, irAvgTime: 0.99, initialMistakes: 1, reconcile: 53, totalLines: 597, normalLines: 449, ediLines: 146, ocrLines: 2, recAvgTime: 5.31, reconcileMistakes: 1, finalReview: 14, frAvgTime: 1.9, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-3', user: 'harpreetkaur', office: 'Chandigarh', points: 243.599, initialReview: 47, irAvgTime: 0.58, initialMistakes: 2, reconcile: 39, totalLines: 230, normalLines: 199, ediLines: 17, ocrLines: 14, recAvgTime: 2.99, reconcileMistakes: 5, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-4', user: 'bainspritika', office: 'Chandigarh', points: 460.316, initialReview: 57, irAvgTime: 1.00, initialMistakes: 1, reconcile: 81, totalLines: 629, normalLines: 432, ediLines: 197, ocrLines: 0, recAvgTime: 4.15, reconcileMistakes: 0, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-5', user: 'kiran', office: 'Chandigarh', points: 397.929, initialReview: 3, irAvgTime: 0.55, initialMistakes: 0, reconcile: 80, totalLines: 677, normalLines: 509, ediLines: 167, ocrLines: 1, recAvgTime: 4.90, reconcileMistakes: 0, finalReview: 2, frAvgTime: 2.53, finalMistakes: 0, qoRed: 4 },
  { id: 'pdf-6', user: 'nikitabhatt', office: 'Chandigarh', points: 4.605, initialReview: 0, irAvgTime: 0.00, initialMistakes: 0, reconcile: 1, totalLines: 5, normalLines: 5, ediLines: 0, ocrLines: 0, recAvgTime: 4.22, reconcileMistakes: 0, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-7', user: 'jasvinderkaur', office: 'Chandigarh', points: 431.702, initialReview: 62, irAvgTime: 0.79, initialMistakes: 4, reconcile: 82, totalLines: 751, normalLines: 382, ediLines: 367, ocrLines: 2, recAvgTime: 2.84, reconcileMistakes: 4, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-8', user: 'roshan', office: 'Chandigarh', points: 354.231, initialReview: 138, irAvgTime: 0.48, initialMistakes: 3, reconcile: 23, totalLines: 247, normalLines: 246, ediLines: 0, ocrLines: 1, recAvgTime: 4.34, reconcileMistakes: 0, finalReview: 14, frAvgTime: 0.5, finalMistakes: 0, qoRed: 52 },
  { id: 'pdf-9', user: 'simran mehta', office: 'Chandigarh', points: 501.640, initialReview: 39, irAvgTime: 0.71, initialMistakes: 2, reconcile: 106, totalLines: 430, normalLines: 395, ediLines: 33, ocrLines: 2, recAvgTime: 1.88, reconcileMistakes: 0, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-10', user: 'garimasohal', office: 'Chandigarh', points: 10.372, initialReview: 0, irAvgTime: 0.00, initialMistakes: 0, reconcile: 3, totalLines: 4, normalLines: 4, ediLines: 0, ocrLines: 0, recAvgTime: 4.40, reconcileMistakes: 0, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-11', user: 'satishkumar', office: 'Chandigarh', points: 293.488, initialReview: 8, irAvgTime: 0.95, initialMistakes: 0, reconcile: 58, totalLines: 336, normalLines: 336, ediLines: 0, ocrLines: 0, recAvgTime: 4.34, reconcileMistakes: 0, finalReview: 60, frAvgTime: 1.87, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-12', user: 'poojadevi', office: 'Chandigarh', points: 74.234, initialReview: 17, irAvgTime: 1.39, initialMistakes: 0, reconcile: 8, totalLines: 78, normalLines: 78, ediLines: 0, ocrLines: 0, recAvgTime: 13.96, reconcileMistakes: 0, finalReview: 39, frAvgTime: 1.5, finalMistakes: 0, qoRed: 10 },
  { id: 'pdf-13', user: 'praveenkumar', office: 'Chandigarh', points: 382.146, initialReview: 112, irAvgTime: 0.79, initialMistakes: 2, reconcile: 47, totalLines: 361, normalLines: 272, ediLines: 89, ocrLines: 0, recAvgTime: 3.67, reconcileMistakes: 0, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-14', user: 'divyasharma', office: 'Chandigarh', points: 289.768, initialReview: 60, irAvgTime: 1.50, initialMistakes: 1, reconcile: 54, totalLines: 319, normalLines: 175, ediLines: 143, ocrLines: 1, recAvgTime: 3.46, reconcileMistakes: 1, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 2 },
  { id: 'pdf-15', user: 'sonali', office: 'Chandigarh', points: 160.064, initialReview: 47, irAvgTime: 0.67, initialMistakes: 5, reconcile: 30, totalLines: 284, normalLines: 37, ediLines: 246, ocrLines: 1, recAvgTime: 2.54, reconcileMistakes: 0, finalReview: 28, frAvgTime: 0.47, finalMistakes: 0, qoRed: 9 },
  { id: 'pdf-16', user: 'radhikaverma', office: 'Chandigarh', points: 433.133, initialReview: 51, irAvgTime: 0.90, initialMistakes: 0, reconcile: 70, totalLines: 556, normalLines: 501, ediLines: 55, ocrLines: 0, recAvgTime: 3.69, reconcileMistakes: 1, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-17', user: 'gouravthakur', office: 'Chandigarh', points: 10.462, initialReview: 0, irAvgTime: 0.00, initialMistakes: 0, reconcile: 2, totalLines: 14, normalLines: 14, ediLines: 0, ocrLines: 0, recAvgTime: 5.08, reconcileMistakes: 0, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-18', user: 'aakashdeepkaur', office: 'Chandigarh', points: 6.353, initialReview: 2, irAvgTime: 0.84, initialMistakes: 0, reconcile: 1, totalLines: 1, normalLines: 1, ediLines: 0, ocrLines: 0, recAvgTime: 1.33, reconcileMistakes: 0, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-19', user: 'nehabhatt', office: 'Chandigarh', points: 191.951, initialReview: 13, irAvgTime: 0.67, initialMistakes: 0, reconcile: 39, totalLines: 347, normalLines: 204, ediLines: 140, ocrLines: 3, recAvgTime: 3.14, reconcileMistakes: 0, finalReview: 81, frAvgTime: 1.21, finalMistakes: 0, qoRed: 45 },
  { id: 'pdf-20', user: 'priyankarawat', office: 'Chandigarh', points: 411.429, initialReview: 55, irAvgTime: 1.26, initialMistakes: 4, reconcile: 75, totalLines: 438, normalLines: 334, ediLines: 95, ocrLines: 9, recAvgTime: 3.17, reconcileMistakes: 0, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-21', user: 'soniarani', office: 'Havana', points: 414.947, initialReview: 67, irAvgTime: 0.55, initialMistakes: 2, reconcile: 83, totalLines: 777, normalLines: 288, ediLines: 488, ocrLines: 1, recAvgTime: 2.65, reconcileMistakes: 1, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-22', user: 'ramandeepdahahar', office: 'Chandigarh', points: 14.228, initialReview: 5, irAvgTime: 1.10, initialMistakes: 0, reconcile: 2, totalLines: 6, normalLines: 6, ediLines: 0, ocrLines: 0, recAvgTime: 1.90, reconcileMistakes: 0, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-23', user: 'palak', office: 'Chandigarh', points: 67.988, initialReview: 0, irAvgTime: 0.00, initialMistakes: 0, reconcile: 17, totalLines: 57, normalLines: 56, ediLines: 1, ocrLines: 0, recAvgTime: 5.36, reconcileMistakes: 0, finalReview: 119, frAvgTime: 2.30, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-24', user: 'laxmi', office: 'Havana', points: 111.634, initialReview: 51, irAvgTime: 1.15, initialMistakes: 3, reconcile: 7, totalLines: 54, normalLines: 32, ediLines: 6, ocrLines: 16, recAvgTime: 6.58, reconcileMistakes: 3, finalReview: 110, frAvgTime: 1.07, finalMistakes: 0, qoRed: 23 },
  { id: 'pdf-25', user: 'sanjaygairola', office: 'Chandigarh', points: 323.831, initialReview: 94, irAvgTime: 0.93, initialMistakes: 2, reconcile: 57, totalLines: 740, normalLines: 133, ediLines: 603, ocrLines: 4, recAvgTime: 2.95, reconcileMistakes: 0, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-26', user: 'anwar_hussain', office: 'Dhaka', points: 390.50, initialReview: 44, irAvgTime: 0.95, initialMistakes: 2, reconcile: 65, totalLines: 480, normalLines: 400, ediLines: 80, ocrLines: 0, recAvgTime: 3.12, reconcileMistakes: 1, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-27', user: 'fatima_begum', office: 'Dhaka', points: 310.20, initialReview: 38, irAvgTime: 1.12, initialMistakes: 1, reconcile: 50, totalLines: 390, normalLines: 310, ediLines: 80, ocrLines: 0, recAvgTime: 3.84, reconcileMistakes: 1, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-28', user: 'manpreet', office: 'Dhaka', points: 280.50, initialReview: 25, irAvgTime: 0.85, initialMistakes: 0, reconcile: 35, totalLines: 290, normalLines: 240, ediLines: 50, ocrLines: 0, recAvgTime: 4.10, reconcileMistakes: 0, finalReview: 45, frAvgTime: 1.44, finalMistakes: 0, qoRed: 6 },
  { id: 'pdf-29', user: 'manjeet_kaur', office: 'Dhaka', points: 250.00, initialReview: 15, irAvgTime: 0.90, initialMistakes: 1, reconcile: 40, totalLines: 300, normalLines: 200, ediLines: 100, ocrLines: 0, recAvgTime: 3.50, reconcileMistakes: 1, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-30', user: 'shabnam_kumari', office: 'Dhaka', points: 190.00, initialReview: 10, irAvgTime: 0.95, initialMistakes: 0, reconcile: 30, totalLines: 240, normalLines: 140, ediLines: 100, ocrLines: 0, recAvgTime: 3.60, reconcileMistakes: 0, finalReview: 20, frAvgTime: 1.50, finalMistakes: 0, qoRed: 1 },
  { id: 'pdf-31', user: 'muskandhiman', office: 'US', points: 288.00, initialReview: 35, irAvgTime: 0.75, initialMistakes: 1, reconcile: 42, totalLines: 310, normalLines: 280, ediLines: 30, ocrLines: 0, recAvgTime: 3.20, reconcileMistakes: 0, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-32', user: 'surajbanyal', office: 'US', points: 240.00, initialReview: 20, irAvgTime: 0.80, initialMistakes: 0, reconcile: 38, totalLines: 280, normalLines: 220, ediLines: 60, ocrLines: 0, recAvgTime: 3.40, reconcileMistakes: 1, finalReview: 0, frAvgTime: 0.0, finalMistakes: 0, qoRed: 0 },
  { id: 'pdf-33', user: 'priyanka_sharma', office: 'US', points: 210.00, initialReview: 15, irAvgTime: 0.85, initialMistakes: 0, reconcile: 30, totalLines: 220, normalLines: 180, ediLines: 40, ocrLines: 0, recAvgTime: 3.80, reconcileMistakes: 0, finalReview: 10, frAvgTime: 1.60, finalMistakes: 0, qoRed: 2 }
];

export default function AnalystQualityDashboard({ 
  userEmail, 
  userName, 
  userPosition, 
  onNavigate, 
  onLogout 
}: AnalystQualityDashboardProps) {
  const [activeTab, setActiveTab] = useState<'LEGACY' | 'LEGACY_ORIGINAL' | 'IPA' | 'RANKINGS'>('LEGACY_ORIGINAL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRankingTab, setSelectedRankingTab] = useState<'team' | 'vendor' | 'analyst'>('team');
  const [codeLanguage, setCodeLanguage] = useState<'typescript' | 'python' | 'sql'>('typescript');
  const [codeType, setCodeType] = useState<'data' | 'utility'>('data');
  const [codeCopied, setCodeCopied] = useState(false);
  const [rankingsSearch, setRankingsSearch] = useState('');
  const [rankingSortField, setRankingSortField] = useState<string>('compositeScore');
  const [rankingSortDirection, setRankingSortDirection] = useState<'asc' | 'desc'>('desc');
  const [selectedLead, setSelectedLead] = useState('All');
  const [sortField, setSortField] = useState<string>('compl_date');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [activeLeadRow, setActiveLeadRow] = useState<string | null>(null);
  const [resolutionStatus, setResolutionStatus] = useState<'unresolved' | 'resolving' | 'resolved'>('unresolved');
  const [resolutionProgress, setResolutionProgress] = useState(0);
  const [globalSearchQuery, setGlobalSearchQuery] = useState('');
  const [showGlobalSearchResults, setShowGlobalSearchResults] = useState(false);

  // IPA Realtime Data integration & state declarations
  const { ipaRecords: liveIpaRecords } = useRealtime();

  const mapToValidTeam = (teamName: string): string => {
    const lower = (teamName || '').toLowerCase().trim();
    if (lower.includes('chandigarh')) return 'Chandigarh';
    if (lower.includes('dhaka')) return 'Dhaka';
    if (lower.includes('havana')) return 'Havana';
    if (lower.includes('us')) return 'US';
    
    // Mapping legacy Alpha and Core to the new locations requested
    if (lower.includes('alpha')) return 'Chandigarh';
    if (lower.includes('core')) return 'Dhaka';
    if (lower.includes('gamma')) return 'Havana';
    
    return 'Chandigarh'; // Default fallback
  };
  
  const defaultIpaList = useMemo(() => [
    { id: 'ipa-1', name: 'salesh_salaria', team: 'Chandigarh', tasks: 942 },
    { id: 'ipa-2', name: 'deepnarawat', team: 'Chandigarh', tasks: 812 },
    { id: 'ipa-3', name: 'hardeeprohilla', team: 'Chandigarh', tasks: 916 },
    { id: 'ipa-4', name: 'jaspreetsaini', team: 'Chandigarh', tasks: 731 },
    { id: 'ipa-5', name: 'monikathakur', team: 'Chandigarh', tasks: 698 },
    { id: 'ipa-6', name: 'dimpiyadav', team: 'Chandigarh', tasks: 443 },
    { id: 'ipa-7', name: 'garimasohal', team: 'Chandigarh', tasks: 294 },
    { id: 'ipa-8', name: 'r_karan', team: 'Havana', tasks: 512 },
    { id: 'ipa-9', name: 'vijaygopal', team: 'Chandigarh', tasks: 842 },
    { id: 'ipa-10', name: 'manpreet', team: 'Dhaka', tasks: 399 },
    { id: 'ipa-11', name: 'kovalverma', team: 'Chandigarh', tasks: 615 },
    { id: 'ipa-12', name: 'muskandhiman', team: 'US', tasks: 288 },
    { id: 'ipa-13', name: 'anwar_hussain', team: 'Dhaka', tasks: 620 },
    { id: 'ipa-14', name: 'fatima_begum', team: 'Dhaka', tasks: 510 },
    { id: 'ipa-15', name: 'rahul_sharma', team: 'Chandigarh', tasks: 550 }
  ], []);

  const [customIpaRecords, setCustomIpaRecords] = useState<{ id: string; name: string; team: string; tasks: number }[]>([]);
  const [selectedIpaAnalyst, setSelectedIpaAnalyst] = useState('salesh_salaria');
  const [selectedLocation, setSelectedLocation] = useState('All');
  const [googleSheetUrl, setGoogleSheetUrl] = useState('');

  useEffect(() => {
    fetch('/api/settings/google-sheet')
      .then(res => res.json())
      .then(data => {
        if (data.url) {
          setGoogleSheetUrl(data.url);
        }
      })
      .catch(err => console.error("Error loading google sheet setting:", err));
  }, []);

  // PDF Spreadsheet Scorecard state
  const [pdfRecords, setPdfRecords] = useState<PdfSpreadsheetRecord[]>(INITIAL_PDF_SPREADSHEET_RECORDS);
  const [selectedPdfLocation, setSelectedPdfLocation] = useState('All');
  const [pdfSearchQuery, setPdfSearchQuery] = useState('');
  const [selectedPdfAnalystName, setSelectedPdfAnalystName] = useState('harpreet');
  const [pdfSortField, setPdfSortField] = useState<keyof PdfSpreadsheetRecord>('points');
  const [pdfSortDirection, setPdfSortDirection] = useState<'asc' | 'desc'>('desc');

  const filteredPdfRecords = useMemo(() => {
    let result = [...pdfRecords];

    // Filter by location
    if (selectedPdfLocation !== 'All') {
      result = result.filter(r => r.office.toLowerCase() === selectedPdfLocation.toLowerCase());
    }

    // Filter by search query
    if (pdfSearchQuery) {
      const q = pdfSearchQuery.toLowerCase().trim();
      result = result.filter(r => 
        r.user.toLowerCase().includes(q) || 
        r.office.toLowerCase().includes(q)
      );
    }

    // Sort
    result.sort((a, b) => {
      let valA = a[pdfSortField];
      let valB = b[pdfSortField];

      if (typeof valA === 'string') {
        return pdfSortDirection === 'asc'
          ? (valA as string).localeCompare(valB as string)
          : (valB as string).localeCompare(valA as string);
      } else {
        return pdfSortDirection === 'asc'
          ? (valA as number) - (valB as number)
          : (valB as number) - (valA as number);
      }
    });

    return result;
  }, [pdfRecords, selectedPdfLocation, pdfSearchQuery, pdfSortField, pdfSortDirection]);

  const activePdfAnalyst = useMemo(() => {
    const found = pdfRecords.find(r => r.user.toLowerCase() === selectedPdfAnalystName.toLowerCase());
    return found || filteredPdfRecords[0] || pdfRecords[0];
  }, [pdfRecords, selectedPdfAnalystName, filteredPdfRecords]);

  // Set the default active PDF analyst when selected location changes
  useEffect(() => {
    if (filteredPdfRecords.length > 0) {
      const exists = filteredPdfRecords.some(r => r.user.toLowerCase() === selectedPdfAnalystName.toLowerCase());
      if (!exists) {
        setSelectedPdfAnalystName(filteredPdfRecords[0].user);
      }
    }
  }, [selectedPdfLocation, filteredPdfRecords, selectedPdfAnalystName]);

  // Scorecard highlights metrics
  const scorecardHighlights = useMemo(() => {
    const records = selectedPdfLocation === 'All' 
      ? pdfRecords 
      : pdfRecords.filter(r => r.office.toLowerCase() === selectedPdfLocation.toLowerCase());

    if (records.length === 0) {
      return { totalPoints: 0, totalLines: 0, avgErrorRate: 0, topAnalyst: 'N/A', topPoints: 0 };
    }

    let sumPoints = 0;
    let sumLines = 0;
    let sumMistakes = 0;
    let sumReviews = 0;
    let topAnalyst = records[0];

    records.forEach(r => {
      sumPoints += r.points;
      sumLines += r.totalLines;
      sumMistakes += (r.initialMistakes + r.reconcileMistakes + r.finalMistakes);
      sumReviews += (r.initialReview + r.reconcile + r.finalReview);

      if (r.points > topAnalyst.points) {
        topAnalyst = r;
      }
    });

    const avgErrorRate = sumReviews > 0 ? (sumMistakes / sumReviews) * 100 : 0;

    return {
      totalPoints: Number(sumPoints.toFixed(3)),
      totalLines: sumLines,
      avgErrorRate: Number(avgErrorRate.toFixed(2)),
      topAnalyst: topAnalyst.user,
      topPoints: Number(topAnalyst.points.toFixed(3))
    };
  }, [pdfRecords, selectedPdfLocation]);

  // Dynamic weekly trend of the active PDF analyst
  const pdfAnalystDailyTrend = useMemo(() => {
    if (!activePdfAnalyst) return [];
    
    const mistakes = activePdfAnalyst.initialMistakes + activePdfAnalyst.reconcileMistakes + activePdfAnalyst.finalMistakes;
    const reviews = activePdfAnalyst.initialReview + activePdfAnalyst.reconcile + activePdfAnalyst.finalReview;
    const baseErrorRate = reviews > 0 ? (mistakes / reviews) * 100 : 1.2;

    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const multipliers = [0.85, 1.15, 0.95, 1.05, 0.80, 1.25, 0.90];
    
    return days.map((day, idx) => {
      const rate = Number((baseErrorRate * multipliers[idx]).toFixed(2));
      const dailyTasks = Math.floor((activePdfAnalyst.totalLines / 6) * multipliers[idx]);
      return {
        day,
        'Error Rate (%)': Math.min(100, Math.max(0, rate)),
        'Target Threshold (%)': 1.5,
        'Lines Processed': dailyTasks
      };
    });
  }, [activePdfAnalyst]);

  const ipaList = useMemo(() => {
    const combined: { id: string; name: string; team: string; tasks: number }[] = [];
    
    customIpaRecords.forEach(item => {
      combined.push({
        ...item,
        team: mapToValidTeam(item.team)
      });
    });

    const sourceList = liveIpaRecords && liveIpaRecords.length > 0 ? liveIpaRecords : defaultIpaList;
    
    sourceList.forEach(item => {
      if (!combined.some(c => c.name.toLowerCase() === item.name.toLowerCase())) {
        combined.push({
          id: item.id,
          name: item.name.toLowerCase(),
          team: mapToValidTeam(item.team),
          tasks: Number(item.tasks) || 0
        });
      }
    });
    return combined;
  }, [liveIpaRecords, customIpaRecords, defaultIpaList]);

  // Dynamic Analyst Rankings combining both PDF Scorecard & IPA lists
  const analystRankings = useMemo(() => {
    const map = new Map<string, {
      name: string;
      office: string;
      points: number;
      tasks: number;
      errors: number;
      reviews: number;
      isIpa: boolean;
      isScorecard: boolean;
    }>();

    // Map PDF scorecard records
    pdfRecords.forEach(r => {
      const nameKey = r.user.toLowerCase().trim();
      const item = map.get(nameKey) || {
        name: r.user,
        office: r.office,
        points: 0,
        tasks: 0,
        errors: 0,
        reviews: 0,
        isIpa: false,
        isScorecard: true,
      };
      item.points += r.points;
      item.errors += (r.initialMistakes + r.reconcileMistakes + r.finalMistakes);
      item.reviews += (r.initialReview + r.reconcile + r.finalReview);
      item.isScorecard = true;
      map.set(nameKey, item);
    });

    // Map IPA records
    ipaList.forEach(r => {
      const nameKey = r.name.toLowerCase().trim();
      const item = map.get(nameKey) || {
        name: r.name,
        office: r.team,
        points: 0,
        tasks: 0,
        errors: 0,
        reviews: 0,
        isIpa: true,
        isScorecard: false,
      };
      item.tasks += r.tasks;
      item.isIpa = true;
      map.set(nameKey, item);
    });

    const list = Array.from(map.values()).map(item => {
      const errorRate = item.reviews > 0 ? (item.errors / item.reviews) * 100 : 0.0;
      // Composite Score: Points + (Tasks * 0.5)
      const compositeScore = item.points + (item.tasks * 0.5);
      return {
        ...item,
        errorRate: Number(errorRate.toFixed(2)),
        compositeScore: Number(compositeScore.toFixed(3)),
      };
    });

    // Sort by composite score descending
    return list.sort((a, b) => b.compositeScore - a.compositeScore);
  }, [pdfRecords, ipaList]);

  // Dynamic Team Rankings grouped by location
  const teamRankings = useMemo(() => {
    const locations = ['Chandigarh', 'Dhaka', 'Havana', 'US'];
    const list = locations.map(loc => {
      const teamAnalysts = analystRankings.filter(a => a.office.toLowerCase() === loc.toLowerCase());
      const totalPoints = teamAnalysts.reduce((sum, a) => sum + a.points, 0);
      const totalTasks = teamAnalysts.reduce((sum, a) => sum + a.tasks, 0);
      const totalErrors = teamAnalysts.reduce((sum, a) => sum + a.errors, 0);
      const totalReviews = teamAnalysts.reduce((sum, a) => sum + a.reviews, 0);
      
      const avgErrorRate = totalReviews > 0 ? (totalErrors / totalReviews) * 100 : 0.0;
      const compositeScore = totalPoints + (totalTasks * 0.5);
      const avgCompositeScore = teamAnalysts.length > 0 ? compositeScore / teamAnalysts.length : 0.0;

      return {
        team: loc,
        analystCount: teamAnalysts.length,
        totalPoints: Number(totalPoints.toFixed(2)),
        totalTasks,
        avgErrorRate: Number(avgErrorRate.toFixed(2)),
        compositeScore: Number(compositeScore.toFixed(2)),
        avgCompositeScore: Number(avgCompositeScore.toFixed(2))
      };
    });

    // Sort by Composite Score descending
    return list.sort((a, b) => b.compositeScore - a.compositeScore);
  }, [analystRankings]);

  // Dynamic Vendor Rankings grouped by vendor name from legacy records
  const vendorRankings = useMemo(() => {
    const map = new Map<string, {
      vendor: string;
      errors: number;
      possiblePoints: number;
      recordsCount: number;
      totalFinalScore: number;
    }>();

    INITIAL_ANALYST_RECORDS.forEach(r => {
      const vendorKey = (r.vendor_name || 'unknown').toLowerCase().trim();
      const item = map.get(vendorKey) || {
        vendor: r.vendor_name,
        errors: 0,
        possiblePoints: 0,
        recordsCount: 0,
        totalFinalScore: 0
      };
      item.errors += r.errors;
      item.possiblePoints += r.possible_error_points;
      item.recordsCount += 1;
      item.totalFinalScore += r.final_score;
      map.set(vendorKey, item);
    });

    const list = Array.from(map.values()).map(item => {
      const errorRate = item.possiblePoints > 0 ? (item.errors / item.possiblePoints) * 100 : 0.0;
      const avgFinalScore = item.recordsCount > 0 ? item.totalFinalScore / item.recordsCount : 0.0;
      return {
        vendor: item.vendor,
        errors: item.errors,
        possiblePoints: item.possiblePoints,
        errorRate: Number(errorRate.toFixed(2)),
        avgFinalScore: Number(avgFinalScore.toFixed(1)),
        recordsCount: item.recordsCount
      };
    });

    // Sort by lowest error rate (which is the best vendor quality)
    return list.sort((a, b) => a.errorRate - b.errorRate);
  }, []);

  // Return Code Snippet Generator
  const generatedCodeSnippet = useMemo(() => {
    if (selectedRankingTab === 'team') {
      if (codeLanguage === 'typescript') {
        if (codeType === 'data') {
          return `// Team Rankings Dataset - Compiled dynamically
export interface TeamRankingRecord {
  team: string;
  analystCount: number;
  totalPoints: number;
  totalTasks: number;
  avgErrorRate: number;
  compositeScore: number;
  avgCompositeScore: number;
}

export const TEAM_RANKINGS_DATA: TeamRankingRecord[] = \n${JSON.stringify(teamRankings, null, 2)};`;
        } else {
          return `// Team Ranking Computation Utility Engine
export interface RawAnalystRecord {
  name: string;
  office: string;
  points: number;
  tasks: number;
  errors: number;
  reviews: number;
}

/**
 * Calculates compiled Team Rankings dynamically from raw Analyst records.
 * Composite Score Formula: TotalPoints + (TotalTasks * 0.5)
 */
export function calculateTeamRankings(records: RawAnalystRecord[]): any[] {
  const teams = ['Chandigarh', 'Dhaka', 'Havana', 'US'];
  const list = teams.map(loc => {
    const teamAnalysts = records.filter(a => a.office.toLowerCase() === loc.toLowerCase());
    const totalPoints = teamAnalysts.reduce((sum, a) => sum + a.points, 0);
    const totalTasks = teamAnalysts.reduce((sum, a) => sum + a.tasks, 0);
    const totalErrors = teamAnalysts.reduce((sum, a) => sum + a.errors, 0);
    const totalReviews = teamAnalysts.reduce((sum, a) => sum + a.reviews, 0);
    
    const avgErrorRate = totalReviews > 0 ? (totalErrors / totalReviews) * 100 : 0.0;
    const compositeScore = totalPoints + (totalTasks * 0.5);
    const avgCompositeScore = teamAnalysts.length > 0 ? compositeScore / teamAnalysts.length : 0.0;

    return {
      team: loc,
      analystCount: teamAnalysts.length,
      totalPoints: Number(totalPoints.toFixed(2)),
      totalTasks,
      avgErrorRate: Number(avgErrorRate.toFixed(2)),
      compositeScore: Number(compositeScore.toFixed(2)),
      avgCompositeScore: Number(avgCompositeScore.toFixed(2))
    };
  });

  return list.sort((a, b) => b.compositeScore - a.compositeScore);
}`;
        }
      } else if (codeLanguage === 'python') {
        if (codeType === 'data') {
          return `# Python Team Rankings Dictionary List
team_rankings = \\
${JSON.stringify(teamRankings, null, 4)}

# Display current Leaderboard
print("--- TEAM LEADERBOARD ---")
for idx, r in enumerate(team_rankings, 1):
    print(f"{idx}. Team {r['team']}: Composite Score={r['compositeScore']}, Error Rate={r['avgErrorRate']}%")`;
        } else {
          return `# Python Team Performance Ranking Calculation Module
import pandas as pd

def calculate_team_rankings(analyst_df: pd.DataFrame) -> pd.DataFrame:
    """
    Computes team performance rankings from a DataFrame of analysts.
    Required columns: ['office', 'points', 'tasks', 'errors', 'reviews']
    """
    # Group by team office
    grp = analyst_df.groupby('office').agg(
        analyst_count=('name', 'count'),
        total_points=('points', 'sum'),
        total_tasks=('tasks', 'sum'),
        total_errors=('errors', 'sum'),
        total_reviews=('reviews', 'sum')
    ).reset_index()
    
    # Apply standard metrics & scores
    grp['avg_error_rate'] = (grp['total_errors'] / grp['total_reviews'].replace(0, 1)) * 100
    grp['composite_score'] = grp['total_points'] + (grp['total_tasks'] * 0.5)
    grp['avg_composite_score'] = grp['composite_score'] / grp['analyst_count'].replace(0, 1)
    
    # Rank teams
    return grp.sort_values(by='composite_score', ascending=False).reset_index(drop=True)`;
        }
      } else { // SQL
        return `-- PostgreSQL Query: Calculate Team Performance Leaderboard
-- Formula: Composite Score = TotalPoints + (TotalTasks * 0.5)

SELECT 
    office AS team,
    COUNT(id) AS analyst_count,
    ROUND(SUM(points)::numeric, 2) AS total_points,
    SUM(tasks) AS total_tasks,
    ROUND(
        (SUM(errors)::numeric / NULLIF(SUM(reviews), 0) * 100), 
        2
    ) AS avg_error_rate,
    ROUND(
        (SUM(points) + (SUM(tasks) * 0.5))::numeric, 
        2
    ) AS composite_score,
    RANK() OVER (ORDER BY SUM(points) + (SUM(tasks) * 0.5) DESC) AS rank_position
FROM analyst_metrics
GROUP BY office
ORDER BY composite_score DESC;`;
      }
    } else if (selectedRankingTab === 'vendor') {
      if (codeLanguage === 'typescript') {
        if (codeType === 'data') {
          return `// Dynamic Vendor Rankings Compiled Dataset
export interface VendorRankingRecord {
  vendor: string;
  errors: number;
  possiblePoints: number;
  errorRate: number;
  avgFinalScore: number;
  recordsCount: number;
}

export const VENDOR_RANKINGS_DATA: VendorRankingRecord[] = \n${JSON.stringify(vendorRankings, null, 2)};`;
        } else {
          return `// Vendor Quality Ranking Calculation Utility
export interface RawInvoiceRecord {
  vendor_name: string;
  errors: number;
  possible_error_points: number;
  final_score: number;
}

/**
 * Ranks vendors based on lowest error rate (Best quality).
 */
export function calculateVendorRankings(records: RawInvoiceRecord[]): any[] {
  const map = new Map<string, {
    vendor: string;
    errors: number;
    possiblePoints: number;
    recordsCount: number;
    totalFinalScore: number;
  }>();

  records.forEach(r => {
    const key = (r.vendor_name || 'unknown').toLowerCase().trim();
    const item = map.get(key) || {
      vendor: r.vendor_name,
      errors: 0,
      possiblePoints: 0,
      recordsCount: 0,
      totalFinalScore: 0
    };
    item.errors += r.errors;
    item.possiblePoints += r.possible_error_points;
    item.recordsCount += 1;
    item.totalFinalScore += r.final_score;
    map.set(key, item);
  });

  const list = Array.from(map.values()).map(item => {
    const errorRate = item.possiblePoints > 0 ? (item.errors / item.possiblePoints) * 100 : 0.0;
    const avgFinalScore = item.recordsCount > 0 ? item.totalFinalScore / item.recordsCount : 0.0;
    return {
      vendor: item.vendor,
      errors: item.errors,
      possiblePoints: item.possiblePoints,
      errorRate: Number(errorRate.toFixed(2)),
      avgFinalScore: Number(avgFinalScore.toFixed(1)),
      recordsCount: item.recordsCount
    };
  });

  // Sort by lowest error rate (optimal quality first)
  return list.sort((a, b) => a.errorRate - b.errorRate);
}`;
        }
      } else if (codeLanguage === 'python') {
        if (codeType === 'data') {
          return `# Python Vendor Rankings List of Dictionaries
vendor_rankings = \\
${JSON.stringify(vendorRankings, null, 4)}

# Output the highest quality vendors (lowest error rate)
print("--- TOP VENDORS BY QUALITY ---")
for idx, v in enumerate(vendor_rankings, 1):
    print(f"Rank {idx}: {v['vendor'].upper()} (Error Rate: {v['errorRate']}%, Avg Score: {v['avgFinalScore']})")`;
        } else {
          return `# Python Vendor Error Rate Analysis Engine
import pandas as pd

def compute_vendor_rankings(invoice_df: pd.DataFrame) -> pd.DataFrame:
    """
    Ranks vendors by quality (lowest error rate first).
    Required columns: ['vendor_name', 'errors', 'possible_error_points', 'final_score']
    """
    # Group by vendor
    grp = invoice_df.groupby('vendor_name').agg(
        records_count=('vendor_name', 'count'),
        total_errors=('errors', 'sum'),
        total_possible_points=('possible_error_points', 'sum'),
        sum_final_score=('final_score', 'sum')
    ).reset_index()

    # Calculate ratios
    grp['error_rate'] = (grp['total_errors'] / grp['total_possible_points'].replace(0, 1)) * 100
    grp['avg_final_score'] = grp['sum_final_score'] / grp['records_count']
    
    # Lower error rates are better
    return grp.sort_values(by='error_rate', ascending=True).reset_index(drop=True)`;
        }
      } else { // SQL
        return `-- PostgreSQL Query: Rank Vendor Audits by Quality (Lowest Error Rate First)

SELECT 
    vendor_name AS vendor,
    COUNT(id) AS records_count,
    SUM(errors) AS total_errors,
    SUM(possible_error_points) AS total_possible_points,
    ROUND(
        (SUM(errors)::numeric / NULLIF(SUM(possible_error_points), 0) * 100), 
        2
    ) AS error_rate,
    ROUND(AVG(final_score)::numeric, 1) AS avg_final_score,
    DENSE_RANK() OVER (ORDER BY (SUM(errors)::numeric / NULLIF(SUM(possible_error_points), 0)) ASC) AS vendor_rank
FROM analyst_records
GROUP BY vendor_name
ORDER BY error_rate ASC;`;
      }
    } else { // analyst
      if (codeLanguage === 'typescript') {
        if (codeType === 'data') {
          return `// Combined Analyst Rankings compiled from Scorecard & IPA datasets
export interface AnalystRankingRecord {
  name: string;
  office: string;
  points: number;
  tasks: number;
  errors: number;
  reviews: number;
  isIpa: boolean;
  isScorecard: boolean;
  errorRate: number;
  compositeScore: number;
}

export const ANALYST_RANKINGS_DATA: AnalystRankingRecord[] = \\
${JSON.stringify(analystRankings.slice(0, 15), null, 2)};`;
        } else {
          return `// Combined Analyst Composite Rankings Calculation Engine
export interface ScorecardRecord {
  user: string;
  office: string;
  points: number;
  initialMistakes: number;
  reconcileMistakes: number;
  finalMistakes: number;
  initialReview: number;
  reconcile: number;
  finalReview: number;
}

export interface IpaRecord {
  name: string;
  team: string;
  tasks: number;
}

/**
 * Combines Legacy Scorecards and modern IPA tasks into a single composite leaderboard.
 * Composite Score = PerformancePoints + (TasksProcessed * 0.5)
 */
export function calculateAnalystLeaderboard(scorecards: ScorecardRecord[], ipas: IpaRecord[]): any[] {
  const map = new Map<string, any>();

  scorecards.forEach(r => {
    const key = r.user.toLowerCase().trim();
    const item = map.get(key) || {
      name: r.user,
      office: r.office,
      points: 0,
      tasks: 0,
      errors: 0,
      reviews: 0,
      isIpa: false,
      isScorecard: true,
    };
    item.points += r.points;
    item.errors += (r.initialMistakes + r.reconcileMistakes + r.finalMistakes);
    item.reviews += (r.initialReview + r.reconcile + r.finalReview);
    item.isScorecard = true;
    map.set(key, item);
  });

  ipas.forEach(r => {
    const key = r.name.toLowerCase().trim();
    const item = map.get(key) || {
      name: r.name,
      office: r.team,
      points: 0,
      tasks: 0,
      errors: 0,
      reviews: 0,
      isIpa: true,
      isScorecard: false,
    };
    item.tasks += r.tasks;
    item.isIpa = true;
    map.set(key, item);
  });

  const list = Array.from(map.values()).map(item => {
    const errorRate = item.reviews > 0 ? (item.errors / item.reviews) * 100 : 0.0;
    const compositeScore = item.points + (item.tasks * 0.5);
    return {
      ...item,
      errorRate: Number(errorRate.toFixed(2)),
      compositeScore: Number(compositeScore.toFixed(3)),
    };
  });

  return list.sort((a, b) => b.compositeScore - a.compositeScore);
}`;
        }
      } else if (codeLanguage === 'python') {
        if (codeType === 'data') {
          return `# Top 15 Combined Analyst Leaderboard
analyst_leaderboard = \\
${JSON.stringify(analystRankings.slice(0, 15), null, 4)}

# Display current top 10 stars
print("--- TOP 10 STAR ANALYSTS ---")
for idx, a in enumerate(analyst_leaderboard[:10], 1):
    print(f"Rank {idx}: @{a['name']} ({a['office']}) - Score: {a['compositeScore']} (Error Rate: {a['errorRate']}%)")`;
        } else {
          return `# Python Analyst Aggregator Leaderboard Algorithm
def build_analyst_leaderboard(scorecards, ipa_tasks):
    """
    Groups and calculates composite metrics for analysts across both sources.
    scorecards: list of dicts with keys ['user', 'office', 'points', 'mistakes', 'reviews']
    ipa_tasks: list of dicts with keys ['name', 'team', 'tasks']
    """
    analysts = {}
    
    # Process Legacy Scorecards
    for s in scorecards:
        key = s['user'].lower().strip()
        if key not in analysts:
            analysts[key] = {
                'name': s['user'], 'office': s['office'],
                'points': 0, 'tasks': 0, 'errors': 0, 'reviews': 0
            }
        analysts[key]['points'] += s['points']
        analysts[key]['errors'] += s.get('mistakes', 0)
        analysts[key]['reviews'] += s.get('reviews', 0)
        
    # Process IPA Tasks
    for i in ipa_tasks:
        key = i['name'].lower().strip()
        if key not in analysts:
            analysts[key] = {
                'name': i['name'], 'office': i['team'],
                'points': 0, 'tasks': 0, 'errors': 0, 'reviews': 0
            }
        analysts[key]['tasks'] += i['tasks']
        
    # Convert and calculate scores
    leaderboard = []
    for key, data in analysts.items():
        err_rate = (data['errors'] / data['reviews'] * 100) if data['reviews'] > 0 else 0.0
        comp_score = data['points'] + (data['tasks'] * 0.5)
        
        leaderboard.append({
            'name': data['name'],
            'office': data['office'],
            'points': data['points'],
            'tasks': data['tasks'],
            'error_rate': round(err_rate, 2),
            'composite_score': round(comp_score, 3)
        })
        
    return sorted(leaderboard, key=lambda x: x['composite_score'], reverse=True)`;
        }
      } else { // SQL
        return `-- PostgreSQL Unified Analyst Leaderboard
-- Combines points scorecard and daily task metrics with full pagination ranking

WITH combined_metrics AS (
    SELECT 
        COALESCE(sc.user_login, ipa.analyst_login) AS analyst_name,
        COALESCE(sc.office, ipa.team) AS office_location,
        COALESCE(SUM(sc.points), 0) AS total_points,
        COALESCE(SUM(ipa.tasks), 0) AS total_tasks,
        COALESCE(SUM(sc.errors), 0) AS total_errors,
        COALESCE(SUM(sc.reviews), 0) AS total_reviews
    FROM scorecard_data sc
    FULL OUTER JOIN ipa_records ipa ON LOWER(sc.user_login) = LOWER(ipa.analyst_login)
    GROUP BY COALESCE(sc.user_login, ipa.analyst_login), COALESCE(sc.office, ipa.team)
)
SELECT 
    analyst_name,
    office_location,
    total_points,
    total_tasks,
    ROUND(
        CASE WHEN total_reviews > 0 THEN (total_errors::numeric / total_reviews * 100) ELSE 0 END, 
        2
    ) AS error_rate,
    ROUND(
        (total_points + (total_tasks * 0.5))::numeric, 
        3
    ) AS composite_score,
    DENSE_RANK() OVER (ORDER BY (total_points + (total_tasks * 0.5)) DESC) AS leaderboard_rank
FROM combined_metrics
ORDER BY composite_score DESC;`;
      }
    }
  }, [selectedRankingTab, codeLanguage, codeType, teamRankings, vendorRankings, analystRankings]);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(generatedCodeSnippet);
    setCodeCopied(true);
    setTimeout(() => setCodeCopied(false), 2000);
  };

  // Global search compilation across both PDF Scorecard & IPA datasets
  const globalAnalysts = useMemo(() => {
    const list: { name: string; source: 'Scorecard' | 'IPA' | 'Both'; location: string; points?: number; tasks?: number }[] = [];
    
    pdfRecords.forEach(pdf => {
      const ipaMatch = ipaList.find(ipa => ipa.name.toLowerCase() === pdf.user.toLowerCase());
      list.push({
        name: pdf.user,
        source: ipaMatch ? 'Both' : 'Scorecard',
        location: pdf.office,
        points: pdf.points,
        tasks: ipaMatch?.tasks
      });
    });

    ipaList.forEach(ipa => {
      if (!list.some(l => l.name.toLowerCase() === ipa.name.toLowerCase())) {
        list.push({
          name: ipa.name,
          source: 'IPA',
          location: ipa.team,
          tasks: ipa.tasks
        });
      }
    });

    return list;
  }, [pdfRecords, ipaList]);

  const globalSearchResults = useMemo(() => {
    if (!globalSearchQuery.trim()) return [];
    const q = globalSearchQuery.toLowerCase().trim();
    return globalAnalysts.filter(a => 
      a.name.toLowerCase().includes(q) || 
      a.location.toLowerCase().includes(q)
    );
  }, [globalAnalysts, globalSearchQuery]);

  const handleSelectGlobalAnalyst = (analyst: typeof globalAnalysts[0]) => {
    // Reset location and team filters so they are not filtered out
    setSelectedPdfLocation('All');
    setSelectedLocation('All');
    setSelectedLead('All');

    // Set them as selected across both PDF Scorecard and IPA views
    const nameLower = analyst.name.toLowerCase();
    setSelectedPdfAnalystName(nameLower);
    setSelectedIpaAnalyst(nameLower);

    // Clear query and hide results
    setGlobalSearchQuery('');
    setShowGlobalSearchResults(false);

    // Switch activeTab to display their detailed view!
    if (activeTab === 'LEGACY_ORIGINAL') {
      if (analyst.source === 'IPA') {
        setActiveTab('IPA');
      } else {
        setActiveTab('LEGACY');
      }
    } else if (activeTab === 'LEGACY' && analyst.source === 'IPA') {
      setActiveTab('IPA');
    } else if (activeTab === 'IPA' && analyst.source === 'Scorecard') {
      setActiveTab('LEGACY');
    }
  };

  const uniqueLocations = useMemo(() => {
    return ['All', 'Chandigarh', 'Dhaka', 'Havana', 'US'];
  }, []);

  const filteredIpaList = useMemo(() => {
    if (selectedLocation === 'All') return ipaList;
    return ipaList.filter(item => item.team.toLowerCase() === selectedLocation.toLowerCase());
  }, [ipaList, selectedLocation]);

  const filteredIpaRankingList = useMemo(() => {
    return [...filteredIpaList].sort((a, b) => b.tasks - a.tasks);
  }, [filteredIpaList]);

  useEffect(() => {
    if (selectedLocation !== 'All') {
      const isCurrentInFiltered = filteredIpaRankingList.some(
        item => item.name.toLowerCase() === selectedIpaAnalyst.toLowerCase()
      );
      if (!isCurrentInFiltered && filteredIpaRankingList.length > 0) {
        setSelectedIpaAnalyst(filteredIpaRankingList[0].name);
      }
    }
  }, [selectedLocation, filteredIpaRankingList, selectedIpaAnalyst]);

  const activeIpaAnalyst = useMemo(() => {
    const found = ipaList.find(item => item.name.toLowerCase() === selectedIpaAnalyst.toLowerCase());
    return found || ipaList[0] || { id: 'default', name: 'salesh_salaria', team: 'Alpha', tasks: 942 };
  }, [ipaList, selectedIpaAnalyst]);

  const totalIpaTasks = useMemo(() => {
    return ipaList.reduce((acc, item) => acc + item.tasks, 0);
  }, [ipaList]);

  const escalatedTasksCount = useMemo(() => {
    return Math.floor(totalIpaTasks * 0.065) || 42;
  }, [totalIpaTasks]);

  const sessionEndTasksCount = useMemo(() => {
    return Math.floor(totalIpaTasks * 0.14) || 98;
  }, [totalIpaTasks]);

  const ipaRankingList = useMemo(() => {
    return [...ipaList].sort((a, b) => b.tasks - a.tasks);
  }, [ipaList]);

  const ipaGraphData = useMemo(() => {
    const baseTasks = activeIpaAnalyst.tasks;
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const multipliers = [0.95, 1.05, 1.15, 0.90, 1.10, 0.80, 0.95];
    return days.map((day, idx) => {
      const dailyTasks = Math.floor((baseTasks / 5) * multipliers[idx]);
      const accuracy = 95 + Number((multipliers[idx] * 4).toFixed(1));
      return {
        day,
        Tasks: dailyTasks,
        Accuracy: Math.min(accuracy, 100),
        Escalated: Math.floor(dailyTasks * 0.05)
      };
    });
  }, [activeIpaAnalyst]);

  const [newAnalystName, setNewAnalystName] = useState('');
  const [newAnalystTeam, setNewAnalystTeam] = useState('Chandigarh');
  const [newAnalystTasks, setNewAnalystTasks] = useState(150);

  const handleAddIpaAnalyst = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAnalystName.trim()) return;
    
    const nameLower = newAnalystName.trim().toLowerCase();
    const existing = ipaList.find(item => item.name.toLowerCase() === nameLower);
    if (existing) {
      alert(`Analyst with login "${nameLower}" already exists!`);
      setSelectedIpaAnalyst(nameLower);
      setSelectedPdfAnalystName(nameLower);
      setNewAnalystName('');
      return;
    }

    const tasksNum = Number(newAnalystTasks) || 150;
    const newAnalyst = {
      id: `ipa-custom-${Date.now()}`,
      name: nameLower,
      team: newAnalystTeam,
      tasks: tasksNum
    };
    
    setCustomIpaRecords(prev => [newAnalyst, ...prev]);
    setSelectedIpaAnalyst(newAnalyst.name);

    // Register also in PDF Spreadsheet Scorecard with initial data
    const newPdfRecord: PdfSpreadsheetRecord = {
      id: `pdf-custom-${Date.now()}`,
      user: nameLower,
      office: newAnalystTeam,
      points: Number((tasksNum * 2.87).toFixed(3)),
      initialReview: Math.floor(tasksNum * 0.4),
      irAvgTime: 0.72,
      initialMistakes: 1,
      reconcile: Math.floor(tasksNum * 0.5),
      totalLines: Math.floor(tasksNum * 4.5),
      normalLines: Math.floor(tasksNum * 3.5),
      ediLines: Math.floor(tasksNum * 0.9),
      ocrLines: Math.floor(tasksNum * 0.1),
      recAvgTime: 3.15,
      reconcileMistakes: 1,
      finalReview: Math.floor(tasksNum * 0.1),
      frAvgTime: 1.45,
      finalMistakes: 0,
      qoRed: 0
    };
    setPdfRecords(prev => [newPdfRecord, ...prev]);
    setSelectedPdfAnalystName(nameLower);

    setNewAnalystName('');
    alert(`Analyst "${newAnalyst.name}" has been successfully registered to both Scorecard and Live Operations!`);
  };

  const [calendarYear, setCalendarYear] = useState(2026);
  const [calendarMonth, setCalendarMonth] = useState(6); // July (0-indexed, so 6 is July)

  const monthNames = useMemo(() => [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ], []);

  const calendarDays = useMemo(() => {
    const totalDays = new Date(calendarYear, calendarMonth + 1, 0).getDate();
    const startDayOfWeek = new Date(calendarYear, calendarMonth, 1).getDay();
    
    const daysArray = [];
    const prevMonthTotalDays = new Date(calendarYear, calendarMonth, 0).getDate();
    
    for (let i = startDayOfWeek - 1; i >= 0; i--) {
      daysArray.push({
        dayNumber: prevMonthTotalDays - i,
        isCurrentMonth: false,
        tasks: 0,
        hours: 0,
        status: 'Off'
      });
    }
    
    const analystSeed = activeIpaAnalyst.name.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0);
    
    for (let i = 1; i <= totalDays; i++) {
      const dayOfWeek = (startDayOfWeek + i - 1) % 7;
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
      
      let dayTasks = 0;
      let status = 'Completed';
      
      if (!isWeekend) {
        const seedMultiplier = ((analystSeed * i) % 15) + 15; // 15 to 30
        dayTasks = Math.floor((activeIpaAnalyst.tasks / 22) * (seedMultiplier / 22));
        if (dayTasks < 5) dayTasks = Math.floor(Math.random() * 15) + 12;
        status = dayTasks > 45 ? 'Peak Load' : 'Normal';
      } else {
        if ((i + analystSeed) % 5 === 0) {
          dayTasks = Math.floor(activeIpaAnalyst.tasks / 35) || 5;
          status = 'Overtime';
        } else {
          dayTasks = 0;
          status = 'Rest Day';
        }
      }
      
      daysArray.push({
        dayNumber: i,
        isCurrentMonth: true,
        tasks: dayTasks,
        hours: dayTasks > 0 ? Number((4 + (dayTasks % 5)).toFixed(1)) : 0,
        status
      });
    }
    
    const remainingSlots = 42 - daysArray.length;
    for (let i = 1; i <= remainingSlots; i++) {
      daysArray.push({
        dayNumber: i,
        isCurrentMonth: false,
        tasks: 0,
        hours: 0,
        status: 'Off'
      });
    }
    
    return daysArray;
  }, [calendarYear, calendarMonth, activeIpaAnalyst]);

  const startTroubleshooting = () => {
    setResolutionStatus('resolving');
    setResolutionProgress(10);
    
    const interval = setInterval(() => {
      setResolutionProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setResolutionStatus('resolved');
          return 100;
        }
        return prev + 15;
      });
    }, 300);
  };

  // Sorting logic for Main table
  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const sortedRecords = useMemo(() => {
    let result = [...INITIAL_ANALYST_RECORDS];
    
    // Filter
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(r => 
        r.analyst_login.toLowerCase().includes(q) || 
        r.team_lead_name.toLowerCase().includes(q) || 
        r.vendor_name.toLowerCase().includes(q)
      );
    }

    if (selectedLead !== 'All') {
      result = result.filter(r => r.team_lead_name.toLowerCase() === selectedLead.toLowerCase());
    }

    // Sort
    result.sort((a: any, b: any) => {
      let valA = a[sortField];
      let valB = b[sortField];

      if (typeof valA === 'string') {
        return sortDirection === 'asc' 
          ? valA.localeCompare(valB) 
          : valB.localeCompare(valA);
      } else {
        return sortDirection === 'asc' 
          ? valA - valB 
          : valB - valA;
      }
    });

    return result;
  }, [searchQuery, selectedLead, sortField, sortDirection]);

  // Chart data formatting
  const performanceTrendData = [
    { name: 'June 20', 'Avg Score': 188, 'Target': 190, 'Error Rate': 0.42 },
    { name: 'June 21', 'Avg Score': 192, 'Target': 190, 'Error Rate': 0.38 },
    { name: 'June 22', 'Avg Score': 185, 'Target': 190, 'Error Rate': 0.48 },
    { name: 'June 23', 'Avg Score': 195, 'Target': 190, 'Error Rate': 0.40 },
    { name: 'June 24', 'Avg Score': 176, 'Target': 190, 'Error Rate': 0.50 },
    { name: 'June 25', 'Avg Score': 183, 'Target': 190, 'Error Rate': 0.45 }
  ];

  return (
    <div className="bg-[#f8f9ff] text-[#191c20] font-sans min-h-screen flex">
      {/* Sidebar Navigation */}
      <aside className="w-64 bg-[#001d33] text-[#c2e7ff] flex flex-col fixed inset-y-0 left-0 z-40">
        <div className="p-6 border-b border-white/10 flex items-center gap-3">
          <span className="p-2 rounded bg-primary text-on-primary">
            <Award className="w-5 h-5" />
          </span>
          <div>
            <h1 className="font-headline text-md font-bold text-white tracking-tight leading-none">MarginEdge Pro</h1>
            <span className="text-[10px] text-white/60 tracking-wider font-bold uppercase">Analytics Platform</span>
          </div>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-1.5">
          <button 
            onClick={() => onNavigate('LIVE_SYNC_DASHBOARD')}
            className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold hover:bg-white/10 transition-colors text-left text-white/70"
          >
            <Layers className="w-4 h-4" />
            <span>Live Sync Panel</span>
          </button>
          
          {(userPosition === 'Admin' || userPosition === 'AM') && (
            <button 
              onClick={() => onNavigate('PRECISION_OPS_DASHBOARD')}
              className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold hover:bg-white/10 transition-colors text-left text-white/70"
            >
              <Layers className="w-4 h-4" />
              <span>Invoice Manager</span>
            </button>
          )}

          <button 
            onClick={() => onNavigate('DETAILED_PORTFOLIO_LOGS')}
            className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold hover:bg-white/10 transition-colors text-left text-white/70"
          >
            <Layers className="w-4 h-4" />
            <span>Detailed Reports</span>
          </button>

          {(userPosition === 'Admin' || userPosition === 'AM') && (
            <button 
              onClick={() => onNavigate('GMAIL_DASHBOARD')}
              className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold hover:bg-white/10 transition-colors text-left text-white/70"
            >
              <Layers className="w-4 h-4" />
              <span>Gmail Gateway</span>
            </button>
          )}

          <button 
            onClick={() => onNavigate('GOOGLE_CHAT_DASHBOARD')}
            className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold hover:bg-white/10 transition-colors text-left text-white/70"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Google Chat Team</span>
          </button>

          {(userPosition === 'Admin' || userPosition === 'AM' || userPosition === 'Team Lead' || userPosition === 'Lead') && (
            <button 
              onClick={() => onNavigate('PRESENTATION_DECK')}
              className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold bg-gradient-to-r from-indigo-500/10 to-purple-500/10 text-purple-300 hover:from-indigo-500/20 transition-colors border-l-2 border-purple-500 text-left"
            >
              <Layers className="w-4 h-4" />
              <span>Presentation & Video</span>
            </button>
          )}

          <div className="pt-4 border-t border-white/10 my-4">
            <span className="text-[9px] font-bold text-white/40 uppercase tracking-widest px-3 block mb-2">Conversion Utilities</span>
            <button 
              onClick={() => onNavigate('EXCEL_PARSER_UTILITY')}
              className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-black hover:bg-white/10 text-white/90 transition-colors text-left"
            >
              <FileSpreadsheet className="w-4 h-4 text-[#2997ff]" />
              <span>Excel to JSON Tool</span>
            </button>
          </div>

          <div className="pt-4 border-t border-white/10 my-4">
            <span className="text-[9px] font-bold text-white/40 uppercase tracking-widest px-3 block mb-2">Operational Analytics</span>
            <button 
              className="w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-semibold bg-[#004a77] text-white transition-colors text-left"
            >
              <Award className="w-4 h-4" />
              <span>Analyst Scoring (IPA/Legacy)</span>
            </button>
          </div>
        </nav>

        {/* User profile card */}
        <div className="p-4 border-t border-white/10 bg-black/20 text-left">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-primary text-on-primary flex items-center justify-center font-bold text-xs uppercase shadow-sm">
              {userName ? userName.split(' ').map(n => n[0]).join('').slice(0, 2) : userEmail.charAt(0)}
            </div>
            <div className="overflow-hidden">
              <p className="text-[11px] font-bold text-white truncate leading-none mb-1">{userName || 'Ankit Thakur'}</p>
              <p className="text-[9px] text-[#c2e7ff]/80 truncate font-semibold leading-none mb-1">{userPosition || 'Lead'}</p>
              <p className="text-[8px] text-[#c2e7ff]/50 truncate font-mono">{userEmail}</p>
            </div>
          </div>
          <button 
            onClick={onLogout}
            className="w-full mt-3 py-1.5 px-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded text-[10px] uppercase tracking-wider transition-all text-center block"
          >
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 pl-64 flex flex-col min-h-screen">
        {/* Top Header navbar */}
        <header className="h-16 bg-white border-b border-[#c1c7d2] flex items-center justify-between px-6 sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-bold font-headline text-[#191c20] flex items-center gap-2">
              <Award className="w-5 h-5 text-primary" />
              <span>Analyst Quality &amp; Productivity Scoring (IPA &amp; Legacy)</span>
            </h2>
            <div className="flex items-center gap-1.5 bg-[#eff4ff] px-2.5 py-1 rounded-full border border-[#c1c7d2] hidden xl:flex">
              <span className="w-2 h-2 rounded-full bg-[#006d37] animate-pulse"></span>
              <span className="text-[10px] text-[#414752] font-bold uppercase tracking-wider">Metrics: Live Reconciled</span>
            </div>
          </div>

          {/* Global Analyst Search Input */}
          <div className="relative flex-1 max-w-xs mx-6 hidden md:block z-50">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search analyst by name..."
                value={globalSearchQuery}
                onChange={(e) => {
                  setGlobalSearchQuery(e.target.value);
                  setShowGlobalSearchResults(true);
                }}
                onFocus={() => setShowGlobalSearchResults(true)}
                className="w-full pl-9 pr-8 py-1.5 border border-slate-300 rounded-lg text-xs bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-all shadow-sm font-semibold text-[#191c20]"
              />
              {globalSearchQuery && (
                <button 
                  type="button"
                  onClick={() => {
                    setGlobalSearchQuery('');
                    setShowGlobalSearchResults(false);
                  }}
                  className="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-[11px] font-bold"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Dropdown list of matching search results */}
            {showGlobalSearchResults && globalSearchResults.length > 0 && (
              <>
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setShowGlobalSearchResults(false)}
                />
                <div className="absolute top-9 left-0 right-0 bg-white border border-slate-200 rounded-xl shadow-xl z-50 max-h-80 overflow-y-auto divide-y divide-slate-100 scrollbar-thin">
                  <div className="p-2 bg-slate-50 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-left">
                    Found {globalSearchResults.length} Matching Analysts
                  </div>
                  {globalSearchResults.map((analyst, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={() => handleSelectGlobalAnalyst(analyst)}
                      className="w-full px-3 py-2 hover:bg-slate-50 transition-colors flex items-center justify-between text-left text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-primary/10 text-primary flex items-center justify-center font-extrabold text-[10px] uppercase">
                          {analyst.name.slice(0, 2)}
                        </div>
                        <div>
                          <p className="font-bold text-[#191c20] capitalize">{analyst.name}</p>
                          <p className="text-[9px] text-slate-500 font-medium">📍 {analyst.location}</p>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <span className="inline-block px-1.5 py-0.5 rounded text-[9px] font-bold font-mono bg-slate-100 text-slate-600">
                          {analyst.points !== undefined ? `${analyst.points.toFixed(1)} pts` : `${analyst.tasks} tasks`}
                        </span>
                        <p className="text-[8px] text-slate-400 font-bold uppercase tracking-wider mt-0.5">
                          {analyst.source}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              </>
            )}

            {showGlobalSearchResults && globalSearchQuery && globalSearchResults.length === 0 && (
              <>
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setShowGlobalSearchResults(false)}
                />
                <div className="absolute top-9 left-0 right-0 bg-white border border-[#c1c7d2] rounded-xl shadow-xl p-4 text-center text-xs text-slate-500 font-medium z-50">
                  No analysts found matching "{globalSearchQuery}"
                </div>
              </>
            )}
          </div>

          <div className="flex items-center gap-4">
            <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200 overflow-x-auto scrollbar-none">
              <button 
                type="button"
                onClick={() => setActiveTab('LEGACY_ORIGINAL')}
                className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all whitespace-nowrap ${activeTab === 'LEGACY_ORIGINAL' ? 'bg-white text-primary shadow-sm font-extrabold' : 'text-[#414752] hover:text-[#191c20]'}`}
              >
                Legacy Metrics
              </button>
              <button 
                type="button"
                onClick={() => setActiveTab('LEGACY')}
                className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all whitespace-nowrap ${activeTab === 'LEGACY' ? 'bg-white text-primary shadow-sm font-extrabold' : 'text-[#414752] hover:text-[#191c20]'}`}
              >
                Location Scorecard (PDF)
              </button>
              <button 
                type="button"
                onClick={() => setActiveTab('IPA')}
                className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all whitespace-nowrap ${activeTab === 'IPA' ? 'bg-white text-primary shadow-sm font-extrabold' : 'text-[#414752] hover:text-[#191c20]'}`}
              >
                IPA Metrics
              </button>
              <button 
                type="button"
                onClick={() => setActiveTab('RANKINGS')}
                className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${activeTab === 'RANKINGS' ? 'bg-white text-primary shadow-sm font-extrabold border border-primary/20' : 'text-[#414752] hover:text-[#191c20]'}`}
              >
                <Trophy className="w-3.5 h-3.5 text-yellow-500 shrink-0" />
                <span>Rankings &amp; Return Code</span>
              </button>
            </div>
          </div>
        </header>

        {/* Dashboard Panels */}
        <div className="p-6 flex-1 space-y-6">
          {activeTab === 'LEGACY_ORIGINAL' ? (
            <>
              {/* Top Row: Metric Highlight Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
                <div className="bg-white border border-[#c1c7d2] rounded-xl p-6 shadow-sm relative overflow-hidden flex items-center justify-between">
                  <div className="text-left">
                    <p className="text-[11px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-1">
                      <span>Legacy Overall Error Rate</span>
                      <Info className="w-3.5 h-3.5 text-slate-400 cursor-help" title="Total errors / total points" />
                    </p>
                    <h3 className="text-3xl font-bold font-headline text-[#191c20] mt-2">0.5%</h3>
                    <span className="text-[10px] text-[#006d37] font-semibold mt-1 block">✓ Within safe threshold limits</span>
                  </div>
                  <div className="p-3 bg-red-50 text-red-600 rounded-xl">
                    <Percent className="w-6 h-6" />
                  </div>
                </div>

                <div className="bg-white border border-[#c1c7d2] rounded-xl p-6 shadow-sm relative overflow-hidden flex items-center justify-between">
                  <div className="text-left">
                    <p className="text-[11px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-1">
                      <span>Legacy Median Error Rate</span>
                      <Info className="w-3.5 h-3.5 text-slate-400 cursor-help" title="Median across analyst-days" />
                    </p>
                    <h3 className="text-3xl font-bold font-headline text-[#191c20] mt-2">0.4%</h3>
                    <span className="text-[10px] text-slate-500 mt-1 block">Consistent across Chandigarh and Dhaka hubs</span>
                  </div>
                  <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
                    <TrendingUp className="w-6 h-6" />
                  </div>
                </div>

                <div className="bg-white border border-[#c1c7d2] rounded-xl p-6 shadow-sm relative overflow-hidden flex items-center justify-between">
                  <div className="text-left">
                    <p className="text-[11px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-1">
                      <span>Legacy Total Errors</span>
                      <Info className="w-3.5 h-3.5 text-slate-400 cursor-help" title="Header + line-item + misc-charge errors" />
                    </p>
                    <h3 className="text-3xl font-bold font-headline text-red-600 mt-2">12.7k</h3>
                    <span className="text-[10px] text-red-500 font-semibold mt-1 block">⚠ 2.3% uptick on invoice header mismatches</span>
                  </div>
                  <div className="p-3 bg-orange-50 text-orange-600 rounded-xl">
                    <AlertCircle className="w-6 h-6" />
                  </div>
                </div>
              </div>

              {/* Main Content Splitting */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-left">
                
                {/* Left side: Main Listing of Analysts & scores */}
                <div className="lg:col-span-8 bg-white border border-[#c1c7d2] rounded-xl shadow-sm overflow-hidden flex flex-col">
                  <div className="p-5 border-b border-slate-100 flex flex-wrap items-center justify-between gap-4 bg-slate-50/50">
                    <h4 className="font-headline text-sm font-bold text-[#191c20] flex items-center gap-2 text-left">
                      <Users className="w-4 h-4 text-primary" />
                      <span>Legacy Quality &amp; Productivity Scoring By Analyst &amp; Date</span>
                    </h4>
                    
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                        <input 
                          type="text" 
                          placeholder="Search analyst..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-primary w-40"
                        />
                      </div>

                      <select 
                        value={selectedLead}
                        onChange={(e) => setSelectedLead(e.target.value)}
                        className="py-1.5 px-2.5 border border-slate-200 rounded-lg text-xs bg-white text-slate-700"
                      >
                        <option value="All">All Leads</option>
                        <option value="shivalika">shivalika</option>
                        <option value="pritika">pritika</option>
                        <option value="harish">harish</option>
                        <option value="abdulrahman">abdulrahman</option>
                        <option value="alok">alok</option>
                        <option value="ashish">ashish</option>
                      </select>
                    </div>
                  </div>

                  <div className="overflow-x-auto max-h-[450px] overflow-y-auto relative scrollbar-thin">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead className="sticky top-0 bg-slate-50 z-20 shadow-[0_1px_0_0_rgba(226,232,240,1)]">
                        <tr className="bg-slate-50 text-slate-600 font-bold">
                          <th className="p-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('compl_date')}>
                            Date <ArrowUpDown className="w-3 h-3 inline ml-1 text-slate-400" />
                          </th>
                          <th className="p-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('analyst_login')}>
                            Analyst <ArrowUpDown className="w-3 h-3 inline ml-1 text-slate-400" />
                          </th>
                          <th className="p-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('team_lead_name')}>
                            Team Lead <ArrowUpDown className="w-3 h-3 inline ml-1 text-slate-400" />
                          </th>
                          <th className="p-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('vendor_name')}>
                            Vendor <ArrowUpDown className="w-3 h-3 inline ml-1 text-slate-400" />
                          </th>
                          <th className="p-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('errors')}>
                            Errors <ArrowUpDown className="w-3 h-3 inline ml-1 text-slate-400" />
                          </th>
                          <th className="p-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('possible_error_points')}>
                            Possible Error Points <ArrowUpDown className="w-3 h-3 inline ml-1 text-slate-400" />
                          </th>
                          <th className="p-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('error_rate')}>
                            Error Rate <ArrowUpDown className="w-3 h-3 inline ml-1 text-slate-400" />
                          </th>
                          <th className="p-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('final_score')}>
                            Final Score <ArrowUpDown className="w-3 h-3 inline ml-1 text-slate-400" />
                          </th>
                          <th className="p-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('median_error_rate')}>
                            Median Error Rate <ArrowUpDown className="w-3 h-3 inline ml-1 text-slate-400" />
                          </th>
                          <th className="p-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('median_final_score')}>
                            Median Final Score <ArrowUpDown className="w-3 h-3 inline ml-1 text-slate-400" />
                          </th>
                          <th className="p-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('delta_from_median_error_rate')}>
                            Delta <ArrowUpDown className="w-3 h-3 inline ml-1 text-slate-400" />
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 bg-white">
                        {sortedRecords.map((rec, i) => (
                          <tr key={i} className="hover:bg-slate-50/80 transition-colors">
                            <td className="p-4 font-mono font-semibold text-slate-500 whitespace-nowrap">{rec.compl_date}</td>
                            <td className="p-4 font-semibold text-[#191c20] whitespace-nowrap">{rec.analyst_login}</td>
                            <td className="p-4 text-slate-600 capitalize whitespace-nowrap">{rec.team_lead_name}</td>
                            <td className="p-4 text-slate-600 uppercase font-mono whitespace-nowrap">{rec.vendor_name ? rec.vendor_name.replace(/_/g, ' ') : '--'}</td>
                            <td className="p-4 font-mono text-slate-700 font-bold whitespace-nowrap">
                              {rec.errors}
                            </td>
                            <td className="p-4 font-mono text-slate-500 font-medium whitespace-nowrap">
                              {rec.possible_error_points}
                            </td>
                            <td className="p-4 whitespace-nowrap">
                              <span className={`px-2 py-0.5 rounded font-bold font-mono ${rec.error_rate > 1.0 ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'}`}>
                                {rec.error_rate}%
                              </span>
                            </td>
                            <td className="p-4 font-bold font-mono text-slate-800 whitespace-nowrap">{rec.final_score}</td>
                            <td className="p-4 font-mono text-slate-500 whitespace-nowrap">{rec.median_error_rate}%</td>
                            <td className="p-4 font-mono text-slate-500 whitespace-nowrap">{rec.median_final_score}</td>
                            <td className="p-4 whitespace-nowrap">
                              <span className={`font-mono text-[11px] font-bold ${rec.delta_from_median_error_rate > 0 ? 'text-red-500' : 'text-green-500'}`}>
                                {rec.delta_from_median_error_rate > 0 ? `+${rec.delta_from_median_error_rate}%` : `${rec.delta_from_median_error_rate}%`}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Right side: Interactive charts & weekly matrices */}
                <div className="lg:col-span-4 space-y-6">
                  {/* Graph Card */}
                  <div className="bg-white border border-[#c1c7d2] rounded-xl p-5 shadow-sm">
                    <h4 className="font-headline text-sm font-bold text-[#191c20] mb-4 text-left flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-primary" />
                      <span>Legacy Score Reliability Trend</span>
                    </h4>
                    <div className="h-44 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={performanceTrendData}>
                          <defs>
                            <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#004a77" stopOpacity={0.2}/>
                              <stop offset="95%" stopColor="#004a77" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <XAxis dataKey="name" stroke="#888888" fontSize={10} tickLine={false} />
                          <YAxis domain={[150, 210]} stroke="#888888" fontSize={10} tickLine={false} />
                          <Tooltip />
                          <Area type="monotone" dataKey="Avg Score" stroke="#004a77" strokeWidth={2} fillOpacity={1} fill="url(#colorScore)" />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Diagnosing DB errors mimicking video */}
                  {resolutionStatus === 'unresolved' ? (
                    <div className="bg-red-50 border border-red-200 rounded-xl p-5 text-left space-y-3 shadow-sm relative overflow-hidden transition-all duration-300">
                      <div className="absolute top-2 right-2 text-red-200">
                        <ShieldAlert className="w-16 h-16" />
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping"></div>
                        <h4 className="font-headline text-xs font-bold text-red-800 uppercase tracking-widest">
                          Legacy Mistake Detail (Order Link)
                        </h4>
                      </div>

                      <p className="text-[11px] text-red-900 leading-relaxed font-mono bg-white/60 p-3 rounded border border-red-100">
                        <span className="font-bold block mb-1">❌ Data Error Detected:</span>
                        Error: COLUMN_NOT_FOUND: line 28:7: Column 'order_link' cannot be resolved or requester is not authorized to access requested resources
                      </p>

                      <div className="pt-2 flex items-center justify-between text-[10px] text-red-700 font-semibold">
                        <span>File Source: spreadsheet.xlsx</span>
                        <button 
                          onClick={startTroubleshooting}
                          className="bg-red-600 hover:bg-red-700 active:scale-95 text-white font-bold py-1.5 px-3 rounded uppercase tracking-wider text-[9px] shadow-sm cursor-pointer transition-all flex items-center gap-1.5 animate-bounce"
                        >
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" style={{ animationDuration: '3s' }} />
                          <span>Troubleshoot Error</span>
                        </button>
                      </div>
                    </div>
                  ) : resolutionStatus === 'resolving' ? (
                    <div className="bg-[#001d33] text-white border border-[#004a77] rounded-xl p-5 text-left space-y-4 shadow-lg relative overflow-hidden transition-all duration-300">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <RefreshCw className="w-4 h-4 text-primary animate-spin" />
                          <h4 className="font-headline text-xs font-bold text-[#c2e7ff] uppercase tracking-widest">
                            Executing Schema Fix...
                          </h4>
                        </div>
                        <span className="text-xs font-mono font-bold text-[#c2e7ff]">{resolutionProgress}%</span>
                      </div>

                      <div className="space-y-1.5 font-mono text-[10px] text-slate-300 bg-black/40 p-3 rounded border border-white/10">
                        <p className="text-green-400">⚡ [INIT] Troubleshooting agent triggered...</p>
                        <p className="text-slate-300">⚡ [SCAN] Reading 'spreadsheet.xlsx' columns...</p>
                        {resolutionProgress >= 40 && (
                          <p className="text-blue-300">⚡ [MAP] Found raw mismatch in line 28, index 7.</p>
                        )}
                        {resolutionProgress >= 70 && (
                          <p className="text-yellow-300">⚡ [MUTATION] Inserting mapped column 'order_link' into virtual scheme...</p>
                        )}
                        {resolutionProgress >= 100 && (
                          <p className="text-green-400">✓ [VALIDATE] Validation succeeded. Safe state reached.</p>
                        )}
                      </div>

                      {/* Progress bar */}
                      <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                        <div 
                          className="bg-[#0091ff] h-1.5 rounded-full transition-all duration-300"
                          style={{ width: `${resolutionProgress}%` }}
                        ></div>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-green-50 border border-green-200 rounded-xl p-5 text-left space-y-3.5 shadow-sm relative overflow-hidden transition-all duration-300">
                      <div className="absolute top-2 right-2 text-green-200">
                        <CheckCircle className="w-16 h-16" />
                      </div>

                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-[#006d37]" />
                        <h4 className="font-headline text-xs font-bold text-green-800 uppercase tracking-widest">
                          Error Resolved Successfully
                        </h4>
                      </div>

                      <div className="text-[11px] text-green-900 leading-relaxed font-mono bg-white/80 p-3 rounded border border-green-100">
                        <span className="font-bold block mb-1 text-[#006d37]">✓ Schema Mapped &amp; Saved:</span>
                        Database column <code className="bg-green-100 px-1 py-0.5 rounded text-xs font-bold text-[#006d37]">'order_link'</code> has been dynamically mapped from spreadsheet spreadsheet.xlsx.
                        <p className="mt-2 text-[10px] text-slate-500 font-sans">All legacy data references are successfully authenticated.</p>
                      </div>

                      <div className="pt-1.5 flex items-center justify-between text-[10px] text-green-700 font-semibold">
                        <span>Status: 100% Synced</span>
                        <button 
                          type="button"
                          onClick={() => setResolutionStatus('unresolved')}
                          className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold py-1 px-2.5 rounded uppercase tracking-wider text-[9px] cursor-pointer transition-all"
                        >
                          Reset Demo
                        </button>
                      </div>
                    </div>
                  )}
                </div>

              </div>

              {/* Row 3: Weekly Error Rate table by Analyst */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-left">
                
                {/* Weekly Error Rate Grid (5 columns wide) */}
                <div className="lg:col-span-5 bg-white border border-[#c1c7d2] rounded-xl shadow-sm overflow-hidden flex flex-col">
                  <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                    <h4 className="font-headline text-xs font-bold text-[#191c20] uppercase tracking-wider text-left flex items-center gap-2">
                      <Layers className="w-4 h-4 text-primary" />
                      <span>Legacy Error Rate By Analyst &amp; Week</span>
                    </h4>
                  </div>
                  <div className="overflow-x-auto max-h-[350px] overflow-y-auto scrollbar-thin">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead className="sticky top-0 bg-slate-50 z-10 shadow-[0_1px_0_0_rgba(226,232,240,1)]">
                        <tr className="bg-slate-50 text-slate-600 font-bold">
                          <th className="p-3">Analyst</th>
                          <th className="p-3">W1</th>
                          <th className="p-3">W2</th>
                          <th className="p-3">W3</th>
                          <th className="p-3">W4</th>
                          <th className="p-3">W5</th>
                          <th className="p-3 bg-slate-100 text-[#191c20]">Avg</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 bg-white">
                        {WEEKLY_ERROR_RATES.map((row, i) => (
                          <tr key={i} className="hover:bg-slate-50/50 transition-colors">
                            <td className="p-3 font-semibold text-[#191c20]">{row.analyst}</td>
                            <td className="p-3 font-mono text-slate-500">{row.w1}</td>
                            <td className="p-3 font-mono text-slate-500">{row.w2}</td>
                            <td className="p-3 font-mono text-slate-500">{row.w3}</td>
                            <td className="p-3 font-mono text-slate-500">{row.w4}</td>
                            <td className="p-3 font-mono text-slate-500">{row.w5}</td>
                            <td className="p-3 font-bold font-mono bg-slate-50/50 text-[#006d37]">{row.average}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Legacy Productivity & Final score group (7 columns wide) */}
                <div className="lg:col-span-7 bg-white border border-[#c1c7d2] rounded-xl shadow-sm overflow-hidden flex flex-col">
                  <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                    <h4 className="font-headline text-xs font-bold text-[#191c20] uppercase tracking-wider text-left flex items-center gap-2">
                      <Award className="w-4 h-4 text-primary" />
                      <span>Legacy Final Score &amp; Productivity Overview</span>
                    </h4>
                    <span className="text-[10px] bg-slate-100 px-2 py-1 rounded font-bold text-slate-600 font-mono">Formula: Prod * (1 - Error Rate)</span>
                  </div>

                  {/* Mini Cards Row inside */}
                  <div className="p-4 grid grid-cols-3 gap-4 border-b border-slate-100 bg-slate-50/30">
                    <div className="bg-white border border-slate-200 p-3.5 rounded-lg text-left shadow-sm">
                      <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block">Mean Final Score</span>
                      <span className="text-xl font-bold font-headline text-[#191c20] block mt-1">176.5</span>
                    </div>
                    <div className="bg-white border border-slate-200 p-3.5 rounded-lg text-left shadow-sm">
                      <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block">Mean Daily Score</span>
                      <span className="text-xl font-bold font-headline text-[#191c20] block mt-1">178.5</span>
                    </div>
                    <div className="bg-white border border-slate-200 p-3.5 rounded-lg text-left shadow-sm">
                      <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block">Median Daily Score</span>
                      <span className="text-xl font-bold font-headline text-[#191c20] block mt-1">113.5</span>
                    </div>
                  </div>

                  {/* Team Lead collapsable list */}
                  <div className="p-4 text-left">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2.5 block">Legacy Group Scoring By Team Lead</span>
                    <div className="space-y-2">
                      {TEAM_LEAD_METRICS.map((tl, index) => (
                        <div key={index} className="border border-slate-200 rounded-lg overflow-hidden bg-white shadow-sm">
                          <button 
                            type="button"
                            onClick={() => setActiveLeadRow(activeLeadRow === tl.team_lead ? null : tl.team_lead)}
                            className="w-full p-3 flex items-center justify-between text-xs hover:bg-slate-50 transition-colors cursor-pointer"
                          >
                            <div className="flex items-center gap-3">
                              <span className="font-bold text-[#191c20] capitalize">Lead: {tl.team_lead}</span>
                              <span className="bg-primary/10 text-primary font-bold px-1.5 py-0.5 rounded text-[10px]">{tl.lead_analysts} Analysts</span>
                            </div>
                            <div className="flex items-center gap-6">
                              <div>
                                <span className="text-[9px] uppercase tracking-wider text-slate-400 font-bold mr-1.5">Avg Score</span>
                                <span className="font-bold font-mono text-[#191c20]">{tl.avg_final_score}</span>
                              </div>
                              {activeLeadRow === tl.team_lead ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
                            </div>
                          </button>

                          {activeLeadRow === tl.team_lead && (
                            <div className="p-3 bg-slate-50/50 border-t border-slate-100 text-[11px] grid grid-cols-4 gap-4">
                              <div>
                                <span className="text-slate-400 block font-semibold">Avg Productivity</span>
                                <span className="font-bold font-mono text-[#191c20]">{tl.avg_productivity}</span>
                              </div>
                              <div>
                                <span className="text-slate-400 block font-semibold">Avg Error Rate</span>
                                <span className="font-bold font-mono text-red-600">{tl.avg_error_rate}%</span>
                              </div>
                              <div>
                                <span className="text-slate-400 block font-semibold">Target Delta</span>
                                <span className="font-bold font-mono text-green-600">+{tl.avg_delta}%</span>
                              </div>
                              <div>
                                <span className="text-slate-400 block font-semibold">Reliability Factor</span>
                                <span className="font-bold text-slate-800">High Reliability</span>
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

              </div>
            </>
          ) : activeTab === 'LEGACY' ? (
            <>
              {/* Scorecard Metric Highlight Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                {/* Total Points */}
                <div className="bg-white border border-[#c1c7d2] rounded-xl p-5 shadow-sm flex items-center justify-between hover:shadow-md transition-all">
                  <div className="text-left">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Total Points Generated</p>
                    <h3 className="text-3xl font-extrabold font-headline text-[#191c20] mt-2">
                      {scorecardHighlights.totalPoints.toLocaleString()}
                    </h3>
                    <span className="text-[10px] text-emerald-600 font-bold block mt-1">
                      ★ Active Location Value
                    </span>
                  </div>
                  <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
                    <Award className="w-6 h-6" />
                  </div>
                </div>

                {/* Total Lines Processed */}
                <div className="bg-white border border-[#c1c7d2] rounded-xl p-5 shadow-sm flex items-center justify-between hover:shadow-md transition-all">
                  <div className="text-left">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Total Lines Processed</p>
                    <h3 className="text-3xl font-extrabold font-headline text-[#191c20] mt-2">
                      {scorecardHighlights.totalLines.toLocaleString()}
                    </h3>
                    <span className="text-[10px] text-slate-500 block mt-1">
                      Normal + EDI + OCR items
                    </span>
                  </div>
                  <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
                    <Layers className="w-6 h-6" />
                  </div>
                </div>

                {/* Weighted Error Rate */}
                <div className="bg-white border border-[#c1c7d2] rounded-xl p-5 shadow-sm flex items-center justify-between hover:shadow-md transition-all">
                  <div className="text-left">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Average Error Rate</p>
                    <h3 className={`text-3xl font-extrabold font-headline mt-2 ${scorecardHighlights.avgErrorRate > 1.5 ? 'text-red-600' : 'text-emerald-600'}`}>
                      {scorecardHighlights.avgErrorRate}%
                    </h3>
                    <span className="text-[10px] font-bold block mt-1">
                      {scorecardHighlights.avgErrorRate > 1.5 ? (
                        <span className="text-red-500">⚠ Exceeds SLA threshold (1.5%)</span>
                      ) : (
                        <span className="text-emerald-600">✓ Within SLA safe limits</span>
                      )}
                    </span>
                  </div>
                  <div className="p-3 bg-rose-50 text-rose-600 rounded-xl">
                    <Percent className="w-6 h-6" />
                  </div>
                </div>

                {/* Top Performer */}
                <div className="bg-white border border-[#c1c7d2] rounded-xl p-5 shadow-sm flex items-center justify-between hover:shadow-md transition-all">
                  <div className="text-left overflow-hidden w-[70%]">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Top Hub Performer</p>
                    <h3 className="text-xl font-extrabold font-headline text-slate-800 mt-2 truncate capitalize">
                      @{scorecardHighlights.topAnalyst}
                    </h3>
                    <span className="text-[10px] text-amber-600 font-bold block mt-1 truncate">
                      🏆 {scorecardHighlights.topPoints} Points
                    </span>
                  </div>
                  <div className="p-3 bg-amber-50 text-amber-500 rounded-xl">
                    <Trophy className="w-6 h-6" />
                  </div>
                </div>
              </div>

              {/* Main Section Splitting */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Left Col (8 spans): Detailed PDF Spreadsheet Grid */}
                <div className="lg:col-span-8 bg-white border border-[#c1c7d2] rounded-xl shadow-sm overflow-hidden flex flex-col">
                  {/* Grid Header & Filters */}
                  <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex flex-col gap-4">
                    <div className="flex flex-wrap items-center justify-between gap-4">
                      <div className="text-left">
                        <h4 className="font-headline text-sm font-bold text-[#191c20] flex items-center gap-2">
                          <Sliders className="w-4 h-4 text-primary" />
                          <span>Detailed Location Performance Ledger</span>
                        </h4>
                        <p className="text-[11px] text-slate-500 mt-0.5">Parsed ledger from system documents (Chandigarh, Dhaka, Havana, US hubs)</p>
                      </div>

                      {/* Search box */}
                      <div className="relative">
                        <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                        <input 
                          type="text" 
                          placeholder="Search login / office..."
                          value={pdfSearchQuery}
                          onChange={(e) => setPdfSearchQuery(e.target.value)}
                          className="pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-primary w-48 bg-white"
                        />
                      </div>
                    </div>

                    {/* Clean Location Filter Selector */}
                    <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mr-2">Hub Filter:</span>
                        {['All', 'Chandigarh', 'Dhaka', 'Havana', 'US'].map((loc) => (
                          <button
                            key={loc}
                            onClick={() => setSelectedPdfLocation(loc)}
                            className={`px-3 py-1 rounded-full text-xs font-bold transition-all border ${
                              selectedPdfLocation === loc 
                                ? 'bg-primary text-white border-primary shadow-sm' 
                                : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300'
                            }`}
                          >
                            {loc === 'Chandigarh' ? 'Chandigarh (चंडीगढ़)' : loc === 'Dhaka' ? 'Dhaka (ढाका)' : loc}
                          </button>
                        ))}
                      </div>

                      <div className="text-[11px] font-medium text-slate-500">
                        Showing <strong className="text-slate-800">{filteredPdfRecords.length}</strong> entries
                      </div>
                    </div>
                  </div>

                  {/* Spreadsheet Grid Table */}
                  <div className="overflow-x-auto max-h-[500px] overflow-y-auto relative scrollbar-thin">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead className="sticky top-0 bg-slate-100 z-30 shadow-[0_1px_0_0_rgba(226,232,240,1)]">
                        <tr className="bg-slate-100 text-slate-600 font-bold select-none text-[10px] uppercase tracking-wider">
                          <th className="p-3 sticky left-0 bg-slate-100 z-40 border-r border-slate-200 min-w-[120px] shadow-[2px_0_5px_-2px_rgba(0,0,0,0.1)]">
                            Analyst User
                          </th>
                          <th className="p-3 cursor-pointer hover:bg-slate-200 transition-colors border-r border-slate-200" onClick={() => {
                            setPdfSortField('office');
                            setPdfSortDirection(pdfSortField === 'office' && pdfSortDirection === 'desc' ? 'asc' : 'desc');
                          }}>
                            Office {pdfSortField === 'office' && (pdfSortDirection === 'desc' ? '▼' : '▲')}
                          </th>
                          <th className="p-3 cursor-pointer hover:bg-slate-200 transition-colors border-r border-slate-200 text-right font-mono" onClick={() => {
                            setPdfSortField('points');
                            setPdfSortDirection(pdfSortField === 'points' && pdfSortDirection === 'desc' ? 'asc' : 'desc');
                          }}>
                            Points {pdfSortField === 'points' && (pdfSortDirection === 'desc' ? '▼' : '▲')}
                          </th>
                          <th className="p-3 cursor-pointer hover:bg-slate-200 transition-colors border-r border-slate-200 text-right" onClick={() => {
                            setPdfSortField('initialReview');
                            setPdfSortDirection(pdfSortField === 'initialReview' && pdfSortDirection === 'desc' ? 'asc' : 'desc');
                          }}>
                            Initial Rev {pdfSortField === 'initialReview' && (pdfSortDirection === 'desc' ? '▼' : '▲')}
                          </th>
                          <th className="p-3 text-right text-slate-500">IR Avg T</th>
                          <th className="p-3 text-right text-red-500">IR Mist</th>
                          <th className="p-3 cursor-pointer hover:bg-slate-200 transition-colors text-right" onClick={() => {
                            setPdfSortField('reconcile');
                            setPdfSortDirection(pdfSortField === 'reconcile' && pdfSortDirection === 'desc' ? 'asc' : 'desc');
                          }}>
                            Reconcile {pdfSortField === 'reconcile' && (pdfSortDirection === 'desc' ? '▼' : '▲')}
                          </th>
                          <th className="p-3 text-right">Rec Avg T</th>
                          <th className="p-3 text-right text-red-500">Rec Mist</th>
                          <th className="p-3 text-right text-slate-500">Final Rev</th>
                          <th className="p-3 text-right text-slate-500">FR Avg T</th>
                          <th className="p-3 text-right text-red-500">FR Mist</th>
                          <th className="p-3 cursor-pointer hover:bg-slate-200 transition-colors border-l border-slate-200 text-right font-mono font-bold text-slate-800" onClick={() => {
                            setPdfSortField('totalLines');
                            setPdfSortDirection(pdfSortField === 'totalLines' && pdfSortDirection === 'desc' ? 'asc' : 'desc');
                          }}>
                            Tot Lines {pdfSortField === 'totalLines' && (pdfSortDirection === 'desc' ? '▼' : '▲')}
                          </th>
                          <th className="p-3 text-right text-slate-500">Normal L</th>
                          <th className="p-3 text-right text-slate-500">EDI Lines</th>
                          <th className="p-3 text-right text-slate-500">OCR Lines</th>
                          <th className="p-3 text-right text-red-500">Q o R ed</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredPdfRecords.length === 0 ? (
                          <tr>
                            <td colSpan={17} className="p-8 text-center text-slate-400 font-semibold bg-slate-50">
                              No analysts matched the filter criteria.
                            </td>
                          </tr>
                        ) : (
                          filteredPdfRecords.map((r) => {
                            const isSelected = r.user.toLowerCase() === selectedPdfAnalystName.toLowerCase();
                            const totalMistakes = r.initialMistakes + r.reconcileMistakes + r.finalMistakes;
                            const totalReviews = r.initialReview + r.reconcile + r.finalReview;
                            
                            return (
                              <tr 
                                key={r.id} 
                                onClick={() => setSelectedPdfAnalystName(r.user)}
                                className={`border-b border-slate-100 hover:bg-slate-50/80 transition-colors cursor-pointer text-left ${
                                  isSelected ? 'bg-primary/5 hover:bg-primary/5 font-medium' : ''
                                }`}
                              >
                                <td className={`p-3 sticky left-0 z-10 border-r border-slate-200 font-semibold min-w-[120px] shadow-[2px_0_5px_-2px_rgba(0,0,0,0.05)] capitalize ${
                                  isSelected ? 'bg-indigo-50/90 text-primary' : 'bg-white text-[#191c20]'
                                }`}>
                                  <div className="flex items-center gap-1.5">
                                    <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                                    <span>{r.user}</span>
                                  </div>
                                </td>
                                <td className="p-3 text-slate-600 border-r border-slate-200 font-medium">{r.office}</td>
                                <td className="p-3 text-right font-mono font-semibold text-primary border-r border-slate-200">
                                  {r.points.toFixed(3)}
                                </td>
                                <td className="p-3 text-right text-slate-700 border-r border-slate-100">{r.initialReview}</td>
                                <td className="p-3 text-right text-slate-500">{r.irAvgTime.toFixed(2)}s</td>
                                <td className={`p-3 text-right font-bold ${r.initialMistakes > 0 ? 'text-red-600 bg-red-50/40' : 'text-slate-400'}`}>
                                  {r.initialMistakes}
                                </td>
                                <td className="p-3 text-right text-slate-700 border-l border-r border-slate-100">{r.reconcile}</td>
                                <td className="p-3 text-right text-slate-500">{r.recAvgTime.toFixed(2)}s</td>
                                <td className={`p-3 text-right font-bold ${r.reconcileMistakes > 0 ? 'text-red-600 bg-red-50/40' : 'text-slate-400'}`}>
                                  {r.reconcileMistakes}
                                </td>
                                <td className="p-3 text-right text-slate-700 border-l border-slate-100">{r.finalReview}</td>
                                <td className="p-3 text-right text-slate-500">{r.frAvgTime.toFixed(2)}s</td>
                                <td className={`p-3 text-right font-bold ${r.finalMistakes > 0 ? 'text-red-600 bg-red-50/40' : 'text-slate-400'}`}>
                                  {r.finalMistakes}
                                </td>
                                <td className="p-3 text-right font-mono font-bold text-slate-800 border-l border-r border-slate-200 bg-slate-50/50">
                                  {r.totalLines}
                                </td>
                                <td className="p-3 text-right text-slate-600">{r.normalLines}</td>
                                <td className="p-3 text-right text-slate-600">{r.ediLines}</td>
                                <td className="p-3 text-right text-slate-600">{r.ocrLines}</td>
                                <td className={`p-3 text-right font-bold ${r.qoRed > 0 ? 'text-red-600 bg-red-50/60' : 'text-slate-400'}`}>
                                  {r.qoRed}
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>

                  <div className="p-4 bg-slate-50 border-t border-slate-100 text-left text-slate-500 text-[11px] flex justify-between items-center">
                    <span>💡 Pro-tip: Click any analyst row to analyze their weekly error rates &amp; mistake metrics on the right.</span>
                    <span className="font-semibold text-slate-700">Chandigarh Operational Desk</span>
                  </div>
                </div>

                {/* Right Col (4 spans): Dynamic Error Rate Visualizer & mistake charts */}
                <div className="lg:col-span-4 space-y-6">
                  {/* Selected Analyst Profile Card */}
                  {activePdfAnalyst ? (
                    <div className="bg-white border border-[#c1c7d2] rounded-xl p-5 shadow-sm text-left">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center font-extrabold text-sm uppercase shadow-sm">
                          {activePdfAnalyst.user.slice(0, 2)}
                        </div>
                        <div>
                          <h4 className="font-headline font-extrabold text-base text-[#191c20] capitalize">
                            {activePdfAnalyst.user}
                          </h4>
                          <span className="inline-block bg-primary/10 text-primary text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase mt-1">
                            📍 {activePdfAnalyst.office} Operational Hub
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4 mt-6 pt-6 border-t border-slate-100">
                        <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Performance Score</span>
                          <span className="text-xl font-black font-mono text-primary block mt-1">
                            {activePdfAnalyst.points.toFixed(3)}
                          </span>
                        </div>
                        <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Error Rate</span>
                          {(() => {
                            const mistakes = activePdfAnalyst.initialMistakes + activePdfAnalyst.reconcileMistakes + activePdfAnalyst.finalMistakes;
                            const reviews = activePdfAnalyst.initialReview + activePdfAnalyst.reconcile + activePdfAnalyst.finalReview;
                            const rate = reviews > 0 ? (mistakes / reviews) * 100 : 0;
                            return (
                              <span className={`text-xl font-black font-mono block mt-1 ${rate > 1.5 ? 'text-red-600' : 'text-emerald-600'}`}>
                                {rate.toFixed(2)}%
                              </span>
                            );
                          })()}
                        </div>
                      </div>

                      <div className="space-y-3 mt-4 pt-4 border-t border-slate-100 text-[11px]">
                        <div className="flex justify-between items-center">
                          <span className="text-slate-500 font-medium">Total Volume Lines:</span>
                          <span className="font-bold text-slate-800 font-mono">{activePdfAnalyst.totalLines} lines</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-500 font-medium">Initial Reviews:</span>
                          <span className="font-bold text-slate-800 font-mono">{activePdfAnalyst.initialReview} units</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-500 font-medium">Reconciliations:</span>
                          <span className="font-bold text-slate-800 font-mono">{activePdfAnalyst.reconcile} units</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-500 font-medium">Final Audited Reviews:</span>
                          <span className="font-bold text-slate-800 font-mono">{activePdfAnalyst.finalReview} units</span>
                        </div>
                      </div>
                    </div>
                  ) : null}

                  {/* Dynamic Error Rate Graph */}
                  <div className="bg-white border border-[#c1c7d2] rounded-xl p-5 shadow-sm text-left">
                    <div className="flex justify-between items-center mb-4">
                      <div>
                        <h4 className="font-headline font-bold text-xs text-[#191c20] uppercase tracking-wider">
                          Error Rate Weekly Trend
                        </h4>
                        <p className="text-[10px] text-slate-400 mt-0.5">Analyst's daily audit failure vs SLA limit</p>
                      </div>
                      <span className="text-[10px] bg-red-50 text-red-600 border border-red-100 px-2 py-0.5 rounded font-bold">
                        SLA Limit: 1.5%
                      </span>
                    </div>

                    <div className="h-48 relative z-10">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={pdfAnalystDailyTrend} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                          <XAxis dataKey="day" tick={{ fontSize: 9, fill: '#64748b' }} />
                          <YAxis tick={{ fontSize: 9, fill: '#64748b' }} unit="%" domain={[0, 'dataMax + 1']} />
                          <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                          <Line 
                            type="monotone" 
                            dataKey="Error Rate (%)" 
                            stroke="#dc2626" 
                            strokeWidth={3} 
                            dot={{ r: 4, strokeWidth: 2 }} 
                            activeDot={{ r: 6 }} 
                          />
                          <Line 
                            type="monotone" 
                            dataKey="Target Threshold (%)" 
                            stroke="#059669" 
                            strokeDasharray="5 5" 
                            strokeWidth={2} 
                            dot={false} 
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Productivity Line Type Breakdown */}
                  <div className="bg-white border border-[#c1c7d2] rounded-xl p-5 shadow-sm text-left">
                    <h4 className="font-headline font-bold text-xs text-[#191c20] uppercase tracking-wider mb-4">
                      Line Item Processing Mix
                    </h4>
                    
                    <div className="h-44 relative z-10">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart 
                          data={[
                            {
                              name: 'Lines',
                              'Normal': activePdfAnalyst?.normalLines || 0,
                              'EDI': activePdfAnalyst?.ediLines || 0,
                              'OCR': activePdfAnalyst?.ocrLines || 0
                            }
                          ]}
                          layout="vertical"
                          margin={{ top: 10, right: 10, left: -20, bottom: 5 }}
                        >
                          <XAxis type="number" tick={{ fontSize: 9, fill: '#64748b' }} />
                          <YAxis dataKey="name" type="category" tick={{ fontSize: 9, fill: '#64748b' }} />
                          <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
                          <Legend wrapperStyle={{ fontSize: '10px' }} />
                          <Bar dataKey="Normal" stackId="a" fill="#006cba" />
                          <Bar dataKey="EDI" stackId="a" fill="#818cf8" />
                          <Bar dataKey="OCR" stackId="a" fill="#f43f5e" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>

                    <div className="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-slate-100 text-center text-[10px]">
                      <div>
                        <span className="font-bold text-[#006cba] block">Normal</span>
                        <span className="font-medium text-slate-500">{activePdfAnalyst?.normalLines}</span>
                      </div>
                      <div>
                        <span className="font-bold text-[#818cf8] block">EDI</span>
                        <span className="font-medium text-slate-500">{activePdfAnalyst?.ediLines}</span>
                      </div>
                      <div>
                        <span className="font-bold text-[#f43f5e] block">OCR</span>
                        <span className="font-medium text-slate-500">{activePdfAnalyst?.ocrLines}</span>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </>
          ) : activeTab === 'IPA' ? (
            /* IPA TAB VIEW PANEL */
            <div className="space-y-6 animate-fade-in text-left">
              
              {/* Google Sheets Live Status / Connection Banner */}
              {googleSheetUrl ? (
                <div className="bg-green-50 border border-green-200 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm animate-fade-in">
                  <div className="flex items-center gap-3 text-left w-full sm:w-auto">
                    <div className="p-2 bg-[#006d37] text-white rounded-lg flex items-center justify-center shrink-0">
                      <span className="material-symbols-outlined text-[20px]">sync</span>
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-green-900 uppercase tracking-wider flex items-center gap-1.5">
                        <span>Live Synced Google Sheet Active</span>
                        <span className="bg-[#006d37] text-white text-[8px] font-extrabold px-1.5 py-0.5 rounded-full animate-pulse">AUTO-SYNC ON</span>
                      </h4>
                      <p className="text-xs text-green-800 leading-normal mt-0.5">
                        IPA metrics are being pulled automatically in real-time from: <a href={googleSheetUrl} target="_blank" rel="noreferrer" className="underline font-bold text-green-950 font-mono text-[10px] truncate max-w-xs sm:max-w-md inline-block align-bottom">{googleSheetUrl}</a>
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => onNavigate('LIVE_SYNC_DASHBOARD')}
                    className="w-full sm:w-auto bg-green-800 hover:bg-green-950 text-white font-bold text-xs px-3 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer shrink-0"
                  >
                    <span className="material-symbols-outlined text-[14px]">settings</span>
                    <span>Manage Sources</span>
                  </button>
                </div>
              ) : (
                <div className="bg-[#eff4ff] border border-[#c1c7d2] rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm animate-fade-in">
                  <div className="flex items-center gap-3 text-left w-full sm:w-auto">
                    <div className="p-2 bg-[#004a77] text-white rounded-lg flex items-center justify-center shrink-0">
                      <span className="material-symbols-outlined text-[20px]">cloud_sync</span>
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-primary uppercase tracking-wider">Link Google Sheet / Excel File</h4>
                      <p className="text-xs text-slate-600 leading-normal mt-0.5">
                        Automatically sync IPA weekly productivity and metrics with your Excel spreadsheet! Connect with Google Login and sync in one click.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => onNavigate('LIVE_SYNC_DASHBOARD')}
                    className="w-full sm:w-auto bg-[#004a77] hover:bg-primary text-white font-bold text-xs px-3.5 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer shrink-0 shadow-sm"
                  >
                    <span className="material-symbols-outlined text-[14px]">link</span>
                    <span>Link &amp; Login Sheet</span>
                  </button>
                </div>
              )}
              
              {/* IPA Overview Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="bg-white border border-[#c1c7d2] rounded-xl p-5 shadow-sm hover:shadow-md transition-all">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Top IPA Performer</span>
                      <span className="text-3xl font-extrabold font-headline text-[#191c20] block mt-2">
                        {ipaRankingList[0]?.tasks || 942} <span className="text-xs font-semibold text-slate-500">Tasks</span>
                      </span>
                    </div>
                    <span className="p-2.5 bg-yellow-50 text-yellow-600 rounded-lg">
                      <Trophy className="w-5 h-5" />
                    </span>
                  </div>
                  <span className="text-[10px] text-green-600 font-bold block mt-2 flex items-center gap-1">
                    <Flame className="w-3.5 h-3.5 inline animate-pulse" />
                    <span>Active Leader: @{ipaRankingList[0]?.name || 'salesh_salaria'}</span>
                  </span>
                </div>

                <div className="bg-white border border-[#c1c7d2] rounded-xl p-5 shadow-sm hover:shadow-md transition-all">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Dashboard Total Tasks</span>
                      <span className="text-3xl font-extrabold font-headline text-[#191c20] block mt-2">
                        {totalIpaTasks.toLocaleString()}
                      </span>
                    </div>
                    <span className="p-2.5 bg-blue-50 text-blue-600 rounded-lg">
                      <Layers className="w-5 h-5" />
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 block mt-2">
                    Across {ipaList.length} monitored IPA analysts
                  </span>
                </div>

                <div className="bg-white border border-[#c1c7d2] rounded-xl p-5 shadow-sm hover:shadow-md transition-all">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Escalated Tasks (AM)</span>
                      <span className="text-3xl font-extrabold font-headline text-red-600 block mt-2">
                        {escalatedTasksCount}
                      </span>
                    </div>
                    <span className="p-2.5 bg-red-50 text-red-600 rounded-lg">
                      <AlertCircle className="w-5 h-5" />
                    </span>
                  </div>
                  <span className="text-[10px] text-red-500 font-semibold block mt-2 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
                    <span>Action required on key SLA outliers</span>
                  </span>
                </div>

                <div className="bg-white border border-[#c1c7d2] rounded-xl p-5 shadow-sm hover:shadow-md transition-all">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Tasks at Session End</span>
                      <span className="text-3xl font-extrabold font-headline text-[#006d37] block mt-2">
                        {sessionEndTasksCount}
                      </span>
                    </div>
                    <span className="p-2.5 bg-green-50 text-green-600 rounded-lg">
                      <CheckCircle className="w-5 h-5" />
                    </span>
                  </div>
                  <span className="text-[10px] text-green-600 font-semibold block mt-2">
                    ✓ Evaluated &amp; ready for next shift handoff
                  </span>
                </div>
              </div>

              {/* Main Content Splitting */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Left Area: Graph & Calendar (Col 8) */}
                <div className="lg:col-span-8 space-y-6">
                  
                  {/* Interactive Productivity Graph */}
                  <div className="bg-white border border-[#c1c7d2] rounded-xl p-5 shadow-sm">
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
                      <div>
                        <h3 className="font-headline text-base font-bold text-[#191c20] flex items-center gap-2">
                          <TrendingUp className="w-5 h-5 text-primary" />
                          <span>IPA Weekly Productivity Trend</span>
                        </h3>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Showing output volume &amp; accuracy metrics for <strong className="text-primary font-bold">@{activeIpaAnalyst.name}</strong>
                        </p>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className="text-xs font-semibold text-slate-600">Select Analyst:</span>
                        <select 
                          value={selectedIpaAnalyst}
                          onChange={(e) => setSelectedIpaAnalyst(e.target.value)}
                          className="py-1.5 px-3 border border-slate-200 rounded-lg text-xs bg-white text-slate-800 focus:ring-1 focus:ring-primary focus:outline-none cursor-pointer font-bold font-mono"
                        >
                          {ipaList.map((analyst) => (
                            <option key={analyst.id} value={analyst.name}>
                              {analyst.name} ({analyst.team} - {analyst.tasks} tasks)
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Chart area */}
                    <div className="h-64 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={ipaGraphData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                          <defs>
                            <linearGradient id="colorTasks" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#004a77" stopOpacity={0.2}/>
                              <stop offset="95%" stopColor="#004a77" stopOpacity={0}/>
                            </linearGradient>
                            <linearGradient id="colorAccuracy" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#006d37" stopOpacity={0.2}/>
                              <stop offset="95%" stopColor="#006d37" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <XAxis 
                            dataKey="day" 
                            tick={{ fill: '#414752', fontSize: 10, fontWeight: 600 }}
                            axisLine={{ stroke: '#c1c7d2' }}
                          />
                          <YAxis 
                            tick={{ fill: '#414752', fontSize: 10 }}
                            axisLine={{ stroke: '#c1c7d2' }}
                          />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#ffffff', borderRadius: '12px', border: '1px solid #c1c7d2', fontSize: '12px' }}
                          />
                          <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                          <Area type="monotone" dataKey="Tasks" name="Tasks Processed" stroke="#004a77" strokeWidth={2.5} fillOpacity={1} fill="url(#colorTasks)" />
                          <Area type="monotone" dataKey="Accuracy" name="Accuracy %" stroke="#006d37" strokeWidth={2.5} fillOpacity={1} fill="url(#colorAccuracy)" />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Elegant Google Calendar work tracker widget */}
                  <div className="bg-white border border-[#c1c7d2] rounded-xl p-5 shadow-sm">
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 pb-4 border-b border-slate-100">
                      <div>
                        <h3 className="font-headline text-base font-bold text-[#191c20] flex items-center gap-2">
                          <Calendar className="w-5 h-5 text-primary" />
                          <span>Google Workload Calendar</span>
                        </h3>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Daily performance &amp; tasks processed by <strong className="text-primary font-bold">@{activeIpaAnalyst.name}</strong> in {monthNames[calendarMonth]} {calendarYear}
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <button 
                          onClick={() => {
                            if (calendarMonth === 0) {
                              setCalendarMonth(11);
                              setCalendarYear(prev => prev - 1);
                            } else {
                              setCalendarMonth(prev => prev - 1);
                            }
                          }}
                          className="w-8 h-8 rounded-lg border border-slate-200 hover:bg-slate-50 flex items-center justify-center text-slate-700 transition-all cursor-pointer"
                        >
                          <ChevronLeft className="w-4 h-4" />
                        </button>
                        <span className="text-xs font-bold font-headline bg-slate-100 px-3 py-1.5 rounded-lg text-slate-800 min-w-[120px] text-center">
                          {monthNames[calendarMonth]} {calendarYear}
                        </span>
                        <button 
                          onClick={() => {
                            if (calendarMonth === 11) {
                              setCalendarMonth(0);
                              setCalendarYear(prev => prev + 1);
                            } else {
                              setCalendarMonth(prev => prev + 1);
                            }
                          }}
                          className="w-8 h-8 rounded-lg border border-slate-200 hover:bg-slate-50 flex items-center justify-center text-slate-700 transition-all cursor-pointer"
                        >
                          <span className="material-symbols-outlined text-[16px]">chevron_right</span>
                        </button>
                      </div>
                    </div>

                    {/* Weekdays names */}
                    <div className="grid grid-cols-7 gap-2 mb-2 text-center">
                      {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d, i) => (
                        <span key={i} className="text-[10px] font-bold text-slate-400 uppercase tracking-wider py-1">
                          {d}
                        </span>
                      ))}
                    </div>

                    {/* Google Calendar days grid */}
                    <div className="grid grid-cols-7 gap-2">
                      {calendarDays.map((day, idx) => {
                        const hasTasks = day.isCurrentMonth && day.tasks > 0;
                        let cellBg = "bg-white border-slate-100";
                        let textColor = "text-slate-800";
                        
                        if (!day.isCurrentMonth) {
                          cellBg = "bg-slate-50 text-slate-300 border-transparent";
                          textColor = "text-slate-300";
                        } else if (day.tasks === 0) {
                          cellBg = "bg-orange-50/30 border-orange-200/50";
                        } else if (day.status === 'Peak Load') {
                          cellBg = "bg-green-50 border-green-300 hover:bg-green-100/70";
                        } else if (day.status === 'Overtime') {
                          cellBg = "bg-blue-50 border-blue-300 hover:bg-blue-100/70";
                        } else {
                          cellBg = "bg-slate-50/80 border-slate-200 hover:bg-slate-100/60";
                        }

                        return (
                          <div 
                            key={idx} 
                            className={`min-h-[70px] border rounded-xl p-2 flex flex-col justify-between transition-all duration-150 relative group select-none ${cellBg}`}
                          >
                            <div className="flex justify-between items-center">
                              <span className={`text-[10px] font-bold ${textColor}`}>
                                {day.dayNumber}
                              </span>
                              {hasTasks && (
                                <span className={`w-1.5 h-1.5 rounded-full ${day.status === 'Peak Load' ? 'bg-green-600' : 'bg-primary'}`}></span>
                              )}
                            </div>

                            {day.isCurrentMonth ? (
                              <div className="mt-1 space-y-0.5">
                                {day.tasks > 0 ? (
                                  <>
                                    <span className="text-[9px] font-extrabold text-slate-800 block leading-tight font-mono">
                                      ⚡ {day.tasks} Tasks
                                    </span>
                                    <span className="text-[8px] text-slate-500 block font-mono flex items-center gap-0.5">
                                      <Clock className="w-2.5 h-2.5 text-slate-400" />
                                      {day.hours} hrs
                                    </span>
                                  </>
                                ) : (
                                  <span className="text-[8px] font-semibold text-slate-400 block italic leading-none">
                                    {day.status}
                                  </span>
                                )}
                              </div>
                            ) : null}

                            {/* Hover Calendar Details tooltip card */}
                            {day.isCurrentMonth && day.tasks > 0 && (
                              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 hidden group-hover:block z-30 bg-slate-900 text-white text-[9px] rounded-lg p-2 shadow-xl min-w-[125px] border border-slate-700 pointer-events-none">
                                <p className="font-bold border-b border-white/10 pb-1 mb-1">Date: {day.dayNumber} {monthNames[calendarMonth]}</p>
                                <p>✓ Volume: {day.tasks} tasks</p>
                                <p>✓ Effort: {day.hours} hours logged</p>
                                <p>✓ Classification: {day.status}</p>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap gap-4 text-[10px] font-semibold text-slate-500 justify-center">
                      <div className="flex items-center gap-1.5">
                        <span className="w-3 h-3 rounded bg-green-50 border border-green-300 block"></span>
                        <span>High / Peak Load (&gt;45 tasks)</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="w-3 h-3 rounded bg-slate-50/80 border border-slate-200 block"></span>
                        <span>Normal Routine Shift</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="w-3 h-3 rounded bg-blue-50 border border-blue-300 block"></span>
                        <span>Overtime / Special Tasks</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="w-3 h-3 rounded bg-orange-50/30 border border-orange-200/50 block"></span>
                        <span>Rest Day / Off</span>
                      </div>
                    </div>
                  </div>

                </div>

                {/* Right Area: Ranking & Register Form (Col 4) */}
                <div className="lg:col-span-4 space-y-6">

                  {/* Register New Analyst Login Form */}
                  <div className="bg-white border border-[#c1c7d2] rounded-xl p-5 shadow-sm">
                    <h3 className="font-headline text-sm font-bold text-[#191c20] flex items-center gap-2 mb-4">
                      <Plus className="w-4 h-4 text-primary" />
                      <span>Register IPA Analyst</span>
                    </h3>
                    
                    <form onSubmit={handleAddIpaAnalyst} className="space-y-3.5">
                      <div>
                        <label className="block text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                          Analyst Login (Name)
                        </label>
                        <input 
                          type="text"
                          required
                          placeholder="e.g. salesh_salaria"
                          value={newAnalystName}
                          onChange={(e) => setNewAnalystName(e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs focus:ring-1 focus:ring-primary focus:border-primary focus:outline-none transition-all font-mono"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                            Operational Team
                          </label>
                          <select 
                            value={newAnalystTeam}
                            onChange={(e) => setNewAnalystTeam(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-2 text-xs focus:ring-1 focus:ring-primary focus:outline-none cursor-pointer font-semibold"
                          >
                            <option value="Chandigarh">Chandigarh</option>
                            <option value="Dhaka">Dhaka</option>
                            <option value="Havana">Havana</option>
                            <option value="US">US</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                            Daily Target Tasks
                          </label>
                          <input 
                            type="number"
                            required
                            min="1"
                            value={newAnalystTasks}
                            onChange={(e) => setNewAnalystTasks(Number(e.target.value) || 0)}
                            className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs focus:ring-1 focus:ring-primary focus:outline-none font-mono"
                          />
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="w-full bg-primary text-on-primary py-2 rounded-lg font-bold text-xs hover:opacity-95 transition-all flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Register &amp; Select Analyst</span>
                      </button>
                    </form>
                  </div>

                  {/* Leaderboard/Ranking Panel */}
                  <div className="bg-white border border-[#c1c7d2] rounded-xl shadow-sm overflow-hidden flex flex-col h-[520px]">
                    <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
                      <h4 className="font-headline text-xs font-extrabold text-[#191c20] flex items-center gap-1.5 uppercase tracking-wider">
                        <Trophy className="w-4 h-4 text-yellow-500" />
                        <span>Daily Task Leaderboard ({filteredIpaRankingList.length})</span>
                      </h4>
                      <span className="text-[9px] font-bold bg-primary/10 text-primary px-2 py-0.5 rounded-full uppercase">
                        {selectedLocation}
                      </span>
                    </div>

                    {/* Location/Office Filter Pills Selector */}
                    <div className="p-2.5 border-b border-slate-100 bg-slate-50/30 flex items-center gap-1.5 overflow-x-auto scrollbar-none shrink-0">
                      {uniqueLocations.map((loc) => {
                        const count = loc === 'All' 
                          ? ipaList.length 
                          : ipaList.filter(item => item.team.toLowerCase() === loc.toLowerCase()).length;
                        const isSelected = selectedLocation.toLowerCase() === loc.toLowerCase();
                        
                        return (
                          <button
                            key={loc}
                            type="button"
                            onClick={() => setSelectedLocation(loc)}
                            className={`px-2.5 py-1 rounded-full text-[10px] font-bold tracking-tight whitespace-nowrap transition-all duration-150 flex items-center gap-1.5 cursor-pointer shrink-0 border ${
                              isSelected 
                                ? 'bg-primary text-on-primary border-primary shadow-sm' 
                                : 'bg-white text-slate-600 hover:text-slate-800 border-slate-200'
                            }`}
                          >
                            <span>{loc}</span>
                            <span className={`px-1 rounded-full text-[9px] ${
                              isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-500 font-bold'
                            }`}>
                              {count}
                            </span>
                          </button>
                        );
                      })}
                    </div>

                    <div className="flex-1 overflow-y-auto divide-y divide-slate-100 scrollbar-thin">
                      {filteredIpaRankingList.map((row, idx) => {
                        const isSelected = row.name.toLowerCase() === selectedIpaAnalyst.toLowerCase();

                        return (
                          <div 
                            key={row.id}
                            onClick={() => setSelectedIpaAnalyst(row.name)}
                            className={`p-3.5 flex items-center justify-between transition-all cursor-pointer hover:bg-slate-50 ${isSelected ? 'bg-[#eff4ff] border-l-4 border-primary font-bold' : ''}`}
                          >
                            <div className="flex items-center gap-3.5">
                              {/* Position number */}
                              <div className="flex items-center justify-center">
                                {idx === 0 ? (
                                  <span className="w-5 h-5 flex items-center justify-center bg-yellow-100 text-yellow-700 text-[10px] font-extrabold rounded-full">1st</span>
                                ) : idx === 1 ? (
                                  <span className="w-5 h-5 flex items-center justify-center bg-slate-200 text-slate-800 text-[10px] font-extrabold rounded-full">2nd</span>
                                ) : idx === 2 ? (
                                  <span className="w-5 h-5 flex items-center justify-center bg-amber-100 text-amber-800 text-[10px] font-extrabold rounded-full">3rd</span>
                                ) : (
                                  <span className="w-5 h-5 flex items-center justify-center text-slate-400 text-xs font-bold font-mono">{idx + 1}</span>
                                )}
                              </div>

                              <div className="text-left">
                                <span className={`text-xs block font-mono ${isSelected ? 'text-primary font-bold' : 'text-[#191c20]'}`}>
                                  @{row.name}
                                </span>
                                <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-tight">
                                  {row.team} Team
                                </span>
                              </div>
                            </div>

                            <div className="text-right">
                              <span className="text-xs font-bold font-mono text-[#191c20] block">
                                {row.tasks}
                              </span>
                              <span className="text-[9px] text-slate-400 block uppercase tracking-wider font-semibold">
                                Tasks / Day
                              </span>
                            </div>
                          </div>
                        );
                      })}
                      {filteredIpaRankingList.length === 0 && (
                        <div className="p-8 text-center text-slate-400 text-xs italic">
                          No analysts registered under {selectedLocation} location yet.
                        </div>
                      )}
                    </div>
                  </div>

                </div>

              </div>

            </div>
          ) : (
            /* RANKINGS TAB VIEW PANEL */
            <div className="space-y-6 animate-fade-in text-left">
              
              {/* Main Tab bar inside advanced rankings */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-200 pb-4">
                <div>
                  <h3 className="text-lg font-bold font-headline text-[#191c20] flex items-center gap-2">
                    <Trophy className="w-5 h-5 text-yellow-500" />
                    <span>Dynamic Rankings &amp; Code Return Engine</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Interactive performance rankings across Teams, Vendors, and Analysts, paired with deployable calculation code.
                  </p>
                </div>

                {/* Sub Tab selector */}
                <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200 w-full sm:w-auto overflow-x-auto scrollbar-none shrink-0">
                  <button
                    onClick={() => { setSelectedRankingTab('team'); setCodeCopied(false); }}
                    className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-md text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${selectedRankingTab === 'team' ? 'bg-white text-primary shadow-sm' : 'text-slate-600 hover:text-slate-800'}`}
                  >
                    <Users className="w-3.5 h-3.5" />
                    <span>Team Rankings</span>
                  </button>
                  <button
                    onClick={() => { setSelectedRankingTab('vendor'); setCodeCopied(false); }}
                    className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-md text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${selectedRankingTab === 'vendor' ? 'bg-white text-primary shadow-sm' : 'text-slate-600 hover:text-slate-800'}`}
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5 text-indigo-500" />
                    <span>Vendor Rankings</span>
                  </button>
                  <button
                    onClick={() => { setSelectedRankingTab('analyst'); setCodeCopied(false); }}
                    className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-md text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${selectedRankingTab === 'analyst' ? 'bg-white text-primary shadow-sm' : 'text-slate-600 hover:text-slate-800'}`}
                  >
                    <Trophy className="w-3.5 h-3.5 text-yellow-600" />
                    <span>Analyst Leaderboard</span>
                  </button>
                </div>
              </div>

              {/* Grid split: Left Side is Ranking Visuals (Col 7), Right Side is Code Return Engine (Col 5) */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Visual Leaderboard display */}
                <div className="lg:col-span-7 space-y-6">
                  {selectedRankingTab === 'team' && (
                    <div className="space-y-6">
                      {/* Team Podiums */}
                      <div className="bg-gradient-to-br from-indigo-50 to-blue-50 border border-slate-200 rounded-xl p-5 shadow-sm">
                        <h4 className="text-xs font-extrabold text-slate-400 uppercase tracking-widest mb-4">🏆 Regional Team Podium</h4>
                        
                        <div className="grid grid-cols-3 gap-3 pt-6 items-end">
                          {/* 2nd Place */}
                          <div className="flex flex-col items-center">
                            <div className="w-10 h-10 rounded-full bg-slate-200 text-slate-700 font-bold flex items-center justify-center text-sm shadow-sm border-2 border-white mb-2">2</div>
                            <div className="bg-white/80 border border-slate-200 rounded-xl p-3 w-full text-center shadow-sm backdrop-blur-sm min-h-[90px] flex flex-col justify-between">
                              <span className="font-extrabold text-xs text-slate-800 truncate block">{teamRankings[1]?.team || 'Dhaka'}</span>
                              <span className="text-[10px] text-slate-400 font-semibold block uppercase">Composite</span>
                              <span className="font-mono text-xs font-bold text-slate-700 block">{teamRankings[1]?.compositeScore || 0} pts</span>
                            </div>
                            <div className="bg-slate-300 w-full h-12 rounded-t-lg mt-2 flex items-center justify-center"><span className="text-[10px] font-black text-slate-600">SILVER</span></div>
                          </div>

                          {/* 1st Place */}
                          <div className="flex flex-col items-center">
                            <span className="text-xl animate-bounce mb-1">👑</span>
                            <div className="w-12 h-12 rounded-full bg-yellow-400 text-yellow-950 font-black flex items-center justify-center text-base shadow-md border-2 border-white mb-2 ring-4 ring-yellow-400/20">1</div>
                            <div className="bg-white border border-yellow-200 rounded-xl p-3.5 w-full text-center shadow-md min-h-[110px] flex flex-col justify-between relative overflow-hidden">
                              <div className="absolute top-0 right-0 w-8 h-8 bg-yellow-400/10 rounded-bl-full flex items-center justify-center"><span className="text-[9px]">★</span></div>
                              <span className="font-black text-sm text-yellow-950 truncate block">{teamRankings[0]?.team || 'Chandigarh'}</span>
                              <span className="text-[10px] text-yellow-600 font-bold block uppercase">Composite</span>
                              <span className="font-mono text-sm font-black text-yellow-700 block">{teamRankings[0]?.compositeScore || 0} pts</span>
                            </div>
                            <div className="bg-yellow-400 w-full h-20 rounded-t-lg mt-2 flex items-center justify-center"><span className="text-[10px] font-black text-yellow-950">GOLD</span></div>
                          </div>

                          {/* 3rd Place */}
                          <div className="flex flex-col items-center">
                            <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-800 font-bold flex items-center justify-center text-sm shadow-sm border-2 border-white mb-2">3</div>
                            <div className="bg-white/80 border border-slate-200 rounded-xl p-3 w-full text-center shadow-sm backdrop-blur-sm min-h-[90px] flex flex-col justify-between">
                              <span className="font-extrabold text-xs text-slate-800 truncate block">{teamRankings[2]?.team || 'Havana'}</span>
                              <span className="text-[10px] text-slate-400 font-semibold block uppercase">Composite</span>
                              <span className="font-mono text-xs font-bold text-slate-700 block">{teamRankings[2]?.compositeScore || 0} pts</span>
                            </div>
                            <div className="bg-amber-200 w-full h-8 rounded-t-lg mt-2 flex items-center justify-center"><span className="text-[10px] font-black text-amber-800">BRONZE</span></div>
                          </div>
                        </div>
                      </div>

                      {/* Team Rankings Table */}
                      <div className="bg-white border border-[#c1c7d2] rounded-xl shadow-sm overflow-hidden">
                        <div className="p-4 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
                          <h4 className="font-headline text-xs font-bold text-slate-700 uppercase tracking-wider">Operational Team Leaderboard</h4>
                          <span className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full font-bold">4 Active Hubs</span>
                        </div>
                        <div className="overflow-x-auto">
                          <table className="w-full text-left border-collapse text-xs">
                            <thead>
                              <tr className="bg-slate-50 text-slate-500 font-bold border-b border-slate-100">
                                <th className="p-3 text-center w-12 border-r border-slate-200/50">Rank</th>
                                <th className="p-3">Team Location</th>
                                <th className="p-3 text-right">Active Staff</th>
                                <th className="p-3 text-right">Total Score</th>
                                <th className="p-3 text-right">Total Tasks</th>
                                <th className="p-3 text-right">Avg Error Rate</th>
                                <th className="p-3 text-right">Avg Score / Staff</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 bg-white">
                              {teamRankings.map((r, idx) => (
                                <tr key={r.team} className="hover:bg-slate-50/50 transition-colors">
                                  <td className="p-3 text-center border-r border-slate-200/50">
                                    <span className={`inline-flex items-center justify-center w-6 h-6 rounded-full text-xs font-black ${idx === 0 ? 'bg-yellow-100 text-yellow-800' : idx === 1 ? 'bg-slate-100 text-slate-800' : idx === 2 ? 'bg-amber-100 text-amber-800' : 'text-slate-400'}`}>
                                      {idx + 1}
                                    </span>
                                  </td>
                                  <td className="p-3 font-bold text-slate-900 flex items-center gap-2">
                                    <span>📍 {r.team} Team</span>
                                    {idx === 0 && <span className="bg-emerald-100 text-emerald-800 text-[8px] px-1.5 py-0.5 rounded-full font-extrabold uppercase">Top Hub</span>}
                                  </td>
                                  <td className="p-3 text-right font-semibold text-slate-600">{r.analystCount} analysts</td>
                                  <td className="p-3 text-right font-mono font-bold text-primary">{r.compositeScore.toLocaleString()} pts</td>
                                  <td className="p-3 text-right font-mono text-slate-600">{r.totalTasks.toLocaleString()}</td>
                                  <td className="p-3 text-right font-mono">
                                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${r.avgErrorRate > 1.5 ? 'bg-red-50 text-red-600' : 'bg-emerald-50 text-emerald-600'}`}>
                                      {r.avgErrorRate}%
                                    </span>
                                  </td>
                                  <td className="p-3 text-right font-mono font-bold text-slate-700">{r.avgCompositeScore} pts</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedRankingTab === 'vendor' && (
                    <div className="space-y-6 animate-fade-in">
                      {/* Highlight card for Best Vendor */}
                      <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-5 flex items-center justify-between shadow-sm">
                        <div className="text-left space-y-1">
                          <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-widest block">⭐ Quality King Vendor</span>
                          <h4 className="text-xl font-extrabold text-emerald-950 uppercase font-mono tracking-tight">
                            {vendorRankings[0]?.vendor.replace(/_/g, ' ') || 'Baldor Foods'}
                          </h4>
                          <p className="text-xs text-emerald-800 leading-normal">
                            Maintains the lowest dynamic audit error rate of <strong className="font-extrabold">{vendorRankings[0]?.errorRate || 0}%</strong>, exceeding MarginEdge's quality standard of 1.5%.
                          </p>
                        </div>
                        <div className="p-3.5 bg-emerald-100 text-emerald-700 rounded-xl shadow-inner shrink-0">
                          <Trophy className="w-8 h-8" />
                        </div>
                      </div>

                      {/* Vendor Table */}
                      <div className="bg-white border border-[#c1c7d2] rounded-xl shadow-sm overflow-hidden">
                        <div className="p-4 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
                          <div className="text-left">
                            <h4 className="font-headline text-xs font-bold text-slate-700 uppercase tracking-wider">Vendor Performance Ranking</h4>
                            <p className="text-[10px] text-slate-400 mt-0.5">Ranked by lowest error rate (optimal compliance first)</p>
                          </div>
                          <span className="text-[10px] bg-indigo-50 text-indigo-600 border border-indigo-100 px-2 py-0.5 rounded font-bold uppercase">
                            Error Rate Target: &lt; 1.5%
                          </span>
                        </div>
                        <div className="overflow-x-auto">
                          <table className="w-full text-left border-collapse text-xs">
                            <thead>
                              <tr className="bg-slate-50 text-slate-500 font-bold border-b border-slate-100">
                                <th className="p-3 text-center w-12 border-r border-slate-200/50">Rank</th>
                                <th className="p-3">Vendor Account</th>
                                <th className="p-3 text-right">Audit Batches</th>
                                <th className="p-3 text-right">Possible Points</th>
                                <th className="p-3 text-right">Errors Tagged</th>
                                <th className="p-3 text-right">Error Rate</th>
                                <th className="p-3 text-right">Avg Score</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 bg-white">
                              {vendorRankings.map((r, idx) => (
                                <tr key={r.vendor} className="hover:bg-slate-50/50 transition-colors">
                                  <td className="p-3 text-center border-r border-slate-200/50">
                                    <span className={`inline-flex items-center justify-center w-6 h-6 rounded-full text-xs font-black ${idx === 0 ? 'bg-emerald-100 text-emerald-800' : idx === 1 ? 'bg-blue-50 text-blue-800' : 'text-slate-400'}`}>
                                      {idx + 1}
                                    </span>
                                  </td>
                                  <td className="p-3 font-bold text-slate-900 uppercase font-mono tracking-tight text-left">
                                    {r.vendor.replace(/_/g, ' ')}
                                  </td>
                                  <td className="p-3 text-right font-medium text-slate-600">{r.recordsCount} runs</td>
                                  <td className="p-3 text-right font-mono font-medium text-slate-500">{r.possiblePoints.toLocaleString()}</td>
                                  <td className="p-3 text-right font-mono font-bold text-red-600">{r.errors}</td>
                                  <td className="p-3 text-right font-mono">
                                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${r.errorRate > 1.0 ? 'bg-red-50 text-red-600' : 'bg-emerald-50 text-emerald-600'}`}>
                                      {r.errorRate}%
                                    </span>
                                  </td>
                                  <td className="p-3 text-right font-mono font-bold text-slate-700">{r.avgFinalScore}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedRankingTab === 'analyst' && (
                    <div className="space-y-6 animate-fade-in">
                      {/* Search & Stats Header */}
                      <div className="bg-white border border-[#c1c7d2] rounded-xl p-4 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
                        <div className="relative w-full sm:max-w-xs text-left">
                          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                          <input
                            type="text"
                            placeholder="Filter leaders by name..."
                            value={rankingsSearch}
                            onChange={(e) => setRankingsSearch(e.target.value)}
                            className="w-full pl-9 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs focus:ring-1 focus:ring-primary focus:outline-none bg-slate-50"
                          />
                        </div>

                        <div className="flex items-center gap-3 text-xs text-slate-500 font-semibold w-full sm:w-auto justify-end">
                          <span>Sort by:</span>
                          <select
                            value={rankingSortField}
                            onChange={(e) => setRankingSortField(e.target.value)}
                            className="py-1 px-2 border border-slate-200 rounded bg-white text-slate-800 focus:outline-none cursor-pointer text-xs font-bold"
                          >
                            <option value="compositeScore">Composite Score</option>
                            <option value="errorRate">Error Rate</option>
                            <option value="points">Legacy Points</option>
                            <option value="tasks">IPA Tasks</option>
                          </select>
                          <button
                            onClick={() => setRankingSortDirection(prev => prev === 'asc' ? 'desc' : 'asc')}
                            className="p-1 border border-slate-200 rounded bg-white hover:bg-slate-50 cursor-pointer font-bold w-7 text-center"
                          >
                            {rankingSortDirection === 'asc' ? '▲' : '▼'}
                          </button>
                        </div>
                      </div>

                      {/* Unified Leaderboard Table */}
                      <div className="bg-white border border-[#c1c7d2] rounded-xl shadow-sm overflow-hidden">
                        <div className="p-4 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
                          <h4 className="font-headline text-xs font-bold text-slate-700 uppercase tracking-wider">Combined Analyst Leaderboard</h4>
                          <span className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full font-bold">
                            Composite = Points + (Tasks * 0.5)
                          </span>
                        </div>
                        <div className="overflow-x-auto max-h-[380px] overflow-y-auto scrollbar-thin">
                          <table className="w-full text-left border-collapse text-xs">
                            <thead className="sticky top-0 bg-slate-50 z-10 shadow-[0_1px_0_0_rgba(226,232,240,1)]">
                              <tr className="bg-slate-50 text-slate-500 font-bold border-b border-slate-100">
                                <th className="p-3 text-center w-12 border-r border-slate-200/50">Rank</th>
                                <th className="p-3">Analyst Login</th>
                                <th className="p-3">Team</th>
                                <th className="p-3 text-right">Points</th>
                                <th className="p-3 text-right">IPA Tasks</th>
                                <th className="p-3 text-right">Error Rate</th>
                                <th className="p-3 text-right">Composite Score</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 bg-white">
                              {(() => {
                                let result = [...analystRankings];
                                if (rankingsSearch.trim()) {
                                  const q = rankingsSearch.toLowerCase().trim();
                                  result = result.filter(a => a.name.toLowerCase().includes(q) || a.office.toLowerCase().includes(q));
                                }

                                // Custom sorting
                                result.sort((a: any, b: any) => {
                                  let valA = a[rankingSortField];
                                  let valB = b[rankingSortField];
                                  
                                  if (typeof valA === 'string') {
                                    return rankingSortDirection === 'asc'
                                      ? valA.localeCompare(valB)
                                      : valB.localeCompare(valA);
                                  } else {
                                    return rankingSortDirection === 'asc'
                                      ? (valA || 0) - (valB || 0)
                                      : (valB || 0) - (valA || 0);
                                  }
                                });

                                return result.map((r, idx) => (
                                  <tr key={r.name} className="hover:bg-slate-50/50 transition-colors">
                                    <td className="p-3 text-center border-r border-slate-200/50">
                                      <span className={`inline-flex items-center justify-center w-5 h-5 rounded-full text-[10px] font-black ${idx === 0 ? 'bg-yellow-100 text-yellow-800' : idx === 1 ? 'bg-slate-100 text-slate-800' : idx === 2 ? 'bg-amber-100 text-amber-800' : 'text-slate-400'}`}>
                                        {idx + 1}
                                      </span>
                                    </td>
                                    <td className="p-3 font-semibold text-slate-900 font-mono text-left">@{r.name}</td>
                                    <td className="p-3 text-left">
                                      <span className="inline-block bg-slate-100 text-slate-600 text-[9px] font-bold px-1.5 py-0.5 rounded-full uppercase">
                                        📍 {r.office}
                                      </span>
                                    </td>
                                    <td className="p-3 text-right font-mono text-slate-500">{r.points > 0 ? r.points.toFixed(2) : '--'}</td>
                                    <td className="p-3 text-right font-mono text-slate-500">{r.tasks > 0 ? r.tasks : '--'}</td>
                                    <td className="p-3 text-right font-mono">
                                      {r.reviews > 0 ? (
                                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${r.errorRate > 1.5 ? 'bg-red-50 text-red-600' : 'bg-emerald-50 text-emerald-600'}`}>
                                          {r.errorRate}%
                                        </span>
                                      ) : <span className="text-slate-300">--</span>}
                                    </td>
                                    <td className="p-3 text-right font-mono font-black text-primary">{r.compositeScore.toLocaleString()} pts</td>
                                  </tr>
                                ));
                              })()}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Right Side: Code Return Engine (Return Code) */}
                <div className="lg:col-span-5 space-y-6">
                  <div className="bg-[#0b0f19] text-slate-200 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col h-[520px]">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-800 shrink-0">
                      <div className="flex items-center gap-2">
                        <div className="p-1.5 bg-yellow-500/10 text-yellow-500 rounded-lg">
                          <Code className="w-4 h-4" />
                        </div>
                        <div className="text-left">
                          <h4 className="text-xs font-black text-white uppercase tracking-wider">Return Code Snippet</h4>
                          <p className="text-[10px] text-slate-400">Instantly deployable logic &amp; metrics</p>
                        </div>
                      </div>
                      
                      {/* Copy snippet button */}
                      <button
                        onClick={handleCopyCode}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${codeCopied ? 'bg-emerald-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-slate-200'}`}
                      >
                        {codeCopied ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-white" />
                            <span>Copied!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy Snippet</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* Language & snippet type controls */}
                    <div className="py-3 flex flex-wrap gap-3 items-center justify-between border-b border-slate-800 text-[10px] shrink-0">
                      <div className="flex bg-slate-900 p-0.5 rounded border border-slate-800">
                        <button
                          onClick={() => setCodeLanguage('typescript')}
                          className={`px-2 py-1 rounded text-[9px] font-bold ${codeLanguage === 'typescript' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'}`}
                        >
                          TypeScript
                        </button>
                        <button
                          onClick={() => setCodeLanguage('python')}
                          className={`px-2 py-1 rounded text-[9px] font-bold ${codeLanguage === 'python' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'}`}
                        >
                          Python
                        </button>
                        <button
                          onClick={() => setCodeLanguage('sql')}
                          className={`px-2 py-1 rounded text-[9px] font-bold ${codeLanguage === 'sql' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'}`}
                        >
                          SQL Query
                        </button>
                      </div>

                      {codeLanguage !== 'sql' && (
                        <div className="flex bg-slate-900 p-0.5 rounded border border-slate-800">
                          <button
                            onClick={() => setCodeType('data')}
                            className={`px-2 py-1 rounded text-[9px] font-bold ${codeType === 'data' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'}`}
                          >
                            Static Data
                          </button>
                          <button
                            onClick={() => setCodeType('utility')}
                            className={`px-2 py-1 rounded text-[9px] font-bold ${codeType === 'utility' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'}`}
                          >
                            Utility Function
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Code Editor Body */}
                    <div className="flex-1 min-h-0 bg-black/40 rounded-lg border border-slate-800/80 p-4 font-mono text-[11px] overflow-y-auto select-text scrollbar-thin scrollbar-thumb-slate-800 text-left">
                      <pre className="whitespace-pre text-slate-300 leading-normal font-mono select-all">
                        {generatedCodeSnippet}
                      </pre>
                    </div>

                    <div className="pt-3 border-t border-slate-800 shrink-0 text-left text-[10px] text-slate-500">
                      💡 Tip: Use static data for frontend mock rendering or utility functions for real production calculation in server-side systems.
                    </div>
                  </div>
                </div>

              </div>

            </div>
          )}
        </div>
      </main>
    </div>
  );
}
