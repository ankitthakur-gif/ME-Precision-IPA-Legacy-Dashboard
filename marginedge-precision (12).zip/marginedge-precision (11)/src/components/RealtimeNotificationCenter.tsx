import React, { useState, useEffect, useRef } from 'react';
import { useRealtime } from '../context/RealtimeContext';
import { RealtimeNotification } from '../types';
import { motion, AnimatePresence } from 'motion/react';

// Helper function to format timestamps relatively
function formatRelativeTime(isoString: string): string {
  const diffMs = Date.now() - new Date(isoString).getTime();
  const diffSec = Math.floor(diffMs / 1000);
  if (diffSec < 5) return 'Just now';
  if (diffSec < 60) return `${diffSec}s ago`;
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  return new Date(isoString).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

// 1. Notification Bell & Dropdown Component
export function NotificationBellDropdown() {
  const { notifications, markAsRead, markAllAsRead, clearNotification, clearAllNotifications } = useRealtime();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter(n => !n.read).length;

  // Close dropdown on clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getIconProps = (type: string) => {
    switch (type) {
      case 'upload':
        return { icon: 'cloud_upload', bg: 'bg-[#006d37]/10 text-[#006d37]' };
      case 'vendor':
        return { icon: 'store', bg: 'bg-blue-500/10 text-blue-600' };
      case 'error':
        return { icon: 'error', bg: 'bg-red-500/10 text-red-600' };
      case 'accuracy':
        return { icon: 'warning', bg: 'bg-amber-500/10 text-amber-600' };
      case 'report':
        return { icon: 'assignment_late', bg: 'bg-purple-500/10 text-purple-600' };
      default:
        return { icon: 'notifications', bg: 'bg-slate-100 text-slate-500' };
    }
  };

  return (
    <div className="relative inline-block text-left" ref={dropdownRef} id="notif-bell-container">
      {/* Bell Button */}
      <button
        onClick={() => {
          setIsOpen(!isOpen);
          if (!isOpen && unreadCount > 0) {
            // Optional: Auto mark read or let user do it
          }
        }}
        className="relative w-10 h-10 flex items-center justify-center rounded-full hover:bg-surface-container hover:scale-105 active:scale-95 transition-all text-on-surface-variant cursor-pointer"
        id="notif-bell-trigger"
        title="Real-Time Alerts Feed"
      >
        <span className="material-symbols-outlined text-[22px] select-none">notifications</span>
        
        {unreadCount > 0 && (
          <span className="absolute top-1.5 right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-error text-white font-extrabold text-[8px] animate-pulse">
            {unreadCount}
          </span>
        )}
      </button>

      {/* Dropdown Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="absolute right-0 mt-2 w-96 rounded-2xl bg-white dark:bg-[#0b0e14] border border-outline-variant shadow-2xl z-50 overflow-hidden"
            id="notif-dropdown-panel"
          >
            {/* Header */}
            <div className="px-4 py-3 bg-surface-container-low border-b border-outline-variant/60 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className="font-headline text-xs font-black text-on-surface tracking-wide uppercase">Real-Time Alerts</span>
                {unreadCount > 0 && (
                  <span className="px-1.5 py-0.5 rounded-full bg-error/10 text-error font-extrabold text-[9px] uppercase tracking-wider">
                    {unreadCount} New
                  </span>
                )}
              </div>
              <div className="flex gap-2">
                {unreadCount > 0 && (
                  <button
                    onClick={markAllAsRead}
                    className="text-[10px] text-primary hover:underline font-bold transition-all cursor-pointer"
                  >
                    Mark all read
                  </button>
                )}
                {notifications.length > 0 && (
                  <button
                    onClick={clearAllNotifications}
                    className="text-[10px] text-on-surface-variant hover:text-error font-bold transition-all cursor-pointer ml-1"
                  >
                    Clear all
                  </button>
                )}
              </div>
            </div>

            {/* List */}
            <div className="max-h-96 overflow-y-auto divide-y divide-outline-variant/30 custom-scrollbar">
              {notifications.length === 0 ? (
                <div className="py-12 px-4 flex flex-col items-center justify-center text-center">
                  <span className="material-symbols-outlined text-[36px] text-on-surface-variant opacity-30 animate-pulse mb-3">
                    notifications_paused
                  </span>
                  <p className="text-xs text-on-surface font-semibold">No recent alerts</p>
                  <p className="text-[10px] text-on-surface-variant mt-1 max-w-[240px]">
                    Monitoring active Firestore streams. Upload an Excel spreadsheet or trigger the simulator to see updates.
                  </p>
                </div>
              ) : (
                notifications.map(notif => {
                  const props = getIconProps(notif.type);
                  return (
                    <div
                      key={notif.id}
                      onClick={() => markAsRead(notif.id)}
                      className={`p-3.5 hover:bg-slate-50 dark:hover:bg-slate-900/10 flex items-start gap-3 transition-colors cursor-pointer relative ${!notif.read ? 'bg-primary/[0.02]' : ''}`}
                    >
                      {/* Unread indicator dot */}
                      {!notif.read && (
                        <span className="absolute left-1.5 top-[18px] w-1.5 h-1.5 rounded-full bg-primary" />
                      )}

                      {/* Icon */}
                      <div className={`p-2 rounded-xl shrink-0 ${props.bg}`}>
                        <span className="material-symbols-outlined text-[18px] font-bold block">{props.icon}</span>
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-1.5">
                          <p className={`text-[11px] leading-tight font-black truncate text-on-surface uppercase tracking-wide`}>
                            {notif.title}
                          </p>
                          <span className="text-[9px] text-on-surface-variant shrink-0 font-bold whitespace-nowrap">
                            {formatRelativeTime(notif.timestamp)}
                          </span>
                        </div>
                        <p className="text-xs leading-snug text-on-surface-variant font-medium mt-1">
                          {notif.message}
                        </p>
                      </div>

                      {/* Dismiss button */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          clearNotification(notif.id);
                        }}
                        className="p-1 text-on-surface-variant hover:text-error rounded-md hover:bg-surface-container transition-colors cursor-pointer shrink-0 mt-0.5"
                        title="Dismiss alert"
                      >
                        <span className="material-symbols-outlined text-sm font-bold block">close</span>
                      </button>
                    </div>
                  );
                })
              )}
            </div>

            {/* Footer */}
            <div className="p-2.5 bg-surface-container-low border-t border-outline-variant/60 text-center text-[10px] text-on-surface-variant font-semibold flex items-center justify-center gap-1.5">
              <span className="block w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              <span>Realtime Listener Active via Firestore SDK onSnapshot</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// 2. Real-Time Floating Toast Stack
export function FloatingToastStack() {
  const { notifications, clearNotification } = useRealtime();
  const [activeToasts, setActiveToasts] = useState<RealtimeNotification[]>([]);

  // Capture new unread notifications that arrive within the last 5 seconds
  useEffect(() => {
    const unread = notifications.filter(n => {
      const isNew = Date.now() - new Date(n.timestamp).getTime() < 6000;
      return isNew && !n.read;
    });
    // Keep only the 3 most recent toasts
    setActiveToasts(unread.slice(0, 3));
  }, [notifications]);

  const getIconProps = (type: string) => {
    switch (type) {
      case 'upload':
        return { icon: 'cloud_upload', border: 'border-[#006d37]/30', iconColor: 'text-[#006d37]' };
      case 'vendor':
        return { icon: 'store', border: 'border-blue-500/30', iconColor: 'text-blue-500' };
      case 'error':
        return { icon: 'error', border: 'border-red-500/30', iconColor: 'text-red-500' };
      case 'accuracy':
        return { icon: 'warning', border: 'border-amber-500/30', iconColor: 'text-amber-500' };
      case 'report':
        return { icon: 'assignment_late', border: 'border-purple-500/30', iconColor: 'text-purple-500' };
      default:
        return { icon: 'notifications', border: 'border-outline-variant', iconColor: 'text-slate-500' };
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 max-w-sm w-full" id="floating-toast-stack">
      <AnimatePresence>
        {activeToasts.map(toast => {
          const props = getIconProps(toast.type);
          return (
            <motion.div
              key={toast.id}
              layout
              initial={{ opacity: 0, x: 50, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.15 } }}
              className={`p-3.5 bg-white/95 dark:bg-[#0b0e14]/95 backdrop-blur-md rounded-xl border ${props.border} shadow-2xl flex items-start gap-3`}
            >
              {/* Type icon */}
              <div className={`mt-0.5 shrink-0 ${props.iconColor}`}>
                <span className="material-symbols-outlined font-bold text-lg block">{props.icon}</span>
              </div>

              {/* Msg */}
              <div className="flex-1 min-w-0">
                <p className="text-[10px] font-black uppercase tracking-wider text-on-surface leading-none">
                  {toast.title}
                </p>
                <p className="text-[11px] font-medium text-on-surface-variant leading-relaxed mt-1">
                  {toast.message}
                </p>
              </div>

              {/* Close Button */}
              <button
                onClick={() => clearNotification(toast.id)}
                className="shrink-0 p-0.5 text-on-surface-variant hover:text-error rounded hover:bg-surface-container transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-sm font-bold block">close</span>
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}

// 3. Realtime Dashboard Panel & Event Simulator Widget
export function RealtimeDashboardPanel() {
  const { notifications, simulateEvent, clearAllNotifications, resetState, isConnected } = useRealtime();
  const [filter, setFilter] = useState<string>('all');
  const [search, setSearch] = useState<string>('');
  const [simulating, setSimulating] = useState<string | null>(null);

  // Group notifications by type for statistics
  const stats = {
    total: notifications.length,
    uploads: notifications.filter(n => n.type === 'upload').length,
    vendors: notifications.filter(n => n.type === 'vendor').length,
    errors: notifications.filter(n => n.type === 'error').length,
    accuracy: notifications.filter(n => n.type === 'accuracy').length,
    reports: notifications.filter(n => n.type === 'report').length,
  };

  const handleSimulate = async (type: 'upload' | 'vendor' | 'error' | 'accuracy' | 'report') => {
    setSimulating(type);
    await simulateEvent(type);
    setTimeout(() => {
      setSimulating(null);
    }, 6000); // simulation cooldown/state duration
  };

  const filtered = notifications.filter(n => {
    const matchesFilter = filter === 'all' || n.type === filter;
    const matchesSearch = search === '' || 
      n.title.toLowerCase().includes(search.toLowerCase()) || 
      n.message.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getIcon = (type: string) => {
    switch (type) {
      case 'upload': return 'cloud_upload';
      case 'vendor': return 'store';
      case 'error': return 'error';
      case 'accuracy': return 'warning';
      case 'report': return 'assignment_late';
      default: return 'notifications';
    }
  };

  const getStyleProps = (type: string) => {
    switch (type) {
      case 'upload': return 'bg-[#006d37]/10 text-[#006d37] border-[#006d37]/20';
      case 'vendor': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
      case 'error': return 'bg-red-500/10 text-red-600 border-red-500/20';
      case 'accuracy': return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
      case 'report': return 'bg-purple-500/10 text-purple-600 border-purple-500/20';
      default: return 'bg-slate-100 text-slate-500 border-slate-200';
    }
  };

  return (
    <div className="bg-white dark:bg-[#0b0e14] border border-outline-variant rounded-2xl shadow-xl overflow-hidden" id="realtime-dashboard-widget">
      {/* Sleek Header */}
      <div className="p-4 bg-surface-container-low border-b border-outline-variant/60 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <h4 className="font-headline text-base font-black text-on-surface uppercase tracking-tight flex items-center gap-2">
            <span className="material-symbols-outlined text-primary animate-pulse">broadcast_on_personal</span>
            Live operations stream &amp; audit feed
          </h4>
          <p className="text-[11px] text-on-surface-variant font-medium mt-0.5">
            Real-time telemetry and error validation driven by Firebase Firestore `onSnapshot` SDK
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1 bg-green-500/10 border border-green-500/20 text-green-700 dark:text-green-400 rounded-full text-[10px] font-bold uppercase tracking-wider">
            <span className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500 animate-pulse' : 'bg-orange-500'}`} />
            {isConnected ? 'Firestore Stream: Active' : 'Offline'}
          </div>
          {notifications.length > 0 && (
            <button
              onClick={clearAllNotifications}
              className="px-2.5 py-1 text-[10px] font-bold border border-outline-variant rounded-full text-on-surface-variant hover:bg-error/10 hover:text-error hover:border-error/20 transition-all cursor-pointer"
            >
              Clear Log
            </button>
          )}
        </div>
      </div>

      {/* Stats Counter Section */}
      <div className="grid grid-cols-2 md:grid-cols-5 border-b border-outline-variant/40 divide-x divide-outline-variant/30 bg-surface-container-lowest">
        <div className="p-4 flex items-center justify-between">
          <div>
            <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider">Total Actions</p>
            <p className="text-2xl font-black font-headline mt-1">{stats.total}</p>
          </div>
          <span className="material-symbols-outlined text-slate-400 text-2xl select-none">analytics</span>
        </div>
        <div className="p-4 flex items-center justify-between">
          <div>
            <p className="text-[10px] font-bold text-[#006d37] uppercase tracking-wider">Uploads Synced</p>
            <p className="text-2xl font-black font-headline text-[#006d37] mt-1">{stats.uploads}</p>
          </div>
          <span className="material-symbols-outlined text-[#006d37]/50 text-2xl select-none">cloud_upload</span>
        </div>
        <div className="p-4 flex items-center justify-between">
          <div>
            <p className="text-[10px] font-bold text-red-600 uppercase tracking-wider">Active Errors</p>
            <p className="text-2xl font-black font-headline text-red-600 mt-1">{stats.errors}</p>
          </div>
          <span className="material-symbols-outlined text-red-600/50 text-2xl select-none">error_outline</span>
        </div>
        <div className="p-4 flex items-center justify-between">
          <div>
            <p className="text-[10px] font-bold text-amber-500 uppercase tracking-wider">Accuracy Warnings</p>
            <p className="text-2xl font-black font-headline text-amber-500 mt-1">{stats.accuracy}</p>
          </div>
          <span className="material-symbols-outlined text-amber-500/50 text-2xl select-none">warning</span>
        </div>
        <div className="p-4 flex items-center justify-between">
          <div>
            <p className="text-[10px] font-bold text-purple-600 uppercase tracking-wider">Missing Reports</p>
            <p className="text-2xl font-black font-headline text-purple-600 mt-1">{stats.reports}</p>
          </div>
          <span className="material-symbols-outlined text-purple-600/50 text-2xl select-none">assignment_late</span>
        </div>
      </div>

      {/* Multi-Pane Layout: Filters + Feed (Left), Event Simulator (Right) */}
      <div className="grid grid-cols-12 divide-y md:divide-y-0 md:divide-x divide-outline-variant/40">
        
        {/* Left Side: Live Feed Stream */}
        <div className="col-span-12 md:col-span-8 flex flex-col">
          {/* Filters & Search */}
          <div className="p-3 border-b border-outline-variant/30 flex flex-col sm:flex-row gap-2 justify-between items-center bg-slate-50/50 dark:bg-slate-900/10">
            {/* Tabs */}
            <div className="flex gap-1 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 scrollbar-none" id="realtime-feed-tabs">
              {[
                { id: 'all', label: 'All Alerts' },
                { id: 'upload', label: 'Uploads' },
                { id: 'vendor', label: 'Vendors' },
                { id: 'error', label: 'Errors' },
                { id: 'accuracy', label: 'Accuracy' },
                { id: 'report', label: 'Reports' }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setFilter(tab.id)}
                  className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider transition-all whitespace-nowrap cursor-pointer ${filter === tab.id ? 'bg-primary text-on-primary' : 'bg-surface-container hover:bg-surface-container-high text-on-surface-variant'}`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Search Input */}
            <div className="relative w-full sm:w-48 shrink-0">
              <span className="material-symbols-outlined absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-on-surface-variant opacity-60">
                search
              </span>
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search telemetry..."
                className="w-full bg-white border border-outline-variant rounded-full py-1 pl-7 pr-3 text-[10px] font-semibold focus:outline-none focus:border-primary transition-all font-sans"
              />
            </div>
          </div>

          {/* List Feed Scroll Container */}
          <div className="h-[360px] overflow-y-auto divide-y divide-outline-variant/20 custom-scrollbar p-1">
            {filtered.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-8">
                <span className="material-symbols-outlined text-[42px] text-on-surface-variant opacity-25 mb-3 animate-pulse">
                  podcasts
                </span>
                <p className="text-xs font-black text-on-surface uppercase tracking-wide">No stream items detected</p>
                <p className="text-[10px] text-on-surface-variant max-w-[280px] mt-1">
                  Try clearing searches, switching filters, or hitting the <b>Firestore Event Simulator</b> on the right to trigger live events.
                </p>
              </div>
            ) : (
              <AnimatePresence initial={false}>
                {filtered.map((notif, index) => {
                  const styleProps = getStyleProps(notif.type);
                  return (
                    <motion.div
                      key={notif.id}
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className={`p-3 hover:bg-slate-50/50 dark:hover:bg-slate-900/5 transition-colors flex items-start gap-3`}
                    >
                      {/* Left category indicator */}
                      <div className={`p-2 rounded-xl border shrink-0 mt-0.5 ${styleProps}`}>
                        <span className="material-symbols-outlined text-[16px] font-bold block">
                          {getIcon(notif.type)}
                        </span>
                      </div>

                      {/* Content details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-center gap-2">
                          <p className="text-[11px] font-black uppercase tracking-wider text-on-surface leading-tight truncate">
                            {notif.title}
                          </p>
                          <span className="text-[9px] font-bold text-on-surface-variant shrink-0 bg-slate-100 dark:bg-slate-900 px-1.5 py-0.5 rounded-full">
                            {formatRelativeTime(notif.timestamp)}
                          </span>
                        </div>
                        <p className="text-xs text-on-surface-variant font-medium mt-1 leading-relaxed">
                          {notif.message}
                        </p>
                        <div className="flex gap-4 mt-1.5">
                          <span className="text-[9px] font-bold text-primary font-mono bg-primary/5 px-1.5 py-0.5 rounded">
                            ID: {notif.id.split('_').slice(-1)[0]}
                          </span>
                          <span className="text-[9px] font-bold text-on-surface-variant font-mono">
                            Type: {notif.type.toUpperCase()}
                          </span>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            )}
          </div>
        </div>

        {/* Right Side: Event Simulator Control Box */}
        <div className="col-span-12 md:col-span-4 p-5 bg-slate-50/20 dark:bg-[#080b0f] flex flex-col justify-between">
          <div className="space-y-4">
            <div>
              <span className="inline-flex items-center gap-1 bg-primary/15 text-primary text-[9px] font-extrabold uppercase tracking-widest px-2 py-0.5 rounded-full border border-primary/20 mb-2">
                <span className="block w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                Live Cloud Sync Lab
              </span>
              <h5 className="text-xs font-black uppercase text-on-surface tracking-wider">
                Firestore Event Simulator
              </h5>
              <p className="text-[11px] text-on-surface-variant font-medium mt-1 leading-relaxed">
                Clicking any trigger executes a genuine client-side write to the active Firestore cloud server. The change instantly broadcasts to all active screens through active `onSnapshot` subscriptions.
              </p>
            </div>

            {/* Simulated Buttons Stack */}
            <div className="space-y-2.5" id="notif-simulator-controls">
              {/* Simulate New Upload */}
              <button
                onClick={() => handleSimulate('upload')}
                disabled={simulating !== null}
                className="w-full py-2 px-3 border border-[#006d37]/20 bg-[#006d37]/5 hover:bg-[#006d37]/10 disabled:opacity-55 transition-all rounded-xl text-left flex items-center justify-between cursor-pointer group"
                id="simulate-upload-btn"
              >
                <div className="flex items-center gap-2.5">
                  <span className="material-symbols-outlined text-[#006d37] font-bold text-lg group-hover:scale-110 transition-transform">cloud_upload</span>
                  <div>
                    <p className="text-[10px] font-black uppercase text-[#006d37] tracking-wider leading-none">Simulate New Upload</p>
                    <p className="text-[9px] font-medium text-slate-500 mt-0.5">Mock an Excel worksheet save</p>
                  </div>
                </div>
                {simulating === 'upload' ? (
                  <span className="material-symbols-outlined text-[#006d37] animate-spin text-sm">refresh</span>
                ) : (
                  <span className="material-symbols-outlined text-[#006d37]/60 text-sm group-hover:translate-x-1 transition-transform">chevron_right</span>
                )}
              </button>

              {/* Simulate Vendor Issue */}
              <button
                onClick={() => handleSimulate('vendor')}
                disabled={simulating !== null}
                className="w-full py-2 px-3 border border-blue-500/20 bg-blue-500/5 hover:bg-blue-500/10 disabled:opacity-55 transition-all rounded-xl text-left flex items-center justify-between cursor-pointer group"
                id="simulate-vendor-btn"
              >
                <div className="flex items-center gap-2.5">
                  <span className="material-symbols-outlined text-blue-500 font-bold text-lg group-hover:scale-110 transition-transform">store</span>
                  <div>
                    <p className="text-[10px] font-black uppercase text-blue-500 tracking-wider leading-none">Simulate Vendor Issue</p>
                    <p className="text-[9px] font-medium text-slate-500 mt-0.5">Flag a live vendor operation issue</p>
                  </div>
                </div>
                {simulating === 'vendor' ? (
                  <span className="material-symbols-outlined text-blue-500 animate-spin text-sm">refresh</span>
                ) : (
                  <span className="material-symbols-outlined text-blue-500/60 text-sm group-hover:translate-x-1 transition-transform">chevron_right</span>
                )}
              </button>

              {/* Simulate High Error */}
              <button
                onClick={() => handleSimulate('error')}
                disabled={simulating !== null}
                className="w-full py-2 px-3 border border-red-500/20 bg-red-500/5 hover:bg-red-500/10 disabled:opacity-55 transition-all rounded-xl text-left flex items-center justify-between cursor-pointer group"
                id="simulate-error-btn"
              >
                <div className="flex items-center gap-2.5">
                  <span className="material-symbols-outlined text-red-500 font-bold text-lg group-hover:scale-110 transition-transform">error</span>
                  <div>
                    <p className="text-[10px] font-black uppercase text-red-500 tracking-wider leading-none">Simulate High Error</p>
                    <p className="text-[9px] font-medium text-slate-500 mt-0.5">Trigger 5 mismatch errors</p>
                  </div>
                </div>
                {simulating === 'error' ? (
                  <span className="material-symbols-outlined text-red-500 animate-spin text-sm">refresh</span>
                ) : (
                  <span className="material-symbols-outlined text-red-500/60 text-sm group-hover:translate-x-1 transition-transform">chevron_right</span>
                )}
              </button>

              {/* Simulate Low Accuracy */}
              <button
                onClick={() => handleSimulate('accuracy')}
                disabled={simulating !== null}
                className="w-full py-2 px-3 border border-amber-500/20 bg-amber-500/5 hover:bg-amber-500/10 disabled:opacity-55 transition-all rounded-xl text-left flex items-center justify-between cursor-pointer group"
                id="simulate-accuracy-btn"
              >
                <div className="flex items-center gap-2.5">
                  <span className="material-symbols-outlined text-amber-500 font-bold text-lg group-hover:scale-110 transition-transform">warning</span>
                  <div>
                    <p className="text-[10px] font-black uppercase text-amber-600 dark:text-amber-400 tracking-wider leading-none">Simulate Low Accuracy</p>
                    <p className="text-[9px] font-medium text-slate-500 mt-0.5">Lower accuracy score below limit</p>
                  </div>
                </div>
                {simulating === 'accuracy' ? (
                  <span className="material-symbols-outlined text-amber-500 animate-spin text-sm">refresh</span>
                ) : (
                  <span className="material-symbols-outlined text-amber-500/60 text-sm group-hover:translate-x-1 transition-transform">chevron_right</span>
                )}
              </button>

              {/* Simulate Missing Report */}
              <button
                onClick={() => handleSimulate('report')}
                disabled={simulating !== null}
                className="w-full py-2 px-3 border border-purple-500/20 bg-purple-500/5 hover:bg-purple-500/10 disabled:opacity-55 transition-all rounded-xl text-left flex items-center justify-between cursor-pointer group"
                id="simulate-report-btn"
              >
                <div className="flex items-center gap-2.5">
                  <span className="material-symbols-outlined text-purple-600 font-bold text-lg group-hover:scale-110 transition-transform">assignment_late</span>
                  <div>
                    <p className="text-[10px] font-black uppercase text-purple-600 tracking-wider leading-none">Simulate Missing Report</p>
                    <p className="text-[9px] font-medium text-slate-500 mt-0.5">Flag missing performance audit</p>
                  </div>
                </div>
                {simulating === 'report' ? (
                  <span className="material-symbols-outlined text-purple-600 animate-spin text-sm">refresh</span>
                ) : (
                  <span className="material-symbols-outlined text-purple-600/60 text-sm group-hover:translate-x-1 transition-transform">chevron_right</span>
                )}
              </button>
            </div>
          </div>

          <div className="pt-4 border-t border-outline-variant/30 mt-4 flex flex-col gap-2">
            <button
              onClick={resetState}
              className="w-full py-1.5 bg-slate-100 hover:bg-slate-200 text-on-surface font-black text-[10px] uppercase tracking-wider rounded-lg transition-colors cursor-pointer text-center"
              title="Resets database back to default initial state"
            >
              Reset Database State
            </button>
            <p className="text-[9px] text-on-surface-variant font-medium text-center leading-normal">
              Need to clear sim logs? "Reset Database State" will restore the original demo records.
            </p>
          </div>
        </div>

      </div>
    </div>
  );
}
