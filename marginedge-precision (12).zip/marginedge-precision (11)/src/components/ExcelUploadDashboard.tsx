import React, { useState } from 'react';
import ExcelUploadTab from './ExcelUploadTab';
import ExcelVersionsTab from './ExcelVersionsTab';
import ExcelExplorerTab from './ExcelExplorerTab';
import ExcelBackupsTab from './ExcelBackupsTab';

interface ExcelUploadDashboardProps {
  userEmail: string;
  userName: string;
  userPosition: string; // e.g. 'Admin', 'Analyst', 'AM', 'Lead', etc.
  onNavigate: (view: any) => void;
}

type TabType = 'UPLOAD' | 'VERSIONS' | 'EXPLORER' | 'BACKUPS';

export default function ExcelUploadDashboard({
  userEmail,
  userName,
  userPosition,
  onNavigate
}: ExcelUploadDashboardProps) {
  const [activeTab, setActiveTab] = useState<TabType>('UPLOAD');
  const [refreshTrigger, setRefreshTrigger] = useState<number>(0);

  // Core Role-Based Access Control logic:
  // Managers & Admin have write access (uploading, editing, restoring, backing up).
  // Analysts are read-only.
  const isAdmin = userPosition === 'Admin';
  const isManager = userPosition === 'Admin' || userPosition === 'AM' || userPosition === 'Lead' || userPosition === 'Team Lead' || userPosition === 'Manager';
  const hasWriteAccess = isManager;

  const handleUploadSuccess = () => {
    // Automatically trigger lists updates in version tabs when upload completes successfully
    setRefreshTrigger(prev => prev + 1);
  };

  const getRoleBadgeColor = () => {
    if (isAdmin) return 'bg-red-500/10 text-red-700 border border-red-500/20';
    if (isManager) return 'bg-indigo-500/10 text-indigo-700 border border-indigo-500/20';
    return 'bg-amber-500/10 text-amber-700 border border-amber-500/20';
  };

  const getRoleLabel = () => {
    if (isAdmin) return 'Platform Administrator';
    if (isManager) return `${userPosition} Manager`;
    return `${userPosition || 'Analyst'} (View-Only)`;
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] dark:bg-[#0b0f19] flex flex-col">
      {/* ENTERPRISE APP HEADER */}
      <header className="h-20 bg-white dark:bg-[#121620] border-b border-slate-200/60 dark:border-slate-800/60 px-8 flex items-center justify-between shrink-0 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center text-white shadow-md shadow-primary/20">
            <span className="material-symbols-outlined text-[22px]">database</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-black text-slate-950 dark:text-white tracking-tight">
                MarginEdge IPA Excel Engine
              </h1>
              <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider ${getRoleBadgeColor()}`}>
                {getRoleLabel()}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium mt-0.5">
              Secure Excel Import, Synced Historical Version Control & Real-time Live Audits
            </p>
          </div>
        </div>

        {/* TOP CONTROLS */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('LIVE_SYNC_DASHBOARD')}
            className="px-3.5 py-2 border border-slate-200 hover:bg-slate-50 rounded-xl text-xs font-bold text-slate-600 transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <span className="material-symbols-outlined text-sm">dashboard</span>
            Back to Dashboard
          </button>
        </div>
      </header>

      <main className="flex-1 p-8 max-w-7xl w-full mx-auto space-y-6">
        
        {/* TAB LIST */}
        <div className="flex items-center gap-2 border-b border-slate-200/50 pb-px">
          <button
            onClick={() => setActiveTab('UPLOAD')}
            className={`px-5 py-3 text-xs font-black uppercase tracking-wider flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
              activeTab === 'UPLOAD'
                ? 'border-primary text-primary'
                : 'border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300'
            }`}
          >
            <span className="material-symbols-outlined text-sm">cloud_upload</span>
            Upload & Sync
          </button>

          <button
            onClick={() => setActiveTab('VERSIONS')}
            className={`px-5 py-3 text-xs font-black uppercase tracking-wider flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
              activeTab === 'VERSIONS'
                ? 'border-primary text-primary'
                : 'border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300'
            }`}
          >
            <span className="material-symbols-outlined text-sm">history</span>
            Version Manager
          </button>

          <button
            onClick={() => setActiveTab('EXPLORER')}
            className={`px-5 py-3 text-xs font-black uppercase tracking-wider flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
              activeTab === 'EXPLORER'
                ? 'border-primary text-primary'
                : 'border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300'
            }`}
          >
            <span className="material-symbols-outlined text-sm">manage_search</span>
            Records Explorer
          </button>

          <button
            onClick={() => setActiveTab('BACKUPS')}
            className={`px-5 py-3 text-xs font-black uppercase tracking-wider flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
              activeTab === 'BACKUPS'
                ? 'border-primary text-primary'
                : 'border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300'
            }`}
          >
            <span className="material-symbols-outlined text-sm">backup</span>
            Backups & Recovery
          </button>
        </div>

        {/* ACTIVE MODULE VIEW */}
        <div className="animate-fadeIn">
          {activeTab === 'UPLOAD' && (
            <ExcelUploadTab
              userEmail={userEmail}
              userName={userName}
              userPosition={userPosition}
              hasWriteAccess={hasWriteAccess}
              onNavigate={onNavigate}
              onUploadSuccess={handleUploadSuccess}
            />
          )}

          {activeTab === 'VERSIONS' && (
            <ExcelVersionsTab
              userEmail={userEmail}
              hasWriteAccess={hasWriteAccess}
              onRefreshTrigger={refreshTrigger}
            />
          )}

          {activeTab === 'EXPLORER' && (
            <ExcelExplorerTab
              userEmail={userEmail}
              hasWriteAccess={hasWriteAccess}
            />
          )}

          {activeTab === 'BACKUPS' && (
            <ExcelBackupsTab
              userEmail={userEmail}
              hasWriteAccess={hasWriteAccess}
              onRefreshTrigger={handleUploadSuccess}
            />
          )}
        </div>

      </main>
    </div>
  );
}
