import React, { useState, useEffect, useMemo, useRef } from 'react';
import * as XLSX from 'xlsx';
import { 
  BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend, Cell, AreaChart, Area
} from 'recharts';
import { 
  Upload, Sparkles, TrendingUp, AlertTriangle, CheckCircle, Clock, FileSpreadsheet, Users, Activity, ChevronLeft, ChevronRight, FileJson, FileText, RefreshCw, BarChart2, ShieldAlert, Trophy, Award, Calendar, Search, Filter, HelpCircle, ArrowUpRight, ArrowDownRight, Eye, Star, Zap
} from 'lucide-react';
import { PresetRecord, PresetReportSummary } from '../types';
import GoogleSheetsAdminPanel from './GoogleSheetsAdminPanel';

interface AIAnalysisResult {
  executiveSummary: string;
  overallPerformanceScore: number;
  bestPerformingAnalyst: string;
  lowestPerformingAnalyst: string;
  bottlenecks: string[];
  trendAnalysis: string;
  riskDetection: string[];
  aiRecommendations: string[];
}

interface PresetReportDashboardProps {
  userEmail: string;
  userName: string;
  userPosition: string;
  onNavigate: (view: any) => void;
  onLogout: () => void;
}

export default function PresetReportDashboard({
  userEmail,
  userName,
  userPosition,
  onNavigate,
  onLogout
}: PresetReportDashboardProps) {
  // Application Data States
  const [records, setRecords] = useState<PresetRecord[]>([]);
  const [reports, setReports] = useState<PresetReportSummary[]>([]);
  const [selectedReportId, setSelectedReportId] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  
  // AI Co-Pilot State
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysisResult | null>(null);
  const [analyzing, setAnalyzing] = useState<boolean>(false);
  const [aiError, setAiError] = useState<string | null>(null);

  // Table & Filters State
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filterEmployee, setFilterEmployee] = useState<string>('ALL');
  const [filterDate, setFilterDate] = useState<string>('ALL');
  const [filterWeek, setFilterWeek] = useState<string>('ALL');
  const [filterMonth, setFilterMonth] = useState<string>('ALL');
  const [filterYear, setFilterYear] = useState<string>('ALL');
  const [filterTeam, setFilterTeam] = useState<string>('ALL');
  const [filterShift, setFilterShift] = useState<string>('ALL');

  const [currentPage, setCurrentPage] = useState<number>(1);
  const [rowsPerPage, setRowsPerPage] = useState<number>(10);
  
  // File upload drag & drop visual helper
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [uploadMessage, setUploadMessage] = useState<{ type: 'success' | 'error' | 'info', text: string } | null>(null);

  // Active Chart Tab State ('daily' | 'weekly' | 'month' | 'year')
  const [activeChartTab, setActiveChartTab] = useState<'daily' | 'weekly' | 'month' | 'year'>('daily');

  // Active Distribution Tab State ('team' | 'vendor')
  const [activeDistributionTab, setActiveDistributionTab] = useState<'team' | 'vendor'>('team');

  // Active Module Context ('IPA' | 'LEGACY' | 'GS_ADMIN')
  const [activeModule, setActiveModule] = useState<'IPA' | 'LEGACY' | 'GS_ADMIN'>('IPA');

  // Interactive Confetti State
  const [celebratedEmployee, setCelebratedEmployee] = useState<string | null>(null);
  const confettiTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Fetch presets whenever activeModule changes
  useEffect(() => {
    if (activeModule !== "GS_ADMIN") {
      fetchPresets();
    }
  }, [activeModule]);

  // Setup real-time WebSocket connection to automatically detect Google Sheet updates and refresh immediately
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    let socket: WebSocket | null = null;
    let reconnectTimer: any = null;

    const connectWS = () => {
      try {
        socket = new WebSocket(wsUrl);
        socket.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            if (data.type === "PRESETS_UPDATE") {
              console.log("⚡ [Real-time Sync] Detected Google Sheet background sync. Refreshing...");
              if (activeModule !== "GS_ADMIN") {
                fetchPresets();
              }
            }
          } catch (err) {
            // Quiet fail for malformed ws messages
          }
        };

        socket.onclose = () => {
          reconnectTimer = setTimeout(connectWS, 4000);
        };
      } catch (err) {
        reconnectTimer = setTimeout(connectWS, 4000);
      }
    };

    connectWS();

    return () => {
      if (socket) socket.close();
      if (reconnectTimer) clearTimeout(reconnectTimer);
    };
  }, [activeModule]);

  const fetchPresets = async () => {
    setLoading(true);
    try {
      const queryModule = activeModule === "GS_ADMIN" ? "ipa" : activeModule.toLowerCase();
      const response = await fetch(`/api/presets?module=${queryModule}`);
      const data = await response.json();
      if (data.success) {
        setRecords(data.presetRecords || []);
        setReports(data.presetReports || []);
        if (data.presetReports && data.presetReports.length > 0) {
          setSelectedReportId(data.presetReports[0].id);
        }
      }
    } catch (error) {
      console.error("Error fetching presets:", error);
    } finally {
      setLoading(false);
    }
  };

  // Find the currently active report summary details
  const activeReportSummary = useMemo(() => {
    if (!selectedReportId) return null;
    return reports.find(r => r.id === selectedReportId) || reports[0] || null;
  }, [selectedReportId, reports]);

  // Sync / Run AI analysis whenever activeReportSummary changes
  useEffect(() => {
    if (activeReportSummary) {
      runAIAnalysis(activeReportSummary);
    }
  }, [activeReportSummary]);

  // Run server-side Gemini Analysis on operational statistics
  const runAIAnalysis = async (summary: PresetReportSummary) => {
    setAnalyzing(true);
    setAiError(null);
    try {
      // Aggregate Analyst Wise and Team Wise summaries to feed to the model
      const topAnalysts = records.slice(0, 10).map(r => ({
        name: r.employeeName,
        Tasks: r.totalTasks,
        Accuracy: r.totalTasks > 400 ? 99 : 96, // calculated proxy
        AverageTAT: r.escalations === 0 ? 11 : 14 // calculated proxy
      }));

      const teamPerformance = Array.from(new Set(records.map(r => r.team))).map(team => {
        const teamRecs = records.filter(r => r.team === team);
        const tasks = teamRecs.reduce((sum, r) => sum + r.totalTasks, 0);
        return { name: team, Tasks: tasks, AverageTAT: 12, Accuracy: 98.5 };
      });

      const response = await fetch('/api/presets/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          stats: {
            totalTasks: summary.totalTasks,
            completedTasks: summary.totalTasks - summary.totalEscalations,
            pendingTasks: summary.totalEscalations,
            processingTime: summary.averageMovingTotal,
            averageTAT: 12, // average turnaround proxy
            accuracy: Math.round(((summary.totalTasks - summary.totalEscalations) / Math.max(summary.totalTasks, 1)) * 100),
            duplicateRecords: 0,
            missingValues: 0,
            errorsCount: summary.totalEscalations
          },
          analystPerformance: topAnalysts,
          vendorSummary: teamPerformance
        })
      });

      const data = await response.json();
      if (data.success) {
        setAiAnalysis(data.analysis);
      } else {
        setAiError(data.error || 'Gemini API not configured or failed to run analysis.');
      }
    } catch (err: any) {
      console.error('Error in AI analysis:', err);
      setAiError(err.message || 'Network error occurred during AI analysis.');
    } finally {
      setAnalyzing(false);
    }
  };

  // -------------------------------------------------------------
  // AUTOMATIC EXCEL SPREADSHEET DETECTOR AND NORMALIZATION ENGINE
  // -------------------------------------------------------------
  const processSpreadsheet = (file: File) => {
    const reader = new FileReader();
    setUploadMessage({ type: 'info', text: 'Reading file...' });
    
    reader.onload = async (e) => {
      try {
        const data = e.target?.result;
        if (!data) throw new Error('Could not read file data.');
        
        const workbook = XLSX.read(data, { type: 'binary' });
        
        // Find suitable worksheet (check for preset/task/report keywords)
        let selectedSheetName = '';
        const presetKeywords = ['preset', 'ipa', 'task', 'report', 'analyst', 'operational', 'log', 'data', 'sheet'];
        
        for (const name of workbook.SheetNames) {
          const lowerName = name.toLowerCase();
          if (presetKeywords.some(keyword => lowerName.includes(keyword))) {
            selectedSheetName = name;
            break;
          }
        }
        
        if (!selectedSheetName) {
          selectedSheetName = workbook.SheetNames[0];
        }
        
        const worksheet = workbook.Sheets[selectedSheetName];
        if (!worksheet) {
          throw new Error('Spreadsheet does not contain any valid worksheet.');
        }

        const rawRows = XLSX.utils.sheet_to_json(worksheet, { defval: "" }) as any[];
        if (rawRows.length === 0) {
          throw new Error('The selected worksheet is empty.');
        }

        const parsedRecords: PresetRecord[] = [];
        
        rawRows.forEach((row, index) => {
          const keys = Object.keys(row);
          
          const findVal = (keywords: string[], defaultVal = ''): string => {
            const foundKey = keys.find(k => {
              const lowerK = k.toLowerCase().replace(/[\s_-]/g, '');
              return keywords.some(kw => lowerK.includes(kw));
            });
            return foundKey ? String(row[foundKey]).trim() : defaultVal;
          };

          const rawDate = findVal(['date', 'time', 'day', 'create', 'pastdate'], new Date().toISOString().split('T')[0]);
          const rawEmployee = findVal(['employeename', 'employee', 'analyst', 'analystname', 'agent', 'name', 'person', 'user'], 'Unknown Employee');
          
          const rawTotalTasksVal = findVal(['totaltaskasperdashboard', 'totaltasks', 'totaltask', 'tasks', 'dashboardtasks', 'dashboardtask', 'kpi'], '0');
          const cleanTotalTasks = parseInt(rawTotalTasksVal.replace(/[^0-9]/g, '')) || 0;

          const rawEscalationsVal = findVal(['totalescalations', 'escalations', 'escalation', 'esc', 'escalated'], '0');
          const cleanEscalations = parseInt(rawEscalationsVal.replace(/[^0-9]/g, '')) || 0;

          const rawMovingTotalVal = findVal(['movingtotalatdayendasperscreenmeter', 'movingtotal', 'screenmeter', 'movingtotalatdayend', 'screenmetertotal', 'meter'], '0');
          const cleanMovingTotal = parseInt(rawMovingTotalVal.replace(/[^0-9]/g, '')) || 0;

          const rawWeek = findVal(['week', 'weeknumber', 'weeknum'], '');
          const rawMonth = findVal(['month'], '');
          const rawYear = findVal(['year'], '');
          const rawTeam = findVal(['team', 'group', 'department', 'ops'], 'Alpha Ops');
          const rawShift = findVal(['shift', 'slot', 'timeslot'], 'Day');
          const rawVendor = findVal(['vendor', 'vendorname', 'client', 'supplier', 'carrier'], '');

          // Date derivative parsers if sheet column values are missing
          let parsedDateObj = new Date(rawDate);
          if (isNaN(parsedDateObj.getTime())) {
            parsedDateObj = new Date();
          }
          const formattedDate = parsedDateObj.toISOString().split('T')[0];
          
          const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
          const monthName = monthNames[parsedDateObj.getMonth()];
          const yearVal = rawYear || String(parsedDateObj.getFullYear());
          const monthVal = rawMonth || `${monthName} ${yearVal}`;
          
          const startOfYear = new Date(parsedDateObj.getFullYear(), 0, 1);
          const days = Math.floor((parsedDateObj.getTime() - startOfYear.getTime()) / (24 * 60 * 60 * 1000));
          const weekVal = rawWeek || `Week ${Math.ceil((days + startOfYear.getDay() + 1) / 7)}`;

          parsedRecords.push({
            id: `rec_${Date.now()}_${index}`,
            date: formattedDate,
            employeeName: rawEmployee,
            totalTasks: cleanTotalTasks,
            escalations: cleanEscalations,
            movingTotal: cleanMovingTotal,
            week: weekVal,
            month: monthVal,
            year: yearVal,
            team: rawTeam,
            shift: rawShift,
            vendor: rawVendor || undefined
          });
        });

        // Calculate the summary metrics
        const totalTasksSum = parsedRecords.reduce((sum, r) => sum + r.totalTasks, 0);
        const totalEscSum = parsedRecords.reduce((sum, r) => sum + r.escalations, 0);
        const avgMovingTotal = parsedRecords.length > 0 
          ? Math.round(parsedRecords.reduce((sum, r) => sum + r.movingTotal, 0) / parsedRecords.length)
          : 0;

        const empMap: Record<string, number> = {};
        parsedRecords.forEach(r => {
          empMap[r.employeeName] = (empMap[r.employeeName] || 0) + r.totalTasks;
        });

        let topEmp = 'None';
        let maxT = -1;
        Object.entries(empMap).forEach(([name, count]) => {
          if (count > maxT) {
            maxT = count;
            topEmp = name;
          }
        });

        const summaryId = `rep_${Date.now()}`;
        const newReportSummary: PresetReportSummary = {
          id: summaryId,
          fileName: file.name,
          uploadDate: new Date().toISOString().split('T')[0],
          totalTasks: totalTasksSum,
          totalEscalations: totalEscSum,
          averageMovingTotal: avgMovingTotal,
          activeEmployeesCount: Object.keys(empMap).length,
          topPerformerName: topEmp
        };

        // Post and Overwrite backend cache
        setIsSyncing(true);
        const syncResponse = await fetch('/api/presets/sync', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fileName: file.name,
            records: parsedRecords,
            summary: newReportSummary
          })
        });

        const syncResult = await syncResponse.json();
        if (syncResult.success) {
          setRecords(parsedRecords);
          setReports(prev => [newReportSummary, ...prev]);
          setSelectedReportId(summaryId);
          setUploadMessage({
            type: 'success',
            text: `Successfully replaced report with "${file.name}" (${parsedRecords.length} operator rows imported and synced securely).`
          });
          
          // Reset filters
          setFilterEmployee('ALL');
          setFilterDate('ALL');
          setFilterWeek('ALL');
          setFilterMonth('ALL');
          setFilterYear('ALL');
          setFilterTeam('ALL');
          setFilterShift('ALL');
          setCurrentPage(1);
        } else {
          throw new Error(syncResult.error || 'Syncing to Database failed.');
        }

      } catch (err: any) {
        console.error('Spreadsheet parse exception:', err);
        setUploadMessage({
          type: 'error',
          text: err.message || 'Error processing spreadsheet file.'
        });
      } finally {
        setIsSyncing(false);
      }
    };

    reader.readAsBinaryString(file);
  };

  const handleFileUploadEvent = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processSpreadsheet(file);
    }
  };

  // Drag and Drop helpers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };
  const handleDragLeave = () => {
    setIsDragging(false);
  };
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processSpreadsheet(file);
    }
  };

  // -------------------------------------------------------------
  // DYNAMIC FILTER ENGINE
  // -------------------------------------------------------------
  const filteredRecords = useMemo(() => {
    return records.filter(rec => {
      const matchesSearch = rec.employeeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            rec.team.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesEmployee = filterEmployee === 'ALL' || rec.employeeName === filterEmployee;
      const matchesDate = filterDate === 'ALL' || rec.date === filterDate;
      const matchesWeek = filterWeek === 'ALL' || rec.week === filterWeek;
      const matchesMonth = filterMonth === 'ALL' || rec.month === filterMonth;
      const matchesYear = filterYear === 'ALL' || rec.year === filterYear;
      const matchesTeam = filterTeam === 'ALL' || rec.team === filterTeam;
      const matchesShift = filterShift === 'ALL' || rec.shift === filterShift;

      return matchesSearch && matchesEmployee && matchesDate && matchesWeek && matchesMonth && matchesYear && matchesTeam && matchesShift;
    });
  }, [records, searchTerm, filterEmployee, filterDate, filterWeek, filterMonth, filterYear, filterTeam, filterShift]);

  // Unique lists for filters
  const uniqueDates = useMemo(() => Array.from(new Set(records.map(r => r.date))).sort(), [records]);
  const uniqueEmployees = useMemo(() => Array.from(new Set(records.map(r => r.employeeName))).sort(), [records]);
  const uniqueWeeks = useMemo(() => Array.from(new Set(records.map(r => r.week))).sort((a, b) => (a as string).localeCompare(b as string, undefined, {numeric: true})), [records]);
  const uniqueMonths = useMemo(() => Array.from(new Set(records.map(r => r.month))).sort(), [records]);
  const uniqueYears = useMemo(() => Array.from(new Set(records.map(r => r.year))).sort(), [records]);
  const uniqueTeams = useMemo(() => Array.from(new Set(records.map(r => r.team))).sort(), [records]);
  const uniqueShifts = useMemo(() => Array.from(new Set(records.map(r => r.shift))).sort(), [records]);

  const clearAllFilters = () => {
    setFilterEmployee('ALL');
    setFilterDate('ALL');
    setFilterWeek('ALL');
    setFilterMonth('ALL');
    setFilterYear('ALL');
    setFilterTeam('ALL');
    setFilterShift('ALL');
    setSearchTerm('');
    setCurrentPage(1);
  };

  // -------------------------------------------------------------
  // CALCULATED DERIVED METRICS FOR FILTERED SUBSET
  // -------------------------------------------------------------
  const filteredMetrics = useMemo(() => {
    const totalTasks = filteredRecords.reduce((sum, r) => sum + r.totalTasks, 0);
    const totalEscalations = filteredRecords.reduce((sum, r) => sum + r.escalations, 0);
    const averageMovingTotal = filteredRecords.length > 0
      ? Math.round(filteredRecords.reduce((sum, r) => sum + r.movingTotal, 0) / filteredRecords.length)
      : 0;
    const activeEmployeesCount = new Set(filteredRecords.map(r => r.employeeName)).size;

    return {
      totalTasks,
      totalEscalations,
      averageMovingTotal,
      activeEmployeesCount
    };
  }, [filteredRecords]);

  // -------------------------------------------------------------
  // EMPLOYEE LEADERBOARD & TOP PERFORMERS SHOWCASE (DYNAMIC)
  // -------------------------------------------------------------
  const leaderboardData = useMemo(() => {
    const empMap: Record<string, { employeeName: string, team: string, shift: string, totalTasks: number, escalations: number, movingTotalSum: number, count: number }> = {};
    
    filteredRecords.forEach(r => {
      if (!empMap[r.employeeName]) {
        empMap[r.employeeName] = {
          employeeName: r.employeeName,
          team: r.team,
          shift: r.shift,
          totalTasks: 0,
          escalations: 0,
          movingTotalSum: 0,
          count: 0
        };
      }
      empMap[r.employeeName].totalTasks += r.totalTasks;
      empMap[r.employeeName].escalations += r.escalations;
      empMap[r.employeeName].movingTotalSum += r.movingTotal;
      empMap[r.employeeName].count++;
    });

    const list = Object.values(empMap).map(item => ({
      employeeName: item.employeeName,
      team: item.team,
      shift: item.shift,
      totalTasks: item.totalTasks,
      escalations: item.escalations,
      movingTotal: item.count > 0 ? Math.round(item.movingTotalSum / item.count) : 0
    }));

    // Sort by totalTasks descending
    list.sort((a, b) => b.totalTasks - a.totalTasks);

    const maxTasks = list.length > 0 ? list[0].totalTasks : 1;

    return list.map((item, index) => ({
      rank: index + 1,
      ...item,
      performancePercent: Math.min(Math.round((item.totalTasks / maxTasks) * 100), 100)
    }));
  }, [filteredRecords]);

  // Top 5 Operators
  const topFivePerformers = useMemo(() => {
    return leaderboardData.slice(0, 5);
  }, [leaderboardData]);

  // -------------------------------------------------------------
  // RECHARTS CHART AGGREGATIONS (COLUMN 1 DATA ONLY)
  // -------------------------------------------------------------
  const dailyChartData = useMemo(() => {
    const dayMap: Record<string, number> = {};
    filteredRecords.forEach(r => {
      dayMap[r.date] = (dayMap[r.date] || 0) + r.totalTasks;
    });
    return Object.entries(dayMap)
      .map(([date, total]) => ({ name: date, "Total Tasks": total }))
      .sort((a, b) => a.name.localeCompare(b.name))
      .slice(-15); // limit to 15 items
  }, [filteredRecords]);

  const weeklyChartData = useMemo(() => {
    const weekMap: Record<string, number> = {};
    filteredRecords.forEach(r => {
      weekMap[r.week] = (weekMap[r.week] || 0) + r.totalTasks;
    });
    return Object.entries(weekMap)
      .map(([week, total]) => ({ name: week, "Total Tasks": total }))
      .sort((a, b) => a.name.localeCompare(b.name, undefined, {numeric: true}));
  }, [filteredRecords]);

  const monthlyChartData = useMemo(() => {
    const monthMap: Record<string, number> = {};
    filteredRecords.forEach(r => {
      monthMap[r.month] = (monthMap[r.month] || 0) + r.totalTasks;
    });
    return Object.entries(monthMap)
      .map(([month, total]) => ({ name: month, "Total Tasks": total }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [filteredRecords]);

  const yearlyChartData = useMemo(() => {
    const yearMap: Record<string, number> = {};
    filteredRecords.forEach(r => {
      yearMap[r.year] = (yearMap[r.year] || 0) + r.totalTasks;
    });
    return Object.entries(yearMap)
      .map(([year, total]) => ({ name: year, "Total Tasks": total }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [filteredRecords]);

  // Get active chart data depending on period tab
  const activeChartData = useMemo(() => {
    if (activeChartTab === 'daily') return dailyChartData;
    if (activeChartTab === 'weekly') return weeklyChartData;
    if (activeChartTab === 'month') return monthlyChartData;
    return yearlyChartData;
  }, [activeChartTab, dailyChartData, weeklyChartData, monthlyChartData, yearlyChartData]);

  // -------------------------------------------------------------
  // LEDGER PAGINATION
  // -------------------------------------------------------------
  const totalPages = Math.max(1, Math.ceil(leaderboardData.length / rowsPerPage));
  const paginatedLeaderboard = useMemo(() => {
    const start = (currentPage - 1) * rowsPerPage;
    return leaderboardData.slice(start, start + rowsPerPage);
  }, [leaderboardData, currentPage, rowsPerPage]);

  // -------------------------------------------------------------
  // ADVANCED EXPORTS
  // -------------------------------------------------------------
  const triggerConfetti = (employeeName: string) => {
    setCelebratedEmployee(employeeName);
    if (confettiTimeoutRef.current) clearTimeout(confettiTimeoutRef.current);
    confettiTimeoutRef.current = setTimeout(() => {
      setCelebratedEmployee(null);
    }, 4500);
  };

  const exportToExcel = () => {
    const formatted = leaderboardData.map(l => ({
      "Rank": l.rank,
      "Employee Name": l.employeeName,
      "Team Group": l.team,
      "Shift": l.shift,
      "Total Task as per Dashboard (Col 1)": l.totalTasks,
      "Total Escalations (Col 2)": l.escalations,
      "Moving Total as per Screen Meter (Col 3)": l.movingTotal,
      "Performance %": `${l.performancePercent}%`
    }));

    const worksheet = XLSX.utils.json_to_sheet(formatted);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Leaderboard Summary");
    
    // Add full ledger sheet as well
    const rawDataExport = filteredRecords.map(r => ({
      "Date": r.date,
      "Employee Name": r.employeeName,
      "Team Group": r.team,
      "Shift": r.shift,
      "Total Task as per Dashboard (Col 1)": r.totalTasks,
      "Total Escalations (Col 2)": r.escalations,
      "Moving Total as per Screen Meter (Col 3)": r.movingTotal,
      "Week": r.week,
      "Month": r.month,
      "Year": r.year
    }));
    const rawWorksheet = XLSX.utils.json_to_sheet(rawDataExport);
    XLSX.utils.book_append_sheet(workbook, rawWorksheet, "Synchronized Preset Log");

    XLSX.writeFile(workbook, `IPA_Preset_Report_${activeReportSummary?.fileName || 'export'}.xlsx`);
  };

  const exportToCSV = () => {
    const headers = 'Rank,Employee Name,Team,Shift,Total Tasks (Col 1),Total Escalations (Col 2),Moving Total (Col 3),Performance %\n';
    const rows = leaderboardData.map(l => 
      `${l.rank},"${l.employeeName}","${l.team}","${l.shift}",${l.totalTasks},${l.escalations},${l.movingTotal},${l.performancePercent}%`
    ).join('\n');
    
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', `IPA_Leaderboard_${activeReportSummary?.fileName || 'export'}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const triggerPDFPrint = () => {
    window.print();
  };

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-[#0b0e14] text-slate-800 dark:text-slate-100 overflow-hidden font-sans">
      
      {/* Sidebar Navigation */}
      <aside className="w-[260px] shrink-0 bg-white dark:bg-[#111827] border-r border-slate-200 dark:border-slate-800 flex flex-col min-h-screen sticky top-0 h-screen z-40">
        <div className="p-6">
          <h1 className="text-xl font-bold text-indigo-600 dark:text-indigo-400 font-headline flex items-center gap-2">
            <Trophy className="w-5 h-5 text-indigo-500 animate-bounce" />
            MarginEdge Pro
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider mt-1">Enterprise Analytics</p>
        </div>
        
        <nav className="flex-1 px-3 space-y-1.5 overflow-y-auto">
          <div className="px-4 py-2 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
            Production Modules
          </div>
          
          <button 
            onClick={() => setActiveModule('IPA')}
            className={`w-full flex items-center gap-3 px-4 py-3 border-l-4 text-left rounded-r-lg text-sm cursor-pointer transition-all ${
              activeModule === 'IPA'
                ? 'border-indigo-600 dark:border-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 font-bold'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            <span className={`material-symbols-outlined text-[20px] ${activeModule === 'IPA' ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400'}`}>analytics</span>
            <span>IPA Module</span>
          </button>

          <button 
            onClick={() => setActiveModule('LEGACY')}
            className={`w-full flex items-center gap-3 px-4 py-3 border-l-4 text-left rounded-r-lg text-sm cursor-pointer transition-all ${
              activeModule === 'LEGACY'
                ? 'border-indigo-600 dark:border-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 font-bold'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            <span className={`material-symbols-outlined text-[20px] ${activeModule === 'LEGACY' ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400'}`}>history_toggle_off</span>
            <span>Legacy Module</span>
          </button>

          {(userPosition === "Admin" || userPosition === "AM" || userPosition === "Team Lead" || userPosition === "Lead") && (
            <>
              <div className="px-4 py-2 pt-4 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
                Executive Tools
              </div>
              <button 
                onClick={() => onNavigate("PRESENTATION_DECK")}
                className="w-full flex items-center gap-3 px-4 py-3 text-purple-600 dark:text-purple-400 border-l-4 border-purple-500 bg-purple-500/10 hover:bg-purple-500/15 transition-all text-left font-bold rounded-r-lg text-sm cursor-pointer mb-1.5"
              >
                <span className="material-symbols-outlined text-purple-600 dark:text-purple-400 text-[20px]">co_present</span>
                <span>Presentation Deck</span>
              </button>

              <button 
                onClick={() => setActiveModule("GS_ADMIN")}
                className={`w-full flex items-center gap-3 px-4 py-3 border-l-4 text-left rounded-r-lg text-sm cursor-pointer transition-all ${
                  activeModule === "GS_ADMIN"
                    ? "border-indigo-600 dark:border-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 font-bold"
                    : "border-transparent text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/50"
                }`}
              >
                <span className={`material-symbols-outlined text-[20px] ${activeModule === "GS_ADMIN" ? "text-indigo-600 dark:text-indigo-400" : "text-slate-400"}`}>settings_suggest</span>
                <span>Google Sheets Admin</span>
              </button>
            </>
          )}
        </nav>

        <div className="p-4 mt-auto">
          <button 
            onClick={onLogout}
            className="flex items-center gap-3 px-4 py-2.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20 text-xs transition-colors rounded-lg text-left w-full cursor-pointer font-bold"
          >
            <span className="material-symbols-outlined text-sm">logout</span>
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Panel Content */}
      <div className="flex-1 min-h-screen flex flex-col overflow-y-auto bg-slate-50 dark:bg-[#0b0e14] relative">
        
        {/* Floating Celebration Overlay */}
        {celebratedEmployee && (
          <div className="absolute inset-0 pointer-events-none z-50 overflow-hidden flex justify-center items-center">
            <div className="absolute inset-0 bg-yellow-500/5 animate-pulse"></div>
            {Array.from({ length: 40 }).map((_, i) => {
              const left = Math.random() * 100;
              const delay = Math.random() * 2;
              const duration = 2 + Math.random() * 2;
              const size = 12 + Math.random() * 20;
              const color = ["#fbbf24", "#3b82f6", "#10b981", "#ec4899", "#8b5cf6"][i % 5];
              return (
                <div 
                  key={i}
                  className="absolute animate-bounce"
                  style={{
                    left: `${left}%`,
                    top: `-10%`,
                    fontSize: `${size}px`,
                    color: color,
                    animation: `fall ${duration}s linear ${delay}s infinite`,
                    transform: `rotate(${Math.random() * 360}deg)`
                  }}
                >
                  {i % 4 === 0 ? "🎉" : i % 4 === 1 ? "✨" : i % 4 === 2 ? "🏆" : "⭐️"}
                </div>
              );
            })}
          </div>
        )}

        <style>{`
          @keyframes fall {
            0% { top: -10%; transform: translateY(0) rotate(0deg); opacity: 1; }
            100% { top: 110%; transform: translateY(100vh) rotate(360deg); opacity: 0; }
          }
          @media print {
            aside { display: none !important; }
            header { display: none !important; }
            .no-print { display: none !important; }
            main { padding: 0 !important; }
            .bg-slate-50 { background-color: white !important; }
          }
        `}</style>

        {/* Top Header */}
        <header className="h-16 shrink-0 bg-white dark:bg-[#111827] border-b border-slate-200 dark:border-slate-800 flex items-center justify-between px-6 sticky top-0 z-30 shadow-sm no-print">
          <div className="flex items-center gap-4">
            <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100 font-headline flex items-center gap-2">
              <FileSpreadsheet className="text-indigo-500 w-5 h-5" />
              {activeModule === "GS_ADMIN" ? "Google Sheets Sync Control" : (activeModule === "IPA" ? "IPA" : "Legacy") + " Preset Performance Dashboard"}
            </h2>
            <div className="flex items-center gap-1.5 bg-green-50 dark:bg-green-950/40 px-2.5 py-1 rounded-full border border-green-200 dark:border-green-800 h-7">
              <span className="w-2 h-2 rounded-full bg-green-600 animate-pulse"></span>
              <span className="text-[10px] text-green-700 dark:text-green-400 font-bold uppercase tracking-wider">
                Active System
              </span>
            </div>
          </div>

          <div className="flex items-center gap-6">
            {reports.length > 0 && activeModule !== "GS_ADMIN" && (
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 dark:text-slate-400 font-bold">Active File:</span>
                <select 
                  value={selectedReportId}
                  onChange={(e) => setSelectedReportId(e.target.value)}
                  className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg py-1 px-2.5 text-xs font-semibold focus:outline-none focus:border-indigo-500 cursor-pointer text-slate-800 dark:text-slate-100"
                >
                  {reports.map(rep => (
                    <option key={rep.id} value={rep.id}>
                      {rep.fileName} ({rep.uploadDate})
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="flex items-center gap-3 pl-4 border-l border-slate-200 dark:border-slate-800">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-bold text-slate-800 dark:text-slate-100">{userName || 'Ankit Thakur'}</p>
                <p className="text-[10px] text-slate-400 font-bold uppercase">{userPosition || 'Lead'}</p>
              </div>
              <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-indigo-500 to-indigo-700 text-white flex items-center justify-center font-bold text-xs uppercase shadow-sm">
                {userName ? userName.split(' ').map(n => n[0]).join('').slice(0, 2) : 'AT'}
              </div>
            </div>
          </div>
        </header>

        {/* Main Body Grid */}
        <main className="p-6 space-y-6 flex-1">
          {activeModule === "GS_ADMIN" ? (
            <GoogleSheetsAdminPanel />
          ) : (
            <>
              {/* File Upload Area */}
              <div className="grid grid-cols-12 gap-6 no-print">
            <div className="col-span-12 xl:col-span-8">
              <div 
                className={`relative border-2 border-dashed rounded-xl p-6 transition-all duration-300 flex flex-col items-center justify-center text-center bg-white dark:bg-[#111827] shadow-sm overflow-hidden ${
                  isDragging ? 'border-indigo-500 bg-indigo-500/[0.02]' : 'border-slate-200 dark:border-slate-800 hover:border-indigo-400/50'
                }`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
              >
                <div className="absolute top-2 right-2 flex items-center gap-1.5 bg-indigo-50 dark:bg-indigo-950/40 px-2.5 py-0.5 rounded-full border border-indigo-200 dark:border-indigo-800 text-[9px] font-bold text-indigo-600 dark:text-indigo-400 uppercase">
                  <Activity className="w-3 h-3 animate-pulse" />
                  Auto-Detect Mode Active
                </div>

                <div className="p-3 bg-indigo-50 dark:bg-indigo-950/60 rounded-full text-indigo-500 dark:text-indigo-400 mb-3">
                  <Upload className="w-6 h-6 animate-pulse" />
                </div>
                
                <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 font-headline">
                  Drag &amp; Drop New Preset Report Spreadsheet Here
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mt-1 mb-4 leading-relaxed">
                  Imports dynamic worksheets exactly matching Column 1, 2, and 3. Automatically removes previous data and updates leaderboards, podiums, and Recharts graphs instantly.
                </p>

                <div className="flex items-center gap-3">
                  <label className="bg-indigo-600 dark:bg-indigo-500 text-white px-4 py-2 rounded-lg text-xs font-bold hover:opacity-95 transition-all shadow-md cursor-pointer flex items-center gap-2">
                    <FileSpreadsheet className="w-4 h-4" />
                    Upload .xlsx / .csv
                    <input 
                      type="file" 
                      accept=".xlsx,.xls,.csv" 
                      className="hidden" 
                      onChange={handleFileUploadEvent}
                    />
                  </label>
                  
                  {isSyncing && (
                    <span className="flex items-center gap-2 text-xs text-indigo-600 dark:text-indigo-400 font-bold animate-pulse">
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      Syncing cloud ledger...
                    </span>
                  )}
                </div>

                {uploadMessage && (
                  <div className={`mt-4 px-4 py-2.5 rounded-lg text-xs font-semibold max-w-xl flex items-center gap-2 ${
                    uploadMessage.type === 'success' ? 'bg-green-500/10 text-green-600 border border-green-500/20' :
                    uploadMessage.type === 'error' ? 'bg-red-500/10 text-red-600 border border-red-500/20' :
                    'bg-indigo-500/10 text-indigo-600 border border-indigo-500/20'
                  }`}>
                    {uploadMessage.type === 'success' ? <CheckCircle className="w-4 h-4 text-green-600" /> : <AlertTriangle className="w-4 h-4" />}
                    <span>{uploadMessage.text}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Guide Info */}
            <div className="col-span-12 xl:col-span-4 bg-gradient-to-br from-indigo-900 to-indigo-950 text-white rounded-xl p-6 shadow-md flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider mb-2">
                  <Sparkles className="w-4 h-4" />
                  SLA Data Integrity Rules
                </div>
                <h4 className="font-headline font-bold text-sm leading-snug">Zero-Configuration Dynamic Import</h4>
                <p className="text-[11px] text-slate-300 mt-2 leading-relaxed">
                  Upload raw logs without predefined mappings. The engine automatically maps the three columns:
                </p>
                <div className="space-y-1.5 mt-3 text-[11px] font-mono text-indigo-200">
                  <div className="flex items-center gap-2 bg-white/5 p-2 rounded">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                    <span>Col 1: Dashboard Total Task (KPI Graph)</span>
                  </div>
                  <div className="flex items-center gap-2 bg-white/5 p-2 rounded">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
                    <span>Col 2: Total Escalations</span>
                  </div>
                  <div className="flex items-center gap-2 bg-white/5 p-2 rounded">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    <span>Col 3: Moving Total as per Screen Meter</span>
                  </div>
                </div>
              </div>
              
              <div className="border-t border-indigo-800/60 pt-3 mt-4 flex items-center justify-between text-[10px] text-indigo-300">
                <span>Enterprise Cloud Storage</span>
                <span className="text-green-400 font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-ping"></span>
                  Connected
                </span>
              </div>
            </div>
          </div>

          {/* Premium Multi-Parameter Filter Card */}
          <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm no-print">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <Filter className="w-4 h-4 text-indigo-500" />
                Interactive Performance Filters
              </h4>
              <button 
                onClick={clearAllFilters}
                className="text-xs text-indigo-600 dark:text-indigo-400 font-bold hover:underline cursor-pointer flex items-center gap-1"
              >
                <RefreshCw className="w-3 h-3" />
                Reset Filters
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
              {/* Date Filter */}
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase">Filter Date</label>
                <select 
                  value={filterDate}
                  onChange={(e) => { setFilterDate(e.target.value); setCurrentPage(1); }}
                  className="w-full mt-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs text-slate-700 dark:text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="ALL">All Dates ({uniqueDates.length})</option>
                  {uniqueDates.map(d => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>

              {/* Employee Filter */}
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase">Filter Employee</label>
                <select 
                  value={filterEmployee}
                  onChange={(e) => { setFilterEmployee(e.target.value); setCurrentPage(1); }}
                  className="w-full mt-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs text-slate-700 dark:text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="ALL">All Employees ({uniqueEmployees.length})</option>
                  {uniqueEmployees.map(e => <option key={e} value={e}>{e}</option>)}
                </select>
              </div>

              {/* Week Filter */}
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase">Filter Week</label>
                <select 
                  value={filterWeek}
                  onChange={(e) => { setFilterWeek(e.target.value); setCurrentPage(1); }}
                  className="w-full mt-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs text-slate-700 dark:text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="ALL">All Weeks ({uniqueWeeks.length})</option>
                  {uniqueWeeks.map(w => <option key={w} value={w}>{w}</option>)}
                </select>
              </div>

              {/* Month Filter */}
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase">Filter Month</label>
                <select 
                  value={filterMonth}
                  onChange={(e) => { setFilterMonth(e.target.value); setCurrentPage(1); }}
                  className="w-full mt-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs text-slate-700 dark:text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="ALL">All Months ({uniqueMonths.length})</option>
                  {uniqueMonths.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
              </div>

              {/* Year Filter */}
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase">Filter Year</label>
                <select 
                  value={filterYear}
                  onChange={(e) => { setFilterYear(e.target.value); setCurrentPage(1); }}
                  className="w-full mt-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs text-slate-700 dark:text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="ALL">All Years ({uniqueYears.length})</option>
                  {uniqueYears.map(y => <option key={y} value={y}>{y}</option>)}
                </select>
              </div>

              {/* Team Filter */}
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase">Filter Team</label>
                <select 
                  value={filterTeam}
                  onChange={(e) => { setFilterTeam(e.target.value); setCurrentPage(1); }}
                  className="w-full mt-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs text-slate-700 dark:text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="ALL">All Teams ({uniqueTeams.length})</option>
                  {uniqueTeams.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>

              {/* Shift Filter */}
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase">Filter Shift</label>
                <select 
                  value={filterShift}
                  onChange={(e) => { setFilterShift(e.target.value); setCurrentPage(1); }}
                  className="w-full mt-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs text-slate-700 dark:text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="ALL">All Shifts ({uniqueShifts.length})</option>
                  {uniqueShifts.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>
          </div>

          {/* 3-Column Enterprise KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {/* KPI 1: Column 1 metric */}
            <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm flex flex-col justify-between hover:border-indigo-400/40 transition-all">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[9px] font-bold text-indigo-500 uppercase tracking-widest block">Column 1 Metric</span>
                  <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase">Total Task per Dashboard</span>
                </div>
                <div className="p-2 bg-indigo-50 dark:bg-indigo-950/60 rounded-lg text-indigo-600 dark:text-indigo-400">
                  <BarChart2 className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-4">
                <h3 className="text-3xl font-black font-mono text-indigo-600 dark:text-indigo-400">{filteredMetrics.totalTasks.toLocaleString()}</h3>
                <div className="flex items-center gap-1.5 mt-1.5">
                  <span className="text-[10px] font-bold text-green-600 bg-green-50 dark:bg-green-950/30 px-1.5 py-0.5 rounded">Primary KPI</span>
                  <span className="text-[10px] text-slate-400 font-medium">Graphs use only this value</span>
                </div>
              </div>
            </div>

            {/* KPI 2: Column 2 metric */}
            <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm flex flex-col justify-between hover:border-red-400/40 transition-all">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[9px] font-bold text-red-500 uppercase tracking-widest block">Column 2 Metric</span>
                  <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase">Total Escalations</span>
                </div>
                <div className="p-2 bg-red-50 dark:bg-red-950/60 rounded-lg text-red-600 dark:text-red-400">
                  <ShieldAlert className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-4">
                <h3 className="text-3xl font-black font-mono text-red-600 dark:text-red-400">{filteredMetrics.totalEscalations.toLocaleString()}</h3>
                <div className="flex items-center gap-1.5 mt-1.5">
                  <span className="text-[10px] font-bold text-red-600 bg-red-50 dark:bg-red-950/30 px-1.5 py-0.5 rounded">Numeric Only</span>
                  <span className="text-[10px] text-slate-400 font-medium">No graphs generated</span>
                </div>
              </div>
            </div>

            {/* KPI 3: Column 3 metric */}
            <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm flex flex-col justify-between hover:border-emerald-400/40 transition-all">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[9px] font-bold text-emerald-500 uppercase tracking-widest block">Column 3 Metric</span>
                  <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase">Avg Screen Meter Total</span>
                </div>
                <div className="p-2 bg-emerald-50 dark:bg-emerald-950/60 rounded-lg text-emerald-600 dark:text-emerald-400">
                  <Activity className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-4">
                <h3 className="text-3xl font-black font-mono text-emerald-600 dark:text-emerald-400">{filteredMetrics.averageMovingTotal.toLocaleString()}</h3>
                <div className="flex items-center gap-1.5 mt-1.5">
                  <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30 px-1.5 py-0.5 rounded">Numeric Only</span>
                  <span className="text-[10px] text-slate-400 font-medium">No graphs generated</span>
                </div>
              </div>
            </div>

            {/* KPI 4: Operators count */}
            <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm flex flex-col justify-between hover:border-indigo-400/40 transition-all">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[9px] font-bold text-indigo-500 uppercase tracking-widest block">Operational Scope</span>
                  <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase">Active Operators</span>
                </div>
                <div className="p-2 bg-indigo-50 dark:bg-indigo-950/60 rounded-lg text-indigo-600 dark:text-indigo-400">
                  <Users className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-4">
                <h3 className="text-3xl font-black font-mono text-slate-800 dark:text-slate-100">{filteredMetrics.activeEmployeesCount}</h3>
                <div className="flex items-center gap-1.5 mt-1.5">
                  <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 dark:bg-indigo-950/30 px-1.5 py-0.5 rounded">FTE Count</span>
                  <span className="text-[10px] text-slate-400 font-medium">Processing sub-divisions</span>
                </div>
              </div>
            </div>
          </div>

          {/* Gamified Performance Podium: Top 5 Operators Showcase */}
          <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h4 className="font-headline font-bold text-base text-slate-800 dark:text-slate-100 flex items-center gap-2">
                  <Trophy className="text-amber-500 w-5 h-5" />
                  Gamified Performance Podium (Top 5 Performers)
                </h4>
                <p className="text-xs text-slate-400 font-medium">Ranked dynamically by Total Task (Column 1 Metric)</p>
              </div>
              <div className="text-[10px] font-bold text-slate-400 uppercase font-mono">
                COMPLIANCE TARGETS MET
              </div>
            </div>

            {topFivePerformers.length === 0 ? (
              <div className="py-8 text-center text-slate-400 italic text-xs">
                No performance records logged in this batch.
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
                {topFivePerformers.map((performer, idx) => {
                  const rank = performer.rank;
                  const isTopThree = rank <= 3;
                  const isFirst = rank === 1;
                  
                  // Style colors based on Rank
                  const borderClass = isFirst 
                    ? 'border-amber-400 dark:border-amber-500 bg-amber-50/15 dark:bg-amber-950/10' 
                    : rank === 2 
                    ? 'border-slate-300 dark:border-slate-600 bg-slate-50/15 dark:bg-slate-800/10' 
                    : rank === 3 
                    ? 'border-orange-300 dark:border-orange-600 bg-orange-50/15'
                    : 'border-slate-100 dark:border-slate-800 bg-white dark:bg-[#111827]';

                  const badgeText = performer.totalTasks > 600 
                    ? "Elite Master Operator" 
                    : performer.totalTasks > 450 
                    ? "SLA Champion" 
                    : "Standard Achiever";

                  const badgeClass = performer.totalTasks > 600
                    ? "bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border-purple-200"
                    : performer.totalTasks > 450
                    ? "bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border-indigo-200"
                    : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200";

                  return (
                    <div 
                      key={performer.employeeName}
                      className={`relative border p-5 rounded-xl shadow-sm flex flex-col justify-between transition-all duration-300 hover:scale-[1.02] hover:shadow-md ${borderClass}`}
                    >
                      {/* Rank Trophy Badge */}
                      <div className="absolute top-2 right-2">
                        {rank === 1 ? (
                          <div className="bg-amber-100 dark:bg-amber-950/80 p-1.5 rounded-full text-amber-500 border border-amber-300">
                            <Trophy className="w-5 h-5 animate-pulse" />
                          </div>
                        ) : rank === 2 ? (
                          <div className="bg-slate-100 dark:bg-slate-800 p-1.5 rounded-full text-slate-500 border border-slate-300">
                            <Award className="w-5 h-5" />
                          </div>
                        ) : rank === 3 ? (
                          <div className="bg-orange-100 dark:bg-orange-950/80 p-1.5 rounded-full text-orange-600 border border-orange-300">
                            <Award className="w-5 h-5" />
                          </div>
                        ) : (
                          <span className="text-xs font-black font-mono text-slate-400 bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-full">
                            #{rank}
                          </span>
                        )}
                      </div>

                      {/* Profile details */}
                      <div>
                        <div className="flex items-center gap-3">
                          <div className={`w-12 h-12 rounded-full font-black text-sm flex items-center justify-center uppercase shadow-sm text-white bg-gradient-to-tr ${
                            rank === 1 
                              ? 'from-amber-400 to-yellow-600' 
                              : rank === 2 
                              ? 'from-slate-400 to-slate-600' 
                              : rank === 3 
                              ? 'from-orange-400 to-amber-700' 
                              : 'from-indigo-400 to-indigo-600'
                          }`}>
                            {performer.employeeName.split(' ').map(n => n[0]).join('').slice(0, 2)}
                          </div>
                          <div>
                            <h5 className="font-bold text-xs text-slate-800 dark:text-slate-100 truncate max-w-[110px]">{performer.employeeName}</h5>
                            <p className="text-[10px] text-slate-400 font-bold">{performer.team}</p>
                          </div>
                        </div>

                        {/* Performance Level */}
                        <div className="mt-4 space-y-2">
                          <div>
                            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">Performance %</span>
                            <div className="flex items-center gap-2 mt-0.5">
                              <div className="flex-1 bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
                                <div 
                                  className={`h-full rounded-full ${
                                    rank === 1 ? 'bg-amber-500' : rank === 2 ? 'bg-slate-400' : rank === 3 ? 'bg-orange-500' : 'bg-indigo-500'
                                  }`}
                                  style={{ width: `${performer.performancePercent}%` }}
                                ></div>
                              </div>
                              <span className="text-[10px] font-black font-mono text-slate-700 dark:text-slate-300">{performer.performancePercent}%</span>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-1 text-[10px]">
                            <div className="bg-slate-50 dark:bg-slate-800/60 p-1.5 rounded">
                              <span className="text-[8px] font-bold text-slate-400 uppercase block">Tasks</span>
                              <span className="font-bold font-mono text-slate-800 dark:text-slate-100">{performer.totalTasks}</span>
                            </div>
                            <div className="bg-slate-50 dark:bg-slate-800/60 p-1.5 rounded">
                              <span className="text-[8px] font-bold text-slate-400 uppercase block">Escalations</span>
                              <span className={`font-bold font-mono ${performer.escalations > 0 ? 'text-red-500' : 'text-slate-600 dark:text-slate-300'}`}>{performer.escalations}</span>
                            </div>
                          </div>

                          <span className={`inline-block text-[9px] font-bold px-2 py-0.5 rounded-full border text-center w-full mt-1 ${badgeClass}`}>
                            {badgeText}
                          </span>
                        </div>
                      </div>

                      {/* Interactive celebration action */}
                      <button 
                        onClick={() => triggerConfetti(performer.employeeName)}
                        className="mt-4 w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-indigo-50 dark:hover:bg-indigo-950 hover:border-indigo-200 dark:hover:border-indigo-800 text-[10px] font-bold py-1.5 rounded-lg text-slate-600 dark:text-slate-300 cursor-pointer flex items-center justify-center gap-1 transition-all"
                      >
                        <Sparkles className="w-3 h-3 text-amber-500" />
                        Celebrate Performer
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Interactive Recharts Data Trends Section */}
          <div className="grid grid-cols-12 gap-6">
            {/* Chart: Tabbed Daily, Weekly, Monthly, Yearly Performance (Column 1 only) */}
            <div className="col-span-12 lg:col-span-8 bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5">
                <div>
                  <h4 className="font-headline font-bold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-2">
                    <TrendingUp className="text-indigo-500 w-4 h-4" />
                    Operational Throughput Trends
                  </h4>
                  <p className="text-xs text-slate-400">Total Task as per Dashboard (Column 1 Metric) ONLY</p>
                </div>

                {/* Tab switchers */}
                <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700">
                  {(['daily', 'weekly', 'month', 'year'] as const).map(tab => (
                    <button
                      key={tab}
                      onClick={() => setActiveChartTab(tab)}
                      className={`px-3 py-1.5 text-[10px] font-bold rounded-md uppercase transition-all cursor-pointer ${
                        activeChartTab === tab 
                          ? 'bg-indigo-600 dark:bg-indigo-500 text-white shadow-sm' 
                          : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300'
                      }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>
              </div>

              <div className="h-72 w-full">
                {activeChartData.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-slate-400 italic text-xs">
                    Please upload an Excel spreadsheet to visualize operational curves.
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={activeChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <defs>
                        <linearGradient id="colorTasks" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#4f46e5" stopOpacity={0.0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                      <XAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 10, fontWeight: 600 }} />
                      <YAxis tick={{ fill: '#64748b', fontSize: 10 }} />
                      <Tooltip contentStyle={{ backgroundColor: '#1e293b', borderRadius: '8px', border: 'none', color: '#fff', fontSize: '11px' }} />
                      <Legend verticalAlign="top" height={36} iconSize={10} style={{ fontSize: '11px' }} />
                      <Area type="monotone" dataKey="Total Tasks" stroke="#4f46e5" strokeWidth={3} fillOpacity={1} fill="url(#colorTasks)" name="Total Tasks Completed" />
                    </AreaChart>
                  </ResponsiveContainer>
                )}
              </div>
            </div>

            {/* Metric distribution breakdown card */}
            <div className="col-span-12 lg:col-span-4 bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-headline font-bold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-2">
                    <BarChart2 className="text-indigo-500 w-4 h-4" />
                    {activeDistributionTab === 'team' ? 'Team Workload Distribution' : 'Vendor Workload Distribution'}
                  </h4>
                  {filteredRecords.some(r => r.vendor) && (
                    <div className="flex bg-slate-100 dark:bg-slate-800 p-0.5 rounded border border-slate-200 dark:border-slate-700">
                      <button
                        onClick={() => setActiveDistributionTab('team')}
                        className={`px-2 py-1 text-[9px] font-black rounded uppercase transition-all cursor-pointer ${
                          activeDistributionTab === 'team'
                            ? 'bg-indigo-600 text-white'
                            : 'text-slate-500'
                        }`}
                      >
                        Teams
                      </button>
                      <button
                        onClick={() => setActiveDistributionTab('vendor')}
                        className={`px-2 py-1 text-[9px] font-black rounded uppercase transition-all cursor-pointer ${
                          activeDistributionTab === 'vendor'
                            ? 'bg-indigo-600 text-white'
                            : 'text-slate-500'
                        }`}
                      >
                        Vendors
                      </button>
                    </div>
                  )}
                </div>
                <p className="text-xs text-slate-400 mb-4">
                  {activeDistributionTab === 'team' 
                    ? 'Comparison of task volumes across divisions' 
                    : 'Comparison of task volumes across vendors/clients parsed from Excel'}
                </p>
                
                <div className="space-y-3.5">
                  {activeDistributionTab === 'team' ? (
                    Array.from(new Set(filteredRecords.map(r => r.team))).slice(0, 4).map(team => {
                      const teamRecs = filteredRecords.filter(r => r.team === team);
                      const totalTasks = teamRecs.reduce((sum, r) => sum + r.totalTasks, 0);
                      const percent = Math.min(Math.round((totalTasks / Math.max(filteredMetrics.totalTasks, 1)) * 100), 100);
                      
                      return (
                        <div key={team} className="space-y-1">
                          <div className="flex items-center justify-between text-xs font-bold">
                            <span className="text-slate-700 dark:text-slate-200">{team}</span>
                            <span className="text-slate-400 font-mono">{totalTasks} ({percent}%)</span>
                          </div>
                          <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
                            <div className="bg-indigo-500 h-full rounded-full" style={{ width: `${percent}%` }}></div>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    Array.from(new Set(filteredRecords.map(r => r.vendor).filter(Boolean))).slice(0, 4).map(vendor => {
                      const vendorRecs = filteredRecords.filter(r => r.vendor === vendor);
                      const totalTasks = vendorRecs.reduce((sum, r) => sum + r.totalTasks, 0);
                      const percent = Math.min(Math.round((totalTasks / Math.max(filteredMetrics.totalTasks, 1)) * 100), 100);
                      
                      return (
                        <div key={vendor} className="space-y-1">
                          <div className="flex items-center justify-between text-xs font-bold">
                            <span className="text-slate-700 dark:text-slate-200">{vendor}</span>
                            <span className="text-slate-400 font-mono">{totalTasks} ({percent}%)</span>
                          </div>
                          <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
                            <div className="bg-indigo-500 h-full rounded-full" style={{ width: `${percent}%` }}></div>
                          </div>
                        </div>
                      );
                    })
                  )}
                  {activeDistributionTab === 'vendor' && !filteredRecords.some(r => r.vendor) && (
                    <div className="text-xs text-slate-400 italic py-4 text-center">
                      No vendor information available in the currently loaded Excel sheet.
                    </div>
                  )}
                </div>
              </div>
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 flex items-center justify-between mt-6">
                <span>Maximum {activeDistributionTab === 'team' ? 'Division' : 'Vendor'} Volume:</span>
                <span className="font-black text-indigo-500">
                  {activeDistributionTab === 'team' ? (
                    Array.from(new Set(filteredRecords.map(r => r.team))).map(team => {
                      return { name: team, count: filteredRecords.filter(r => r.team === team).reduce((sum, r) => sum + r.totalTasks, 0) };
                    }).sort((a,b) => b.count - a.count)[0]?.name || "N/A"
                  ) : (
                    Array.from(new Set(filteredRecords.map(r => r.vendor).filter(Boolean))).map(vendor => {
                      return { name: vendor, count: filteredRecords.filter(r => r.vendor === vendor).reduce((sum, r) => sum + r.totalTasks, 0) };
                    }).sort((a,b) => b.count - a.count)[0]?.name || "N/A"
                  )}
                </span>
              </div>
            </div>
          </div>

          {/* AI Operational Co-Pilot Panel */}
          <div className="grid grid-cols-12 gap-6 no-print">
            <div className="col-span-12">
              <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 text-white rounded-xl shadow-xl border border-indigo-500/20 overflow-hidden">
                <div className="px-6 py-4 bg-white/[0.03] border-b border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="bg-indigo-500/20 p-2 rounded-lg text-indigo-300">
                      <Sparkles className="w-5 h-5 animate-pulse" />
                    </div>
                    <div>
                      <h4 className="font-headline font-bold text-base">Gemini AI Operational Co-Pilot</h4>
                      <p className="text-[10px] text-indigo-200/70 font-bold uppercase">Dynamic Preset Report Audit</p>
                    </div>
                  </div>
                  
                  <button
                    disabled={analyzing || !activeReportSummary}
                    onClick={() => activeReportSummary && runAIAnalysis(activeReportSummary)}
                    className="bg-indigo-500 text-white px-4 py-1.5 rounded-lg text-xs font-bold hover:bg-indigo-400 transition-all cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${analyzing ? 'animate-spin' : ''}`} />
                    {analyzing ? 'Generating audit...' : 'Regenerate Operations Audit'}
                  </button>
                </div>

                <div className="p-6">
                  {analyzing ? (
                    <div className="py-12 flex flex-col items-center justify-center space-y-4">
                      <div className="w-8 h-8 border-4 border-indigo-400 border-t-transparent rounded-full animate-spin"></div>
                      <p className="text-xs text-indigo-200/80 font-bold uppercase tracking-wider animate-pulse">
                        Analyzing 3-column operator matrix with Gemini...
                      </p>
                    </div>
                  ) : aiError ? (
                    <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg text-xs text-red-300 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                      <div>
                        <p className="font-bold">Operations Audit Pending</p>
                        <p className="text-red-300/80 mt-0.5">{aiError}</p>
                      </div>
                    </div>
                  ) : aiAnalysis ? (
                    <div className="grid grid-cols-12 gap-6">
                      
                      {/* Circle health rating */}
                      <div className="col-span-12 lg:col-span-4 space-y-5 border-r border-white/5 pr-6">
                        <div className="bg-white/5 rounded-xl p-5 border border-white/5 flex items-center gap-5">
                          <div className="relative w-20 h-20 flex-shrink-0">
                            <svg className="w-full h-full transform -rotate-90">
                              <circle cx="40" cy="40" r="34" stroke="rgba(255,255,255,0.05)" strokeWidth="6" fill="transparent" />
                              <circle 
                                cx="40" cy="40" r="34" 
                                stroke={aiAnalysis.overallPerformanceScore >= 90 ? '#10b981' : aiAnalysis.overallPerformanceScore >= 80 ? '#fbbf24' : '#f87171'} 
                                strokeWidth="6" 
                                fill="transparent" 
                                strokeDasharray={2 * Math.PI * 34}
                                strokeDashoffset={2 * Math.PI * 34 * (1 - aiAnalysis.overallPerformanceScore / 100)}
                                strokeLinecap="round"
                              />
                            </svg>
                            <span className="absolute inset-0 flex items-center justify-center text-lg font-black font-mono">
                              {aiAnalysis.overallPerformanceScore}
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] font-bold text-indigo-300 uppercase tracking-widest block font-mono">Operations rating</span>
                            <h4 className="text-base font-bold mt-0.5">SLA Health Score</h4>
                            <p className="text-xs text-slate-300/80">Derived from tasks completed.</p>
                          </div>
                        </div>

                        {/* Top Performers and Needs Support */}
                        <div className="space-y-3.5">
                          <div className="bg-green-500/5 rounded-xl p-4 border border-green-500/20">
                            <span className="text-[9px] font-bold text-green-400 uppercase tracking-wider block">⭐ OUTSTANDING PERFORMER</span>
                            <p className="text-sm font-bold text-white mt-1">{aiAnalysis.bestPerformingAnalyst}</p>
                          </div>

                          <div className="bg-red-500/5 rounded-xl p-4 border border-red-500/20">
                            <span className="text-[9px] font-bold text-red-400 uppercase tracking-wider block">⚠️ SLA COMPLIANCE WATCHLIST</span>
                            <p className="text-sm font-bold text-white mt-1">{aiAnalysis.lowestPerformingAnalyst}</p>
                          </div>
                        </div>
                      </div>

                      {/* AI recommendations */}
                      <div className="col-span-12 lg:col-span-8 space-y-6">
                        <div className="space-y-2">
                          <span className="text-[10px] font-bold text-indigo-300 uppercase tracking-widest block font-mono">Executive Operations summary</span>
                          <p className="text-xs text-slate-300 leading-relaxed font-sans">
                            {aiAnalysis.executiveSummary}
                          </p>
                        </div>

                        {/* Risk, Bottlenecks and Actions Bullet Grid */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-4 border-t border-white/5">
                          <div>
                            <span className="text-[10px] font-bold text-red-400 uppercase tracking-widest flex items-center gap-1 font-mono">
                              <AlertTriangle className="w-3.5 h-3.5" />
                              Compliance Risks Detected
                            </span>
                            <ul className="mt-2.5 space-y-2">
                              {aiAnalysis.riskDetection.map((risk, index) => (
                                <li key={index} className="text-xs text-slate-300 flex items-start gap-2 leading-relaxed">
                                  <span className="w-1.5 h-1.5 rounded-full bg-red-400 mt-1.5 flex-shrink-0"></span>
                                  <span>{risk}</span>
                                </li>
                              ))}
                            </ul>
                          </div>

                          <div>
                            <span className="text-[10px] font-bold text-green-400 uppercase tracking-widest flex items-center gap-1 font-mono">
                              <Sparkles className="w-3.5 h-3.5" />
                              Actionable Playbooks
                            </span>
                            <ul className="mt-2.5 space-y-2">
                              {aiAnalysis.aiRecommendations.map((rec, index) => (
                                <li key={index} className="text-xs text-slate-300 flex items-start gap-2 leading-relaxed">
                                  <span className="w-1.5 h-1.5 rounded-full bg-green-400 mt-1.5 flex-shrink-0"></span>
                                  <span>{rec}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>

                    </div>
                  ) : (
                    <div className="py-8 text-center text-slate-400 text-xs italic">
                      Upload an IPA spreadsheet file to generate an automated AI co-pilot operations audit.
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Detailed Paginated Records Table Block */}
          <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm overflow-hidden flex flex-col">
            
            {/* Filter bar */}
            <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                <h4 className="font-headline font-bold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-2">
                  <Star className="w-4 h-4 text-indigo-500" />
                  Synchronized Preset Ledger
                </h4>
                <div className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-500 px-2 py-0.5 rounded-full font-bold">
                  {filteredRecords.length} records parsed
                </div>
              </div>

              {/* Search and export actions */}
              <div className="flex items-center gap-3 no-print">
                <div className="relative">
                  <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-base">search</span>
                  <input 
                    type="text"
                    value={searchTerm}
                    onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1); }}
                    placeholder="Search name or division..."
                    className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg py-1.5 pl-9 pr-4 text-xs focus:outline-none focus:border-indigo-500 w-52 text-slate-800 dark:text-slate-100"
                  />
                </div>

                <div className="flex gap-1.5">
                  <button 
                    onClick={exportToExcel}
                    className="w-8 h-8 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 cursor-pointer transition-all"
                    title="Export as Excel"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-indigo-500" />
                  </button>
                  <button 
                    onClick={exportToCSV}
                    className="w-8 h-8 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 cursor-pointer transition-all"
                    title="Export as CSV"
                  >
                    <FileText className="w-4 h-4 text-indigo-500" />
                  </button>
                  <button 
                    onClick={triggerPDFPrint}
                    className="w-8 h-8 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 cursor-pointer transition-all"
                    title="Print PDF Report"
                  >
                    <Trophy className="w-4 h-4 text-amber-500" />
                  </button>
                </div>
              </div>
            </div>

            {/* Table data */}
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 sticky top-0">
                  <tr>
                    <th className="px-5 py-3 text-[10px] font-bold text-slate-400 text-left uppercase tracking-wider">Rank</th>
                    <th className="px-5 py-3 text-[10px] font-bold text-slate-400 text-left uppercase tracking-wider">Employee (Operator)</th>
                    <th className="px-5 py-3 text-[10px] font-bold text-slate-400 text-left uppercase tracking-wider">Division Team</th>
                    <th className="px-5 py-3 text-[10px] font-bold text-slate-400 text-left uppercase tracking-wider">Shift Slot</th>
                    <th className="px-5 py-3 text-[10px] font-bold text-slate-400 text-right uppercase tracking-wider">Total Tasks (Col 1)</th>
                    <th className="px-5 py-3 text-[10px] font-bold text-slate-400 text-right uppercase tracking-wider">Total Escalations (Col 2)</th>
                    <th className="px-5 py-3 text-[10px] font-bold text-slate-400 text-right uppercase tracking-wider">Moving Total (Col 3)</th>
                    <th className="px-5 py-3 text-[10px] font-bold text-slate-400 text-right uppercase tracking-wider">SLA Performance %</th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {paginatedLeaderboard.length > 0 ? (
                    paginatedLeaderboard.map((row) => (
                      <tr 
                        key={row.employeeName} 
                        className={`hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors ${
                          row.escalations > 2 ? 'bg-red-500/5' : ''
                        }`}
                      >
                        <td className="px-5 py-3.5 text-xs font-black font-mono text-slate-400 whitespace-nowrap">
                          {row.rank <= 3 ? (
                            <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-black ${
                              row.rank === 1 ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200' :
                              row.rank === 2 ? 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200' :
                              'bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-200'
                            }`}>
                              Rank {row.rank}
                            </span>
                          ) : (
                            `#${row.rank}`
                          )}
                        </td>
                        <td className="px-5 py-3.5 text-xs font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                          <div className="w-7 h-7 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 text-[10px] font-bold flex items-center justify-center uppercase">
                            {row.employeeName.split(' ').map(n => n[0]).join('').slice(0, 2)}
                          </div>
                          <span>{row.employeeName}</span>
                          {row.totalTasks > 600 && (
                            <span className="bg-purple-100 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300 text-[8px] font-black px-1.5 py-0.5 rounded uppercase">ELITE</span>
                          )}
                        </td>
                        <td className="px-5 py-3.5 text-xs text-slate-700 dark:text-slate-300 font-semibold">{row.team}</td>
                        <td className="px-5 py-3.5 text-xs text-slate-500 dark:text-slate-400">
                          <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                            row.shift === 'Day' ? 'bg-amber-50 text-amber-700 border border-amber-100' : 'bg-slate-100 text-slate-700 border border-slate-200'
                          }`}>
                            {row.shift}
                          </span>
                        </td>
                        <td className="px-5 py-3.5 text-xs text-right font-black font-mono text-indigo-600 dark:text-indigo-400">{row.totalTasks.toLocaleString()}</td>
                        <td className="px-5 py-3.5 text-xs text-right font-black font-mono text-red-600 dark:text-red-400">{row.escalations.toLocaleString()}</td>
                        <td className="px-5 py-3.5 text-xs text-right font-semibold font-mono text-slate-500 dark:text-slate-400">{row.movingTotal.toLocaleString()}</td>
                        <td className="px-5 py-3.5 text-xs text-right">
                          <div className="flex items-center justify-end gap-2">
                            <div className="w-24 bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
                              <div 
                                className={`h-full rounded-full ${
                                  row.performancePercent >= 90 ? 'bg-green-500' : row.performancePercent >= 75 ? 'bg-amber-500' : 'bg-red-500'
                                }`} 
                                style={{ width: `${row.performancePercent}%` }}
                              ></div>
                            </div>
                            <span className="font-bold font-mono min-w-[32px]">{row.performancePercent}%</span>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={8} className="px-6 py-12 text-center text-slate-400 italic text-xs">
                        No active records match the current filters.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination footer */}
            <div className="px-5 py-3.5 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/20 flex items-center justify-between no-print">
              <div className="flex items-center gap-4 text-xs">
                <span className="text-slate-500 dark:text-slate-400 font-bold">Page {currentPage} of {totalPages}</span>
                <div className="flex gap-1">
                  <button 
                    onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                    disabled={currentPage === 1}
                    className="w-8 h-8 flex items-center justify-center rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-50 disabled:pointer-events-none transition-all cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4 text-slate-600 dark:text-slate-300" />
                  </button>
                  <button 
                    onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                    disabled={currentPage === totalPages}
                    className="w-8 h-8 flex items-center justify-center rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-50 disabled:pointer-events-none transition-all cursor-pointer"
                  >
                    <ChevronRight className="w-4 h-4 text-slate-600 dark:text-slate-300" />
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                <span>Rows per page:</span>
                <select 
                  value={rowsPerPage}
                  onChange={(e) => { setRowsPerPage(Number(e.target.value)); setCurrentPage(1); }}
                  className="border border-slate-200 dark:border-slate-700 rounded py-1 px-2 bg-white dark:bg-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-xs"
                >
                  <option value={10}>10</option>
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
              </div>
            </div>

          </div>
          </>
        )}
        </main>
      </div>

    </div>
  );
}
