import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { 
  ReconciliationRecord, 
  IPARecord, 
  TeamPerformance, 
  AMAlert, 
  PortfolioLog,
  RealtimeNotification
} from '../types';
import { useAuth } from './AuthContext';
import { collection, doc, onSnapshot, getDocFromServer, setDoc, updateDoc, deleteDoc, query, orderBy } from 'firebase/firestore';
import { db, auth } from '../firebase';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.warn('Firestore Handled Error: ', JSON.stringify(errInfo));
}

interface RealtimeContextType {
  reconciliationRecords: ReconciliationRecord[];
  ipaRecords: IPARecord[];
  teamPerformance: TeamPerformance[];
  amAlerts: AMAlert[];
  portfolioLogs: PortfolioLog[];
  productionTrend: any[];
  updateRecord: (record: ReconciliationRecord) => void;
  createLog: (log: PortfolioLog) => void;
  updateAlert: (alert: AMAlert) => void;
  updateAllIpaRecords: (records: IPARecord[]) => void;
  resetState: () => void;
  isConnected: boolean;
  notifications: RealtimeNotification[];
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  clearNotification: (id: string) => void;
  clearAllNotifications: () => void;
  simulateEvent: (type: 'upload' | 'vendor' | 'error' | 'accuracy' | 'report') => Promise<void>;
  refreshData: () => Promise<void>;
}

const RealtimeContext = createContext<RealtimeContextType | undefined>(undefined);

export function RealtimeProvider({ children }: { children: React.ReactNode }) {
  const [reconciliationRecords, setReconciliationRecords] = useState<ReconciliationRecord[]>(() => [
    { id: 'rec-1', user: 'kazimuhammad', office: 'Dhaka', team: 'Core Ops', points: 345, errors: 2, errorPercentage: 0.6, status: 'MATCHED' },
    { id: 'rec-2', user: 'mehedi', office: 'Dhaka', team: 'Core Ops', points: 176.5, errors: 176.5, errorPercentage: 100.0, status: 'HIGH PRIORITY' },
    { id: 'rec-3', user: 'tasnim', office: 'Dhaka', team: 'Core Ops', points: 3.0, errors: 3.0, errorPercentage: 100.0, status: 'PENDING' },
    { id: 'rec-4', user: 'ankushsharma', office: 'Havana', team: 'Island Ops', points: 412.0, errors: 8.6, errorPercentage: 2.1, status: 'MATCHED' },
    { id: 'rec-5', user: 'pritipal', office: 'Dhaka', team: 'Alpha Ops', points: 128.0, errors: 5.3, errorPercentage: 4.1, status: 'PENDING' },
    { id: 'rec-6', user: 'vikasnegi', office: 'Chandigarh', team: 'Capital Lead', points: 842.0, errors: 11.7, errorPercentage: 1.4, status: 'MATCHED' },
    { id: 'rec-7', user: 'swatirana', office: 'Chandigarh', team: 'Alpha Ops', points: 399.0, errors: 2.4, errorPercentage: 0.6, status: 'MATCHED' },
    { id: 'rec-8', user: 'amanarora', office: 'Dhaka', team: 'Core Ops', points: 615.0, errors: 7.3, errorPercentage: 1.2, status: 'MATCHED' },
    { id: 'rec-9', user: 'jyotisharma', office: 'US', team: 'Capital Lead', points: 288.0, errors: 32.1, errorPercentage: 11.1, status: 'HIGH PRIORITY' }
  ]);
  const [ipaRecords, setIpaRecords] = useState<IPARecord[]>(() => [
    { id: 'ipa-1', name: 'deepnarawat', team: 'Alpha', tasks: 300 },
    { id: 'ipa-2', name: 'hardeeprohilla', team: 'Alpha', tasks: 916 },
    { id: 'ipa-3', name: 'jaspreetsaini', team: 'Alpha', tasks: 731 },
    { id: 'ipa-4', name: 'monikathakur', team: 'Alpha', tasks: 698 },
    { id: 'ipa-5', name: 'dimpiyadav', team: 'Alpha', tasks: 443 },
    { id: 'ipa-6', name: 'garimasohal', team: 'Alpha', tasks: 294 },
    { id: 'ipa-7', name: 'ankushsharma', team: 'Havana', tasks: 512 },
    { id: 'ipa-8', name: 'pritipal', team: 'Dhaka', tasks: 128 },
    { id: 'ipa-9', name: 'vikasnegi', team: 'Chandigarh', tasks: 842 },
    { id: 'ipa-10', name: 'swatirana', team: 'Alpha', tasks: 399 },
    { id: 'ipa-11', name: 'amanarora', team: 'Core', tasks: 615 },
    { id: 'ipa-12', name: 'jyotisharma', team: 'US', tasks: 288 }
  ]);
  const [teamPerformance, setTeamPerformance] = useState<TeamPerformance[]>(() => [
    { teamName: 'Alpha', efficiency: 92, errorRate: 12, output: '12.4k', lead: 'Alpha Ops' },
    { teamName: 'Core Ops', efficiency: 85, errorRate: 25, output: '8.1k', lead: 'Beta Team' },
    { teamName: 'Havana', efficiency: 70, errorRate: 40, output: '5.2k', lead: 'Island Ops' },
    { teamName: 'Dhaka Admin', efficiency: 45, errorRate: 85, output: '12.4k', lead: 'Alpha Ops' },
    { teamName: 'Chandigarh BPO', efficiency: 78, errorRate: 18, output: '15.9k', lead: 'Capital Lead' }
  ]);
  const [amAlerts, setAmAlerts] = useState<AMAlert[]>(() => [
    { id: 'am-1', name: 'Sarah Jenkins', role: 'Senior Manager', alertsCount: 14, accuracyCurrent: 94.2, accuracyTarget: 98.0, criticality: 'High Risk' },
    { id: 'am-2', name: 'Michael Chen', role: 'Portfolio Lead', alertsCount: 8, accuracyCurrent: 97.8, accuracyTarget: 98.0, criticality: 'Stable' },
    { id: 'am-3', name: 'Elena Rodriguez', role: 'Associate Manager', alertsCount: 20, accuracyCurrent: 82.5, accuracyTarget: 98.0, criticality: 'Immediate Action' }
  ]);
  const [portfolioLogs, setPortfolioLogs] = useState<PortfolioLog[]>(() => [
    { id: 'log-1', date: 'Oct 24, 2023', analystName: 'Michael Chen', vendorName: 'US Foods', taskType: 'Invoice', status: 'MATCHING', accuracy: 98.2, ir: 12, reco: 8, time: '45m', errors: 1, fr: 6, qres: 2 },
    { id: 'log-2', date: 'Oct 24, 2023', analystName: 'Amanda Rogers', vendorName: 'Sysco Services', taskType: 'Credit Note', status: 'ALERT', accuracy: 84.5, ir: 15, reco: 10, time: '1.2h', errors: 3, fr: 8, qres: 5 },
    { id: 'log-3', date: 'Oct 23, 2023', analystName: 'David Miller', vendorName: 'GORDON Food', taskType: 'Invoice', status: 'PENDING', accuracy: 92.0, ir: 9, reco: 7, time: '30m', errors: 0, fr: 5, qres: 1 },
    { id: 'log-4', date: 'Oct 23, 2023', analystName: 'Sarah Jenkins', vendorName: 'US Foods', taskType: 'Discrepancy Log', status: 'MATCHING', accuracy: 99.8, ir: 22, reco: 18, time: '2.5h', errors: 0, fr: 15, qres: 12 },
    { id: 'log-5', date: 'Oct 23, 2023', analystName: 'Michael Chen', vendorName: 'Performance Food', taskType: 'Invoice', status: 'ALERT', accuracy: 72.1, ir: 14, reco: 9, time: '55m', errors: 4, fr: 7, qres: 0 }
  ]);
  const [productionTrend, setProductionTrend] = useState<any[]>(() => [
    { name: '08:00 AM', value: 2000 },
    { name: '10:00 AM', value: 5500 },
    { name: '12:00 PM', value: 4200 },
    { name: '02:00 PM', value: 14204 },
    { name: '04:00 PM', value: 8100 },
    { name: '06:00 PM', value: 9500 },
    { name: '08:00 PM', value: 3000 },
    { name: '10:00 PM', value: 5800 }
  ]);
  const [isConnected, setIsConnected] = useState<boolean>(false);
  
  const [notifications, setNotifications] = useState<RealtimeNotification[]>([]);

  const { currentUser, userProfile } = useAuth();
  const knownVendorsRef = useRef<Set<string>>(new Set());

  const addNotification = useCallback(async (notif: Omit<RealtimeNotification, 'id' | 'timestamp' | 'read'> & { customId?: string }) => {
    const id = notif.customId || `notif_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
    const newNotif = {
      id,
      type: notif.type,
      title: notif.title,
      message: notif.message,
      timestamp: new Date().toISOString(),
      read: false,
      meta: notif.meta || null
    };

    try {
      await setDoc(doc(db, "notifications", id), newNotif);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `notifications/${id}`);
    }
  }, []);

  const markAsRead = useCallback(async (id: string) => {
    try {
      await updateDoc(doc(db, "notifications", id), { read: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `notifications/${id}`);
    }
  }, []);

  const markAllAsRead = useCallback(async () => {
    try {
      const unread = notifications.filter(n => !n.read);
      const batchPromises = unread.map(n => updateDoc(doc(db, "notifications", n.id), { read: true }));
      await Promise.all(batchPromises);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "notifications");
    }
  }, [notifications]);

  const clearNotification = useCallback(async (id: string) => {
    try {
      await deleteDoc(doc(db, "notifications", id));
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `notifications/${id}`);
    }
  }, []);

  const clearAllNotifications = useCallback(async () => {
    try {
      const batchPromises = notifications.map(n => deleteDoc(doc(db, "notifications", n.id)));
      await Promise.all(batchPromises);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "notifications");
    }
  }, [notifications]);

  const simulateEvent = useCallback(async (type: 'upload' | 'vendor' | 'error' | 'accuracy' | 'report') => {
    const ts = Date.now();
    const id = `sim_${type}_${ts}`;
    
    const mockData: any = {
      id,
      date: new Date().toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' }),
      analystName: currentUser?.displayName || userProfile?.name || 'Ankit Thakur',
      taskType: type === 'upload' ? 'Excel Upload' : 'Matching',
      status: 'PENDING' as const,
      accuracy: 99.0
    };

    if (type === 'upload') {
      mockData.vendorName = 'Acme Supplies';
      mockData.taskType = 'Excel Upload';
      mockData.status = 'MATCHING';
      mockData.accuracy = 98.8;
      mockData.errors = 0;
    } else if (type === 'vendor') {
      const vendorNames = ['Oceanic Fresh', 'Metro Paper Co', 'Direct Dairy', 'Summit Meats', 'Vortex Produce'];
      const chosen = vendorNames[Math.floor(Math.random() * vendorNames.length)] + ' ' + Math.floor(Math.random() * 1000);
      mockData.vendorName = chosen;
      mockData.taskType = 'Manual Entry';
      mockData.status = 'ALERT';
      mockData.accuracy = 88.5;
      mockData.errors = 1;
    } else if (type === 'error') {
      mockData.vendorName = 'Sysco Logistics';
      mockData.taskType = 'Reconciliation';
      mockData.status = 'ALERT';
      mockData.accuracy = 82.5;
      mockData.errors = 5;
    } else if (type === 'accuracy') {
      mockData.vendorName = 'US Foods BPO';
      mockData.taskType = 'Matching';
      mockData.status = 'PENDING';
      mockData.accuracy = 68.0;
      mockData.errors = 2;
    } else if (type === 'report') {
      mockData.vendorName = 'Baldor Foods';
      mockData.taskType = 'Missing Report';
      mockData.status = 'ALERT';
      mockData.accuracy = 0.0;
      mockData.errors = 0;
    }

    try {
      const colRef = collection(db, 'logs');
      await setDoc(doc(colRef, id), mockData);
      console.log(`Successfully wrote simulated Firestore event of type: ${type}`);
    } catch (err) {
      console.warn('⚠️ Client-side direct Firestore write was restricted. Falling back to secure backend log creation endpoint...', err);
      await fetch('/api/logs/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(mockData)
      }).catch(fetchErr => console.error('Failed to write log via fallback API:', fetchErr));
      
      // Optimistically update local logs list so changes are immediately visible
      setPortfolioLogs(prev => {
        if (prev.some(p => p.id === mockData.id)) return prev;
        return [mockData, ...prev];
      });
    }
  }, [currentUser, userProfile]);

  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.warn("Firestore connection is offline or restricted by iframe. Using REST backend/simulated fallback.");
        }
      }
    }
    if (currentUser) {
      testConnection();
    }
  }, [currentUser]);

  const fetchStateFallback = useCallback(async () => {
    try {
      const response = await fetch('/api/state');
      if (response.ok) {
        const data = await response.json();
        if (data.portfolioLogs) setPortfolioLogs(data.portfolioLogs);
        if (data.reconciliationRecords) setReconciliationRecords(data.reconciliationRecords);
        if (data.ipaRecords) setIpaRecords(data.ipaRecords);
        if (data.teamPerformance) setTeamPerformance(data.teamPerformance);
        if (data.amAlerts) setAmAlerts(data.amAlerts);
        if (data.productionTrend) setProductionTrend(data.productionTrend);
        console.log('🔄 [RealtimeContext] Fallback REST state successfully populated.');
      }
    } catch (err) {
      console.warn('⚠️ [RealtimeContext] Fallback REST fetch failed (using local state):', err);
    }
  }, []);

  useEffect(() => {
    if (!currentUser) {
      setIsConnected(false);
      return;
    }

    setIsConnected(true);

    // 1. Listen to dashboardStats / reconciliation_records
    const unsubRecon = onSnapshot(doc(db, "dashboardStats", "reconciliation_records"), (snapshot) => {
      if (snapshot.exists()) {
        setReconciliationRecords(snapshot.data().records || []);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, "dashboardStats/reconciliation_records");
      fetchStateFallback();
    });

    // 2. Listen to dashboardStats / am_alerts
    let isInitialAlerts = true;
    const unsubAlerts = onSnapshot(doc(db, "dashboardStats", "am_alerts"), (snapshot) => {
      if (snapshot.exists()) {
        const alertsList = snapshot.data().alerts || [];
        setAmAlerts(alertsList);

        if (!isInitialAlerts) {
          // Compare alerts and notify of low accuracy or escalation
          alertsList.forEach((alert: any) => {
            if (alert.accuracyCurrent < 90) {
              addNotification({
                type: 'accuracy',
                title: 'Low Accuracy Escalation',
                message: `AM Warning: Analyst ${alert.name} current accuracy is low at ${alert.accuracyCurrent}% (Target: ${alert.accuracyTarget}%).`,
                meta: { id: alert.id, accuracy: alert.accuracyCurrent }
              });
            } else if (alert.criticality === 'Immediate Action') {
              addNotification({
                type: 'error',
                title: 'AM Immediate Action Alert',
                message: `Analyst ${alert.name} requires immediate supervisor review due to ${alert.alertsCount} outstanding alerts.`,
                meta: { id: alert.id }
              });
            }
          });
        } else {
          isInitialAlerts = false;
        }
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, "dashboardStats/am_alerts");
      fetchStateFallback();
    });

    // 3. Listen to dashboardStats / production_trend
    const unsubTrend = onSnapshot(doc(db, "dashboardStats", "production_trend"), (snapshot) => {
      if (snapshot.exists()) {
        setProductionTrend(snapshot.data().trend || []);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, "dashboardStats/production_trend");
      fetchStateFallback();
    });

    // 4. Listen to teams
    let isInitialTeams = true;
    const unsubTeams = onSnapshot(collection(db, "teams"), (snapshot) => {
      const teamsList = snapshot.docs.map(doc => doc.data() as TeamPerformance);
      setTeamPerformance(teamsList);

      if (!isInitialTeams) {
        snapshot.docChanges().forEach(change => {
          if (change.type === 'added') {
            const team = change.doc.data() as TeamPerformance;
            addNotification({
              type: 'upload',
              title: 'New Team performance logged',
              message: `Team '${team.teamName}' has been synced under Lead ${team.lead}. Efficiency: ${team.efficiency}%.`,
              meta: { id: team.teamName }
            });
          } else if (change.type === 'modified') {
            const team = change.doc.data() as TeamPerformance;
            if (team.errorRate > 5) {
              addNotification({
                type: 'accuracy',
                title: 'High Team Error Rate Alert',
                message: `Team '${team.teamName}' error rate increased to ${team.errorRate}% (Threshold: 5.0%).`,
                meta: { id: team.teamName }
              });
            }
          }
        });
      } else {
        isInitialTeams = false;
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, "teams");
      fetchStateFallback();
    });

    // 5. Listen to analysts
    let isInitialAnalysts = true;
    const unsubAnalysts = onSnapshot(collection(db, "analysts"), (snapshot) => {
      const analystsList = snapshot.docs.map(doc => doc.data() as IPARecord);
      setIpaRecords(analystsList);

      if (!isInitialAnalysts) {
        snapshot.docChanges().forEach(change => {
          if (change.type === 'added') {
            const analyst = change.doc.data() as IPARecord;
            addNotification({
              type: 'upload',
              title: 'New Analyst Profile Added',
              message: `Analyst profile for '${analyst.name}' has been synced for Team ${analyst.team}.`,
              meta: { id: analyst.id }
            });
          }
        });
      } else {
        isInitialAnalysts = false;
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, "analysts");
      fetchStateFallback();
    });

    // 6. Listen to logs
    let isInitialLogs = true;
    const unsubLogs = onSnapshot(collection(db, "logs"), (snapshot) => {
      const logsList = snapshot.docs.map(doc => doc.data() as PortfolioLog);
      setPortfolioLogs(logsList);

      if (isInitialLogs) {
        logsList.forEach(log => {
          if (log.vendorName) {
            knownVendorsRef.current.add(log.vendorName);
          }
        });
        isInitialLogs = false;
      } else {
        snapshot.docChanges().forEach(change => {
          if (change.type === 'added') {
            const newLog = change.doc.data() as PortfolioLog;
            
            // 1. Detect New Upload:
            addNotification({
              customId: `notif_upload_${newLog.id}`,
              type: 'upload',
              title: 'New Upload',
              message: `${newLog.analystName} uploaded a log for ${newLog.vendorName || 'unnamed'} (Accuracy: ${newLog.accuracy}%).`,
              meta: { id: newLog.id, vendorName: newLog.vendorName }
            });

            // 2. Detect Low Accuracy:
            if (newLog.accuracy < 90) {
              addNotification({
                customId: `notif_accuracy_${newLog.id}`,
                type: 'accuracy',
                title: 'Low Accuracy',
                message: `Vendor ${newLog.vendorName} audit matched at ${newLog.accuracy}% (Threshold: 90%).`,
                meta: { id: newLog.id, accuracy: newLog.accuracy }
              });
            }

            // 3. Detect High Error:
            if (newLog.errors && newLog.errors >= 3) {
              addNotification({
                customId: `notif_error_${newLog.id}`,
                type: 'error',
                title: 'High Error',
                message: `Critical high error rate for ${newLog.vendorName || 'unnamed'}: ${newLog.errors} mismatch errors detected.`,
                meta: { id: newLog.id, vendorName: newLog.vendorName }
              });
            }

            // 4. Detect Vendor Issue:
            if (newLog.status === 'ALERT') {
              addNotification({
                customId: `notif_vendor_${newLog.id}`,
                type: 'vendor',
                title: 'Vendor Issue',
                message: `Active operational issue flagged on vendor ${newLog.vendorName || 'unnamed'}.`,
                meta: { id: newLog.id, vendorName: newLog.vendorName }
              });
            }

            // 5. Detect Missing Report:
            if (newLog.taskType === 'Missing Report' || (newLog as any).isMissingReport) {
              addNotification({
                customId: `notif_report_${newLog.id}`,
                type: 'report',
                title: 'Missing Report',
                message: `Scheduled monthly performance audit report is missing for ${newLog.vendorName || 'unnamed'}.`,
                meta: { id: newLog.id, vendorName: newLog.vendorName }
              });
            }
          } else if (change.type === 'modified') {
            const modifiedLog = change.doc.data() as PortfolioLog;
            
            // Detect Vendor Issue:
            if (modifiedLog.status === 'ALERT') {
              addNotification({
                customId: `notif_vendor_${modifiedLog.id}`,
                type: 'vendor',
                title: 'Vendor Issue',
                message: `Active operational issue flagged on vendor ${modifiedLog.vendorName || 'unnamed'}.`,
                meta: { id: modifiedLog.id, vendorName: modifiedLog.vendorName }
              });
            }

            // Detect Low Accuracy:
            if (modifiedLog.accuracy < 90) {
              addNotification({
                customId: `notif_accuracy_${modifiedLog.id}`,
                type: 'accuracy',
                title: 'Low Accuracy',
                message: `${modifiedLog.vendorName} current accuracy has dropped to ${modifiedLog.accuracy}% (Threshold: 90%).`,
                meta: { id: modifiedLog.id, accuracy: modifiedLog.accuracy }
              });
            }

            // Detect High Error:
            if (modifiedLog.errors && modifiedLog.errors >= 3) {
              addNotification({
                customId: `notif_error_${modifiedLog.id}`,
                type: 'error',
                title: 'High Error',
                message: `Critical high error rate for ${modifiedLog.vendorName || 'unnamed'}: ${modifiedLog.errors} mismatch errors detected.`,
                meta: { id: modifiedLog.id, vendorName: modifiedLog.vendorName }
              });
            }
          }
        });
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, "logs");
      fetchStateFallback();
    });

    // 7. Listen to notifications
    const unsubNotifs = onSnapshot(collection(db, "notifications"), (snapshot) => {
      const notifsList = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as RealtimeNotification));
      // Sort descending by timestamp
      notifsList.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      setNotifications(notifsList);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, "notifications");
    });

    return () => {
      unsubRecon();
      unsubAlerts();
      unsubTrend();
      unsubTeams();
      unsubAnalysts();
      unsubLogs();
      unsubNotifs();
    };
  }, [currentUser, addNotification, fetchStateFallback]);

  const updateRecord = (record: ReconciliationRecord) => {
    setReconciliationRecords(prev => prev.map(rec => rec.id === record.id ? record : rec));
    fetch('/api/records/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(record)
    }).catch(err => console.error('Failed to sync record update via HTTP:', err));
  };

  const createLog = (log: PortfolioLog) => {
    setPortfolioLogs(prev => [log, ...prev]);
    fetch('/api/logs/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(log)
    }).catch(err => console.error('Failed to sync log creation via HTTP:', err));
  };

  const updateAlert = (alert: AMAlert) => {
    setAmAlerts(prev => prev.map(a => a.id === alert.id ? alert : a));
    fetch('/api/alerts/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(alert)
    }).catch(err => console.error('Failed to sync alert update via HTTP:', err));
  };

  const updateAllIpaRecords = (records: IPARecord[]) => {
    setIpaRecords(records);
    fetch('/api/ipa/update-all', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(records)
    }).catch(err => console.error('Failed to sync IPA records update via HTTP:', err));
  };

  const resetState = () => {
    fetch('/api/reset', { method: 'POST' })
      .then(() => {
        clearAllNotifications();
      })
      .catch(err => console.error('Failed to reset state:', err));
  };

  const refreshData = useCallback(async () => {
    try {
      const response = await fetch('/api/state');
      if (response.ok) {
        const data = await response.json();
        if (data.portfolioLogs) setPortfolioLogs(data.portfolioLogs);
        if (data.reconciliationRecords) setReconciliationRecords(data.reconciliationRecords);
        if (data.ipaRecords) setIpaRecords(data.ipaRecords);
        if (data.teamPerformance) setTeamPerformance(data.teamPerformance);
        if (data.amAlerts) setAmAlerts(data.amAlerts);
        if (data.productionTrend) setProductionTrend(data.productionTrend);
        console.log('🔄 [RealtimeContext] Backend state successfully re-fetched.');
      } else {
        throw new Error(`HTTP Error ${response.status}`);
      }
    } catch (err) {
      console.error('❌ [RealtimeContext] Failed to manually refresh backend state:', err);
      throw err;
    }
  }, []);

  return (
    <RealtimeContext.Provider value={{
      reconciliationRecords,
      ipaRecords,
      teamPerformance,
      amAlerts,
      portfolioLogs,
      productionTrend,
      updateRecord,
      createLog,
      updateAlert,
      updateAllIpaRecords,
      resetState,
      isConnected,
      notifications,
      markAsRead,
      markAllAsRead,
      clearNotification,
      clearAllNotifications,
      simulateEvent,
      refreshData
    }}>
      {children}
    </RealtimeContext.Provider>
  );
}

export function useRealtime() {
  const context = useContext(RealtimeContext);
  if (context === undefined) {
    throw new Error('useRealtime must be used within a RealtimeProvider');
  }
  return context;
}
