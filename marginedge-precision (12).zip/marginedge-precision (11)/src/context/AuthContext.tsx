import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  User, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithPopup
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db, googleProvider } from '../firebase';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: 'Admin' | 'Lead' | 'AM' | 'Analyst' | 'Specialist' | 'Team Lead';
  office: string;
  status: string;
  photoURL?: string | null;
  createdAt?: string;
  lastLogin?: string;
}

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  loginWithEmail: (email: string, name: string, role: 'Admin' | 'Lead' | 'AM' | 'Analyst' | 'Specialist' | 'Team Lead', password: string) => Promise<void>;
  loginWithGoogle: () => Promise<{ email: string; name: string; role: 'Admin' | 'Lead' | 'AM' | 'Analyst' | 'Specialist' | 'Team Lead'; } | void>;
  simulateGoogleLogin: (email: string, name: string) => Promise<{ email: string; name: string; role: 'Admin' | 'Lead' | 'AM' | 'Analyst' | 'Specialist' | 'Team Lead'; }>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const loginWithEmail = async (email: string, name: string, role: 'Admin' | 'Lead' | 'AM' | 'Analyst' | 'Specialist' | 'Team Lead', password: string) => {
    try {
      // Attempt to sign in
      await signInWithEmailAndPassword(auth, email, password);
    } catch (err: any) {
      // If user doesn't exist, create an account
      if (err.code === 'auth/user-not-found' || err.code === 'auth/invalid-credential') {
        try {
          const userCredential = await createUserWithEmailAndPassword(auth, email, password);
          const profile: UserProfile = {
            uid: userCredential.user.uid,
            name: name || email.split('@')[0],
            email,
            role,
            office: 'Chandigarh',
            status: 'active',
            photoURL: userCredential.user.photoURL || '',
            createdAt: new Date().toISOString(),
            lastLogin: new Date().toISOString()
          };
          await setDoc(doc(db, 'users', userCredential.user.uid), profile);
        } catch (signUpErr: any) {
          if (signUpErr.code === 'auth/email-already-in-use') {
            throw new Error('Incorrect password or user profile mismatch.');
          }
          throw signUpErr;
        }
      } else if (err.code === 'auth/operation-not-allowed' || err.message?.includes('operation-not-allowed')) {
        console.warn('Firebase Email/Password Auth is disabled in the Firebase Console. Logging into a sandbox demo session instead.');
        const mockUid = `demo-${role.toLowerCase()}-${email.split('@')[0]}`;
        const profile: UserProfile = {
          uid: mockUid,
          name: name || email.split('@')[0],
          email,
          role,
          office: 'Chandigarh',
          status: 'active',
          photoURL: '',
          createdAt: new Date().toISOString(),
          lastLogin: new Date().toISOString()
        };
        setCurrentUser({
          uid: mockUid,
          email: email,
          displayName: name || email.split('@')[0],
          emailVerified: true,
          isAnonymous: false,
          providerData: [],
          metadata: {},
          phoneNumber: null,
          photoURL: null,
          tenantId: null,
          delete: async () => {},
          getIdToken: async () => 'demo-token',
          getIdTokenResult: async () => ({ token: 'demo-token', claims: {}, authTime: '', expirationTime: '', issuedAtTime: '', signInProvider: 'password' }),
          reload: async () => {},
          toJSON: () => ({}),
        } as unknown as User);
        setUserProfile(profile);
      } else {
        throw err;
      }
    }
  };

  const loginWithGoogle = async () => {
    const userCredential = await signInWithPopup(auth, googleProvider);
    const user = userCredential.user;
    
    const userDocRef = doc(db, 'users', user.uid);
    
    let role: 'Admin' | 'Lead' | 'AM' | 'Analyst' | 'Specialist' | 'Team Lead' = 'Analyst';
    let name = user.displayName || user.email?.split('@')[0] || 'User';
    
    try {
      // Race getDoc with a 2-second timeout to prevent hangs
      const userDoc = await Promise.race([
        getDoc(userDocRef),
        new Promise<any>((_, reject) => 
          setTimeout(() => reject(new Error('Firestore timeout')), 2000)
        )
      ]);
      
      if (userDoc && userDoc.exists()) {
        const data = userDoc.data();
        role = data.role || 'Analyst';
        name = data.name || name;
        const updatedProfile = {
          ...data,
          lastLogin: new Date().toISOString()
        };
        await setDoc(userDocRef, updatedProfile, { merge: true });
      } else {
        const isLead = user.email === 'ankit.thakur@marginedge.com' || user.email === 'ankit.thakur+persona@marginedge.com';
        role = isLead ? 'Admin' : 'Analyst'; // Make Ankit Admin as per the quick-access but support both
        const profile: UserProfile = {
          uid: user.uid,
          name: name,
          email: user.email || '',
          photoURL: user.photoURL || '',
          role: role,
          office: 'Chandigarh',
          status: 'active',
          createdAt: new Date().toISOString(),
          lastLogin: new Date().toISOString()
        };
        await setDoc(userDocRef, profile);
      }
    } catch (err) {
      console.warn('Firestore failed during Google login (using fallback profile):', err);
      const isLead = user.email === 'ankit.thakur@marginedge.com' || user.email === 'ankit.thakur+persona@marginedge.com';
      role = isLead ? 'Admin' : 'Analyst';
    }
    return { email: user.email || '', name, role };
  };

  const simulateGoogleLogin = async (email: string, name: string) => {
    const isLead = email === 'ankit.thakur@marginedge.com' || email === 'ankit.thakur+persona@marginedge.com';
    const role = isLead ? 'Lead' : 'Analyst';
    const mockUid = `demo-google-${email.split('@')[0] || 'user'}`;
    
    const mockUser = {
      uid: mockUid,
      email: email,
      displayName: name || email.split('@')[0] || 'User',
      emailVerified: true,
      isAnonymous: false,
      providerData: [],
      metadata: {},
      phoneNumber: null,
      photoURL: null,
      tenantId: null,
      delete: async () => {},
      getIdToken: async () => 'demo-token',
      getIdTokenResult: async () => ({ token: 'demo-token', claims: {}, authTime: '', expirationTime: '', issuedAtTime: '', signInProvider: 'google.com' }),
      reload: async () => {},
      toJSON: () => ({}),
    } as unknown as User;

    const userDocRef = doc(db, 'users', mockUid);
    const userDoc = await getDoc(userDocRef);

    let finalRole: 'Admin' | 'Lead' | 'AM' | 'Analyst' | 'Specialist' | 'Team Lead' = role;
    let finalName = name || email.split('@')[0] || 'User';

    if (userDoc.exists()) {
      const data = userDoc.data();
      finalRole = data.role || role;
      finalName = data.name || finalName;
      const updatedProfile = {
        ...data,
        lastLogin: new Date().toISOString()
      };
      await setDoc(userDocRef, updatedProfile, { merge: true });
    } else {
      const profile: UserProfile = {
        uid: mockUid,
        name: finalName,
        email: email,
        photoURL: '',
        role: finalRole,
        office: 'Chandigarh',
        status: 'active',
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString()
      };
      await setDoc(userDocRef, profile);
    }

    setCurrentUser(mockUser);
    setUserProfile({
      uid: mockUid,
      name: finalName,
      email: email,
      photoURL: '',
      role: finalRole,
      office: 'Chandigarh',
      status: 'active',
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString()
    });

    return { email, name: finalName, role: finalRole };
  };

  const logout = async () => {
    setCurrentUser(null);
    setUserProfile(null);
    try {
      await signOut(auth);
    } catch (err) {
      console.error('Error signing out:', err);
    }
  };

  const resetPassword = async (email: string) => {
    await sendPasswordResetEmail(auth, email);
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setLoading(true);
      if (user) {
        try {
          const userDocRef = doc(db, 'users', user.uid);
          
          // Race getDoc with a 2-second timeout to prevent iframe/network hangs
          const userDoc = await Promise.race([
            getDoc(userDocRef),
            new Promise<any>((_, reject) => 
              setTimeout(() => reject(new Error('Firestore timeout')), 2000)
            )
          ]);
          
          if (userDoc && userDoc.exists()) {
            const data = userDoc.data();
            const updatedProfile = {
              ...data,
              lastLogin: new Date().toISOString()
            };
            setDoc(userDocRef, updatedProfile, { merge: true }).catch(err => 
              console.warn('Failed to update lastLogin in background:', err)
            );
            setUserProfile(updatedProfile as UserProfile);
          } else {
            const isLead = user.email === 'ankit.thakur@marginedge.com' || user.email === 'ankit.thakur+persona@marginedge.com';
            const role = isLead ? 'Lead' : 'Analyst';
            const profile: UserProfile = {
              uid: user.uid,
              name: user.displayName || user.email?.split('@')[0] || 'User',
              email: user.email || '',
              photoURL: user.photoURL || '',
              role: role,
              office: 'Chandigarh',
              status: 'active',
              createdAt: new Date().toISOString(),
              lastLogin: new Date().toISOString()
            };
            setDoc(userDocRef, profile).catch(err => 
              console.warn('Failed to save profile in background:', err)
            );
            setUserProfile(profile);
          }
          setCurrentUser(user);
        } catch (err: any) {
          console.warn('Firestore connection unavailable, using fallback profile:', err?.message || err);
          const isLead = user.email === 'ankit.thakur@marginedge.com' || user.email === 'ankit.thakur+persona@marginedge.com';
          const role = isLead ? 'Lead' : 'Analyst';
          const fallbackProfile: UserProfile = {
            uid: user.uid,
            name: user.displayName || user.email?.split('@')[0] || 'User',
            email: user.email || '',
            photoURL: user.photoURL || '',
            role: role,
            office: 'Chandigarh',
            status: 'active',
            createdAt: new Date().toISOString(),
            lastLogin: new Date().toISOString()
          };
          setUserProfile(fallbackProfile);
          setCurrentUser(user);
        }
      } else {
        // Prevent clearing local/simulated demo sessions if one is active
        setCurrentUser(prev => {
          if (prev && prev.uid && (prev.uid.startsWith('demo-') || prev.uid.startsWith('demo-google-'))) {
            return prev;
          }
          return null;
        });
        setUserProfile(prev => {
          if (prev && prev.uid && (prev.uid.startsWith('demo-') || prev.uid.startsWith('demo-google-'))) {
            return prev;
          }
          return null;
        });
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  return (
    <AuthContext.Provider value={{
      currentUser,
      userProfile,
      loading,
      loginWithEmail,
      loginWithGoogle,
      simulateGoogleLogin,
      logout,
      resetPassword
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
