export interface GmailAttachment {
  id: string;
  filename: string;
  mimeType: string;
  size: number;
}

export interface GmailMessage {
  id: string;
  threadId: string;
  subject: string;
  from: string;
  to: string;
  date: string;
  snippet: string;
  body: string;
  labels: string[];
  attachments?: GmailAttachment[];
}

// Extract attachments from a Gmail message payload
export function extractAttachments(payload: any): GmailAttachment[] {
  const attachments: GmailAttachment[] = [];
  
  function traverse(part: any) {
    if (part.filename && part.body && part.body.attachmentId) {
      attachments.push({
        id: part.body.attachmentId,
        filename: part.filename,
        mimeType: part.mimeType || 'application/octet-stream',
        size: part.body.size || 0,
      });
    }
    if (part.parts) {
      for (const subPart of part.parts) {
        traverse(subPart);
      }
    }
  }

  if (payload) {
    traverse(payload);
  }
  return attachments;
}

// Fetch attachment content (base64url encoded) from Gmail API
export async function getGmailAttachment(
  accessToken: string,
  messageId: string,
  attachmentId: string
): Promise<string> {
  const res = await fetch(
    `https://gmail.googleapis.com/gmail/v1/users/me/messages/${messageId}/attachments/${attachmentId}`,
    {
      headers: { Authorization: `Bearer ${accessToken}` },
    }
  );

  if (!res.ok) {
    throw new Error(`Gmail API Get Attachment Error: ${res.statusText} (${res.status})`);
  }

  const data = await res.json();
  return data.data; // Base64url encoded
}

// Convert string to base64url format for Gmail API raw send
export function base64urlEncode(str: string): string {
  return btoa(unescape(encodeURIComponent(str)))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

// Helper to decode base64url formatted strings
export function base64urlDecode(base64: string): string {
  try {
    let normalized = base64.replace(/-/g, '+').replace(/_/g, '/');
    while (normalized.length % 4) {
      normalized += '=';
    }
    return decodeURIComponent(escape(atob(normalized)));
  } catch (err) {
    console.error('Failed to decode email body:', err);
    return 'HTML or binary attachment content';
  }
}

// Parse headers from a message details response
export function getHeaderValue(headers: { name: string; value: string }[], name: string): string {
  const header = headers.find(h => h.name.toLowerCase() === name.toLowerCase());
  return header ? header.value : '';
}

// Extract body text from Gmail message parts
export function extractBody(payload: any): string {
  if (!payload) return '';
  
  if (payload.body && payload.body.data) {
    return base64urlDecode(payload.body.data);
  }
  
  if (payload.parts) {
    // Look for text/html first, fallback to text/plain
    const htmlPart = payload.parts.find((part: any) => part.mimeType === 'text/html');
    if (htmlPart && htmlPart.body && htmlPart.body.data) {
      return base64urlDecode(htmlPart.body.data);
    }
    
    const plainPart = payload.parts.find((part: any) => part.mimeType === 'text/plain');
    if (plainPart && plainPart.body && plainPart.body.data) {
      return base64urlDecode(plainPart.body.data);
    }
    
    // Recursively look into deeper parts
    for (const part of payload.parts) {
      const deepBody = extractBody(part);
      if (deepBody) return deepBody;
    }
  }
  
  return '';
}

// Fetch list of messages
export async function listGmailMessages(accessToken: string, query: string = ''): Promise<any[]> {
  const url = new URL('https://gmail.googleapis.com/gmail/v1/users/me/messages');
  if (query) {
    url.searchParams.append('q', query);
  }
  url.searchParams.append('maxResults', '15');

  const res = await fetch(url.toString(), {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!res.ok) {
    throw new Error(`Gmail API List Error: ${res.statusText} (${res.status})`);
  }

  const data = await res.json();
  return data.messages || [];
}

// Fetch details for a specific message
export async function getGmailMessageDetails(accessToken: string, messageId: string): Promise<GmailMessage> {
  const res = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${messageId}`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!res.ok) {
    throw new Error(`Gmail API Get Message Error: ${res.statusText} (${res.status})`);
  }

  const msg = await res.json();
  const headers = msg.payload?.headers || [];
  
  return {
    id: msg.id,
    threadId: msg.threadId,
    subject: getHeaderValue(headers, 'subject') || '(No Subject)',
    from: getHeaderValue(headers, 'from') || 'Unknown Sender',
    to: getHeaderValue(headers, 'to') || 'me',
    date: getHeaderValue(headers, 'date') || 'Unknown Date',
    snippet: msg.snippet || '',
    body: extractBody(msg.payload),
    labels: msg.labelIds || [],
    attachments: extractAttachments(msg.payload)
  };
}

// Send email
export async function sendGmailMessage(
  accessToken: string,
  to: string,
  subject: string,
  body: string
): Promise<any> {
  // Construct a standard RFC 822 email format
  const rawEmail = [
    `To: ${to}`,
    'Content-Type: text/html; charset=utf-8',
    'MIME-Version: 1.0',
    `Subject: ${subject}`,
    '',
    body
  ].join('\r\n');

  const base64Raw = base64urlEncode(rawEmail);

  const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ raw: base64Raw })
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `Gmail API Send Error: ${res.statusText} (${res.status})`);
  }

  return await res.json();
}

// Modify message labels (e.g. archive, mark unread/read)
export async function modifyMessageLabels(
  accessToken: string,
  messageId: string,
  addLabelIds: string[] = [],
  removeLabelIds: string[] = []
): Promise<any> {
  const res = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${messageId}/modify`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      addLabelIds,
      removeLabelIds
    })
  });

  if (!res.ok) {
    throw new Error(`Gmail API Modify Error: ${res.statusText} (${res.status})`);
  }

  return await res.json();
}
