/**
 * Google Chat API Client Services
 */

export interface GoogleChatSpace {
  name: string; // e.g. "spaces/AAAAAAAAAAA"
  displayName: string;
  spaceType: 'SPACE' | 'DIRECT_MESSAGE' | 'GROUP_CHAT' | string;
  singleUserBotCardFormat?: boolean;
}

export interface GoogleChatUser {
  name: string;
  displayName: string;
  type: 'HUMAN' | 'BOT' | string;
}

export interface GoogleChatMessage {
  name: string; // e.g. "spaces/AAAAAAAAAAA/messages/BBBBBBBBBBB"
  sender: GoogleChatUser;
  text: string;
  createTime: string;
  thread?: {
    name: string;
  };
}

export interface GoogleChatMembership {
  name: string; // e.g. "spaces/AAAAAAAAAAA/members/BBBBBBBBBBB"
  state: 'JOINED' | 'INVITED' | string;
  role: 'ROLE_MEMBER' | 'ROLE_MANAGER' | string;
  member: GoogleChatUser;
}

/**
 * List all Google Chat spaces available to the authenticated user.
 */
export async function listChatSpaces(accessToken: string): Promise<GoogleChatSpace[]> {
  try {
    const response = await fetch('https://chat.googleapis.com/v1/spaces', {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Failed to list spaces (HTTP ${response.status}): ${errText}`);
    }

    const data = await response.json();
    return data.spaces || [];
  } catch (error) {
    console.error('Error listing Google Chat spaces:', error);
    throw error;
  }
}

/**
 * List messages in a specific space.
 */
export async function listChatMessages(accessToken: string, spaceName: string): Promise<GoogleChatMessage[]> {
  try {
    // spaceName is of the format "spaces/{spaceId}"
    const response = await fetch(`https://chat.googleapis.com/v1/${spaceName}/messages?pageSize=40`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Failed to list messages (HTTP ${response.status}): ${errText}`);
    }

    const data = await response.json();
    return data.messages || [];
  } catch (error) {
    console.error(`Error listing messages for space ${spaceName}:`, error);
    throw error;
  }
}

/**
 * Send a message to a specific space.
 */
export async function sendChatMessage(accessToken: string, spaceName: string, text: string): Promise<GoogleChatMessage> {
  try {
    const response = await fetch(`https://chat.googleapis.com/v1/${spaceName}/messages`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ text }),
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Failed to send message (HTTP ${response.status}): ${errText}`);
    }

    return await response.json();
  } catch (error) {
    console.error(`Error sending message to space ${spaceName}:`, error);
    throw error;
  }
}

/**
 * List members of a specific space.
 */
export async function listChatMembers(accessToken: string, spaceName: string): Promise<GoogleChatMembership[]> {
  try {
    const response = await fetch(`https://chat.googleapis.com/v1/${spaceName}/members`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Failed to list members (HTTP ${response.status}): ${errText}`);
    }

    const data = await response.json();
    return data.memberships || [];
  } catch (error) {
    console.error(`Error listing members for space ${spaceName}:`, error);
    throw error;
  }
}

/**
 * Create a new Chat space.
 */
export async function createChatSpace(accessToken: string, displayName: string): Promise<GoogleChatSpace> {
  try {
    const response = await fetch('https://chat.googleapis.com/v1/spaces', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        spaceType: 'SPACE',
        displayName: displayName,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Failed to create space (HTTP ${response.status}): ${errText}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Error creating Google Chat space:', error);
    throw error;
  }
}
