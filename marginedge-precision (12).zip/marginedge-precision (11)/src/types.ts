/**
 * Shared Type Definitions for MarginEdge Precision
 */

export type ActiveView = 
  | 'SIGN_IN' 
  | 'LIVE_SYNC_DASHBOARD' 
  | 'PRECISION_OPS_DASHBOARD' 
  | 'DETAILED_PORTFOLIO_LOGS'
  | 'GMAIL_DASHBOARD'
  | 'ANALYST_QUALITY_DASHBOARD'
  | 'UNAUTHORIZED'
  | 'EXCEL_PARSER_UTILITY'
  | 'GOOGLE_CHAT_DASHBOARD'
  | 'PRESENTATION_DECK'
  | 'PRESET_REPORT';

export interface ReconciliationRecord {
  id: string;
  user: string;
  office: string;
  team: string;
  points: number;
  errors: number;
  errorPercentage: number;
  status: 'MATCHED' | 'HIGH PRIORITY' | 'PENDING';
}

export interface IPARecord {
  id: string;
  name: string;
  team: string;
  tasks: number;
}

export interface TeamPerformance {
  teamName: string;
  efficiency: number;
  errorRate: number;
  output: string;
  lead: string;
}

export interface PortfolioLog {
  id: string;
  date: string;
  analystName: string;
  vendorName: string;
  taskType: string;
  status: 'MATCHING' | 'ALERT' | 'PENDING';
  accuracy: number;
  // Additional fields for expanded mode (IR, Reco, Time, Errors, FR, Q. Res, etc.)
  ir?: number;
  reco?: number;
  time?: string;
  errors?: number;
  fr?: number;
  qres?: number;
}

export interface AMAlert {
  id: string;
  name: string;
  role: string;
  alertsCount: number;
  accuracyCurrent: number;
  accuracyTarget: number;
  criticality: 'High Risk' | 'Stable' | 'Immediate Action';
}

export interface RealtimeNotification {
  id: string;
  type: 'upload' | 'vendor' | 'error' | 'accuracy' | 'report';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  meta?: {
    id?: string;
    vendorName?: string;
    accuracy?: number;
  };
}

// Excel Data Management Interfaces
export interface DatasetVersion {
  id: string;
  fileName: string;
  fileSize: string;
  uploadedBy: string;
  uploadDate: string;
  totalRecords: number;
  sheetName: string;
  targetCollection: string;
  status: 'ACTIVE' | 'ARCHIVED' | 'DELETED';
  schemaKeys: string[];
}

export interface ExcelRecord {
  id: string;
  datasetId: string;
  targetCollection: string;
  data: Record<string, any>;
  recordId: string;
  createdAt: string;
}

export interface ExcelAuditLog {
  id: string;
  datasetId: string;
  collection: string;
  recordId: string;
  editedBy: string;
  editedAt: string;
  changes: {
    field: string;
    oldValue: any;
    newValue: any;
  }[];
}

export interface ExcelBackup {
  id: string;
  createdAt: string;
  createdBy: string;
  type: 'AUTOMATIC' | 'MANUAL';
  description: string;
  recordCounts: {
    logs: number;
    analysts: number;
    teams: number;
    invoices: number;
    vendors: number;
    users: number;
  };
  status: 'SUCCESS' | 'FAILED';
}

export interface ValidationError {
  row?: number;
  column?: string;
  message: string;
  severity: 'error' | 'warning';
}

export interface ValidationPreset {
  name: string;
  id: string;
  columns: string[];
  description: string;
}

export interface SchemaField {
  key: string;
  label: string;
  type: 'string' | 'number' | 'enum';
  required: boolean;
  enumValues?: string[];
  description: string;
}

export interface TargetSchema {
  name: string;
  collection: string;
  fields: SchemaField[];
}

export interface PresetRecord {
  id: string;
  date: string; // YYYY-MM-DD
  employeeName: string; // Col 1: Employee/Analyst name
  totalTasks: number; // Col 1: Total Task as per Dashboard (Past Date) (primary KPI)
  escalations: number; // Col 2: Total Escalations (numeric value)
  movingTotal: number; // Col 3: Moving Total at Day End as per Screen Meter
  week: string; // e.g. "Week 28"
  month: string; // e.g. "July 2026"
  year: string; // e.g. "2026"
  team: string; // e.g. "Alpha Ops"
  shift: string; // e.g. "Day" or "Night"
  vendor?: string; // Col: Vendor/Client (optional, if available in Excel)
}

export interface PresetReportSummary {
  id: string;
  fileName: string;
  uploadDate: string;
  totalTasks: number;
  totalEscalations: number;
  averageMovingTotal: number;
  activeEmployeesCount: number;
  topPerformerName: string;
}



