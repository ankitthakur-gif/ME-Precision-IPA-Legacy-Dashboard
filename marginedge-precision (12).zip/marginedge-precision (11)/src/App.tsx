/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, Suspense, lazy } from 'react';
import { ActiveView } from './types';
import { RealtimeProvider } from './context/RealtimeContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { PerformanceProfiler, PerformanceMonitorHUD } from './components/PerformanceMonitor';
import GlobalSearch from './components/GlobalSearch';

// Implement Code Splitting and Lazy Loading for all major dashboards and views
const SignIn = lazy(() => import('./components/SignIn'));
const LiveSyncDashboard = lazy(() => import('./components/LiveSyncDashboard'));
const InvoiceManagerDashboard = lazy(() => import('./components/InvoiceManagerDashboard'));
const DetailedLogs = lazy(() => import('./components/DetailedLogs'));
const GmailDashboard = lazy(() => import('./components/GmailDashboard'));
const AnalystQualityDashboard = lazy(() => import('./components/AnalystQualityDashboard'));
const Unauthorized = lazy(() => import('./components/Unauthorized'));
const ExcelUploadDashboard = lazy(() => import('./components/ExcelUploadDashboard'));
const GoogleChatDashboard = lazy(() => import('./components/GoogleChatDashboard'));
const PresentationDashboard = lazy(() => import('./components/PresentationDashboard'));
const PresetReportDashboard = lazy(() => import('./components/PresetReportDashboard'));

const ROLE_PERMISSIONS: Record<string, ActiveView[]> = {
  'Admin': [
    'PRESET_REPORT',
    'PRESENTATION_DECK'
  ],
  'AM': [
    'PRESET_REPORT',
    'PRESENTATION_DECK'
  ],
  'Team Lead': [
    'PRESET_REPORT',
    'PRESENTATION_DECK'
  ],
  'Lead': [
    'PRESET_REPORT',
    'PRESENTATION_DECK'
  ],
  'Analyst': [
    'PRESET_REPORT'
  ]
};

// Polished fallback loading component
function ViewFallback() {
  return (
    <div className="min-h-screen bg-[#f7f9ff] dark:bg-[#0b0e14] flex flex-col items-center justify-center font-sans">
      <div className="flex flex-col items-center space-y-4 animate-pulse">
        <div className="w-9 h-9 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        <div className="text-center space-y-1">
          <p className="text-xs text-slate-600 dark:text-slate-300 font-bold uppercase tracking-wider">Optimizing Bundle...</p>
          <p className="text-[10px] text-slate-400">Loading component chunk on-demand</p>
        </div>
      </div>
    </div>
  );
}

function AppContent() {
  const { currentUser, userProfile, loading, logout } = useAuth();
  const [activeView, setActiveView] = useState<ActiveView>('SIGN_IN');
  const [attemptedView, setAttemptedView] = useState<ActiveView>('PRESET_REPORT');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('marginedge_theme');
    if (saved === 'dark') return true;
    if (saved === 'light') return false;
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return true;
    }
    return false;
  });

  // Global Ctrl+K / Cmd+K Search Hotkey
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        if (activeView !== 'SIGN_IN') {
          setIsSearchOpen(prev => !prev);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeView]);

  useEffect(() => {
    const htmlElement = document.documentElement;
    if (isDarkMode) {
      htmlElement.classList.add('dark');
      htmlElement.classList.remove('light');
      localStorage.setItem('marginedge_theme', 'dark');
    } else {
      htmlElement.classList.add('light');
      htmlElement.classList.remove('dark');
      localStorage.setItem('marginedge_theme', 'light');
    }
  }, [isDarkMode]);

  // Sync activeView with Auth state
  useEffect(() => {
    if (!loading) {
      if (currentUser && userProfile) {
        if (activeView === 'SIGN_IN') {
          setActiveView('PRESET_REPORT');
        }
      } else {
        setActiveView('SIGN_IN');
      }
    }
  }, [currentUser, userProfile, loading, activeView]);

  // Redirect unauthorized users to UNAUTHORIZED page
  useEffect(() => {
    if (!loading && currentUser && userProfile && activeView !== 'SIGN_IN' && activeView !== 'UNAUTHORIZED') {
      const currentRole = userProfile.role || 'Analyst';
      const allowed = ROLE_PERMISSIONS[currentRole] || ['LIVE_SYNC_DASHBOARD', 'DETAILED_PORTFOLIO_LOGS', 'ANALYST_QUALITY_DASHBOARD'];
      if (!allowed.includes(activeView)) {
        setAttemptedView(activeView);
        setActiveView('UNAUTHORIZED');
      }
    }
  }, [activeView, userProfile, loading, currentUser]);

  // Memoized event handlers to prevent child component re-renders
  const handleLogout = useCallback(async () => {
    setActiveView('SIGN_IN');
    try {
      await logout();
    } catch (e) {
      console.error('Firebase signout failed:', e);
    }
  }, [logout]);

  const handleNavigate = useCallback((view: ActiveView) => {
    setActiveView(view);
  }, []);

  if (loading) {
    return <ViewFallback />;
  }

  // Map the context's UserProfile fields to the component's expected positions
  const rawRole = userProfile?.role || 'Analyst';
  const userPosition = rawRole === 'Lead' ? 'Team Lead' : rawRole;
  const userEmail = userProfile?.email || currentUser?.email || '';
  const userName = userProfile?.name || currentUser?.displayName || 'User';

  const allowedViews = ROLE_PERMISSIONS[rawRole] || ['LIVE_SYNC_DASHBOARD', 'DETAILED_PORTFOLIO_LOGS', 'ANALYST_QUALITY_DASHBOARD'];
  const isPermitted = activeView === 'SIGN_IN' || activeView === 'UNAUTHORIZED' || allowedViews.includes(activeView);

  if (!isPermitted || activeView === 'UNAUTHORIZED') {
    return (
      <Suspense fallback={<ViewFallback />}>
        <Unauthorized 
          userPosition={userPosition}
          attemptedView={activeView === 'UNAUTHORIZED' ? attemptedView : activeView}
          allowedViews={allowedViews}
          onNavigate={handleNavigate}
          onLogout={handleLogout}
        />
      </Suspense>
    );
  }

  return (
    <div className="relative min-h-screen bg-background text-on-background transition-colors duration-300">
      <Suspense fallback={<ViewFallback />}>
        <PerformanceProfiler id={activeView}>
          {/* Render Active View Component with Code Splitting Chunk Loading */}
          {activeView === 'SIGN_IN' ? (
            <SignIn onLogin={() => {}} />
          ) : activeView === 'LIVE_SYNC_DASHBOARD' ? (
            <LiveSyncDashboard 
              userEmail={userEmail} 
              userName={userName}
              userPosition={userPosition}
              onNavigate={handleNavigate} 
              onLogout={handleLogout} 
            />
          ) : activeView === 'PRECISION_OPS_DASHBOARD' ? (
            <InvoiceManagerDashboard 
              userEmail={userEmail} 
              userName={userName}
              userPosition={userPosition}
              onNavigate={handleNavigate} 
              onLogout={handleLogout} 
            />
          ) : activeView === 'DETAILED_PORTFOLIO_LOGS' ? (
            <DetailedLogs 
              userEmail={userEmail} 
              userName={userName}
              userPosition={userPosition}
              onNavigate={handleNavigate} 
              onLogout={handleLogout} 
            />
          ) : activeView === 'GMAIL_DASHBOARD' ? (
            <GmailDashboard 
              userEmail={userEmail} 
              userName={userName}
              userPosition={userPosition}
              onNavigate={handleNavigate} 
              onLogout={handleLogout} 
            />
          ) : activeView === 'ANALYST_QUALITY_DASHBOARD' ? (
            <AnalystQualityDashboard 
              userEmail={userEmail} 
              userName={userName}
              userPosition={userPosition}
              onNavigate={handleNavigate} 
              onLogout={handleLogout} 
            />
          ) : activeView === 'EXCEL_PARSER_UTILITY' ? (
            <ExcelUploadDashboard 
              userEmail={userEmail} 
              userName={userName}
              userPosition={userPosition}
              onNavigate={handleNavigate} 
              onLogout={handleLogout} 
            />
          ) : activeView === 'GOOGLE_CHAT_DASHBOARD' ? (
            <GoogleChatDashboard 
              userEmail={userEmail} 
              userName={userName}
              userPosition={userPosition}
              onNavigate={handleNavigate} 
              onLogout={handleLogout} 
            />
          ) : activeView === 'PRESENTATION_DECK' ? (
            <PresentationDashboard 
              userEmail={userEmail} 
              userName={userName}
              userPosition={userPosition}
              onNavigate={handleNavigate} 
              onLogout={handleLogout} 
            />
          ) : activeView === 'PRESET_REPORT' ? (
            <PresetReportDashboard 
              userEmail={userEmail} 
              userName={userName}
              userPosition={userPosition}
              onNavigate={handleNavigate} 
              onLogout={handleLogout} 
            />
          ) : null}
        </PerformanceProfiler>
      </Suspense>

      {/* Live Performance Monitoring Overlay HUD */}
      <PerformanceMonitorHUD />

      {/* Global Dark Mode Floating Toggle Switch */}
      <button
        onClick={() => setIsDarkMode(!isDarkMode)}
        className="fixed bottom-6 left-6 z-50 flex items-center justify-center w-11 h-11 rounded-full bg-surface-container border border-outline-variant text-on-surface shadow-2xl hover:bg-surface-container-high hover:scale-105 transition-all duration-200 transform active:scale-95 cursor-pointer hover:-translate-y-0.5"
        title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
        aria-label="Toggle dark mode theme"
      >
        <span className="material-symbols-outlined text-[20px] select-none transition-transform duration-300 transform hover:rotate-12">
          {isDarkMode ? "light_mode" : "dark_mode"}
        </span>
      </button>

      {/* Global Search Trigger Floating Action Button & Modal */}
      {activeView !== 'SIGN_IN' && (
        <>
          <button
            onClick={() => setIsSearchOpen(true)}
            className="fixed bottom-6 left-20 z-50 flex items-center justify-center w-11 h-11 rounded-full bg-primary text-on-primary border border-primary/20 shadow-2xl hover:brightness-110 hover:scale-105 transition-all duration-200 transform active:scale-95 cursor-pointer hover:-translate-y-0.5"
            title="Open Global Search (Ctrl+K)"
            aria-label="Open global search center"
          >
            <span className="material-symbols-outlined text-[20px] select-none">
              search
            </span>
          </button>

          <GlobalSearch 
            isOpen={isSearchOpen} 
            onClose={() => setIsSearchOpen(false)} 
          />
        </>
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <RealtimeProvider>
        <AppContent />
      </RealtimeProvider>
    </AuthProvider>
  );
}
