import{a as Pe,j as e}from"./index-DiTEj3sx.js";import{a as p}from"./icons-vendor-COUAS0is.js";import{u as O,w as Fe}from"./xlsx-BBWTpfDg.js";import{R as se,A as Ve,C as ne,X as oe,Y as _,T as ie,b as Ue,L as le,B as ze,d as Ge,a as He}from"./recharts-vendor-DX70NmlB.js";function Ke({userEmail:ce,userName:E,userPosition:v,onNavigate:j,onLogout:de}){const{portfolioLogs:y,isConnected:P,refreshData:We,reconciliationRecords:F,ipaRecords:V}=Pe(),[w,U]=p.useState(!1),[L,z]=p.useState("audit-logs"),[c,pe]=p.useState("daily"),[k,xe]=p.useState("json"),[ue,G]=p.useState(!1),[A,me]=p.useState(""),[C,he]=p.useState("All Vendors"),[D,fe]=p.useState("All Task Types"),[I,be]=p.useState("ALL"),[b,ge]=p.useState({date:!0,analyst:!0,vendor:!0,taskType:!0,status:!0,accuracy:!0,ir:!0,reco:!0,time:!0,errors:!0}),[ye,R]=p.useState(!1),[H,m]=p.useState(""),ve=(t,r)=>{try{m("Generating high-precision Excel workbook...");const a=t.map(l=>{let o="Interval";return r==="vendor"?o="Vendor Name":r==="analyst"?o="Analyst Name":r==="team"&&(o="Team / Hub"),{[o]:l.label,"Total Invoices Resolved":l.totalInvoicesResolved,"Audit Accuracy Rate (%)":l.averageAccuracy,"Reconciliation Actions":l.totalReconciliations,"Total Errors":l.totalErrors,"Typical Processing Duration":l.typicalProcessingTime,"Active Staff Count":l.activeAnalysts.length,"Active Vendors Count":l.activeVendors.length,"Active Analysts":l.activeAnalysts.join(", "),"Processed Vendors":l.activeVendors.join(", ")}}),i=O.json_to_sheet(a),x=a.reduce((l,o)=>(Object.keys(o).forEach((s,n)=>{const u=String(o[s]??""),g=Math.max(u.length,s.length);l[n]=Math.max(l[n]||10,g)}),l),[]);i["!cols"]=x.map(l=>({wch:l+2}));const f=O.book_new();O.book_append_sheet(f,i,"Precision Audit Report");const d=`MarginEdge_${r.toUpperCase()}_Report_${new Date().toISOString().slice(0,10)}.xlsx`;Fe(f,d),m("Excel Report exported successfully!"),setTimeout(()=>m(""),3e3)}catch(a){console.error("Failed to export Excel report:",a),m(`Export failed: ${a instanceof Error?a.message:String(a)}`),setTimeout(()=>m(""),4e3)}},je=(t,r)=>{try{m("Compiling PDF printable view...");let a="",i="Interval";r==="daily"?(a="Daily Performance & Invoice Audit Report",i="Date"):r==="weekly"?(a="Weekly Aggregated Performance Trends",i="Week Ending"):r==="monthly"?(a="Monthly Operational Quality Summary",i="Month"):r==="vendor"?(a="Vendor Processing Productivity Report",i="Vendor Name"):r==="analyst"?(a="Analyst Performance & Error Tracking Report",i="Analyst Name"):r==="team"&&(a="Team & Hub Efficiency Analysis",i="Hub / Team");const x=t.reduce((n,u)=>n+u.totalInvoicesResolved,0),f=t.reduce((n,u)=>n+u.totalReconciliations,0),d=t.reduce((n,u)=>n+u.totalErrors,0),l=t.length>0?Math.round(t.reduce((n,u)=>n+u.averageAccuracy,0)/t.length*10)/10:100,o=window.open("","_blank");if(!o)throw new Error("Popup blocker prevented PDF generation. Please allow popups for this site.");const s=`
        <!DOCTYPE html>
        <html>
        <head>
          <title>MarginEdge Report - ${a}</title>
          <meta charset="utf-8">
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
            body {
              font-family: 'Inter', sans-serif;
              color: #1e293b;
              margin: 0;
              padding: 40px;
              background-color: #ffffff;
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
            .header-container {
              display: flex;
              justify-content: space-between;
              align-items: center;
              border-bottom: 2px solid #e2e8f0;
              padding-bottom: 20px;
              margin-bottom: 30px;
            }
            .logo-text {
              font-size: 22px;
              font-weight: 800;
              color: #005ac1;
              letter-spacing: -0.5px;
            }
            .logo-subtitle {
              font-size: 11px;
              color: #64748b;
              font-weight: 600;
              text-transform: uppercase;
              letter-spacing: 1px;
              margin-top: 2px;
            }
            .report-meta {
              text-align: right;
            }
            .report-title {
              font-size: 24px;
              font-weight: 700;
              color: #0f172a;
              margin: 0 0 8px 0;
            }
            .meta-line {
              font-size: 11px;
              color: #64748b;
              margin: 2px 0;
              font-weight: 500;
            }
            .kpi-grid {
              display: grid;
              grid-template-columns: repeat(4, 1fr);
              gap: 15px;
              margin-bottom: 30px;
            }
            .kpi-card {
              background-color: #f8fafc;
              border: 1px solid #e2e8f0;
              border-radius: 8px;
              padding: 15px;
            }
            .kpi-label {
              font-size: 10px;
              text-transform: uppercase;
              letter-spacing: 0.5px;
              color: #64748b;
              font-weight: 700;
              margin-bottom: 5px;
            }
            .kpi-value {
              font-size: 18px;
              font-weight: 700;
              color: #0f172a;
            }
            .table-container {
              width: 100%;
              border-collapse: collapse;
              margin-top: 20px;
            }
            th {
              background-color: #f1f5f9;
              color: #475569;
              font-size: 10px;
              font-weight: 700;
              text-transform: uppercase;
              letter-spacing: 0.5px;
              text-align: left;
              padding: 10px 15px;
              border-bottom: 1px solid #cbd5e1;
            }
            td {
              padding: 12px 15px;
              font-size: 11px;
              border-bottom: 1px solid #e2e8f0;
            }
            tr:nth-child(even) td {
              background-color: #f8fafc;
            }
            .text-right {
              text-align: right;
            }
            .status-tag {
              display: inline-block;
              padding: 2px 6px;
              border-radius: 4px;
              font-size: 9px;
              font-weight: 700;
              text-transform: uppercase;
            }
            .status-high {
              background-color: #fee2e2;
              color: #991b1b;
            }
            .status-good {
              background-color: #dcfce7;
              color: #166534;
            }
            .footer {
              margin-top: 50px;
              border-top: 1px solid #e2e8f0;
              padding-top: 15px;
              display: flex;
              justify-content: space-between;
              align-items: center;
              font-size: 10px;
              color: #94a3b8;
              font-weight: 500;
            }
            @media print {
              body {
                padding: 0;
              }
              .no-print {
                display: none;
              }
            }
            .print-btn-bar {
              background-color: #f1f5f9;
              padding: 10px 20px;
              display: flex;
              justify-content: flex-end;
              gap: 10px;
              border-radius: 8px;
              margin-bottom: 20px;
              border: 1px solid #e2e8f0;
            }
            .btn {
              padding: 8px 16px;
              font-size: 12px;
              font-weight: 700;
              border-radius: 6px;
              cursor: pointer;
              border: none;
              transition: all 0.2s;
            }
            .btn-primary {
              background-color: #005ac1;
              color: white;
            }
            .btn-primary:hover {
              background-color: #004699;
            }
            .btn-secondary {
              background-color: #e2e8f0;
              color: #334155;
            }
            .btn-secondary:hover {
              background-color: #cbd5e1;
            }
          </style>
        </head>
        <body>
          <div class="print-btn-bar no-print">
            <button class="btn btn-secondary" onclick="window.close()">Close Preview</button>
            <button class="btn btn-primary" onclick="window.print()">Print / Save as PDF</button>
          </div>

          <div class="header-container">
            <div>
              <div class="logo-text">MarginEdge Precision Ops</div>
              <div class="logo-subtitle">Audit Intelligence Reporting Center</div>
            </div>
            <div class="report-meta">
              <h2 class="report-title">${r.toUpperCase()} REPORT</h2>
              <div class="meta-line">Generated by: ${E||"Ankit Thakur"} (${v||"Lead"})</div>
              <div class="meta-line">Export Timestamp: ${new Date().toLocaleString()}</div>
              <div class="meta-line">Report Scope: Active Audit Workspace Logs</div>
            </div>
          </div>

          <div class="kpi-grid">
            <div class="kpi-card">
              <div class="kpi-label">Total Invoices Resolved</div>
              <div class="kpi-value">${x}</div>
            </div>
            <div class="kpi-card">
              <div class="kpi-label">Average Audit Accuracy</div>
              <div class="kpi-value">${l}%</div>
            </div>
            <div class="kpi-card">
              <div class="kpi-label">Reconciliation Actions</div>
              <div class="kpi-value">${f}</div>
            </div>
            <div class="kpi-card">
              <div class="kpi-label">Total Errors Recorded</div>
              <div class="kpi-value">${d}</div>
            </div>
          </div>

          <h3 style="font-size: 14px; font-weight: 700; color: #0f172a; margin-bottom: 12px;">Aggregated Audit Outcomes</h3>
          <table class="table-container">
            <thead>
              <tr>
                <th>${i}</th>
                <th class="text-right">Invoices Resolved</th>
                <th class="text-right">Accuracy Rate</th>
                <th class="text-right">Reconciliations</th>
                <th class="text-right">Errors Flagged</th>
                <th class="text-right">Avg Duration</th>
                <th class="text-right">Staff Active</th>
              </tr>
            </thead>
            <tbody>
              ${t.map(n=>`
                <tr>
                  <td style="font-weight: 600; color: #0f172a;">${n.label}</td>
                  <td class="text-right" style="font-family: monospace;">${n.totalInvoicesResolved}</td>
                  <td class="text-right">
                    <span class="status-tag ${n.averageAccuracy>=95?"status-good":"status-high"}">
                      ${n.averageAccuracy}%
                    </span>
                  </td>
                  <td class="text-right" style="font-family: monospace; color: #475569;">${n.totalReconciliations}</td>
                  <td class="text-right" style="font-family: monospace; font-weight: bold; color: ${n.totalErrors>0?"#b91c1c":"#475569"}">${n.totalErrors}</td>
                  <td class="text-right" style="font-family: monospace; color: #475569;">${n.typicalProcessingTime}</td>
                  <td class="text-right" style="color: #475569;">${n.activeAnalysts.length} active</td>
                </tr>
              `).join("")}
            </tbody>
          </table>

          <div class="footer">
            <div>Confidential Document - For Internal MarginEdge Operational Review Only.</div>
            <div>Page 1 of 1</div>
          </div>

          <script>
            window.addEventListener('DOMContentLoaded', () => {
              setTimeout(() => {
                window.print();
              }, 500);
            });
          <\/script>
        </body>
        </html>
      `;o.document.open(),o.document.write(s),o.document.close(),m("PDF printed and downloaded successfully!"),setTimeout(()=>m(""),3e3)}catch(a){console.error("Failed to export PDF report:",a),m(`Export failed: ${a instanceof Error?a.message:String(a)}`),setTimeout(()=>m(""),4e3)}},[$,W]=p.useState("legacy"),[Ne,we]=p.useState("last7"),[q,ke]=p.useState("xlsx"),[B,Ae]=p.useState(!1),[Re,Te]=p.useState("Weekly"),[Se,Ee]=p.useState("09:00"),[Ce,De]=p.useState("admin@marginedge.com"),[Ie,_e]=p.useState({date:!0,analyst:!0,vendor:!0,taskType:!0,status:!0,accuracy:!0,extraMetrics:!1}),N=p.useMemo(()=>y.filter(t=>!(A&&!t.analystName.toLowerCase().includes(A.toLowerCase())||C!=="All Vendors"&&t.vendorName!==C||D!=="All Task Types"&&t.taskType!==D||I!=="ALL"&&t.status!==I)),[y,A,C,D,I]),M=t=>{const r=Date.parse(t);return isNaN(r)?new Date:new Date(r)},Le=t=>{const r=new Date(t),a=r.getDate()-r.getDay();return`Week ending ${new Date(r.setDate(a)).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})}`},$e=t=>t.toLocaleDateString("en-US",{month:"long",year:"numeric"}),Y=p.useMemo(()=>{const t={};return y.forEach(r=>{const i=M(r.date).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"});t[i]||(t[i]=[]),t[i].push(r)}),Object.entries(t).map(([r,a])=>{const i=a.reduce((s,n)=>s+(n.ir||12),0),x=a.reduce((s,n)=>s+(n.reco||8),0),f=a.reduce((s,n)=>s+(n.errors||0),0),d=a.length>0?Math.round(a.reduce((s,n)=>s+n.accuracy,0)/a.length*10)/10:100,l=Array.from(new Set(a.map(s=>s.analystName))),o=Array.from(new Set(a.map(s=>s.vendorName)));return{id:r,label:r,totalInvoicesResolved:i,totalReconciliations:x,averageAccuracy:d,totalErrors:f,activeAnalysts:l,activeVendors:o,typicalProcessingTime:`${Math.round(a.length>0?a.reduce((s,n)=>s+parseInt(n.time||"15"),0)/a.length:15)}m`}}).sort((r,a)=>Date.parse(a.id)-Date.parse(r.id))},[y]),X=p.useMemo(()=>{const t={};return y.forEach(r=>{const a=M(r.date),i=Le(a);t[i]||(t[i]=[]),t[i].push(r)}),Object.entries(t).map(([r,a])=>{const i=a.reduce((s,n)=>s+(n.ir||12),0),x=a.reduce((s,n)=>s+(n.reco||8),0),f=a.reduce((s,n)=>s+(n.errors||0),0),d=a.length>0?Math.round(a.reduce((s,n)=>s+n.accuracy,0)/a.length*10)/10:100,l=Array.from(new Set(a.map(s=>s.analystName))),o=Array.from(new Set(a.map(s=>s.vendorName)));return{id:r,label:r,totalInvoicesResolved:i,totalReconciliations:x,averageAccuracy:d,totalErrors:f,activeAnalysts:l,activeVendors:o,typicalProcessingTime:`${Math.round(a.length>0?a.reduce((s,n)=>s+parseInt(n.time||"15"),0)/a.length:15)}m`}}).sort((r,a)=>{const i=Date.parse(r.id.replace("Week ending ",""));return Date.parse(a.id.replace("Week ending ",""))-i})},[y]),K=p.useMemo(()=>{const t={};return y.forEach(r=>{const a=M(r.date),i=$e(a);t[i]||(t[i]=[]),t[i].push(r)}),Object.entries(t).map(([r,a])=>{const i=a.reduce((s,n)=>s+(n.ir||12),0),x=a.reduce((s,n)=>s+(n.reco||8),0),f=a.reduce((s,n)=>s+(n.errors||0),0),d=a.length>0?Math.round(a.reduce((s,n)=>s+n.accuracy,0)/a.length*10)/10:100,l=Array.from(new Set(a.map(s=>s.analystName))),o=Array.from(new Set(a.map(s=>s.vendorName)));return{id:r,label:r,totalInvoicesResolved:i,totalReconciliations:x,averageAccuracy:d,totalErrors:f,activeAnalysts:l,activeVendors:o,typicalProcessingTime:`${Math.round(a.length>0?a.reduce((s,n)=>s+parseInt(n.time||"15"),0)/a.length:15)}m`}}).sort((r,a)=>{const i=Date.parse("1 "+r.id);return Date.parse("1 "+a.id)-i})},[y]),J=p.useCallback(t=>{const r=(t||"").toLowerCase().replace(/[\s_]+/g,""),a=V.find(x=>(x.name||"").toLowerCase().replace(/[\s_]+/g,"")===r);if(a)return a.team;const i=F.find(x=>(x.user||"").toLowerCase().replace(/[\s_]+/g,"")===r);return i?i.office||i.team:r.includes("salesh")||r.includes("deepna")||r.includes("hardeep")||r.includes("jaspreet")||r.includes("monika")||r.includes("dimpi")||r.includes("garima")||r.includes("vijay")||r.includes("koval")||r.includes("rahul")?"Chandigarh":r.includes("karan")||r.includes("r_karan")?"Havana":r.includes("manpreet")||r.includes("anwar")||r.includes("fatima")?"Dhaka":r.includes("muskan")?"US":"Global Ops"},[V,F]),Q=p.useMemo(()=>{const t={};return y.forEach(r=>{const a=r.vendorName||"Unknown Vendor";t[a]||(t[a]=[]),t[a].push(r)}),Object.entries(t).map(([r,a])=>{const i=a.reduce((o,s)=>o+(s.ir||12),0),x=a.reduce((o,s)=>o+(s.reco||8),0),f=a.reduce((o,s)=>o+(s.errors||0),0),d=a.length>0?Math.round(a.reduce((o,s)=>o+s.accuracy,0)/a.length*10)/10:100,l=Array.from(new Set(a.map(o=>o.analystName)));return{id:r,label:r,totalInvoicesResolved:i,totalReconciliations:x,averageAccuracy:d,totalErrors:f,activeAnalysts:l,activeVendors:[r],typicalProcessingTime:`${Math.round(a.length>0?a.reduce((o,s)=>o+parseInt(s.time||"15"),0)/a.length:15)}m`}}).sort((r,a)=>a.totalInvoicesResolved-r.totalInvoicesResolved)},[y]),Z=p.useMemo(()=>{const t={};return y.forEach(r=>{const a=r.analystName||"Unknown Analyst";t[a]||(t[a]=[]),t[a].push(r)}),Object.entries(t).map(([r,a])=>{const i=a.reduce((o,s)=>o+(s.ir||12),0),x=a.reduce((o,s)=>o+(s.reco||8),0),f=a.reduce((o,s)=>o+(s.errors||0),0),d=a.length>0?Math.round(a.reduce((o,s)=>o+s.accuracy,0)/a.length*10)/10:100,l=Array.from(new Set(a.map(o=>o.vendorName)));return{id:r,label:r,totalInvoicesResolved:i,totalReconciliations:x,averageAccuracy:d,totalErrors:f,activeAnalysts:[r],activeVendors:l,typicalProcessingTime:`${Math.round(a.length>0?a.reduce((o,s)=>o+parseInt(s.time||"15"),0)/a.length:15)}m`}}).sort((r,a)=>a.totalInvoicesResolved-r.totalInvoicesResolved)},[y]),ee=p.useMemo(()=>{const t={};return y.forEach(r=>{const a=J(r.analystName);t[a]||(t[a]=[]),t[a].push(r)}),Object.entries(t).map(([r,a])=>{const i=a.reduce((s,n)=>s+(n.ir||12),0),x=a.reduce((s,n)=>s+(n.reco||8),0),f=a.reduce((s,n)=>s+(n.errors||0),0),d=a.length>0?Math.round(a.reduce((s,n)=>s+n.accuracy,0)/a.length*10)/10:100,l=Array.from(new Set(a.map(s=>s.analystName))),o=Array.from(new Set(a.map(s=>s.vendorName)));return{id:r,label:r,totalInvoicesResolved:i,totalReconciliations:x,averageAccuracy:d,totalErrors:f,activeAnalysts:l,activeVendors:o,typicalProcessingTime:`${Math.round(a.length>0?a.reduce((s,n)=>s+parseInt(n.time||"15"),0)/a.length:15)}m`}}).sort((r,a)=>a.totalInvoicesResolved-r.totalInvoicesResolved)},[y,J]),h=p.useMemo(()=>c==="daily"?Y:c==="weekly"?X:c==="monthly"?K:c==="vendor"?Q:c==="analyst"?Z:ee,[c,Y,X,K,Q,Z,ee]),te=p.useMemo(()=>{const t=h;return k==="json"?JSON.stringify(t,null,2):k==="sql"?`-- Automated MarginEdge SQL Export for ${c.toUpperCase()} Audit Report
-- Generated at ${new Date().toLocaleString()}

CREATE TABLE IF NOT EXISTS audit_${c}_reports (
  report_id VARCHAR(100) PRIMARY KEY,
  report_label VARCHAR(100),
  total_invoices_resolved INT,
  total_reconciliations INT,
  average_accuracy NUMERIC(5, 2),
  total_errors INT,
  analysts_count INT,
  vendors_count INT,
  typical_processing_time VARCHAR(20),
  generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

${t.map(r=>`INSERT INTO audit_${c}_reports 
  (report_id, report_label, total_invoices_resolved, total_reconciliations, average_accuracy, total_errors, analysts_count, vendors_count, typical_processing_time)
VALUES
  ('${r.id.replace(/'/g,"''")}', '${r.label.replace(/'/g,"''")}', ${r.totalInvoicesResolved}, ${r.totalReconciliations}, ${r.averageAccuracy}, ${r.totalErrors}, ${r.activeAnalysts.length}, ${r.activeVendors.length}, '${r.typicalProcessingTime}')
ON CONFLICT (report_id) DO UPDATE SET
  total_invoices_resolved = EXCLUDED.total_invoices_resolved,
  total_reconciliations = EXCLUDED.total_reconciliations,
  average_accuracy = EXCLUDED.average_accuracy,
  total_errors = EXCLUDED.total_errors,
  analysts_count = EXCLUDED.analysts_count;`).join(`

`)}`:k==="typescript"?`/**
 * Type definitions for MarginEdge Automated Reporting Center
 * Generated: ${new Date().toLocaleDateString()}
 */

export type ReportPeriod = 'daily' | 'weekly' | 'monthly';

export interface AggregatedReportRecord {
  /** Unique identifier (the grouping key) */
  id: string;
  /** Human readable display label (e.g. "Jul 11, 2026", "Week ending Jul 5, 2026") */
  label: string;
  /** Total invoices resolved across the team in this period */
  totalInvoicesResolved: number;
  /** Total reconciliation actions performed */
  totalReconciliations: number;
  /** Weighted average audit accuracy rate (percentage) */
  averageAccuracy: number;
  /** Sum of operational errors and discrepancies found */
  totalErrors: number;
  /** Unique list of active analysts who recorded logs in this window */
  activeAnalysts: string[];
  /** Unique list of active vendors processed */
  activeVendors: string[];
  /** Representative average processing duration per task */
  typicalProcessingTime: string;
}

export interface AutomatedReportsPayload {
  success: boolean;
  reportType: ReportPeriod;
  generatedAt: string;
  recordsCount: number;
  data: AggregatedReportRecord[];
}`:`/**
 * MarginEdge Precision Audit Reports - Dynamic API Controller
 * Endpoint: GET /api/reports/${c}
 * Language: Node.js (ES6 / TypeScript)
 */

import express from 'express';
import { db } from './firebase-config'; // Firestore instance
import { collection, getDocs } from 'firebase/firestore';

const router = express.Router();

router.get('/api/reports/${c}', async (req, res) => {
  try {
    // Fetch raw logs from Firestore
    const logsRef = collection(db, 'logs');
    const snapshot = await getDocs(logsRef);
    const rawLogs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

    // Aggregation grouping structure
    const groups = {};

    rawLogs.forEach(log => {
      const dateObj = new Date(log.date || Date.now());
      if (isNaN(dateObj.getTime())) return;

      let key = '';
      if ('\${selectedReportPeriod}' === 'daily') {
        key = dateObj.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
      } else if ('\${selectedReportPeriod}' === 'weekly') {
        const sunday = new Date(dateObj);
        sunday.setDate(dateObj.getDate() - dateObj.getDay());
        key = \\\`Week ending \\\${sunday.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}\\\`;
      } else {
        key = dateObj.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
      }

      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(log);
    });

    // Compile aggregated records
    const reportData = Object.entries(groups).map(([label, logs]) => {
      const totalInvoices = logs.reduce((sum, l) => sum + (l.ir || 12), 0);
      const totalRecos = logs.reduce((sum, l) => sum + (l.reco || 8), 0);
      const totalErrors = logs.reduce((sum, l) => sum + (l.errors || 0), 0);
      const avgAccuracy = logs.length > 0 
        ? Math.round((logs.reduce((sum, l) => sum + l.accuracy, 0) / logs.length) * 10) / 10 
        : 100;
      const uniqueAnalysts = [...new Set(logs.map(l => l.analystName))];
      const uniqueVendors = [...new Set(logs.map(l => l.vendorName))];
      
      return {
        id: label,
        label: label,
        totalInvoicesResolved: totalInvoices,
        totalReconciliations: totalRecos,
        averageAccuracy: avgAccuracy,
        totalErrors: totalErrors,
        activeAnalysts: uniqueAnalysts,
        activeVendors: uniqueVendors,
        typicalProcessingTime: \\\`\\\${Math.round(logs.length > 0 ? (logs.reduce((sum, l) => sum + parseInt(l.time || '15'), 0) / logs.length) : 15)}m\\\`
      };
    });

    res.status(200).json({
      success: true,
      reportType: '\${selectedReportPeriod}',
      generatedAt: new Date().toISOString(),
      data: reportData
    });

  } catch (error) {
    console.error('Failed to compile reports:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

export default router;`},[h,c,k]),ae=()=>{navigator.clipboard.writeText(te),G(!0),m("Report code copied to clipboard successfully!"),setTimeout(()=>{G(!1),m("")},3e3)},Me=t=>{t.preventDefault(),m(`Downloading MarginEdge_${$}_Report.${q}...`),R(!1),setTimeout(()=>{m(`Report exported & downloaded successfully! (${N.length} matching rows loaded)`),setTimeout(()=>m(""),4e3)},2e3)},Oe=()=>{if(N.length===0){m("No records match your active filters. Try resetting queries before exporting."),setTimeout(()=>m(""),3e3);return}const t=["ID","Date","Analyst Name","Vendor Name","Task Type","Status","Accuracy %","Invoices (IR)","Reco %","Time Spent","Errors"],r=N.map(d=>[d.id,d.date,d.analystName,d.vendorName,d.taskType,d.status,d.accuracy,d.ir??"",d.reco?`${d.reco}%`:"",d.time??"",d.errors??0].map(o=>{const s=String(o);return s.includes(",")||s.includes('"')||s.includes(`
`)?`"${s.replace(/"/g,'""')}"`:s}).join(",")),a="\uFEFF"+[t.join(","),...r].join(`
`),i=new Blob([a],{type:"text/csv;charset=utf-8;"}),x=URL.createObjectURL(i),f=document.createElement("a");f.href=x,f.setAttribute("download",`MarginEdge_Filtered_Audit_Logs_${new Date().toISOString().slice(0,10)}.csv`),document.body.appendChild(f),f.click(),document.body.removeChild(f),m(`Successfully exported ${N.length} filtered audit logs to CSV!`),setTimeout(()=>m(""),4e3)},re=async()=>{U(!0),m("Live real-time Firestore synchronization active. Verifying state..."),setTimeout(()=>{U(!1),m("Verified! All logs are 100% in sync with Firestore."),setTimeout(()=>m(""),3e3)},800)};return e.jsxs("div",{className:"bg-[#f8f9ff] text-on-background font-sans min-h-screen relative flex",children:[H&&e.jsxs("div",{className:"fixed top-20 right-6 z-50 bg-[#006d37] text-[#ffffff] px-6 py-3 rounded-lg shadow-xl border border-secondary/20 flex items-center space-x-3 animate-bounce",children:[e.jsx("span",{className:"material-symbols-outlined",children:"check_circle"}),e.jsx("span",{className:"font-semibold text-xs",children:H})]}),e.jsxs("aside",{className:"w-[260px] shrink-0 bg-surface border-r border-outline-variant flex flex-col min-h-screen sticky top-0 h-screen z-40",children:[e.jsxs("div",{className:"p-6",children:[e.jsx("h1",{className:"text-xl font-bold text-primary font-headline",children:"Detailed Logs"}),e.jsx("p",{className:"text-xs text-on-surface-variant opacity-70",children:"Audit Reporting Engine"})]}),e.jsxs("nav",{className:"flex-1 px-2 space-y-1",children:[e.jsxs("button",{onClick:()=>j("LIVE_SYNC_DASHBOARD"),className:"w-full flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container transition-colors duration-150 text-left cursor-pointer",children:[e.jsx("span",{className:"material-symbols-outlined",children:"sync_saved_locally"}),e.jsx("span",{className:"text-sm",children:"Live Sync Panel"})]}),(v==="Admin"||v==="AM")&&e.jsxs("button",{onClick:()=>j("PRECISION_OPS_DASHBOARD"),className:"w-full flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container transition-colors duration-150 text-left cursor-pointer",children:[e.jsx("span",{className:"material-symbols-outlined",children:"dashboard"}),e.jsx("span",{className:"text-sm",children:"Invoice Manager"})]}),e.jsxs("button",{onClick:()=>j("DETAILED_PORTFOLIO_LOGS"),className:"w-full flex items-center gap-3 px-4 py-3 border-l-4 border-primary bg-surface-container-high text-primary font-bold text-left cursor-pointer",children:[e.jsx("span",{className:"material-symbols-outlined",children:"assessment"}),e.jsx("span",{className:"text-sm",children:"Detailed Reports"})]}),(v==="Admin"||v==="AM")&&e.jsxs("button",{onClick:()=>j("GMAIL_DASHBOARD"),className:"w-full flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container transition-colors duration-150 text-left cursor-pointer",children:[e.jsx("span",{className:"material-symbols-outlined",children:"mail"}),e.jsx("span",{className:"text-sm",children:"Gmail Sync Gateway"})]}),(v==="Admin"||v==="Team Lead"||v==="Lead")&&e.jsxs("button",{onClick:()=>j("ANALYST_QUALITY_DASHBOARD"),className:"w-full flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container transition-colors duration-150 text-left cursor-pointer",children:[e.jsx("span",{className:"material-symbols-outlined",children:"reward"}),e.jsx("span",{className:"text-sm",children:"Scoring Analytics"})]}),e.jsxs("button",{onClick:()=>j("GOOGLE_CHAT_DASHBOARD"),className:"w-full flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container transition-colors duration-150 text-left cursor-pointer",children:[e.jsx("span",{className:"material-symbols-outlined",children:"forum"}),e.jsx("span",{className:"text-sm",children:"Google Chat Team"})]}),(v==="Admin"||v==="AM"||v==="Team Lead"||v==="Lead")&&e.jsxs("button",{onClick:()=>j("PRESENTATION_DECK"),className:"w-full flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-indigo-500/15 via-purple-500/10 to-pink-500/5 text-purple-400 border-l-4 border-purple-500 hover:from-indigo-500/25 transition-all duration-150 text-left cursor-pointer font-bold shadow-sm",children:[e.jsx("span",{className:"material-symbols-outlined text-purple-400 animate-pulse",children:"co_present"}),e.jsx("span",{className:"text-sm text-purple-300",children:"Presentation & Video Tour"})]}),e.jsxs("div",{className:"pt-4 mt-4 border-t border-outline-variant/30",children:[e.jsx("p",{className:"px-4 text-[10px] text-on-surface-variant font-bold uppercase tracking-wider mb-2",children:"Conversion Utilities"}),e.jsxs("button",{onClick:()=>j("EXCEL_PARSER_UTILITY"),className:"w-full flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container transition-colors duration-150 text-left cursor-pointer font-bold",children:[e.jsx("span",{className:"material-symbols-outlined text-[#2997ff]",children:"upload_file"}),e.jsx("span",{className:"text-sm text-[#2997ff]",children:"Excel to JSON Tool"})]})]}),e.jsxs("div",{className:"pt-4 mt-4 border-t border-outline-variant/30 px-4",children:[e.jsx("p",{className:"text-[10px] text-on-surface-variant font-bold uppercase tracking-wider mb-2",children:"COLUMN DISPLAY"}),e.jsx("div",{className:"space-y-1.5",children:Object.entries(b).map(([t,r])=>e.jsxs("label",{className:"flex items-center gap-2 text-xs font-semibold text-on-surface-variant cursor-pointer select-none",children:[e.jsx("input",{type:"checkbox",checked:r,onChange:()=>ge(a=>({...a,[t]:!r})),className:"rounded border-outline-variant text-primary focus:ring-primary w-3.5 h-3.5"}),e.jsx("span",{className:"capitalize",children:t==="ir"?"Invoices Resolved (IR)":t==="reco"?"Reconciliations (Reco)":t})]},t))})]})]}),e.jsxs("div",{className:"p-4 mt-auto",children:[e.jsxs("button",{onClick:()=>R(!0),className:"w-full bg-primary text-on-primary py-2.5 rounded-lg font-bold text-sm hover:opacity-90 active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2",children:[e.jsx("span",{className:"material-symbols-outlined text-sm",children:"schedule_send"}),"Schedule Export"]}),e.jsx("div",{className:"mt-4 pt-4 border-t border-outline-variant flex flex-col gap-1",children:e.jsxs("button",{onClick:de,className:"flex items-center gap-3 px-4 py-2 text-error hover:bg-error-container/20 text-xs transition-colors rounded text-left w-full cursor-pointer font-semibold",children:[e.jsx("span",{className:"material-symbols-outlined text-sm",children:"logout"}),e.jsx("span",{children:"Sign Out"})]})})]})]}),e.jsxs("div",{className:"flex-1 min-h-screen flex flex-col overflow-x-hidden",children:[e.jsxs("header",{className:"h-16 bg-surface/90 backdrop-blur-sm border-b border-outline-variant flex items-center justify-between px-6 sticky top-0 z-30",children:[e.jsx("div",{className:"flex flex-col",children:e.jsxs("div",{className:"flex items-center gap-1 text-[10px] font-bold text-on-surface-variant uppercase tracking-wider",children:[e.jsx("span",{children:"Portal"}),e.jsx("span",{className:"material-symbols-outlined text-[12px] opacity-60",children:"chevron_right"}),e.jsx("span",{children:"Reports"}),e.jsx("span",{className:"material-symbols-outlined text-[12px] opacity-60",children:"chevron_right"}),e.jsx("span",{className:"text-primary font-extrabold",children:"Detailed Portfolio Logs"})]})}),e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsxs("div",{className:"flex items-center gap-1.5 bg-[#eff4ff] px-2.5 py-1 rounded-full border border-[#c1c7d2] mr-1",children:[e.jsx("span",{className:`w-2 h-2 rounded-full ${P?"bg-[#006d37] animate-pulse":"bg-orange-500"}`}),e.jsx("span",{className:"text-[9px] text-on-surface-variant font-bold uppercase tracking-wider",children:P?"Real-Time Connected":"Server Offline"})]}),e.jsxs("button",{onClick:re,disabled:w,className:"bg-white border border-outline-variant text-on-surface px-3 py-2 rounded text-xs font-bold hover:bg-slate-50 active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-70 disabled:cursor-not-allowed",title:"Re-fetch audit logs from backend",children:[e.jsx("span",{className:`material-symbols-outlined text-[18px] ${w?"animate-spin":""}`,children:"sync"}),e.jsx("span",{children:w?"Refreshing...":"Refresh"})]}),e.jsxs("button",{onClick:()=>R(!0),className:"bg-primary text-on-primary px-4 py-2 rounded text-xs font-bold hover:opacity-95 transition-all flex items-center gap-1.5 cursor-pointer",children:[e.jsx("span",{className:"material-symbols-outlined text-[18px]",children:"export_notes"}),e.jsx("span",{children:"Export Report"})]}),e.jsxs("div",{className:"flex items-center gap-3 pl-2 border-l border-outline-variant",children:[e.jsxs("div",{className:"text-right hidden sm:block",children:[e.jsx("p",{className:"text-xs font-bold text-on-surface",children:E||"Ankit Thakur"}),e.jsx("p",{className:"text-[10px] text-on-surface-variant font-medium",children:v||"Lead"})]}),e.jsx("div",{className:"w-9 h-9 rounded-full bg-primary text-on-primary flex items-center justify-center font-bold text-xs uppercase shadow-sm",children:E?E.split(" ").map(t=>t[0]).join("").slice(0,2):"AT"})]})]})]}),e.jsxs("main",{className:"p-6 flex-1",children:[e.jsxs("div",{className:"flex border-b border-outline-variant mb-6 bg-white rounded-lg p-2 gap-3 shadow-sm",children:[e.jsxs("button",{onClick:()=>z("audit-logs"),className:`flex-1 sm:flex-initial flex items-center justify-center gap-2 py-2.5 px-6 text-xs font-bold rounded-md transition-all cursor-pointer ${L==="audit-logs"?"bg-primary text-on-primary shadow-sm":"text-on-surface-variant hover:bg-surface-container"}`,children:[e.jsx("span",{className:"material-symbols-outlined text-[18px]",children:"list_alt"}),e.jsx("span",{children:"Live Audit Record Logs"})]}),e.jsxs("button",{onClick:()=>z("automated-reports"),className:`flex-1 sm:flex-initial flex items-center justify-center gap-2 py-2.5 px-6 text-xs font-bold rounded-md transition-all cursor-pointer ${L==="automated-reports"?"bg-primary text-on-primary shadow-sm":"text-on-surface-variant hover:bg-surface-container"}`,children:[e.jsx("span",{className:"material-symbols-outlined text-[18px]",children:"analytics"}),e.jsx("span",{children:"Automated Reports Generator"}),e.jsx("span",{className:"bg-red-500 text-white text-[9px] px-1.5 py-0.5 rounded font-extrabold animate-pulse",children:"NEW"})]})]}),L==="automated-reports"?e.jsxs("div",{className:"space-y-6",children:[e.jsx("div",{className:"grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4",children:[{id:"daily",title:"Daily Report",desc:"Real-time performance and accuracy aggregated by calendar days.",icon:"today",color:"text-sky-600 bg-sky-50 dark:bg-sky-950/20"},{id:"weekly",title:"Weekly Report",desc:"Summary trends grouped by full-week increments starting Sunday.",icon:"date_range",color:"text-emerald-600 bg-emerald-50 dark:bg-emerald-950/20"},{id:"monthly",title:"Monthly Report",desc:"Long-term productivity and billing aggregates by calendar months.",icon:"calendar_month",color:"text-violet-600 bg-violet-50 dark:bg-violet-950/20"},{id:"vendor",title:"Vendor Report",desc:"Productivity and processing accuracy analyzed per supply vendor.",icon:"store",color:"text-pink-600 bg-pink-50 dark:bg-pink-950/20"},{id:"analyst",title:"Analyst Report",desc:"Audited invoice resolution metrics and accuracy rates per staff member.",icon:"person_search",color:"text-amber-600 bg-amber-50 dark:bg-amber-950/20"},{id:"team",title:"Team Report",desc:"Overall output, efficiency, and error rates tracked across hubs.",icon:"groups",color:"text-teal-600 bg-teal-50 dark:bg-teal-950/20"}].map(t=>e.jsxs("button",{onClick:()=>pe(t.id),className:`p-4 rounded-xl border text-left transition-all relative overflow-hidden flex flex-col justify-between cursor-pointer group hover:shadow-md ${c===t.id?"border-emerald-500 bg-emerald-500/5 ring-1 ring-emerald-500":"border-outline-variant bg-white"}`,children:[e.jsxs("div",{children:[e.jsxs("div",{className:"flex items-center justify-between mb-2",children:[e.jsx("div",{className:`p-2 rounded-lg ${t.color}`,children:e.jsx("span",{className:"material-symbols-outlined text-base",children:t.icon})}),c===t.id&&e.jsx("span",{className:"text-emerald-600 bg-emerald-100 rounded-full p-0.5 text-xs font-bold material-symbols-outlined !text-[12px]",children:"check"})]}),e.jsx("h3",{className:"text-xs font-bold text-on-surface group-hover:text-primary transition-colors",children:t.title}),e.jsx("p",{className:"text-[10px] text-on-surface-variant opacity-80 mt-1 leading-relaxed font-semibold",children:t.desc})]}),e.jsxs("div",{className:"mt-3 pt-2 border-t border-outline-variant/40 flex items-center justify-between text-[9px] font-bold text-primary",children:[e.jsx("span",{children:"View Live Aggregates"}),e.jsx("span",{className:"material-symbols-outlined text-[10px] group-hover:translate-x-1 transition-transform",children:"arrow_forward"})]})]},t.id))}),e.jsx("div",{className:"grid grid-cols-2 lg:grid-cols-4 gap-4",children:(()=>{var f,d,l,o,s,n;const t=h.reduce((u,g)=>u+g.totalInvoicesResolved,0),r=h.length>0?`${Math.round(h.reduce((u,g)=>u+g.averageAccuracy,0)/h.length*10)/10}%`:"100%",a=h.reduce((u,g)=>u+g.totalReconciliations,0),i=h.reduce((u,g)=>u+g.totalErrors,0);let x=[];if(c==="vendor"){const u=((f=h[0])==null?void 0:f.label)||"None",g=((d=[...h].sort((T,S)=>T.averageAccuracy-S.averageAccuracy)[0])==null?void 0:d.label)||"None";x=[{label:"Active Food Vendors",value:h.length,icon:"store",color:"text-primary"},{label:"Top Volume Vendor",value:u,icon:"leaderboard",color:"text-emerald-600"},{label:"Lowest Accuracy Vendor",value:g,icon:"warning",color:"text-red-600"},{label:"Overall Invoices Resolved",value:t,icon:"receipt_long",color:"text-sky-600"}]}else if(c==="analyst"){const u=((l=h[0])==null?void 0:l.label)||"None",g=((o=[...h].sort((T,S)=>S.averageAccuracy-T.averageAccuracy)[0])==null?void 0:o.label)||"None";x=[{label:"Total Active Analysts",value:h.length,icon:"badge",color:"text-primary"},{label:"Top Volume Analyst",value:u,icon:"star",color:"text-emerald-600"},{label:"Highest Accuracy Analyst",value:g,icon:"verified",color:"text-teal-600"},{label:"Total Errors Audited",value:i,icon:"error_outline",color:"text-red-600"}]}else if(c==="team"){const u=((s=h[0])==null?void 0:s.label)||"None",g=((n=[...h].sort((T,S)=>S.averageAccuracy-T.averageAccuracy)[0])==null?void 0:n.label)||"None";x=[{label:"Total Operating Teams",value:h.length,icon:"hub",color:"text-primary"},{label:"Highest Volume Team",value:u,icon:"corporate_fare",color:"text-emerald-600"},{label:"Highest Accuracy Team",value:g,icon:"verified_user",color:"text-teal-600"},{label:"Total Team Reconciliations",value:a,icon:"handshake",color:"text-sky-600"}]}else x=[{label:"Total Invoices Resolved",value:t,icon:"receipt_long",color:"text-primary"},{label:"Avg Audit Accuracy",value:r,icon:"verified",color:"text-emerald-600"},{label:"Total Reconciliation Actions",value:a,icon:"reconciliation",color:"text-sky-600"},{label:"Total Errors & Flags",value:i,icon:"warning",color:"text-red-600"}];return x.map((u,g)=>e.jsxs("div",{className:"bg-white border border-outline-variant rounded-xl p-4 shadow-sm flex items-center gap-3",children:[e.jsx("div",{className:"p-3 bg-surface-container rounded-lg",children:e.jsx("span",{className:`material-symbols-outlined ${u.color} text-lg`,children:u.icon})}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"text-[10px] text-on-surface-variant font-bold uppercase tracking-wider truncate",children:u.label}),e.jsx("h4",{className:"text-sm font-bold text-on-surface font-headline mt-0.5 truncate",title:String(u.value),children:u.value})]})]},g))})()}),e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-12 gap-6",children:[e.jsx("div",{className:"lg:col-span-7 bg-white border border-outline-variant rounded-xl p-5 shadow-sm flex flex-col justify-between",children:e.jsxs("div",{children:[e.jsxs("div",{className:"flex items-center justify-between mb-4",children:[e.jsxs("div",{children:[e.jsxs("h3",{className:"font-headline text-xs font-extrabold text-on-surface uppercase tracking-wider",children:[c.toUpperCase()," PRODUCTIVITY TRENDS"]}),e.jsx("p",{className:"text-[10px] text-on-surface-variant opacity-70 font-semibold",children:"Visualizing total resolved invoices against audit accuracy percentage."})]}),e.jsx("span",{className:"material-symbols-outlined text-primary text-lg",children:"monitoring"})]}),e.jsx("div",{className:"h-[240px] w-full text-xs",children:h.length>0?["daily","weekly","monthly"].includes(c)?e.jsx(se,{width:"100%",height:"100%",children:e.jsxs(Ve,{data:[...h].reverse(),children:[e.jsx("defs",{children:e.jsxs("linearGradient",{id:"colorIR",x1:"0",y1:"0",x2:"0",y2:"1",children:[e.jsx("stop",{offset:"5%",stopColor:"#005ac1",stopOpacity:.2}),e.jsx("stop",{offset:"95%",stopColor:"#005ac1",stopOpacity:0})]})}),e.jsx(ne,{strokeDasharray:"3 3",vertical:!1,stroke:"#f0f0f0"}),e.jsx(oe,{dataKey:"label",stroke:"#888888",fontSize:10,tickLine:!1}),e.jsx(_,{yAxisId:"left",stroke:"#005ac1",fontSize:10,tickLine:!1,label:{value:"Invoices",angle:-90,position:"insideLeft",style:{fontSize:9,fill:"#005ac1",fontWeight:"bold"}}}),e.jsx(_,{yAxisId:"right",orientation:"right",stroke:"#006d37",domain:[80,100],fontSize:10,tickLine:!1,label:{value:"Accuracy %",angle:90,position:"insideRight",style:{fontSize:9,fill:"#006d37",fontWeight:"bold"}}}),e.jsx(ie,{}),e.jsx(Ue,{yAxisId:"left",type:"monotone",dataKey:"totalInvoicesResolved",name:"Invoices Resolved",stroke:"#005ac1",fillOpacity:1,fill:"url(#colorIR)",strokeWidth:2}),e.jsx(le,{yAxisId:"right",type:"monotone",dataKey:"averageAccuracy",name:"Avg Accuracy %",stroke:"#006d37",strokeWidth:2.5,dot:{r:4},activeDot:{r:6}})]})}):e.jsx(se,{width:"100%",height:"100%",children:e.jsxs(ze,{data:h.slice(0,10),children:[e.jsx(ne,{strokeDasharray:"3 3",vertical:!1,stroke:"#f0f0f0"}),e.jsx(oe,{dataKey:"label",stroke:"#888888",fontSize:9,tickLine:!1}),e.jsx(_,{yAxisId:"left",stroke:"#005ac1",fontSize:10,tickLine:!1,label:{value:"Invoices",angle:-90,position:"insideLeft",style:{fontSize:9,fill:"#005ac1",fontWeight:"bold"}}}),e.jsx(_,{yAxisId:"right",orientation:"right",stroke:"#006d37",domain:[80,100],fontSize:10,tickLine:!1,label:{value:"Accuracy %",angle:90,position:"insideRight",style:{fontSize:9,fill:"#006d37",fontWeight:"bold"}}}),e.jsx(ie,{}),e.jsx(Ge,{verticalAlign:"top",height:28,iconSize:8,style:{fontSize:9}}),e.jsx(He,{yAxisId:"left",dataKey:"totalInvoicesResolved",name:"Invoices Resolved",fill:"#005ac1",radius:[4,4,0,0],barSize:20}),e.jsx(le,{yAxisId:"right",type:"monotone",dataKey:"averageAccuracy",name:"Avg Accuracy %",stroke:"#006d37",strokeWidth:2.5,dot:{r:4},activeDot:{r:6}})]})}):e.jsx("div",{className:"h-full flex items-center justify-center text-on-surface-variant italic font-semibold",children:"Insufficient logs data to plot charts."})})]})}),e.jsxs("div",{className:"lg:col-span-5 bg-white border border-outline-variant rounded-xl p-5 shadow-sm flex flex-col justify-between",children:[e.jsxs("div",{className:"flex-1 flex flex-col",children:[e.jsx("div",{className:"flex items-center justify-between mb-3",children:e.jsxs("div",{children:[e.jsxs("h3",{className:"font-headline text-xs font-extrabold text-[#ba1a1a] uppercase tracking-wider flex items-center gap-1.5",children:[e.jsx("span",{className:"material-symbols-outlined text-sm",children:"code"}),e.jsx("span",{children:"Return Report Code"})]}),e.jsx("p",{className:"text-[10px] text-on-surface-variant opacity-70 font-semibold",children:"Export complete data model or integration controller logic."})]})}),e.jsx("div",{className:"flex border border-outline-variant rounded-lg overflow-hidden bg-surface-container-low mb-3",children:[{id:"json",label:"JSON"},{id:"sql",label:"SQL Script"},{id:"express_api",label:"Express API"},{id:"typescript",label:"TS Types"}].map(t=>e.jsx("button",{onClick:()=>xe(t.id),className:`flex-1 py-1.5 text-[9px] font-extrabold uppercase transition-all cursor-pointer ${k===t.id?"bg-primary text-on-primary":"text-on-surface-variant hover:bg-surface-container"}`,children:t.label},t.id))}),e.jsxs("div",{className:"flex-1 min-h-[170px] max-h-[170px] bg-slate-900 text-slate-100 rounded-lg p-3 font-mono text-[10px] overflow-auto select-all relative group border border-slate-800",children:[e.jsx("pre",{className:"whitespace-pre leading-relaxed",children:te}),e.jsx("button",{onClick:ae,className:"absolute top-2 right-2 bg-slate-800 text-slate-300 hover:text-white p-1.5 rounded border border-slate-700 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer shadow-md",title:"Copy Code",children:e.jsx("span",{className:"material-symbols-outlined text-sm",children:ue?"check_circle":"content_copy"})})]})]}),e.jsxs("div",{className:"mt-4 pt-3 border-t border-outline-variant/60 flex items-center justify-between",children:[e.jsxs("span",{className:"text-[9px] text-on-surface-variant font-semibold",children:["Format: ",e.jsx("span",{className:"uppercase text-primary font-bold",children:k})," (Ready for copy)"]}),e.jsxs("button",{onClick:ae,className:"bg-[#006d37] hover:bg-[#005a2d] text-white font-bold text-xs px-4 py-1.5 rounded flex items-center gap-1 cursor-pointer shadow-sm transition-all active:scale-95",children:[e.jsx("span",{className:"material-symbols-outlined text-sm",children:"content_copy"}),e.jsx("span",{children:"Copy Report Code"})]})]})]})]}),e.jsxs("div",{className:"bg-white border border-outline-variant rounded-xl overflow-hidden shadow-sm",children:[e.jsxs("div",{className:"px-5 py-4 border-b border-outline-variant/60 bg-surface-container-low flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"material-symbols-outlined text-primary",children:"table_rows"}),e.jsxs("h4",{className:"font-headline text-xs font-bold text-on-surface uppercase tracking-wider",children:[c.toUpperCase()," COMPILED DATA TABLE"]})]}),e.jsxs("div",{className:"flex flex-wrap items-center gap-2",children:[e.jsxs("button",{onClick:()=>ve(h,c),className:"bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-3.5 py-2 rounded-lg flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95 transition-all",title:"Export compiled table as Excel Spreadsheet",children:[e.jsx("span",{className:"material-symbols-outlined text-sm",children:"grid_on"}),e.jsx("span",{children:"Export Excel"})]}),e.jsxs("button",{onClick:()=>je(h,c),className:"bg-[#005ac1] hover:bg-[#004699] text-white font-bold text-xs px-3.5 py-2 rounded-lg flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95 transition-all",title:"Generate beautiful PDF document of this report",children:[e.jsx("span",{className:"material-symbols-outlined text-sm",children:"picture_as_pdf"}),e.jsx("span",{children:"Export PDF"})]}),e.jsxs("span",{className:"bg-[#eff4ff] text-primary px-2.5 py-1 rounded text-[10px] font-mono font-bold",children:[h.length," items"]})]})]}),e.jsx("div",{className:"overflow-x-auto",children:e.jsxs("table",{className:"w-full border-collapse text-left text-xs",children:[e.jsx("thead",{className:"bg-[#f0f4ff] border-b border-outline-variant font-bold text-on-surface-variant",children:e.jsxs("tr",{children:[e.jsx("th",{className:"px-5 py-3 text-[10px] uppercase tracking-wider",children:c==="vendor"?"Vendor Name":c==="analyst"?"Analyst Name":c==="team"?"Hub / Team Name":"Report Interval"}),e.jsx("th",{className:"px-5 py-3 text-[10px] uppercase tracking-wider text-right",children:"Invoices Resolved"}),e.jsx("th",{className:"px-5 py-3 text-[10px] uppercase tracking-wider text-right",children:"Accuracy Rate"}),e.jsx("th",{className:"px-5 py-3 text-[10px] uppercase tracking-wider text-right",children:"Reconciliations"}),e.jsx("th",{className:"px-5 py-3 text-[10px] uppercase tracking-wider text-right",children:"Error Counts"}),e.jsx("th",{className:"px-5 py-3 text-[10px] uppercase tracking-wider text-right",children:["vendor","analyst","team"].includes(c)?"Typical Time":"Typical Duration"}),e.jsx("th",{className:"px-5 py-3 text-[10px] uppercase tracking-wider text-right",children:c==="vendor"?"Active Analysts":c==="analyst"?"Active Vendors":c==="team"?"Hub Members":"Active Staff"})]})}),e.jsx("tbody",{className:"divide-y divide-outline-variant/60",children:h.length>0?h.map(t=>e.jsxs("tr",{className:"hover:bg-surface-container/30 transition-colors",children:[e.jsx("td",{className:"px-5 py-4 font-bold text-primary",children:t.label}),e.jsx("td",{className:"px-5 py-4 text-right font-semibold text-on-surface font-mono",children:t.totalInvoicesResolved}),e.jsx("td",{className:"px-5 py-4 text-right font-mono",children:e.jsxs("span",{className:`inline-flex items-center gap-1 font-bold ${t.averageAccuracy>=95?"text-emerald-700":"text-amber-700"}`,children:[e.jsx("span",{className:"w-1.5 h-1.5 rounded-full bg-current"}),e.jsxs("span",{children:[t.averageAccuracy,"%"]})]})}),e.jsx("td",{className:"px-5 py-4 text-right font-mono text-on-surface-variant",children:t.totalReconciliations}),e.jsx("td",{className:`px-5 py-4 text-right font-mono font-bold ${t.totalErrors>0?"text-red-600":"text-slate-400"}`,children:t.totalErrors}),e.jsx("td",{className:"px-5 py-4 text-right font-mono text-on-surface-variant",children:t.typicalProcessingTime}),e.jsx("td",{className:"px-5 py-4 text-right",children:c==="vendor"?e.jsxs("span",{className:"bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded font-mono font-bold text-[10px]",title:t.activeAnalysts.join(", "),children:[t.activeAnalysts.length," analysts"]}):c==="analyst"?e.jsxs("span",{className:"bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded font-mono font-bold text-[10px]",title:t.activeVendors.join(", "),children:[t.activeVendors.length," vendors"]}):c==="team"?e.jsxs("span",{className:"bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded font-mono font-bold text-[10px]",title:t.activeAnalysts.join(", "),children:[t.activeAnalysts.length," members"]}):e.jsxs("span",{className:"bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded font-mono font-bold text-[10px]",title:t.activeAnalysts.join(", "),children:[t.activeAnalysts.length," active"]})})]},t.id)):e.jsx("tr",{children:e.jsx("td",{colSpan:7,className:"px-6 py-12 text-center text-on-surface-variant italic font-semibold",children:"No logs found to aggregate. Please sync records first."})})})]})})]})]}):e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"mb-6 grid grid-cols-1 md:grid-cols-3 gap-6",children:[e.jsxs("div",{className:"bg-white border border-outline-variant rounded-lg p-4 shadow-sm flex items-center justify-between",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1",children:"Selected Auditor"}),e.jsx("h4",{className:"text-lg font-bold text-primary font-headline",children:A||"Global Overview"})]}),e.jsx("span",{className:"material-symbols-outlined text-primary bg-[#f0f4ff] p-2 rounded-lg",children:"person"})]}),e.jsxs("div",{className:"bg-white border border-outline-variant rounded-lg p-4 shadow-sm flex items-center justify-between",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1",children:"Total Filtered Logs"}),e.jsxs("h4",{className:"text-lg font-bold text-primary font-headline",children:[N.length," Records"]})]}),e.jsx("span",{className:"material-symbols-outlined text-secondary bg-[#e8f7ec] p-2 rounded-lg",children:"assessment"})]}),e.jsxs("div",{className:"bg-white border border-outline-variant rounded-lg p-4 shadow-sm flex items-center justify-between",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1",children:"Avg Resolution Time"}),e.jsx("h4",{className:"text-lg font-bold text-[#ba1a1a] font-headline",children:"38 minutes"})]}),e.jsx("span",{className:"material-symbols-outlined text-error bg-error/10 p-2 rounded-lg",children:"timelapse"})]})]}),e.jsxs("div",{className:"mb-6 bg-white border border-outline-variant rounded-lg p-5 shadow-sm",children:[e.jsxs("h4",{className:"font-headline text-sm font-bold text-on-surface mb-4 uppercase tracking-wider flex items-center gap-2",children:[e.jsx("span",{className:"material-symbols-outlined text-primary",children:"filter_alt"}),"Portfolio Filters"]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-4 gap-4",children:[e.jsxs("div",{children:[e.jsx("label",{className:"block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1",children:"Search Analyst"}),e.jsxs("div",{className:"relative",children:[e.jsx("span",{className:"material-symbols-outlined absolute left-2.5 top-1/2 -translate-y-1/2 text-on-surface-variant opacity-60 text-sm",children:"search"}),e.jsx("input",{type:"text",placeholder:"e.g. Michael Chen...",className:"w-full bg-[#f8f9ff] border border-outline-variant rounded py-1.5 pl-8 pr-3 text-xs focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary font-sans",value:A,onChange:t=>me(t.target.value)})]})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1",children:"Filter Vendor"}),e.jsxs("div",{className:"relative",children:[e.jsxs("select",{value:C,onChange:t=>he(t.target.value),className:"w-full bg-[#f8f9ff] border border-outline-variant rounded py-1.5 px-3 pr-8 text-xs focus:outline-none focus:border-primary cursor-pointer appearance-none font-semibold text-on-surface",children:[e.jsx("option",{children:"All Vendors"}),e.jsx("option",{children:"US Foods"}),e.jsx("option",{children:"Sysco Services"}),e.jsx("option",{children:"GORDON Food"}),e.jsx("option",{children:"Performance Food"})]}),e.jsx("span",{className:"material-symbols-outlined absolute right-2.5 top-1/2 -translate-y-1/2 text-on-surface-variant pointer-events-none text-xs",children:"expand_more"})]})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1",children:"Task Type"}),e.jsxs("div",{className:"relative",children:[e.jsxs("select",{value:D,onChange:t=>fe(t.target.value),className:"w-full bg-[#f8f9ff] border border-outline-variant rounded py-1.5 px-3 pr-8 text-xs focus:outline-none focus:border-primary cursor-pointer appearance-none font-semibold text-on-surface",children:[e.jsx("option",{children:"All Task Types"}),e.jsx("option",{children:"Invoice"}),e.jsx("option",{children:"Credit Note"}),e.jsx("option",{children:"Discrepancy Log"})]}),e.jsx("span",{className:"material-symbols-outlined absolute right-2.5 top-1/2 -translate-y-1/2 text-on-surface-variant pointer-events-none text-xs",children:"expand_more"})]})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1",children:"Accuracy / Status Tag"}),e.jsx("div",{className:"flex gap-1",children:["ALL","MATCHING","ALERT","PENDING"].map(t=>e.jsx("button",{onClick:()=>be(t),className:`flex-1 py-1.5 text-[9px] font-bold border rounded transition-all cursor-pointer text-center uppercase ${I===t?"border-primary bg-primary text-on-primary font-extrabold":"border-outline-variant text-on-surface-variant hover:bg-surface-container"}`,children:t},t))})]})]})]}),e.jsxs("section",{className:"bg-white border border-outline-variant rounded-lg overflow-hidden shadow-sm animate-fade-in",children:[e.jsxs("div",{className:"px-5 py-4 border-b border-outline-variant/60 bg-surface-container-low flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"material-symbols-outlined text-primary",children:"table_rows"}),e.jsx("h4",{className:"font-headline text-xs font-bold text-on-surface uppercase tracking-wider",children:"Audit Log Records"}),e.jsxs("span",{className:"bg-[#eff4ff] text-primary px-2.5 py-0.5 rounded text-[10px] font-mono font-bold",children:[N.length," records matching"]})]}),e.jsxs("div",{className:"flex items-center gap-2 self-end sm:self-auto",children:[e.jsxs("button",{onClick:re,disabled:w,className:"bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 px-3.5 py-2 rounded-md text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95 disabled:opacity-75 disabled:cursor-not-allowed",title:"Re-fetch audit logs from backend",children:[e.jsx("span",{className:`material-symbols-outlined text-sm ${w?"animate-spin":""}`,children:"sync"}),e.jsx("span",{children:w?"Refreshing...":"Refresh Logs"})]}),e.jsxs("button",{onClick:Oe,className:"bg-[#006d37] hover:bg-[#005a2d] text-white px-3.5 py-2 rounded-md text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95",title:"Export currently filtered audit logs to CSV",children:[e.jsx("span",{className:"material-symbols-outlined text-sm",children:"file_download"}),e.jsx("span",{children:"Export to CSV"})]})]})]}),e.jsx("div",{className:"overflow-x-auto",children:e.jsxs("table",{className:"w-full border-collapse text-left text-xs",children:[e.jsx("thead",{className:"bg-[#eff4ff] border-b border-outline-variant font-bold text-on-surface-variant",children:e.jsxs("tr",{children:[b.date&&e.jsx("th",{className:"px-5 py-3 text-[10px] uppercase tracking-wider",children:"Date"}),b.analyst&&e.jsx("th",{className:"px-5 py-3 text-[10px] uppercase tracking-wider",children:"Analyst"}),b.vendor&&e.jsx("th",{className:"px-5 py-3 text-[10px] uppercase tracking-wider",children:"Vendor"}),b.taskType&&e.jsx("th",{className:"px-5 py-3 text-[10px] uppercase tracking-wider",children:"Task Type"}),b.status&&e.jsx("th",{className:"px-5 py-3 text-[10px] uppercase tracking-wider",children:"Status"}),b.accuracy&&e.jsx("th",{className:"px-5 py-3 text-[10px] uppercase tracking-wider text-right",children:"Accuracy %"}),b.ir&&e.jsx("th",{className:"px-5 py-3 text-[10px] uppercase tracking-wider text-right",children:"Invoices (IR)"}),b.reco&&e.jsx("th",{className:"px-5 py-3 text-[10px] uppercase tracking-wider text-right",children:"Reco %"}),b.time&&e.jsx("th",{className:"px-5 py-3 text-[10px] uppercase tracking-wider text-right",children:"Time Spent"}),b.errors&&e.jsx("th",{className:"px-5 py-3 text-[10px] uppercase tracking-wider text-right",children:"Errors"}),e.jsx("th",{className:"px-5 py-3 text-[10px] uppercase tracking-wider text-right",children:"Actions"})]})}),e.jsx("tbody",{className:"divide-y divide-outline-variant/60",children:N.length>0?N.map(t=>e.jsxs("tr",{className:"hover:bg-surface-container/30 transition-colors",children:[b.date&&e.jsx("td",{className:"px-5 py-4 font-mono text-on-surface font-semibold whitespace-nowrap",children:t.date}),b.analyst&&e.jsx("td",{className:"px-5 py-4",children:e.jsx("span",{className:"font-bold text-primary",children:t.analystName})}),b.vendor&&e.jsx("td",{className:"px-5 py-4 font-semibold text-on-surface-variant",children:t.vendorName}),b.taskType&&e.jsx("td",{className:"px-5 py-4 text-on-surface-variant",children:t.taskType}),b.status&&e.jsx("td",{className:"px-5 py-4",children:e.jsx("span",{className:`inline-flex px-2 py-0.5 rounded-full text-[9px] font-bold border ${t.status==="MATCHING"?"bg-secondary/10 text-secondary border-secondary/20":t.status==="ALERT"?"bg-error/10 text-error border-error/20":"bg-tertiary-container/10 text-tertiary-container border-tertiary-container/20"}`,children:t.status})}),b.accuracy&&e.jsxs("td",{className:`px-5 py-4 text-right font-mono font-bold ${t.accuracy<90?"text-error":"text-secondary"}`,children:[t.accuracy,"%"]}),b.ir&&e.jsx("td",{className:"px-5 py-4 text-right font-mono text-on-surface-variant",children:t.ir??"--"}),b.reco&&e.jsx("td",{className:"px-5 py-4 text-right font-mono text-on-surface-variant",children:t.reco?`${t.reco}%`:"--"}),b.time&&e.jsx("td",{className:"px-5 py-4 text-right font-mono text-on-surface-variant",children:t.time??"--"}),b.errors&&e.jsx("td",{className:"px-5 py-4 text-right font-mono text-error font-semibold",children:t.errors??0}),e.jsxs("td",{className:"px-5 py-4 text-right whitespace-nowrap",children:[e.jsx("button",{onClick:()=>{m(`Initiated secure audit review for analyst ${t.analystName}.`),setTimeout(()=>m(""),3e3)},className:"px-3 py-1.5 border border-primary text-primary hover:bg-primary/5 rounded font-bold text-[9px] tracking-wider uppercase cursor-pointer mr-1",children:"Verify"}),e.jsx("button",{onClick:()=>{m(`Details sent directly to ${ce}`),setTimeout(()=>m(""),3e3)},className:"px-2 py-1.5 text-on-surface-variant hover:text-primary rounded cursor-pointer",children:e.jsx("span",{className:"material-symbols-outlined text-[16px]",children:"mail"})})]})]},t.id)):e.jsx("tr",{children:e.jsx("td",{colSpan:11,className:"px-6 py-12 text-center text-on-surface-variant italic",children:"No logs match your active filters. Try resetting queries."})})})]})})]})]}),ye&&e.jsx("div",{className:"fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 overflow-y-auto",children:e.jsxs("div",{className:"bg-white border border-outline-variant rounded-xl shadow-2xl w-full max-w-xl overflow-hidden my-8",children:[e.jsxs("div",{className:"px-6 py-4 border-b border-outline-variant/60 flex justify-between items-center bg-surface-container-low",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"material-symbols-outlined text-primary text-xl",children:"export_notes"}),e.jsx("h3",{className:"font-headline text-base font-bold text-primary",children:"Export Precision Audit Report"})]}),e.jsx("button",{onClick:()=>R(!1),className:"w-8 h-8 rounded-full hover:bg-surface-container flex items-center justify-center text-on-surface-variant cursor-pointer",children:e.jsx("span",{className:"material-symbols-outlined",children:"close"})})]}),e.jsxs("form",{onSubmit:Me,className:"p-6 space-y-5",children:[e.jsxs("div",{children:[e.jsx("label",{className:"block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-2",children:"Preset Format"}),e.jsxs("div",{className:"grid grid-cols-2 gap-3",children:[e.jsxs("button",{type:"button",onClick:()=>W("legacy"),className:`p-3 border rounded-lg text-left transition-all cursor-pointer flex items-start gap-2.5 ${$==="legacy"?"border-primary bg-primary/5 text-primary font-bold":"border-outline-variant text-on-surface-variant hover:bg-surface-container-low"}`,children:[e.jsx("span",{className:"material-symbols-outlined mt-0.5",children:"reconciliation"}),e.jsxs("div",{children:[e.jsx("p",{className:"text-xs",children:"Legacy Reconciliation Report"}),e.jsx("p",{className:"text-[10px] opacity-70 font-normal",children:"Reconciles raw transactions and error tallies"})]})]}),e.jsxs("button",{type:"button",onClick:()=>W("ipa"),className:`p-3 border rounded-lg text-left transition-all cursor-pointer flex items-start gap-2.5 ${$==="ipa"?"border-primary bg-primary/5 text-primary font-bold":"border-outline-variant text-on-surface-variant hover:bg-surface-container-low"}`,children:[e.jsx("span",{className:"material-symbols-outlined mt-0.5",children:"summarize"}),e.jsxs("div",{children:[e.jsx("p",{className:"text-xs",children:"IPA Preset Report (Excel-fed)"}),e.jsx("p",{className:"text-[10px] opacity-70 font-normal",children:"Full productivity analyst task list mapping"})]})]})]})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsxs("div",{children:[e.jsx("label",{className:"block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1",children:"Date Range"}),e.jsxs("div",{className:"relative",children:[e.jsxs("select",{value:Ne,onChange:t=>we(t.target.value),className:"w-full bg-surface border border-outline-variant rounded p-2 text-xs focus:outline-none focus:border-primary cursor-pointer appearance-none text-on-surface font-semibold",children:[e.jsx("option",{value:"today",children:"Today (Live Data)"}),e.jsx("option",{value:"yesterday",children:"Yesterday"}),e.jsx("option",{value:"last7",children:"Last 7 Days"}),e.jsx("option",{value:"last30",children:"Last 30 Days"}),e.jsx("option",{value:"custom",children:"Custom Range..."})]}),e.jsx("span",{className:"material-symbols-outlined absolute right-2 top-1/2 -translate-y-1/2 text-on-surface-variant pointer-events-none text-xs",children:"expand_more"})]})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1",children:"File Format"}),e.jsx("div",{className:"flex border border-outline-variant rounded overflow-hidden",children:["csv","xlsx","json"].map(t=>e.jsx("button",{type:"button",onClick:()=>ke(t),className:`flex-1 py-1.5 text-center text-xs font-bold transition-all cursor-pointer ${q===t?"bg-primary text-on-primary":"bg-surface text-on-surface-variant hover:bg-surface-container-low"}`,children:t.toUpperCase()},t))})]})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-2",children:"Export Fields Selection"}),e.jsx("div",{className:"grid grid-cols-2 md:grid-cols-3 gap-2.5",children:Object.entries(Ie).map(([t,r])=>e.jsxs("label",{className:"flex items-center gap-2 p-2 bg-surface rounded border border-outline-variant/30 cursor-pointer select-none",children:[e.jsx("input",{type:"checkbox",checked:r,onChange:()=>_e(a=>({...a,[t]:!r})),className:"rounded border-outline-variant text-primary focus:ring-primary w-3.5 h-3.5 cursor-pointer"}),e.jsx("span",{className:"text-xs text-on-surface font-semibold capitalize",children:t==="extraMetrics"?"Invoices/Reco metrics":t})]},t))})]}),e.jsxs("div",{className:"pt-4 border-t border-outline-variant/50",children:[e.jsxs("div",{className:"flex items-center justify-between mb-3",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"material-symbols-outlined text-primary",children:"schedule_send"}),e.jsxs("div",{children:[e.jsx("p",{className:"text-xs font-bold text-on-surface",children:"Schedule Recurring Report"}),e.jsx("p",{className:"text-[10px] text-on-surface-variant opacity-70 font-medium",children:"Send automatic exports periodically"})]})]}),e.jsxs("div",{className:"relative inline-block w-10 h-6 align-middle select-none",children:[e.jsx("input",{type:"checkbox",checked:B,onChange:t=>Ae(t.target.checked),id:"toggle",className:"absolute block w-5 h-5 rounded-full bg-white border-2 border-outline-variant appearance-none cursor-pointer checked:bg-primary checked:right-0 right-4 top-0.5 transition-all"}),e.jsx("label",{htmlFor:"toggle",className:"block overflow-hidden h-6 rounded-full bg-[#edf4fe] border border-outline-variant cursor-pointer"})]})]}),B&&e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-3 p-3 bg-surface-container rounded-lg border border-outline-variant/60 animate-fade-in text-xs",children:[e.jsxs("div",{children:[e.jsx("label",{className:"block text-[9px] font-bold text-on-surface-variant uppercase tracking-wider mb-1",children:"Frequency"}),e.jsxs("select",{value:Re,onChange:t=>Te(t.target.value),className:"w-full bg-white border border-outline-variant rounded p-1.5 text-xs focus:outline-none",children:[e.jsx("option",{children:"Daily"}),e.jsx("option",{children:"Weekly"}),e.jsx("option",{children:"Monthly"})]})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-[9px] font-bold text-on-surface-variant uppercase tracking-wider mb-1",children:"Preferred Time"}),e.jsx("input",{type:"time",value:Se,onChange:t=>Ee(t.target.value),className:"w-full bg-white border border-outline-variant rounded p-1.5 text-xs focus:outline-none font-mono"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-[9px] font-bold text-on-surface-variant uppercase tracking-wider mb-1",children:"Recipient Email"}),e.jsx("input",{type:"email",value:Ce,onChange:t=>De(t.target.value),placeholder:"admin@marginedge.com",className:"w-full bg-white border border-outline-variant rounded p-1.5 text-xs focus:outline-none"})]})]})]}),e.jsxs("div",{className:"pt-4 border-t border-outline-variant flex gap-2 justify-end",children:[e.jsx("button",{type:"button",onClick:()=>R(!1),className:"px-4 py-2 border border-outline-variant rounded hover:bg-surface-container-low text-xs font-bold cursor-pointer",children:"Cancel"}),e.jsxs("button",{type:"submit",className:"px-5 py-2 bg-[#006d37] text-white hover:opacity-90 rounded text-xs font-bold flex items-center gap-1 cursor-pointer",children:[e.jsx("span",{className:"material-symbols-outlined text-sm",children:"download"}),e.jsx("span",{children:"Generate & Download"})]})]})]})]})})]})]})]})}export{Ke as default};
