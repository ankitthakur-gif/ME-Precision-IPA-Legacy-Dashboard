var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_http = require("http");
var import_ws = require("ws");
var import_vite = require("vite");
var import_firestore = require("@google-cloud/firestore");
var XLSX = __toESM(require("xlsx"), 1);
var USERS = [
  "kazimuhammad",
  "mehedi",
  "tasnim",
  "ankushsharma",
  "pritipal",
  "vikasnegi",
  "swatirana",
  "amanarora",
  "jyotisharma",
  "salesh_salaria",
  "r_karan",
  "vijaygopal",
  "manpreet",
  "deepnarawat",
  "dimpiyadav",
  "garimasohal",
  "kovalverma",
  "muskandhiman",
  "harpreetdhaliwal",
  "harpreetthani",
  "harpreetsingh",
  "harshitalohat",
  "jaspreetsaini",
  "kashishbawa",
  "kirandeep",
  "amitsharma",
  "nehadubey",
  "rahulgupta",
  "priyasingh",
  "sandeepkumar",
  "sunitarani",
  "manishkumar",
  "poojasharma",
  "rajeshkumar",
  "jyotiranjan",
  "alokpandey",
  "shivanisood",
  "vinaykumar",
  "rohitsharma",
  "ayushisaxena",
  "abhisheksharma"
];
var OFFICES = ["Dhaka", "Chandigarh", "Havana", "US", "Delhi"];
var TEAMS = ["Core Ops", "Alpha Ops", "Island Ops", "Capital Lead", "Beta Team"];
var mockReconciliationRecords = Array.from({ length: 155 }, (_, i) => {
  if (i === 0) return { id: "rec-1", user: "kazimuhammad", office: "Dhaka", team: "Core Ops", points: 0, errors: 0, errorPercentage: 0, status: "MATCHED" };
  if (i === 1) return { id: "rec-2", user: "mehedi", office: "Dhaka", team: "Core Ops", points: 176.5, errors: 176.5, errorPercentage: 100, status: "HIGH PRIORITY" };
  if (i === 2) return { id: "rec-3", user: "tasnim", office: "Dhaka", team: "Core Ops", points: 3, errors: 3, errorPercentage: 100, status: "PENDING" };
  if (i === 3) return { id: "rec-4", user: "ankushsharma", office: "Havana", team: "Island Ops", points: 412, errors: 8.6, errorPercentage: 2.1, status: "MATCHED" };
  if (i === 4) return { id: "rec-5", user: "pritipal", office: "Dhaka", team: "Alpha Ops", points: 128, errors: 5.3, errorPercentage: 4.1, status: "PENDING" };
  if (i === 5) return { id: "rec-6", user: "vikasnegi", office: "Chandigarh", team: "Capital Lead", points: 842, errors: 11.7, errorPercentage: 1.4, status: "MATCHED" };
  if (i === 6) return { id: "rec-7", user: "swatirana", office: "Chandigarh", team: "Alpha Ops", points: 399, errors: 2.4, errorPercentage: 0.6, status: "MATCHED" };
  if (i === 7) return { id: "rec-8", user: "amanarora", office: "Dhaka", team: "Core Ops", points: 615, errors: 7.3, errorPercentage: 1.2, status: "MATCHED" };
  if (i === 8) return { id: "rec-9", user: "jyotisharma", office: "US", team: "Capital Lead", points: 288, errors: 32.1, errorPercentage: 11.1, status: "HIGH PRIORITY" };
  const user = USERS[i % USERS.length] + (i >= USERS.length ? `_${Math.floor(i / USERS.length)}` : "");
  const office = OFFICES[i % OFFICES.length];
  const team = TEAMS[i % TEAMS.length];
  let points = Math.floor(Math.random() * 850) + 15;
  let errors = 0;
  if (Math.random() < 0.25) {
    errors = Number((Math.random() * (points * 0.12)).toFixed(1));
  } else if (Math.random() < 0.04) {
    errors = points;
  }
  const errorPercentage = points > 0 ? Number((errors / points * 100).toFixed(1)) : 0;
  const status = errorPercentage === 0 ? "MATCHED" : errorPercentage > 10 ? "HIGH PRIORITY" : "PENDING";
  return {
    id: `rec-${i + 1}`,
    user,
    office,
    team,
    points,
    errors,
    errorPercentage,
    status
  };
});
var mockIPARecords = [
  { id: "ipa-1", name: "deepnarawat", team: "Alpha", tasks: 300 },
  { id: "ipa-2", name: "hardeeprohilla", team: "Alpha", tasks: 916 },
  { id: "ipa-3", name: "jaspreetsaini", team: "Alpha", tasks: 731 },
  { id: "ipa-4", name: "monikathakur", team: "Alpha", tasks: 698 },
  { id: "ipa-5", name: "dimpiyadav", team: "Alpha", tasks: 443 },
  { id: "ipa-6", name: "garimasohal", team: "Alpha", tasks: 294 },
  { id: "ipa-7", name: "ankushsharma", team: "Havana", tasks: 512 },
  { id: "ipa-8", name: "pritipal", team: "Dhaka", tasks: 128 },
  { id: "ipa-9", name: "vikasnegi", team: "Chandigarh", tasks: 842 },
  { id: "ipa-10", name: "swatirana", team: "Alpha", tasks: 399 },
  { id: "ipa-11", name: "amanarora", team: "Core", tasks: 615 },
  { id: "ipa-12", name: "jyotisharma", team: "US", tasks: 288 }
];
var mockTeamPerformance = [
  { teamName: "Alpha", efficiency: 92, errorRate: 12, output: "12.4k", lead: "Alpha Ops" },
  { teamName: "Core Ops", efficiency: 85, errorRate: 25, output: "8.1k", lead: "Beta Team" },
  { teamName: "Havana", efficiency: 70, errorRate: 40, output: "5.2k", lead: "Island Ops" },
  { teamName: "Dhaka Admin", efficiency: 45, errorRate: 85, output: "12.4k", lead: "Alpha Ops" },
  { teamName: "Chandigarh BPO", efficiency: 78, errorRate: 18, output: "15.9k", lead: "Capital Lead" }
];
var mockAMAlerts = [
  { id: "am-1", name: "Sarah Jenkins", role: "Senior Manager", alertsCount: 14, accuracyCurrent: 94.2, accuracyTarget: 98, criticality: "High Risk" },
  { id: "am-2", name: "Michael Chen", role: "Portfolio Lead", alertsCount: 8, accuracyCurrent: 97.8, accuracyTarget: 98, criticality: "Stable" },
  { id: "am-3", name: "Elena Rodriguez", role: "Associate Manager", alertsCount: 20, accuracyCurrent: 82.5, accuracyTarget: 98, criticality: "Immediate Action" }
];
var mockPortfolioLogs = [
  { id: "log-1", date: "Oct 24, 2023", analystName: "Michael Chen", vendorName: "US Foods", taskType: "Invoice", status: "MATCHING", accuracy: 98.2, ir: 12, reco: 8, time: "45m", errors: 1, fr: 6, qres: 2 },
  { id: "log-2", date: "Oct 24, 2023", analystName: "Amanda Rogers", vendorName: "Sysco Services", taskType: "Credit Note", status: "ALERT", accuracy: 84.5, ir: 15, reco: 10, time: "1.2h", errors: 3, fr: 8, qres: 5 },
  { id: "log-3", date: "Oct 23, 2023", analystName: "David Miller", vendorName: "GORDON Food", taskType: "Invoice", status: "PENDING", accuracy: 92, ir: 9, reco: 7, time: "30m", errors: 0, fr: 5, qres: 1 },
  { id: "log-4", date: "Oct 23, 2023", analystName: "Sarah Jenkins", vendorName: "US Foods", taskType: "Discrepancy Log", status: "MATCHING", accuracy: 99.8, ir: 22, reco: 18, time: "2.5h", errors: 0, fr: 15, qres: 12 },
  { id: "log-5", date: "Oct 23, 2023", analystName: "Michael Chen", vendorName: "Performance Food", taskType: "Invoice", status: "ALERT", accuracy: 72.1, ir: 14, reco: 9, time: "55m", errors: 4, fr: 7, qres: 0 }
];
var mockProductionTrend = [
  { name: "08:00 AM", value: 2e3 },
  { name: "10:00 AM", value: 5500 },
  { name: "12:00 PM", value: 4200 },
  { name: "02:00 PM", value: 14204 },
  { name: "04:00 PM", value: 8100 },
  { name: "06:00 PM", value: 9500 },
  { name: "08:00 PM", value: 3e3 },
  { name: "10:00 PM", value: 5800 }
];
var reconciliationRecords = [...mockReconciliationRecords];
var ipaRecords = [...mockIPARecords];
var teamPerformance = [...mockTeamPerformance];
var amAlerts = [...mockAMAlerts];
var portfolioLogs = [...mockPortfolioLogs];
var productionTrend = [...mockProductionTrend];
var mockInvoices = [
  { id: "inv-1", invoiceNumber: "INV-2026-001", vendorName: "US Foods", amount: 1542.5, status: "MATCHED", date: "2026-07-10", analystName: "Kazi Muhammad", accuracy: 98.2 },
  { id: "inv-2", invoiceNumber: "INV-2026-002", vendorName: "Sysco Services", amount: 890.15, status: "PENDING", date: "2026-07-11", analystName: "Ankit Thakur", accuracy: 95 },
  { id: "inv-3", invoiceNumber: "INV-2026-003", vendorName: "GORDON Food", amount: 4500, status: "ALERT", date: "2026-07-11", analystName: "Sarah Jenkins", accuracy: 84.5 },
  { id: "inv-4", invoiceNumber: "INV-2026-004", vendorName: "Performance Food", amount: 320.4, status: "MATCHED", date: "2026-07-12", analystName: "Michael Chen", accuracy: 100 }
];
var mockNotifications = [
  { id: "notif-1", type: "upload", title: "New Sync Complete", message: "Havana Desk synced 5,123 invoices.", timestamp: (/* @__PURE__ */ new Date()).toISOString(), read: true },
  { id: "notif-2", type: "accuracy", title: "Low Accuracy Warning", message: "Sarah Jenkins accuracy dropped below 95%.", timestamp: new Date(Date.now() - 6e5).toISOString(), read: false },
  { id: "notif-3", type: "error", title: "Operational Exception", message: "Reconciliation error reported in Core Ops.", timestamp: new Date(Date.now() - 36e5).toISOString(), read: false }
];
var invoices = [...mockInvoices];
var serverNotifications = [...mockNotifications];
var db = null;
var isFirebaseReady = false;
try {
  const configPath = import_path.default.resolve(process.cwd(), "firebase-applet-config.json");
  if (import_fs.default.existsSync(configPath)) {
    const firebaseConfig = JSON.parse(import_fs.default.readFileSync(configPath, "utf8"));
    db = new import_firestore.Firestore({
      projectId: firebaseConfig.projectId,
      databaseId: firebaseConfig.firestoreDatabaseId || "(default)"
    });
    console.log(`\u{1F525} [Backend] Server-side @google-cloud/firestore successfully initialized with project: ${firebaseConfig.projectId}, database: ${firebaseConfig.firestoreDatabaseId || "(default)"}`);
  } else {
    console.warn("\u26A0\uFE0F [Backend] firebase-applet-config.json not found. Operating in-memory mode.");
  }
} catch (error) {
  console.error("\u274C [Backend] Failed to initialize Firebase on startup:", error);
}
var googleSheetUrl = "";
var broadcastRef = null;
async function fetchAndSyncGoogleSheet(url) {
  if (!url) return;
  try {
    const match = url.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    if (!match) {
      console.log("\u26A0\uFE0F [Google Sheets] Invalid Sheet URL format:", url);
      return;
    }
    const spreadsheetId = match[1];
    const csvUrl = `https://docs.google.com/spreadsheets/d/${spreadsheetId}/export?format=csv`;
    console.log(`\u{1F4E1} [Google Sheets] Auto-sync checking URL: ${csvUrl}`);
    const res = await fetch(csvUrl);
    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }
    const csvText = await res.text();
    const workbook = XLSX.read(csvText, { type: "string" });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const json = XLSX.utils.sheet_to_json(worksheet);
    if (!json || json.length === 0) {
      console.log("\u26A0\uFE0F [Google Sheets] Parsed data is empty.");
      return;
    }
    const parsedRecords = json.map((row, index) => {
      const keys = Object.keys(row);
      const nameKey = keys.find((k) => /name|user|analyst|employee|member/i.test(k)) || keys[0];
      const teamKey = keys.find((k) => /team|dept|office|group/i.test(k)) || keys[1];
      const tasksKey = keys.find((k) => /task|point|volume|count|score/i.test(k)) || keys[2];
      return {
        id: row.id || `ipa-${index + 1}-${Date.now()}`,
        name: String(row[nameKey] || `Analyst ${index + 1}`).trim(),
        team: String(row[teamKey] || "Alpha").trim(),
        tasks: Number(row[tasksKey]) || 0
      };
    });
    const isDifferent = JSON.stringify(parsedRecords) !== JSON.stringify(ipaRecords);
    if (isDifferent) {
      console.log(`\u{1F504} [Google Sheets Auto-Sync] Detected changes. Updating ${parsedRecords.length} records...`);
      ipaRecords = parsedRecords;
      if (isFirebaseReady && db) {
        try {
          const batch = db.batch();
          for (const rec of parsedRecords) {
            batch.set(db.collection("analysts").doc(rec.id), rec);
          }
          await batch.commit();
        } catch (err) {
          console.error("Firestore sync error:", err);
        }
      }
      if (broadcastRef) {
        broadcastRef({ type: "IPA_RECORDS_UPDATE", payload: ipaRecords });
      }
    } else {
      console.log("\u2705 [Google Sheets Auto-Sync] No changes detected in the Google Sheet.");
    }
  } catch (error) {
    console.error("\u274C [Google Sheets Auto-Sync] Error during background fetch:", error);
  }
}
async function loadAndSeedDatabase() {
  if (!db) {
    console.log("\u{1F4A1} [Backend] Running with local in-memory fallback state.");
    return;
  }
  try {
    console.log("\u2699\uFE0F [Backend] Testing connection to Firestore...");
    await db.collection("users").limit(1).get();
    isFirebaseReady = true;
    console.log("\u{1F525} [Backend] Firestore connection successfully verified! Loading/seeding collections from Firestore...");
    const usersSnap = await db.collection("users").get();
    if (usersSnap.empty) {
      console.log("\u{1F331} [Seeding] users to Firestore...");
      const defaultUsers = [
        {
          uid: "default-lead-ankit",
          name: "Ankit Thakur",
          email: "ankit.thakur@marginedge.com",
          role: "Lead",
          office: "Chandigarh",
          status: "active"
        },
        {
          uid: "default-analyst-kazi",
          name: "Kazi Muhammad",
          email: "kazimuhammad@marginedge.com",
          role: "Analyst",
          office: "Dhaka",
          status: "active"
        }
      ];
      const batch = db.batch();
      for (const u of defaultUsers) {
        batch.set(db.collection("users").doc(u.uid), u);
      }
      await batch.commit();
    }
    const teamsSnap = await db.collection("teams").get();
    if (teamsSnap.empty) {
      console.log("\u{1F331} [Seeding] teams to Firestore...");
      const batch = db.batch();
      for (const rec of mockTeamPerformance) {
        const docId = rec.teamName.replace(/[\/\s]+/g, "_");
        batch.set(db.collection("teams").doc(docId), rec);
      }
      await batch.commit();
      teamPerformance = [...mockTeamPerformance];
    } else {
      teamPerformance = teamsSnap.docs.map((doc) => doc.data());
    }
    const analystsSnap = await db.collection("analysts").get();
    if (analystsSnap.empty) {
      console.log("\u{1F331} [Seeding] analysts to Firestore...");
      const batch = db.batch();
      for (const rec of mockIPARecords) {
        batch.set(db.collection("analysts").doc(rec.id), rec);
      }
      await batch.commit();
      ipaRecords = [...mockIPARecords];
    } else {
      ipaRecords = analystsSnap.docs.map((doc) => doc.data());
    }
    const vendorsSnap = await db.collection("vendors").get();
    const defaultVendors = [
      { id: "v-1", name: "US Foods" },
      { id: "v-2", name: "Sysco Services" },
      { id: "v-3", name: "GORDON Food" },
      { id: "v-4", name: "Performance Food" },
      { id: "v-5", name: "Baldor Foods" }
    ];
    if (vendorsSnap.empty) {
      console.log("\u{1F331} [Seeding] vendors to Firestore...");
      const batch = db.batch();
      for (const v of defaultVendors) {
        batch.set(db.collection("vendors").doc(v.id), v);
      }
      await batch.commit();
    }
    const logsSnap = await db.collection("logs").get();
    if (logsSnap.empty) {
      console.log("\u{1F331} [Seeding] logs to Firestore...");
      const batch = db.batch();
      for (const rec of mockPortfolioLogs) {
        batch.set(db.collection("logs").doc(rec.id), rec);
      }
      await batch.commit();
      portfolioLogs = [...mockPortfolioLogs];
    } else {
      portfolioLogs = logsSnap.docs.map((doc) => doc.data());
    }
    const statsSnap = await db.collection("dashboardStats").get();
    if (statsSnap.empty) {
      console.log("\u{1F331} [Seeding] dashboardStats to Firestore...");
      const batch = db.batch();
      batch.set(db.collection("dashboardStats").doc("reconciliation_records"), { records: mockReconciliationRecords });
      batch.set(db.collection("dashboardStats").doc("production_trend"), { trend: mockProductionTrend });
      batch.set(db.collection("dashboardStats").doc("am_alerts"), { alerts: mockAMAlerts });
      await batch.commit();
      reconciliationRecords = [...mockReconciliationRecords];
      productionTrend = [...mockProductionTrend];
      amAlerts = [...mockAMAlerts];
    } else {
      const recDoc = await db.collection("dashboardStats").doc("reconciliation_records").get();
      if (recDoc.exists) {
        reconciliationRecords = recDoc.data()?.records || [];
      } else {
        reconciliationRecords = [...mockReconciliationRecords];
      }
      const trendDoc = await db.collection("dashboardStats").doc("production_trend").get();
      if (trendDoc.exists) {
        productionTrend = trendDoc.data()?.trend || [];
      } else {
        productionTrend = [...mockProductionTrend];
      }
      const alertsDoc = await db.collection("dashboardStats").doc("am_alerts").get();
      if (alertsDoc.exists) {
        amAlerts = alertsDoc.data()?.alerts || [];
      } else {
        amAlerts = [...mockAMAlerts];
      }
    }
    const invoicesSnap = await db.collection("invoices").get();
    if (invoicesSnap.empty) {
      console.log("\u{1F331} [Seeding] invoices to Firestore...");
      const batch = db.batch();
      for (const rec of mockInvoices) {
        batch.set(db.collection("invoices").doc(rec.id), rec);
      }
      await batch.commit();
      invoices = [...mockInvoices];
    } else {
      invoices = invoicesSnap.docs.map((doc) => doc.data());
    }
    const notificationsSnap = await db.collection("notifications").get();
    if (notificationsSnap.empty) {
      console.log("\u{1F331} [Seeding] notifications to Firestore...");
      const batch = db.batch();
      for (const rec of mockNotifications) {
        batch.set(db.collection("notifications").doc(rec.id), rec);
      }
      await batch.commit();
      serverNotifications = [...mockNotifications];
    } else {
      serverNotifications = notificationsSnap.docs.map((doc) => doc.data());
    }
    try {
      const gsDoc = await db.collection("settings").doc("google_sheet").get();
      if (gsDoc.exists) {
        googleSheetUrl = gsDoc.data()?.url || "";
        console.log("\u2699\uFE0F [Backend] Restored saved Google Sheet URL:", googleSheetUrl);
        if (googleSheetUrl) {
          fetchAndSyncGoogleSheet(googleSheetUrl);
        }
      }
    } catch (err) {
      console.warn("\u26A0\uFE0F [Backend] Non-fatal error loading settings:", err);
    }
    console.log("\u{1F3AF} [Backend] All database records loaded & synced cleanly using standard collections: users, teams, analysts, vendors, logs, dashboardStats!");
  } catch (error) {
    console.error("\u274C [Backend] Error synchronizing database collections:", error);
    console.warn("\u26A0\uFE0F [Backend] Falling back to local in-memory simulation because Firestore is unprovisioned, unauthorized, or not found. Disabling active Firestore connection flag.");
    isFirebaseReady = false;
  }
}
async function executeDailySnapshot() {
  const todayStr = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  if (!isFirebaseReady || !db) {
    console.warn("\u26A0\uFE0F [Backup Engine] Firestore is not ready. Performing in-memory simulation backup.");
    return {
      success: true,
      logsCount: portfolioLogs.length,
      snapshotDate: todayStr
    };
  }
  try {
    console.log(`\u{1F4E1} [Backup Engine] Initiating disaster recovery backup for ${todayStr}...`);
    const logsSnap = await db.collection("logs").get();
    const logsList = logsSnap.docs.map((doc) => ({
      id: doc.id,
      ...doc.data()
    }));
    if (logsList.length === 0) {
      console.log(`\u26A0\uFE0F [Backup Engine] "logs" collection is empty. Skipping backup execution.`);
      return {
        success: true,
        logsCount: 0,
        snapshotDate: todayStr
      };
    }
    const batchSize = 400;
    for (let i = 0; i < logsList.length; i += batchSize) {
      const chunk = logsList.slice(i, i + batchSize);
      const batch = db.batch();
      for (const log of chunk) {
        const backupDocRef = db.collection("backups").doc(`${todayStr}_${log.id}`);
        batch.set(backupDocRef, {
          ...log,
          snapshotDate: todayStr,
          backedUpAt: (/* @__PURE__ */ new Date()).toISOString(),
          disasterRecoveryValid: true
        });
      }
      await batch.commit();
    }
    const summaryRef = db.collection("backups").doc(`summary_${todayStr}`);
    await summaryRef.set({
      snapshotDate: todayStr,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      logsCount: logsList.length,
      status: "success",
      type: "daily_snapshot",
      metadata: {
        systemCode: "DR-AUTO-SNAPSHOT-V1",
        integrityChecked: true
      }
    });
    await db.collection("dashboardStats").doc("backup_metadata").set({
      lastSnapshotDate: todayStr,
      lastSnapshotTime: (/* @__PURE__ */ new Date()).toISOString(),
      lastSnapshotLogsCount: logsList.length,
      status: "completed"
    });
    console.log(`\u2705 [Backup Engine] Daily snapshot successfully completed. Backed up ${logsList.length} logs to 'backups' collection.`);
    return {
      success: true,
      logsCount: logsList.length,
      snapshotDate: todayStr
    };
  } catch (error) {
    console.error(`\u274C [Backup Engine] Error executing daily snapshot:`, error);
    console.warn("\u26A0\uFE0F [Backup Engine] Disabling active Firestore connection flag and falling back to in-memory simulation backup.");
    isFirebaseReady = false;
    return {
      success: true,
      logsCount: portfolioLogs.length,
      snapshotDate: todayStr
    };
  }
}
function startBackupScheduler() {
  const checkIntervalMs = 60 * 60 * 1e3;
  async function checkAndRunBackup() {
    if (!isFirebaseReady || !db) return;
    try {
      const todayStr = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
      const metaDoc = await db.collection("dashboardStats").doc("backup_metadata").get();
      let shouldRun = false;
      if (!metaDoc.exists) {
        shouldRun = true;
      } else {
        const data = metaDoc.data();
        if (data?.lastSnapshotDate !== todayStr) {
          shouldRun = true;
        }
      }
      if (shouldRun) {
        console.log(`\u23F0 [Backup Scheduler] New day detected (${todayStr}). Running scheduled backup...`);
        await executeDailySnapshot();
      } else {
        console.log(`\u{1F4A4} [Backup Scheduler] Already backed up today (${todayStr}).`);
      }
    } catch (err) {
      console.error("\u274C [Backup Scheduler] Error in verification loop:", err);
    }
  }
  checkAndRunBackup();
  setInterval(checkAndRunBackup, checkIntervalMs);
}
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json());
  app.get("/api/state", (req, res) => {
    res.json({
      reconciliationRecords,
      ipaRecords,
      teamPerformance,
      amAlerts,
      portfolioLogs,
      productionTrend
    });
  });
  app.post("/api/records/update", async (req, res) => {
    const updatedRecord = req.body;
    reconciliationRecords = reconciliationRecords.map(
      (rec) => rec.id === updatedRecord.id ? updatedRecord : rec
    );
    if (isFirebaseReady && db) {
      try {
        await db.collection("dashboardStats").doc("reconciliation_records").set({ records: reconciliationRecords });
      } catch (err) {
        console.error("Firestore update error:", err);
      }
    }
    broadcast({ type: "RECORDS_UPDATE", payload: reconciliationRecords });
    res.json({ success: true, reconciliationRecords });
  });
  app.post("/api/logs/create", async (req, res) => {
    const newLog = req.body;
    portfolioLogs = [newLog, ...portfolioLogs];
    if (isFirebaseReady && db) {
      try {
        await db.collection("logs").doc(newLog.id).set(newLog);
      } catch (err) {
        console.error("Firestore create log error:", err);
      }
    }
    broadcast({ type: "LOGS_UPDATE", payload: portfolioLogs });
    res.json({ success: true, portfolioLogs });
  });
  app.get("/api/reports/:period", async (req, res) => {
    try {
      const { period } = req.params;
      const allowedPeriods = ["daily", "weekly", "monthly"];
      if (!allowedPeriods.includes(period)) {
        return res.status(400).json({ success: false, error: `Invalid period. Must be one of: ${allowedPeriods.join(", ")}` });
      }
      const logs = portfolioLogs;
      const groups = {};
      logs.forEach((log) => {
        const dateObj = new Date(log.date || Date.now());
        if (isNaN(dateObj.getTime())) return;
        let key = "";
        if (period === "daily") {
          key = dateObj.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
        } else if (period === "weekly") {
          const sunday = new Date(dateObj);
          sunday.setDate(dateObj.getDate() - dateObj.getDay());
          key = `Week ending ${sunday.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}`;
        } else {
          key = dateObj.toLocaleDateString("en-US", { month: "long", year: "numeric" });
        }
        if (!groups[key]) {
          groups[key] = [];
        }
        groups[key].push(log);
      });
      const reportData = Object.entries(groups).map(([label, logsInGroup]) => {
        const totalInvoices = logsInGroup.reduce((sum, l) => sum + (l.ir || 12), 0);
        const totalRecos = logsInGroup.reduce((sum, l) => sum + (l.reco || 8), 0);
        const totalErrors = logsInGroup.reduce((sum, l) => sum + (l.errors || 0), 0);
        const avgAccuracy = logsInGroup.length > 0 ? Math.round(logsInGroup.reduce((sum, l) => sum + l.accuracy, 0) / logsInGroup.length * 10) / 10 : 100;
        const uniqueAnalysts = [...new Set(logsInGroup.map((l) => l.analystName || ""))].filter(Boolean);
        const uniqueVendors = [...new Set(logsInGroup.map((l) => l.vendorName || ""))].filter(Boolean);
        return {
          id: label,
          label,
          totalInvoicesResolved: totalInvoices,
          totalReconciliations: totalRecos,
          averageAccuracy: avgAccuracy,
          totalErrors,
          activeAnalysts: uniqueAnalysts,
          activeVendors: uniqueVendors,
          typicalProcessingTime: `${Math.round(logsInGroup.length > 0 ? logsInGroup.reduce((sum, l) => sum + parseInt(l.time || "15"), 0) / logsInGroup.length : 15)}m`
        };
      });
      res.status(200).json({
        success: true,
        reportType: period,
        generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        recordsCount: reportData.length,
        data: reportData
      });
    } catch (error) {
      console.error(`Failed to compile ${req.params.period} reports:`, error);
      res.status(500).json({ success: false, error: error.message });
    }
  });
  app.post("/api/alerts/update", async (req, res) => {
    const updatedAlert = req.body;
    amAlerts = amAlerts.map(
      (alert) => alert.id === updatedAlert.id ? updatedAlert : alert
    );
    if (isFirebaseReady && db) {
      try {
        await db.collection("dashboardStats").doc("am_alerts").set({ alerts: amAlerts });
      } catch (err) {
        console.error("Firestore update alert error:", err);
      }
    }
    broadcast({ type: "ALERTS_UPDATE", payload: amAlerts });
    res.json({ success: true, amAlerts });
  });
  app.post("/api/ipa/update-all", async (req, res) => {
    const updatedList = req.body;
    ipaRecords = updatedList;
    if (isFirebaseReady && db) {
      try {
        const batch = db.batch();
        for (const rec of updatedList) {
          batch.set(db.collection("analysts").doc(rec.id), rec);
        }
        await batch.commit();
        console.log(`\u{1F331} [Backend] Successfully saved ${updatedList.length} uploaded IPA records to Firestore.`);
      } catch (err) {
        console.error("Firestore update all ipa error:", err);
      }
    }
    broadcast({ type: "IPA_RECORDS_UPDATE", payload: ipaRecords });
    res.json({ success: true, ipaRecords });
  });
  app.get("/api/settings/google-sheet", (req, res) => {
    res.json({ url: googleSheetUrl });
  });
  app.post("/api/settings/google-sheet", async (req, res) => {
    const { url } = req.body;
    googleSheetUrl = url || "";
    if (isFirebaseReady && db) {
      try {
        await db.collection("settings").doc("google_sheet").set({ url: googleSheetUrl });
        console.log("\u{1F331} [Backend] Successfully saved Google Sheet URL to Firestore settings.");
      } catch (err) {
        console.error("Firestore settings save error:", err);
      }
    }
    if (googleSheetUrl) {
      await fetchAndSyncGoogleSheet(googleSheetUrl);
    }
    res.json({ success: true, url: googleSheetUrl, ipaRecords });
  });
  app.get("/api/backups/status", async (req, res) => {
    try {
      if (!isFirebaseReady || !db) {
        return res.json({
          success: true,
          mode: "simulation",
          message: "Firebase operating in local simulation mode.",
          metadata: {
            lastSnapshotDate: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
            lastSnapshotTime: (/* @__PURE__ */ new Date()).toISOString(),
            lastSnapshotLogsCount: portfolioLogs.length,
            status: "completed"
          },
          history: [
            {
              snapshotDate: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
              timestamp: (/* @__PURE__ */ new Date()).toISOString(),
              logsCount: portfolioLogs.length,
              status: "success",
              type: "daily_snapshot",
              isSimulation: true
            }
          ]
        });
      }
      const metaDoc = await db.collection("dashboardStats").doc("backup_metadata").get();
      const metadata = metaDoc.exists ? metaDoc.data() : null;
      const backupsSnap = await db.collection("backups").get();
      const summaries = backupsSnap.docs.map((doc) => doc.data()).filter((d) => d && d.type === "daily_snapshot").sort((a, b) => {
        const dateA = a.snapshotDate || "";
        const dateB = b.snapshotDate || "";
        return dateB.localeCompare(dateA);
      });
      res.json({
        success: true,
        mode: "live",
        metadata,
        history: summaries
      });
    } catch (error) {
      console.error("\u274C [Backup API] Error retrieving backup status:", error);
      console.warn("\u26A0\uFE0F [Backup API] Disabling active Firestore connection flag and falling back to in-memory simulation state.");
      isFirebaseReady = false;
      return res.json({
        success: true,
        mode: "simulation",
        message: "Firebase operating in local simulation mode (Dynamic Fallback).",
        metadata: {
          lastSnapshotDate: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
          lastSnapshotTime: (/* @__PURE__ */ new Date()).toISOString(),
          lastSnapshotLogsCount: portfolioLogs.length,
          status: "completed"
        },
        history: [
          {
            snapshotDate: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
            timestamp: (/* @__PURE__ */ new Date()).toISOString(),
            logsCount: portfolioLogs.length,
            status: "success",
            type: "daily_snapshot",
            isSimulation: true
          }
        ]
      });
    }
  });
  app.post("/api/backups/snapshot", async (req, res) => {
    try {
      const result = await executeDailySnapshot();
      res.json(result);
    } catch (error) {
      console.error("\u274C [Backup API] Manual snapshot trigger failed:", error);
      res.status(500).json({ success: false, error: error.message });
    }
  });
  app.post("/api/reset", async (req, res) => {
    console.log("\u{1F504} Resetting database collections back to pristine seed data...");
    reconciliationRecords = [...mockReconciliationRecords];
    ipaRecords = [...mockIPARecords];
    teamPerformance = [...mockTeamPerformance];
    amAlerts = [...mockAMAlerts];
    portfolioLogs = [...mockPortfolioLogs];
    productionTrend = [...mockProductionTrend];
    invoices = [...mockInvoices];
    serverNotifications = [...mockNotifications];
    if (isFirebaseReady && db) {
      try {
        const batch2 = db.batch();
        for (const rec of mockIPARecords) {
          batch2.set(db.collection("analysts").doc(rec.id), rec);
        }
        await batch2.commit();
        const batch3 = db.batch();
        for (const rec of mockTeamPerformance) {
          const docId = rec.teamName.replace(/[\/\s]+/g, "_");
          batch3.set(db.collection("teams").doc(docId), rec);
        }
        await batch3.commit();
        const batch4 = db.batch();
        for (const rec of mockPortfolioLogs) {
          batch4.set(db.collection("logs").doc(rec.id), rec);
        }
        await batch4.commit();
        const batch5 = db.batch();
        batch5.set(db.collection("dashboardStats").doc("reconciliation_records"), { records: mockReconciliationRecords });
        batch5.set(db.collection("dashboardStats").doc("production_trend"), { trend: mockProductionTrend });
        batch5.set(db.collection("dashboardStats").doc("am_alerts"), { alerts: mockAMAlerts });
        await batch5.commit();
        const batch6 = db.batch();
        for (const rec of mockInvoices) {
          batch6.set(db.collection("invoices").doc(rec.id), rec);
        }
        await batch6.commit();
        const batch7 = db.batch();
        for (const rec of mockNotifications) {
          batch7.set(db.collection("notifications").doc(rec.id), rec);
        }
        await batch7.commit();
        console.log("\u{1F525} [Backend] Firestore reset done successfully using clean custom collections!");
      } catch (err) {
        console.error("Firestore reset database error:", err);
      }
    }
    broadcast({
      type: "FULL_STATE",
      payload: {
        reconciliationRecords,
        ipaRecords,
        teamPerformance,
        amAlerts,
        portfolioLogs,
        productionTrend
      }
    });
    res.json({ success: true });
  });
  const server = (0, import_http.createServer)(app);
  const wss = new import_ws.WebSocketServer({ noServer: true });
  server.on("upgrade", (request, socket, head) => {
    try {
      const host = request.headers.host || "localhost";
      const parsedUrl = new URL(request.url || "", `http://${host}`);
      const pathname = parsedUrl.pathname;
      if (pathname === "/ws") {
        wss.handleUpgrade(request, socket, head, (ws) => {
          wss.emit("connection", ws, request);
        });
      }
    } catch (err) {
      console.error("\u274C Error during WebSocket upgrade:", err);
      socket.destroy();
    }
  });
  const activeClients = /* @__PURE__ */ new Set();
  wss.on("connection", (ws) => {
    activeClients.add(ws);
    ws.send(JSON.stringify({
      type: "FULL_STATE",
      payload: {
        reconciliationRecords,
        ipaRecords,
        teamPerformance,
        amAlerts,
        portfolioLogs,
        productionTrend
      }
    }));
    ws.on("message", async (messageData) => {
      try {
        const message = JSON.parse(messageData.toString());
        switch (message.type) {
          case "UPDATE_RECORD": {
            const updated = message.payload;
            reconciliationRecords = reconciliationRecords.map(
              (rec) => rec.id === updated.id ? updated : rec
            );
            if (isFirebaseReady && db) {
              db.collection("dashboardStats").doc("reconciliation_records").set({ records: reconciliationRecords }).catch(
                (err) => console.error("WS record update Firestore error:", err)
              );
            }
            broadcast({ type: "RECORDS_UPDATE", payload: reconciliationRecords }, ws);
            break;
          }
          case "CREATE_LOG": {
            const newLog = message.payload;
            portfolioLogs = [newLog, ...portfolioLogs];
            if (isFirebaseReady && db) {
              db.collection("logs").doc(newLog.id).set(newLog).catch(
                (err) => console.error("WS create log Firestore error:", err)
              );
            }
            broadcast({ type: "LOGS_UPDATE", payload: portfolioLogs }, ws);
            break;
          }
          case "UPDATE_ALERT": {
            const updatedAlert = message.payload;
            amAlerts = amAlerts.map(
              (alert) => alert.id === updatedAlert.id ? updatedAlert : alert
            );
            if (isFirebaseReady && db) {
              db.collection("dashboardStats").doc("am_alerts").set({ alerts: amAlerts }).catch(
                (err) => console.error("WS update alert Firestore error:", err)
              );
            }
            broadcast({ type: "ALERTS_UPDATE", payload: amAlerts }, ws);
            break;
          }
          case "UPDATE_IPA_RECORDS": {
            const updatedList = message.payload;
            ipaRecords = updatedList;
            if (isFirebaseReady && db) {
              try {
                const batch = db.batch();
                for (const rec of updatedList) {
                  batch.set(db.collection("analysts").doc(rec.id), rec);
                }
                await batch.commit();
                console.log(`\u{1F331} [Backend-WS] Successfully saved ${updatedList.length} uploaded IPA records to Firestore.`);
              } catch (err) {
                console.error("WS ipa update Firestore error:", err);
              }
            }
            broadcast({ type: "IPA_RECORDS_UPDATE", payload: ipaRecords }, ws);
            break;
          }
          case "REQUEST_STATE": {
            ws.send(JSON.stringify({
              type: "FULL_STATE",
              payload: {
                reconciliationRecords,
                ipaRecords,
                teamPerformance,
                amAlerts,
                portfolioLogs,
                productionTrend
              }
            }));
            break;
          }
        }
      } catch (err) {
        console.error("Error processing websocket message:", err);
      }
    });
    ws.on("close", () => {
      activeClients.delete(ws);
    });
  });
  function broadcast(data, excludeWs) {
    const rawMessage = JSON.stringify(data);
    for (const client of activeClients) {
      if (client !== excludeWs && client.readyState === import_ws.WebSocket.OPEN) {
        client.send(rawMessage);
      }
    }
  }
  broadcastRef = broadcast;
  setInterval(() => {
    if (googleSheetUrl) {
      console.log("\u23F0 [Google Sheets Auto-Sync] Checking for changes...");
      fetchAndSyncGoogleSheet(googleSheetUrl);
    }
  }, 15e3);
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  server.listen(PORT, "0.0.0.0", () => {
    console.log(`\u{1F680} Server running on http://0.0.0.0:${PORT}`);
    loadAndSeedDatabase().then(() => {
      console.log("\u{1F331} [Backend] Background database sync/seeding complete.");
      startBackupScheduler();
    }).catch((error) => {
      console.error("\u274C [Backend] Error during background database sync/seeding:", error);
    });
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
