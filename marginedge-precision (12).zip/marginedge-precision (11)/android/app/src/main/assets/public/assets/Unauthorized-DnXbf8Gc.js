import{j as e}from"./index-DiTEj3sx.js";import{a as s}from"./icons-vendor-COUAS0is.js";import"./recharts-vendor-DX70NmlB.js";function D({userPosition:a,attemptedView:O,allowedViews:l,onNavigate:i,onLogout:_}){const[o,d]=s.useState(!1),[r,E]=s.useState("json"),[c,m]=s.useState(!1),A=t=>t.replace(/_/g," ").toLowerCase().replace(/\b\w/g,R=>R.toUpperCase()),x={Admin:{desc:"Master operator with full system-wide configuration, audit database access, quality scoring overview, integrations control, and analytical dashboards.",target:"Full Platform Access",color:"from-purple-500 to-indigo-600"},AM:{desc:"Account & Portfolio Manager overseeing invoice pipelines, vendor reconciliations, gmail communications, and area operations. Restricted from analyst scorecard dashboard.",target:"Operations & Comms Access",color:"from-blue-500 to-cyan-600"},"Team Lead":{desc:"Supervisor managing Chandigarh / Dhaka / Havanna hub analyst operations, scorecards, SLA targets, error monitoring, and training metrics. Restricted from direct client Gmail integrations and financial portfolios.",target:"SLA & Team Performance Access",color:"from-teal-500 to-emerald-600"},Analyst:{desc:"Task specialist focused on processing line-item matching, food supply invoice verification, error correction, and manual sheet logging.",target:"Execution level Access",color:"from-slate-500 to-slate-700"}},n=x[a]||x.Analyst,u={Admin:["LIVE_SYNC_DASHBOARD","PRECISION_OPS_DASHBOARD","DETAILED_PORTFOLIO_LOGS","GMAIL_DASHBOARD","ANALYST_QUALITY_DASHBOARD","EXCEL_PARSER_UTILITY","GOOGLE_CHAT_DASHBOARD","PRESENTATION_DECK"],AM:["LIVE_SYNC_DASHBOARD","PRECISION_OPS_DASHBOARD","DETAILED_PORTFOLIO_LOGS","GMAIL_DASHBOARD","EXCEL_PARSER_UTILITY","GOOGLE_CHAT_DASHBOARD","PRESENTATION_DECK"],"Team Lead":["LIVE_SYNC_DASHBOARD","DETAILED_PORTFOLIO_LOGS","ANALYST_QUALITY_DASHBOARD","EXCEL_PARSER_UTILITY","GOOGLE_CHAT_DASHBOARD","PRESENTATION_DECK"],Analyst:["LIVE_SYNC_DASHBOARD","DETAILED_PORTFOLIO_LOGS","EXCEL_PARSER_UTILITY","GOOGLE_CHAT_DASHBOARD"]},p=s.useMemo(()=>r==="json"?JSON.stringify({system:"MarginEdge Precision Ops",authModel:"Role Based Access Control (RBAC)",roles:["Admin","AM","Team Lead","Analyst"],restrictions:{PRECISION_OPS_DASHBOARD:["Admin","AM"],GMAIL_DASHBOARD:["Admin","AM"],ANALYST_QUALITY_DASHBOARD:["Admin","Team Lead"],PRESENTATION_DECK:["Admin","AM","Team Lead"],EXCEL_PARSER_UTILITY:["Admin","AM","Team Lead","Analyst"],GOOGLE_CHAT_DASHBOARD:["Admin","AM","Team Lead","Analyst"],LIVE_SYNC_DASHBOARD:["Admin","AM","Team Lead","Analyst"],DETAILED_PORTFOLIO_LOGS:["Admin","AM","Team Lead","Analyst"]},permissionsSchema:u},null,2):r==="sql"?`-- PostgreSQL Schema for MarginEdge Role Based Access Control (RBAC)
-- Generated: ${new Date().toLocaleString()}

-- Create roles enum
CREATE TYPE user_role AS ENUM ('Admin', 'AM', 'Team Lead', 'Analyst');

-- Create system modules table
CREATE TABLE IF NOT EXISTS platform_modules (
  module_id VARCHAR(100) PRIMARY KEY,
  module_name VARCHAR(150) NOT NULL,
  description TEXT
);

-- Create module permissions table
CREATE TABLE IF NOT EXISTS module_access_control (
  module_id VARCHAR(100) REFERENCES platform_modules(module_id) ON DELETE CASCADE,
  role_name user_role NOT NULL,
  is_permitted BOOLEAN DEFAULT TRUE,
  PRIMARY KEY (module_id, role_name)
);

-- Seed platform modules
INSERT INTO platform_modules (module_id, module_name, description) VALUES
('LIVE_SYNC_DASHBOARD', 'Real-Time Operational Log Sync', 'Live streaming of task updates'),
('PRECISION_OPS_DASHBOARD', 'Invoice Manager Operations', 'AM client portfolios and verification'),
('DETAILED_PORTFOLIO_LOGS', 'Detailed Auditor Ledger', 'Comprehensive operations audit ledger'),
('GMAIL_DASHBOARD', 'Client Gmail Automation Pipeline', 'Access to email synchronization'),
('ANALYST_QUALITY_DASHBOARD', 'Analyst Performance Scorecard', 'Quality ranking, points, and scorecards'),
('EXCEL_PARSER_UTILITY', 'Dynamic Excel Parser & Sync', 'Spreadsheet importing and sync'),
('GOOGLE_CHAT_DASHBOARD', 'Operational GChat Client', 'Real-time alert coordination'),
('PRESENTATION_DECK', 'Operational Overview Briefing', 'Briefing decks and slides')
ON CONFLICT (module_id) DO NOTHING;

-- Seed Access Control Rules
-- ADMIN FULL ACCESS
INSERT INTO module_access_control (module_id, role_name) VALUES
('LIVE_SYNC_DASHBOARD', 'Admin'), ('PRECISION_OPS_DASHBOARD', 'Admin'),
('DETAILED_PORTFOLIO_LOGS', 'Admin'), ('GMAIL_DASHBOARD', 'Admin'),
('ANALYST_QUALITY_DASHBOARD', 'Admin'), ('EXCEL_PARSER_UTILITY', 'Admin'),
('GOOGLE_CHAT_DASHBOARD', 'Admin'), ('PRESENTATION_DECK', 'Admin')
ON CONFLICT DO NOTHING;

-- AM ACCESS RULES
INSERT INTO module_access_control (module_id, role_name) VALUES
('LIVE_SYNC_DASHBOARD', 'AM'), ('PRECISION_OPS_DASHBOARD', 'AM'),
('DETAILED_PORTFOLIO_LOGS', 'AM'), ('GMAIL_DASHBOARD', 'AM'),
('EXCEL_PARSER_UTILITY', 'AM'), ('GOOGLE_CHAT_DASHBOARD', 'AM'),
('PRESENTATION_DECK', 'AM')
ON CONFLICT DO NOTHING;

-- TEAM LEAD ACCESS RULES
INSERT INTO module_access_control (module_id, role_name) VALUES
('LIVE_SYNC_DASHBOARD', 'Team Lead'), ('DETAILED_PORTFOLIO_LOGS', 'Team Lead'),
('ANALYST_QUALITY_DASHBOARD', 'Team Lead'), ('EXCEL_PARSER_UTILITY', 'Team Lead'),
('GOOGLE_CHAT_DASHBOARD', 'Team Lead'), ('PRESENTATION_DECK', 'Team Lead')
ON CONFLICT DO NOTHING;

-- ANALYST ACCESS RULES
INSERT INTO module_access_control (module_id, role_name) VALUES
('LIVE_SYNC_DASHBOARD', 'Analyst'), ('DETAILED_PORTFOLIO_LOGS', 'Analyst'),
('EXCEL_PARSER_UTILITY', 'Analyst'), ('GOOGLE_CHAT_DASHBOARD', 'Analyst')
ON CONFLICT DO NOTHING;`:r==="typescript"?`/**
 * TypeScript Typings and Static Configuration for RBAC
 * System: MarginEdge Precision Ops
 */

export type PlatformRole = 'Admin' | 'AM' | 'Team Lead' | 'Analyst';

export type PlatformModule =
  | 'LIVE_SYNC_DASHBOARD'
  | 'PRECISION_OPS_DASHBOARD'
  | 'DETAILED_PORTFOLIO_LOGS'
  | 'GMAIL_DASHBOARD'
  | 'ANALYST_QUALITY_DASHBOARD'
  | 'EXCEL_PARSER_UTILITY'
  | 'GOOGLE_CHAT_DASHBOARD'
  | 'PRESENTATION_DECK';

export interface RBACRuleset {
  roles: PlatformRole[];
  modulePermissions: Record<PlatformRole, PlatformModule[]>;
}

export const MARGINEDGE_RBAC_RULES: RBACRuleset = {
  roles: ['Admin', 'AM', 'Team Lead', 'Analyst'],
  modulePermissions: ${JSON.stringify(u,null,2)}
};

export function hasPermission(role: PlatformRole, module: PlatformModule): boolean {
  const allowed = MARGINEDGE_RBAC_RULES.modulePermissions[role];
  return allowed ? allowed.includes(module) : false;
}`:r==="express_middleware"?`/**
 * Express.js Authorization Middleware for MarginEdge RBAC
 */
import { Request, Response, NextFunction } from 'express';

export type PlatformRole = 'Admin' | 'AM' | 'Team Lead' | 'Analyst';

export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    role: PlatformRole;
    name: string;
  };
}

// Map of module permissions
const MODULE_PERMISSIONS: Record<string, PlatformRole[]> = {
  'LIVE_SYNC_DASHBOARD': ['Admin', 'AM', 'Team Lead', 'Analyst'],
  'DETAILED_PORTFOLIO_LOGS': ['Admin', 'AM', 'Team Lead', 'Analyst'],
  'EXCEL_PARSER_UTILITY': ['Admin', 'AM', 'Team Lead', 'Analyst'],
  'GOOGLE_CHAT_DASHBOARD': ['Admin', 'AM', 'Team Lead', 'Analyst'],
  'PRECISION_OPS_DASHBOARD': ['Admin', 'AM'],
  'GMAIL_DASHBOARD': ['Admin', 'AM'],
  'ANALYST_QUALITY_DASHBOARD': ['Admin', 'Team Lead'],
  'PRESENTATION_DECK': ['Admin', 'AM', 'Team Lead']
};

/**
 * Express middleware to restrict route access based on role permissions
 */
export function requireModuleAccess(moduleKey: string) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const user = req.user;
      
      if (!user || !user.role) {
        return res.status(401).json({
          success: false,
          error: 'Unauthorized: No active credentials found'
        });
      }

      const allowedRoles = MODULE_PERMISSIONS[moduleKey];
      if (!allowedRoles) {
        return res.status(500).json({
          success: false,
          error: 'Configuration Error: Invalid system module requested'
        });
      }

      if (!allowedRoles.includes(user.role)) {
        return res.status(403).json({
          success: false,
          error: 'Access Restricted',
          details: \`Your active role '\${user.role}' lacks clearance for '\${moduleKey}'\`
        });
      }

      // User has required permission, proceed
      next();
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  };
}`:"",[r]),S=()=>{navigator.clipboard.writeText(p),m(!0),setTimeout(()=>m(!1),2e3)};return e.jsx("div",{className:"min-h-screen bg-[#f7f9ff] dark:bg-[#0b0e14] flex items-center justify-center font-sans p-4 md:p-6 transition-colors duration-300",children:e.jsxs("div",{className:"max-w-4xl w-full bg-white dark:bg-[#121620] border border-outline-variant/60 rounded-3xl shadow-2xl overflow-hidden relative",children:[e.jsx("div",{className:"absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-red-500 via-amber-500 to-red-600"}),e.jsxs("div",{className:"px-6 py-4 border-b border-outline-variant/50 flex items-center justify-between bg-surface-container-low/50",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse"}),e.jsx("span",{className:"text-[10px] font-black uppercase text-on-surface-variant tracking-wider",children:"Security Boundary Active"})]}),e.jsxs("button",{onClick:()=>d(!o),className:`px-3 py-1.5 rounded-lg text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer border ${o?"bg-emerald-600 text-white border-emerald-600 shadow-sm":"bg-surface-container text-emerald-600 border-emerald-500/20 hover:bg-emerald-50 dark:hover:bg-emerald-950/20"}`,title:"Toggle code-only authorization details view",children:[e.jsx("span",{className:"material-symbols-outlined text-sm",children:"code"}),e.jsx("span",{children:"Return Code Only"})]})]}),o?e.jsxs("div",{className:"p-6 md:p-8 bg-slate-950 text-slate-100 flex flex-col min-h-[450px]",children:[e.jsxs("div",{className:"flex flex-col sm:flex-row sm:items-center sm:justify-between pb-4 border-b border-slate-800 mb-4 gap-3",children:[e.jsxs("div",{children:[e.jsxs("h3",{className:"text-sm font-black text-white uppercase tracking-wider flex items-center gap-2",children:[e.jsx("span",{className:"material-symbols-outlined text-emerald-400",children:"admin_panel_settings"}),"RBAC Config Compiler"]}),e.jsx("p",{className:"text-[11px] text-slate-400 mt-1",children:"Export, debug, and implement the platform authorization blueprint directly."})]}),e.jsx("div",{className:"flex bg-slate-900 border border-slate-800 rounded-lg p-0.5 self-start sm:self-auto",children:[{id:"json",label:"JSON Model"},{id:"sql",label:"SQL Seed"},{id:"typescript",label:"TS Types"},{id:"express_middleware",label:"Express MW"}].map(t=>e.jsx("button",{onClick:()=>E(t.id),className:`px-2.5 py-1 text-[10px] font-black uppercase rounded transition-all cursor-pointer ${r===t.id?"bg-emerald-600 text-white shadow":"text-slate-400 hover:text-slate-100 hover:bg-slate-800"}`,children:t.label},t.id))})]}),e.jsxs("div",{className:"flex-1 bg-slate-900/40 border border-slate-900 rounded-2xl p-5 font-mono text-[11px] overflow-auto select-all relative min-h-[300px]",children:[e.jsx("pre",{className:"whitespace-pre leading-relaxed text-emerald-400",children:p}),e.jsxs("button",{onClick:S,className:"absolute top-4 right-4 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white px-3 py-2 rounded-xl border border-slate-700 transition-all flex items-center gap-1.5 cursor-pointer shadow-lg",title:"Copy Code to Clipboard",children:[e.jsx("span",{className:"material-symbols-outlined text-sm",children:c?"check_circle":"content_copy"}),e.jsx("span",{className:"text-[10px] font-bold",children:c?"Copied!":"Copy Code"})]})]}),e.jsxs("div",{className:"mt-4 pt-3 border-t border-slate-900 text-[10px] text-slate-500 font-mono flex items-center justify-between",children:[e.jsx("span",{children:"Security Access Level: Admin Control Plane"}),e.jsx("button",{onClick:()=>d(!1),className:"text-emerald-400 hover:underline cursor-pointer font-bold",children:"Return to standard message"})]})]}):e.jsxs("div",{className:"p-6 md:p-10 flex flex-col md:flex-row gap-8 items-stretch",children:[e.jsxs("div",{className:"flex-1 flex flex-col justify-between space-y-6",children:[e.jsxs("div",{className:"space-y-4",children:[e.jsx("div",{className:"w-16 h-16 bg-red-500/10 dark:bg-red-500/20 rounded-2xl flex items-center justify-center text-red-600 dark:text-red-400 border border-red-200/50 dark:border-red-500/30",children:e.jsx("span",{className:"material-symbols-outlined text-[32px] select-none",children:"gpp_maybe"})}),e.jsxs("div",{className:"space-y-2",children:[e.jsx("h2",{className:"text-2xl font-black tracking-tight text-slate-900 dark:text-white",children:"Access Restricted"}),e.jsxs("p",{className:"text-sm text-slate-500 dark:text-slate-400 leading-relaxed font-medium",children:["Your authenticated role as ",e.jsx("span",{className:"font-extrabold text-red-600 dark:text-red-400 px-1.5 py-0.5 bg-red-50 dark:bg-red-950/30 rounded border border-red-100 dark:border-red-950/50",children:a})," lacks clearance to enter the ",e.jsx("span",{className:"font-bold text-slate-800 dark:text-slate-200",children:A(O)})," module."]})]})]}),e.jsxs("div",{className:"bg-slate-50 dark:bg-[#161b29] border border-outline-variant/40 rounded-2xl p-4 space-y-2.5",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("div",{className:`w-2 h-2 rounded-full bg-gradient-to-r ${n.color}`}),e.jsxs("h4",{className:"text-[11px] font-black uppercase text-on-surface-variant tracking-wider",children:["Role Profile: ",a]})]}),e.jsx("p",{className:"text-xs text-slate-600 dark:text-slate-400 leading-relaxed font-medium",children:n.desc}),e.jsxs("div",{className:"text-[10px] text-primary font-bold bg-[#eff4ff] dark:bg-primary/10 px-2 py-0.5 rounded-md inline-block",children:["Scope: ",n.target]})]}),e.jsxs("div",{className:"flex flex-col sm:flex-row items-center gap-3 pt-2",children:[e.jsxs("button",{onClick:()=>{const t=l[0]||"LIVE_SYNC_DASHBOARD";i(t)},className:"w-full sm:w-auto flex-1 bg-primary text-on-primary py-3 px-6 rounded-xl font-bold text-xs hover:opacity-95 active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md hover:shadow-lg hover:shadow-primary/15",children:[e.jsx("span",{className:"material-symbols-outlined text-sm",children:"home"}),"Go to Authorized Home"]}),e.jsxs("button",{onClick:_,className:"w-full sm:w-auto flex-1 bg-slate-100 dark:bg-slate-800/40 text-slate-700 dark:text-slate-300 py-3 px-6 rounded-xl font-bold text-xs border border-slate-200/50 dark:border-slate-700/30 hover:bg-slate-200/50 dark:hover:bg-slate-800/80 active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2",children:[e.jsx("span",{className:"material-symbols-outlined text-sm",children:"logout"}),"Sign Out"]})]})]}),e.jsxs("div",{className:"w-full md:w-[320px] border-t md:border-t-0 md:border-l border-outline-variant/60 pt-6 md:pt-0 md:pl-8 flex flex-col justify-between",children:[e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"flex items-center gap-2 text-slate-700 dark:text-slate-300 font-extrabold text-xs uppercase tracking-wider",children:[e.jsx("span",{className:"material-symbols-outlined text-sm text-slate-400",children:"lock_open"}),"Your Authorized Modules (",l.length,")"]}),e.jsx("div",{className:"space-y-2 max-h-[250px] overflow-y-auto pr-1",children:l.map(t=>e.jsxs("button",{onClick:()=>i(t),className:"w-full flex items-center gap-3 px-3.5 py-3 rounded-xl border border-slate-200/60 dark:border-slate-800/50 bg-white dark:bg-[#11141e] text-slate-700 dark:text-slate-300 hover:border-primary/50 dark:hover:border-primary/50 hover:bg-slate-100/50 dark:hover:bg-[#1a202e] hover:text-primary dark:hover:text-primary-light text-left transition-all duration-200 cursor-pointer group text-xs font-semibold",children:[e.jsxs("span",{className:"material-symbols-outlined text-lg text-slate-400 group-hover:text-primary transition-colors",children:[t==="LIVE_SYNC_DASHBOARD"&&"sync",t==="PRECISION_OPS_DASHBOARD"&&"dashboard",t==="DETAILED_PORTFOLIO_LOGS"&&"analytics",t==="GMAIL_DASHBOARD"&&"mail",t==="ANALYST_QUALITY_DASHBOARD"&&"reward",t==="EXCEL_PARSER_UTILITY"&&"grid_on",t==="GOOGLE_CHAT_DASHBOARD"&&"forum",t==="PRESENTATION_DECK"&&"slideshow"]}),e.jsx("span",{className:"truncate",children:A(t)})]},t))})]}),e.jsx("div",{className:"pt-4 border-t border-outline-variant/40 mt-4 text-[10px] text-on-surface-variant font-medium opacity-75",children:e.jsx("p",{className:"leading-relaxed",children:"Need access to other components? Contact the system administrator to request higher credential elevation."})})]})]}),e.jsxs("div",{className:"px-6 py-3 border-t border-outline-variant/50 bg-surface-container flex items-center justify-between text-[9px] font-bold text-on-surface-variant",children:[e.jsx("span",{children:"Confidential • Internal MarginEdge Operational Security Boundary"}),e.jsx("span",{children:"Access Level: Verified"})]})]})})}export{D as default};
