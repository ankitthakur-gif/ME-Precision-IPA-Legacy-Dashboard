package com.company.marginedgeprecision;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
